/********************************************************************************[Statistics-mt.cc]
Copyright (c) 2012, Norbert Manthey, LGPL v2, see LICENSE
**************************************************************************************************/

#include "riss/utils/Statistics-mt.h"

// global accessable statistics object

Statistics statistics;
