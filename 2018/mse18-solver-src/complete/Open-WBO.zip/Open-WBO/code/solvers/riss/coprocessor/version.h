#ifndef RISS_Coprocessor_version_h
#define RISS_Coprocessor_version_h

namespace Coprocessor
{

extern const char* gitSHA1;
extern const char* gitDate;
extern const char* coprocessorVersion;
extern const char* signature;

}

#endif
