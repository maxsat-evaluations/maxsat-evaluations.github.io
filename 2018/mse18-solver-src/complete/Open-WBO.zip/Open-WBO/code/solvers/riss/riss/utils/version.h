#ifndef Riss_version_h
#define Riss_version_h

namespace Riss
{

extern const char* gitSHA1;
extern const char* gitDate;
extern const char* solverVersion;
extern const char* signature;

}

#endif