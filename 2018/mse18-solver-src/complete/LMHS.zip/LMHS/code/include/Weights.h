#pragma once

#define EPS 1e-7

#include "stdint.h"
#include "inttypes.h"

typedef uint64_t weight_t;

#define WEIGHT_MAX INT64_MAX
#define WGT_FMT PRId64
