#include <iostream>
#include <fstream>
#include <algorithm>
#include <functional>
#include <thread>
#include <cstdio>
#include <cstdlib>
#include <errno.h>
#include <math.h>  // ceil
#include <assert.h>

#include "Solver.h"
#include "Util.h"
#include "NonoptHS.h"

#include "Timer.h"
#include "MinisatSolver.h"
#include "CPLEXSolver.h"

using namespace std;

Solver::Solver(ProblemInstance &pi, ostream& out)
    : cfg(GlobalConfig::get()),
      instance(pi),
      newInstance(true),
      nSolutions(0),
      nNonoptCores(0),
      nLearntEquivs(0),
      nEquivConstraints(0),
      nDisjointCores(0),
      out(out)
{

  if (!cfg.initialized) {
    ofstream nullstream("/dev/null");
    cfg.parseArgs(0, nullptr, nullstream);
  }

  instance.attach(new CPLEXSolver());
  if (!cfg.solveAsMIP) {
    instance.attach(new MinisatSolver());
    if (cfg.separate_muser) {
      instance.attachMuser(new MinisatSolver());
    }
  }
}

void Solver::solve() {
  log(3, "c Solver::solve\n");

  instance.solve_timer.start();

  weight_t weight = -1;

  //instance.printStats();

  if (!cfg.solveAsMIP && !hardClausesSatisfiable()) {
    //log(0, "s UNSATISFIABLE\n");
    //fflush(stdout);
    return;
  }

  if (cfg.solveAsMIP) {
    solveAsMIP();
  }

  else if (cfg.doEnumeration) {
    weight_t optWeight = 0;
    bool optFound = false;

    weight_t init_UB = 0;
    for (auto & b_w : instance.bvar_weights)
      init_UB += b_w.second;

    do {
      solveMaxHS();
      weight = instance.UB;
      if (instance.UB_solution.empty()) break;

      if (cfg.enumerationType < 0)
        instance.forbidCurrentMIPSol();
      instance.forbidCurrentModel();

      if (!optFound) {
        optWeight = instance.UB;
        optFound = true;
      } else if (abs(cfg.enumerationType) == 1 && (weight - optWeight) > EPS) {
        break;
      }

      // reset upper bound
      instance.UB = init_UB;

      ++nSolutions;
      instance.printSolution(cout);

    } while (nSolutions < cfg.enumerationLimit);
  } else {
    solveMaxHS();
    assert(instance.LB == instance.UB);
    ++nSolutions;
  }
}

// check that a maxsat solution exists
bool Solver::hardClausesSatisfiable() {

  instance.sat_solver->setBvars();
  instance.sat_solver->clearAssumptions();
  instance.sat_solver->assumeBvars();
  if (!instance.sat_solver->solve()) {
    log(1, "c hard clauses unsatisfiable\n");
    return false;
  } else {

    log(1, "c hard clauses satisfiable\n");
    instance.updateUB(instance.getSolutionWeight(instance.sat_solver));
    return true;
  }
}

void Solver::presolve() {
  log(3, "c Solver::presolve\n");

  if (cfg.doDisjointPhase) {
    findDisjointCores();
  }

  // seed MIP solver with "equiv-constraints"

  if (cfg.doEquivSeed) {

    instance.getBvarEquivConstraints(equivConstraints);
    nEquivConstraints = equivConstraints.size();
    log(1, "c Seeding MIP solver with %u equiv constraints.\n", nEquivConstraints);
    for (auto & eq : equivConstraints) {

      if (cfg.eqCoreFix) {
        for (auto lit : eq) {
          if (lit < 0)
            goto noncore;
        }
      } else {
        goto noncore;
      }

      processCore(eq);
      continue;

      noncore:
      logCore(2, eq);
      instance.mip_solver->addConstraint(eq);
    }
  }

  newInstance = false;
}

void Solver::solveAsMIP() {
  log(3, "c Solver::solveAsMIP\n");
  weight_t weight;

  for (int i = 1; i <= instance.max_var; ++i)
    if (!instance.bvar_weights.count(i))
      instance.mip_solver->addVariable(i);

  instance.mip_solver->addObjectiveVariables(instance.bvar_weights);

  log(1, "c added MIP objective variables: %lu\n", instance.bvar_weights.size());
  log(1, "c added MIP variables: %lu\n", instance.max_var);
  for (auto cl : instance.clauses)
    instance.mip_solver->addConstraint(*cl);

  log(1, "c added MIP constraints: %lu\n", instance.clauses.size());
  bool ok = instance.mip_solver->solveForModel(instance.UB_solution, weight);
  condTerminate(!ok, 1, "c Solver::solveAsMIP : no MIP solution\n");
  //instance.updateUB(weight);
  instance.UB = weight;
  instance.LB = weight;
}

//
// Find a solution to the MAXSAT instance
// solution retured by reference
// return value is solution weight
//
void Solver::solveMaxHS() {
  log(3, "c Solver::solveMaxHS\n");

  //vector<int> core;
  vector<vector<int>> new_cores;
  vector<int> hs;

  if (cfg.RC_maxsat_lp) {
    for (int i = 1; i <= instance.max_var; ++i)
      if (!instance.bvar_weights.count(i))
        instance.mip_solver->addVariable(i, false);
    /*
        sort(instance.clauses.begin(), instance.clauses.end(), [](auto a, auto b){ return a->size() < b->size(); });
    /*
        for (auto cl : instance.clauses)
          cout << cl->size() << " ";
        cout << endl;
    */
    unsigned count = 0;
    for (auto cl : instance.clauses) {

      instance.mip_solver->addConstraint(*cl, 1, CPLEXSolver::Comparator::GTE, true);

      if (count++ > cfg.RC_maxsat_lp_limit)
        break;
    }
  }


  if (cfg.stratification) {

    vector<pair<weight_t, int>> weight_bvars;
    for (auto b_w : instance.bvar_weights) {
      weight_bvars.push_back({b_w.second, b_w.first});
    }

    sort(weight_bvars.begin(), weight_bvars.end());

    weight_t cumulative_weight = 0;

    unsigned level_count = 0;

    vector<pair<weight_t, int>> this_level;


    for (auto w_b : weight_bvars) {
      weight_t w = w_b.first;
      //int bvar = w_b.second;

      if (cumulative_weight > std::numeric_limits<weight_t>::max() - w) {
        out << "c cumulative weight overflows weight type max" << endl;
        level_count = 0;
        current_level = 0;
        cfg.stratification = false;
        break;
      }

      cumulative_weight += w;

      if (w > cumulative_weight - w && cumulative_weight - w > 0) {
        level_count += 1;
        levels.push_back(this_level);
        this_level = {w_b};
      } else {
        this_level.push_back(w_b);
      }
    }

    if (this_level.size()) {
      levels.push_back(this_level);
      level_count += 1;
    }

    out << "c weight levels " << level_count << endl;
    for (unsigned i = 0 ; i < levels.size() ; ++i) {
      out << "c level " << i << " (size " << levels[i].size() << "): ";
      out << levels[i][0].first << " .. " << levels[i][levels[i].size() - 1].first << endl;
    }

    current_level = levels.size() - 1;
  } else {
    current_level = 0;
  }

  // For the first run on an instance, perform initial
  // steps of finding disjoint cores and seeding MIP
  // solver with equiv constraints

  if (newInstance) presolve();

  if (cfg.small_IP && instance.clauses.size() < cfg.small_IP_limit) {

    //
    log(3, "c Solver::solveAsMIP\n");
    weight_t weight;

    for (int i = 1; i <= instance.max_var; ++i)
      if (!instance.bvar_weights.count(i))
        instance.mip_solver->addVariable(i);

    log(1, "c added MIP variables: %lu\n", instance.max_var);

    for (auto cl : instance.clauses)
      instance.mip_solver->addConstraint(*cl);

    log(1, "c added MIP constraints: %lu\n", instance.clauses.size());

    bool ok = instance.mip_solver->solveForModel(instance.UB_solution, weight);
    condTerminate(!ok, 1, "c Solver::solveAsMIP : no MIP solution\n");
    //instance.updateUB(weight);
    instance.UB = weight;
    instance.LB = weight;
    return;
  }


  // level loop
  while (true) {

    // main MaxHS loop
    for (unsigned iteration = 0;;++iteration) {

      hs.clear();

      // find minimum cost hitting set
      weight_t opt_lb;
      CPLEXSolver::Status status = instance.mip_solver->solveForHS(hs, opt_lb, &instance);

      while (!instance.fixQueue.empty()) {
        int fixed = instance.fixQueue.back();
        instance.fixQueue.pop_back();

        coreClauseCounts.erase(fixed);

        for (auto & core : cores) {
          core.erase(std::remove(core.begin(), core.end(), fixed), core.end());
          if (core.size() == 0)
            terminate(1, "Empty core in core set pruning");
        }
      }

      while (!instance.relaxQueue.empty()) {
        int relaxed = instance.relaxQueue.back();
        instance.relaxQueue.pop_back();

        for (auto & core : cores) {
          if (std::find(core.begin(), core.end(), relaxed) != core.end()) {
            for (int l : core) {
              coreClauseCounts[l]--;
            }
          }
        }

        cores.erase(std::remove_if(cores.begin(), cores.end(), [&](vector<int> & x){
            return std::find(x.begin(), x.end(), relaxed) != x.end();
          }), cores.end());
      }

      if (status == CPLEXSolver::Status::Failed) { // no MIP solution
        instance.UB_solution.clear();
        log(1, "c empty hitting set\n");
        break;
      } else if (cfg.printHittingSets & PRINT_OPT_HS) {
        out << "c opt hs " << hs << endl;
      }

      log(1, "c CPLEX opt %" WGT_FMT "\n", opt_lb);

      if (status == CPLEXSolver::Status::Optimal) {
        instance.updateLB(opt_lb);
        if (instance.UB == instance.LB) {
          log(1, "c solved by LB == UB\n");
          goto maxhs_stop;
        }
      }

      getCores(hs, new_cores);

      // satisfiable with current assumptions -> found an optimal solution
      if (new_cores.empty()) {
        if (status == CPLEXSolver::Status::Optimal) {
          if (current_level == 0)
            instance.updateLB(instance.UB);
          break;
        } else {
          if (instance.UB == instance.LB) {
            log(1, "c solved by LB == UB\n");
            goto maxhs_stop;
          }
        }
      }

      // reduce MIP solver calls by trying to find cores with non-optimal hitting
      // sets
      int nonOpts = 0;
      if (cfg.lpNonOpt) {
        nonopt_timer.start();
        while (true) {
          weight_t lb;
          instance.mip_solver->LPsolveHS(hs, lb);
          if (cfg.printHittingSets & PRINT_NONOPT_HS) {
            out << "c nonopt (lp) hs " << hs << endl;
          }
          instance.updateLB(lb);

          if (!getCores(hs, new_cores)) {
            if (instance.UB == instance.LB) {
              log(1, "c solved by LB == UB\n");
              nonopt_timer.stop();
              goto maxhs_stop;
            }
            nonopt_timer.stop();
            break;
          }
          nNonoptCores += 1;
        }
      } else if (cfg.nonoptPrimary) {
        nonopt_timer.start();
        while (true) {
          while (true) {
            cfg.nonoptPrimary(hs, new_cores, cores, instance.bvar_weights, coreClauseCounts);
            if (cfg.printHittingSets & PRINT_NONOPT_HS) {
              out << "c nonopt (1) hs " << hs << endl;
            }

            // try to find a core using the non-optimal hitting set
            if (!getCores(hs, new_cores)) {
              if (instance.UB == instance.LB) {
                log(1, "c solved by LB == UB\n");
                nonopt_timer.stop();
                goto maxhs_stop;
              }
              break;
            }
            nNonoptCores += 1;
            nonOpts += 1;
            if (nonOpts >= cfg.nonoptLimit) goto nonopt_stop;
          }
          // second nonopt stage exists?
          if (not cfg.nonoptSecondary) break;
          cfg.nonoptSecondary(hs, new_cores, cores, instance.bvar_weights, coreClauseCounts);
          if (cfg.printHittingSets & PRINT_NONOPT_HS) {
            out << "c nonopt (2) hs " << hs << endl;
          }

          if (!getCores(hs, new_cores)) {
            if (instance.UB == instance.LB) {
              log(1, "c solved by LB == UB\n");
              nonopt_timer.stop();
              goto maxhs_stop;
            }
            break;
          }

          nNonoptCores += 1;
          nonOpts += 1;
          if (nonOpts >= cfg.nonoptLimit) goto nonopt_stop;
        }
      }
      nonopt_stop: nonopt_timer.stop();

      log(1, "c iteration %d: %d cores\n", iteration, nonOpts+1);
      continue;
    } // end main MaxHS loop

  maxhs_stop:
    if (current_level == 0) break;

    out << "c ### Level " << current_level << " optimized "
      << instance.LB << ".." << instance.UB << endl;

    // hs is optimal for this level
    for (auto w_b : levels[current_level]) {
      int bv = w_b.second;
      if (find(hs.begin(), hs.end(), bv) != hs.end()) {
        instance.mip_solver->forceVar(&instance, bv, true);
        //instance.forceBvar(bv, true);
      } else {
        //instance.forceBvar(bv, false);
      }
    }

    current_level--;
  }

  if (cfg.MIP_modelFile != "") {
    instance.mip_solver->exportModel(cfg.MIP_modelFile);
  }

  // write cores of hitting set instance to file
  if (cfg.coreFile != "") {
    ofstream out(cfg.coreFile);

    for (auto eq : equivConstraints) {
      out << "eq " << eq << endl;
    }

    for (auto core : cores) {
      out << "core " << core << endl;
    }

    out.close();
  }

  instance.solve_timer.stop();
}

void Solver::processCore(vector<int> &core) {
  static int processed = 0;
  ++ processed;
  condTerminate(core.empty(), 1, "Error: attempting to process empty core.\n");
  cores.push_back(core);

  if (cfg.printCores) {
    out << "c core " << core << endl;
  }

  instance.mip_solver->addConstraint(core);
  coreSizes.push_back(core.size());
  for (int b : core) {
    coreClauseCounts[b]++;
    assert(b > 0);
  }
}

//
// Print stats for MAXSAT solver and its SAT and MIP solver components
//
void Solver::printStats() {

  log(0, "c Solutions found: %d\n", nSolutions);
  if (cfg.solveAsMIP) return;
  log(0, "c Nonopt time:        %lu ms\n", nonopt_timer.cpu_ms_total());
  if (instance.mip_solver) instance.mip_solver->printStats();
  if (instance.sat_solver) instance.sat_solver->printStats("Minisat");
  if (instance.muser) instance.muser->printStats("Muser");
  instance.printStats();
  log(0, "c Cores:\n");
  log(0, "c   total cores:  %lu\n", coreSizes.size());
  condLog(cfg.doDisjointPhase, 0, "c   disjoints:    %d\n", nDisjointCores);
  condLog(cfg.nonoptPrimary != nullptr,        0, "c   from nonopt:  %d\n", nNonoptCores);
  condLog(cfg.doEquivSeed,     0, "c   eq-constr:    %d\n", nEquivConstraints);
  condLog(cfg.doLearntEquiv,   0, "c   learnt-eq:    %d\n", nLearntEquivs);

  unsigned totalSize = 0;
  for (unsigned s : coreSizes) totalSize += s;
  log(0, "c   total size: %d clauses\n", totalSize);
  log(0, "c   avg size:   %.2f clauses\n", totalSize == 0 ? 0 :
         ((double)totalSize) / ((double)coreSizes.size()));

  log(0, "c Time:\n");
  log(0, "c   disjoint phase     %lu ms\n", disjoint_timer.cpu_ms_total());
  log(0, "c   file parsing       %lu ms\n", instance.parse_timer.cpu_ms_total());

  cout.flush();
}


//
// Set the SAT instance assumptions so that the soft clauses
// indicated by hs are deactivated, and all other soft clauses
// are activated.
//
void Solver::setHSAssumptions(vector<int>& hs) {
  log(3, "c Solver::setHSAssumptions\n");
  if (cfg.stratification) {
    instance.sat_solver->unsetBvars();
    // activate all clauses on lower levels than current_level
    for (int level = 0; level < current_level; ++level) {
      for (auto w_b : levels[level]) {
        // bvar could have been hardened and removed
        if (instance.bvar_weights.count(w_b.second))
          instance.sat_solver->setBvar(w_b.second);
      }
    }
    // activate clauses in hs
    for (int c : hs) {
      instance.sat_solver->setBvar(c);
    }
    instance.sat_solver->clearAssumptions();
    instance.sat_solver->assumeBvars();
  } else {
    instance.sat_solver->unsetBvars();
    for (int c : hs)
      instance.sat_solver->setBvar(c);
    instance.sat_solver->clearAssumptions();
    instance.sat_solver->assumeBvars();
  }
}

// Get a core from the SAT solver
// using whatever assumptions have been set
// return false if instance is satisfiable
bool Solver::getCore(vector<int>& hs, vector<int>& core) {
  log(3, "c Solver::getCore\n");
  // todo: rewrite as probleminstance::getcore

  if (cfg.iterativeGetCore) {
    // this adds all cores! TODO: fix
    core.clear();
    vector<vector<int>> cores;
    iterativeGetCores(hs, cores);
    if (cores.empty()) return false;
    core = cores[0];
    return true;
  }

  setHSAssumptions(hs);

  instance.sat_solver->findCore(core);

  if (cfg.doLearntEquiv) {
    vector<vector<int>> new_constr;
    instance.getLearntEquivs(new_constr);

    for (auto & eq : new_constr) {
      ++nLearntEquivs;
      if (cfg.eqCoreFix) {
        for (auto lit : eq) {
          if (lit < 0)
            goto noncore;
        }
      } else {
        goto noncore;
      }

      processCore(eq);
      continue;

      noncore:
      logCore(2, eq);
      instance.mip_solver->addConstraint(eq);
    }

    instance.sat_solver->deleteLearnts();
  }

  if (core.empty()) {
    weight_t soln_weight = instance.getSolutionWeight(instance.sat_solver);
    log(2, "c getcore found soln w=%lu\n", soln_weight);
    return false;
  }
  log(3, "c Solver::getCore found core (size %lu)\n", core.size());

  if (cfg.doRerefuteCores) {
    instance.reduceCore(core, MinimizeAlgorithm::rerefute);
  }

  if (cfg.doMinimizeCores) {
    instance.reduceCore(core, cfg.minAlg);
  }

  processCore(core);

  if (cfg.doResetClauses) instance.sat_solver->deleteLearnts();
  if (cfg.doInvertActivity) instance.sat_solver->invertActivity();

  return true;
}

bool Solver::getCores(vector<int>& hs, vector<vector<int>>& cores) {
  log(3, "c Solver::getCores\n");

  // todo: rewrite as probleminstance::getcore

  if (cfg.iterativeGetCore) {
    return iterativeGetCores(hs, cores);
  }

  setHSAssumptions(hs);
  instance.sat_solver->findCores(cores);

  if (cfg.doLearntEquiv) {
    vector<vector<int>> new_constr;
    instance.getLearntEquivs(new_constr);

    for (auto & eq : new_constr) {
      ++nLearntEquivs;
      if (cfg.eqCoreFix) {
        for (auto lit : eq) {
          if (lit < 0)
            goto noncore;
        }
      } else {
        goto noncore;
      }

      processCore(eq);
      continue;

      noncore:
      logCore(2, eq);
      instance.mip_solver->addConstraint(eq);
    }

    instance.sat_solver->deleteLearnts();
  }

  if (cores.empty()) {
    instance.updateUB(instance.getSolutionWeight(instance.sat_solver));
    return false;
  }

  for (auto core : cores) {
    if (cfg.doRerefuteCores) {
      instance.reduceCore(core, MinimizeAlgorithm::rerefute);
    }

    if (cfg.doMinimizeCores) {
      instance.reduceCore(core, cfg.minAlg);
    }

    processCore(core);

    if (cfg.doResetClauses) instance.sat_solver->deleteLearnts();
    if (cfg.doInvertActivity) instance.sat_solver->invertActivity();
  }

  return true;
}

bool Solver::iterativeGetCores(vector<int>& hs, vector<vector<int>>& cores) {
  log(3, "c Solver::iterativeGetCores\n");
  vector<int> bVars;
  for (auto w_v : instance.bvar_weights) {
    if (std::find(hs.begin(), hs.end(), w_v.first) == hs.end())
      bVars.push_back(w_v.first);
  }

  unsigned long start_bvars = cfg.iterativeGetCore_start;
  unsigned all_bvars = bVars.size();

  random_shuffle(bVars.begin(), bVars.end());

  //assert(bVars.size() >= start_bvars);
  //printf("%u %u\n", start_bvars, bVars.size());
  start_bvars = min(start_bvars, bVars.size());
  //assert(start_bvars > 0);
  //assert(all_bvars > 0);

  vector<bool> lastModel;

  vector<int> sortedBvars(bVars);
  sort(sortedBvars.begin(), sortedBvars.end());

  unsigned partitions = cfg.iterativeGetCore_parts;
  unsigned increment = partitions ? all_bvars / partitions : 1;
  increment = max(increment, 1u);

  if (partitions) start_bvars = 1;

  for (unsigned i = start_bvars - 1; ; i += increment) {

    vector<int> relaxed_hs(hs);

    if (all_bvars) {
      if (increment == 1 and (lastModel.size() && instance.bVarSatisfied(lastModel, bVars[i]))) {
        // this bvar was already redundant in previous solution
        log(4, "c iterativeGetCore skip bVar %d (w %lu)\n", bVars[i], instance.bvar_weights[bVars[i]]);
        if (i == all_bvars - 1) return false;
        continue;
      } else {
        log(4, "c iterativeGetCore test bVar %d\n", bVars[i]);
      }
    }

    if (all_bvars)
      for (int j = all_bvars - 1; j >= int(i); --j)
        relaxed_hs.push_back(bVars[j]);

    setHSAssumptions(relaxed_hs);

    instance.sat_solver->findCores(cores);

    if (cores.empty()) {

      instance.sat_solver->getModel(lastModel);
      weight_t newBound = instance.tightenModel(lastModel);


      log(4, "c iterativeGetCore SAT (w = %d)\n", newBound);
      if (newBound < instance.UB) {
        log(1, "c iterativeGetCore improved UB %lu -> %lu\n", instance.UB, newBound);
        instance.updateUB(newBound);
      }

      if (i + 1 >= all_bvars) {// hs is not relaxed
        return false;
      } else { // relax hs less on next iteration
        continue;
      }
    }

    // else core found
    log(2, "c Core from relaxed hs (%u)\n", all_bvars - i + 1);
    break;
  }


  for (auto core: cores) {
    if (cfg.doRerefuteCores) {
      instance.reduceCore(core, MinimizeAlgorithm::rerefute);
    }

    if (cfg.doMinimizeCores) {
      instance.reduceCore(core, cfg.minAlg);
    }

    processCore(core);
  }

  if (cfg.doResetClauses) instance.sat_solver->deleteLearnts();
  if (cfg.doInvertActivity) instance.sat_solver->invertActivity();

  return true;
}

// finds initial set of disjoint cores
void Solver::findDisjointCores() {
  log(3, "c Solver::findDisjointCores\n");
  disjoint_timer.start();

  vector<int> disjoint_clauses;
  vector<int> core;
  weight_t cost = 0;

  if (cfg.jeremiasDisjoint) {
    // loop until a new core isn't found
    unordered_map<int, weight_t> dWeight;
    for (auto v_w : instance.bvar_weights)
      dWeight.insert(v_w);

    for (;;) {

      // break when no more disjoint cores
      if (!getCore(disjoint_clauses, core)) break;
      nDisjointCores += 1;

      // update dWeights
      weight_t min_w = numeric_limits<weight_t>::max();
      for (int b : core)
        if (dWeight[b] < min_w)
          min_w = dWeight[b];

      for (int b : core) {
        if (dWeight[b] <= min_w) {
          dWeight[b] = 0;
          disjoint_clauses.push_back(b);
        } else {
          dWeight[b] -= min_w;
        }
      }

      cost += min_w;
      instance.updateLB(cost);
    }
  } else {
    // loop until a new core isn't found
    for (;;) {

      // break when no more disjoint cores
      if (!getCore(disjoint_clauses, core)) break;
      nDisjointCores += 1;

      for (int b : core) disjoint_clauses.push_back(b);

      weight_t minCost = WEIGHT_MAX;
      for (int b : core)
        minCost = min(minCost, instance.bvar_weights[b]);
      cost += minCost;
      instance.updateLB(cost);
    }
  }

  cost = instance.getSolutionWeight(instance.sat_solver);
  instance.updateUB(cost);

  log(1, "c Found %ld disjoint cores\n", cores.size());
    //cores.size(), instance.sat_solver->coresMinimized);

  disjoint_timer.stop();
}