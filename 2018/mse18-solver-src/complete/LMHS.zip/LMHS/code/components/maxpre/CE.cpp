void Preprocessor::CBIGdfs1(int x, vector<int>& ns, vector<pair<int, pair<int, int> > >& condEdges) {
	queue<int> bfs;
	bfs.push(x);
	while (!bfs.empty()) {
		int v = bfs.front();
		bfs.pop();
		if (BIGu[v] == BIGIt) continue;
		BIGu[v] = BIGIt;
		ns.push_back(v);
		for (int c : pi.litClauses[negLit(v)]) {
			if (pi.clauses[c].lit.size() == 3) {
				int lab = -1;
				int v2 = -1;
				for (int lit : pi.clauses[c].lit) {
					if (pi.isLabel[litVariable(lit)]) lab = lit;
					else if(litVariable(lit) != v) v2 = lit;
				}
				if (lab == -1 || v2 == -1) continue;
				if (pi.litClauses[lab].size() != 2) continue;
				if (pi.clauses[pi.litClauses[lab][0]].lit.size() != 3) continue;
				if (pi.clauses[pi.litClauses[lab][1]].lit.size() != 3) continue;
				vector<int> t = {lab, posLit(v), litNegation(v2)};
				sort(t.begin(), t.end());
				if (pi.clauses[pi.litClauses[lab][0]].lit == t || pi.clauses[pi.litClauses[lab][1]].lit == t) {
					condEdges.push_back({litToDimacs(litNegation(lab)), {litToDimacs(posLit(v)), litToDimacs(v2)}});
					if (condEdges.back().S.F < 0) condEdges.pop_back();
					if (abs(condEdges.back().S.F) < abs(condEdges.back().S.S)) condEdges.pop_back();
					bfs.push(litVariable(v2));
				}
			}
		}
		for (int c : pi.litClauses[posLit(v)]) {
			if (pi.clauses[c].lit.size() == 3) {
				int lab = -1;
				int v2 = -1;
				for (int lit : pi.clauses[c].lit) {
					if (pi.isLabel[litVariable(lit)]) lab = lit;
					else if(litVariable(lit) != v) v2 = lit;
				}
				if (lab == -1 || v2 == -1) continue;
				if (pi.litClauses[lab].size() != 2) continue;
				if (pi.clauses[pi.litClauses[lab][0]].lit.size() != 3) continue;
				if (pi.clauses[pi.litClauses[lab][1]].lit.size() != 3) continue;
				vector<int> t = {lab, negLit(v), litNegation(v2)};
				sort(t.begin(), t.end());
				if (pi.clauses[pi.litClauses[lab][0]].lit == t || pi.clauses[pi.litClauses[lab][1]].lit == t) {
					condEdges.push_back({litToDimacs(litNegation(lab)), {litToDimacs(negLit(v)), litToDimacs(v2)}});
					if (condEdges.back().S.F < 0) condEdges.pop_back();
					if (abs(condEdges.back().S.F) < abs(condEdges.back().S.S)) condEdges.pop_back();
					bfs.push(litVariable(v2));
				}
			}
		}
	}
}

int Preprocessor::findConditionalGraph(int var, vector<pair<int, pair<int, int> > >& condEdges) {
	vector<int> cc;
	CBIGdfs1(var, cc, condEdges);
	return cc.size();
}

vector<pair<int, pair<int, int> > > Preprocessor::findConditionalComponents() {
	vector<pair<int, pair<int, int> > > condEdges;
	BIGIt++;
	if ((int)BIGu.size() < pi.vars) BIGu.resize(pi.vars);
	int maxC = 0;
	for (int var = 0; var < pi.vars; var++) {
		if (!pi.isLabel[var]) maxC = max(maxC, findConditionalGraph(var, condEdges));
	}
	return condEdges;
}