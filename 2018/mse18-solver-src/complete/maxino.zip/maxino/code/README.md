zuccherino
==========

A collection of solvers built on top of Glucose 4.1.


Build
=====

Just run one of the following commands:

$ make

$ make static

$ make lib


Binaries are created in the 'build' directory.
