This is Pacose a MaxSAT 2018 competition solver based on QMaxSAT, based on glucose 3.0.

To build the binary enter the folder "./code/" and run "make rs".



