
/********************************************************************************************
antom.h -- Copyright (c) 2014-2016, Sven Reimer

Permission is hereby granted, free of charge, to any person obtaining a copy of this 
software and associated documentation files (the "Software"), to deal in the Software 
without restriction, including without limitation the rights to use, copy, modify, merge, 
publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons 
to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING 
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
********************************************************************************************/

#ifndef ANTOM_ANTOM_H_
#define ANTOM_ANTOM_H_

// Include standard headers.
//#include "antombase.h"
#include "settings.h"
#include "core/Solver.h"
#include <vector> 


namespace antom
{

// Some definitions.
#define ANTOM_UNKNOWN                  0
#define ANTOM_SAT                     10
#define ANTOM_UNSAT                   20
#define ANTOM_UNSAT_WITH_ASSUMPTION   30
#define ANTOM_UNKNOWN_WITH_PRE_RESULT 40

enum SolverType
  {
	ANTOMSOLVER,
	CRYPTOMINISATSOLVER
  };

  class SoftClause;
  class Sorter;
  class Cascade;
  class MultipleCascade;
  struct TimeVariables;

  // The "MaxAntom" class.
  class Antom
  {
  public:

    // Constructor. 
    Antom(Glucose::Solver* glucose);
   
    // Destructor.
    ~Antom(void);

    // Glucose
    bool AddClause(Glucose::vec<Glucose::Lit>& clause);

    // Creates and returns a fresh variable index not used so far.
    uint32_t NewVariable(void);

    bool AddClause(std::vector<uint32_t>& clause, uint32_t lbd = 1);
    bool AddUnit(uint32_t lit);

    uint32_t Solve(void);
    uint32_t Solve(const std::vector<uint32_t>& assumptions);
    std::vector<uint32_t> Model(void) const;
    uint32_t Model(uint32_t var) const;

    uint32_t Variables(void) const; 
    // Returns the current number of clauses within the clause database. 
    uint32_t Clauses(void) const; 
    uint32_t StaticClauses(void) const;

    uint32_t CurrentBinaryClauses() const;
    uint32_t CurrentTernaryClauses() const;

//    void EncodeOR(uint32_t output, uint32_t input1, uint32_t input2);
//    void EncodeAND(uint32_t output, uint32_t input1, uint32_t input2);

    Settings* GetSetting();
    uint64_t GetMinWeight();
    uint64_t GetMaxWeight();
    bool GetHasHardClauses();
    bool GetHasMoreThanTwoWeights();

    // Add weighted SoftClauses to _softClauseVector
    bool AddWeightedSoftClause(std::vector<uint32_t>& clause, uint64_t weight = 1);

    // Add whole _softclause Vector to clause database
    void AddSCfromGlucose(uint64_t weight, const std::vector<u_int32_t>& literals, uint32_t antBlock);

    // Solve weighted partial maxSAT Problem
    uint32_t MaxSolveWeightedPartial(int64_t& optimum);
    uint32_t MaxSolveWeightedPartial(const std::vector< uint32_t >& externalAssumptions, int64_t& optimum);

    /* Some maxSAT related interface functions */
    void SetMaxWidth(uint32_t width);
    void SetSplittedWidth(uint32_t width);
    void SetMaxParts(uint32_t parts);
    void SetSortSoftClauses(uint32_t val);
    void CalcSplitWidth(void);
    void SetSkip(bool val);
    void SetCSC(uint32_t val);
    void SetRelaxationLits(bool val);
    void SetIncompleteMode(bool val);
    void SetHorizontalWidth(uint32_t val);
    void SetGridMode(uint32_t val);
    void SetNetworktype(SorterType val);
    void SetMaxInprocessing(bool val);

    // Weighted MaxSat Stuff
    StructureInfo AnalyzeandConvertStructure();

    void SetGreatestCommonDivisor(uint64_t val);
    void SetMoreThanTwoWeights(bool val);
    void SetTopWeight(uint64_t val);
    void SetMinWeight(uint64_t val);
    void SetMaxWeight(uint64_t val);
    void SetHasHardClauses(bool val);

    friend class Cascade;
    friend class MultipleCascade;
    friend class Bucket;
    friend class Sorter;
    friend class Counter;
    friend class Parser;

  private:
    // Copy constructor.
    Antom (const Antom&) = default;

    uint64_t CountSatisfiedSoftClauses(Sorter* sorter);
    uint64_t CountSatisfiedSoftClauses(std::vector<SoftClause *> softclauses);

    //void mergePartTrigger ( Sorter& trigger1, Sorter& trigger2 );
    void CheckAllConflictingSoftclauses(void);

    // Cout the model of the buckets and which position has the first set bit.
    void DumpBucketModel();

    // Called from Cascade and Bucket - they only calculate their own optimum.
    uint64_t CalculateOverallOptimum(uint64_t SatWeight, bool countAgain);

    std::vector< SoftClause* > _softClauses;

    std::vector< std::vector< Sorter* > > _sorterTree;

    Glucose::Solver* _glucose;
    Settings* _antomSetting;
	
    uint32_t _maxSorterDepth;

    uint32_t _maxsatResult;

    // needed for updating optimum value from Weighted Mode - Cascade and Bucket
    int64_t* _optimum;

    //Weighted MaxSAT stuff
    TimeVariables* _timeVariables;
    Cascade* _mainCascade;
    MultipleCascade* _mainMultipleCascade;
    int64_t _greatestCommonDivisor;
    enum StructureInformation
    {
      NOERROR,
      CONVERTTOMAXSATFORMULA,
      ISSATFORMULA,
      DIVIDEWEIGHTSBYDIVISOR,
      ISMAXSATFORMULA,
      HASONLYTWOWEIGHTS,      // not yet used
      NOTOPWEIGHT,            // not yet used
      SOFTWEIGHTSTOOBIG       // not yet used
    } _formulaStructure;
    StructureInfo AnalyzeStructure();
    //StructureInformation AnalyzeStructure();
    void ConvertFormulaToMaxSAT(uint64_t maxWeight);
    void DivideAllSoftClausesByFactor(uint64_t factor);
    uint64_t GreatestCommonDivisor(uint64_t a, uint64_t b);

    uint32_t _currentBucketForTare;
    uint64_t _satWeight;
    bool _moreThanTwoWeights;
    uint64_t _topWeight;
    uint64_t _minWeight;
    uint64_t _maxWeight;
    bool _hasHardClauses;
    uint64_t _sumOfSoftWeights;
	
    // if last solver call returned ANTOMUNKNOWN - this variable is set to true
    bool _resultUnknown;

    // maybe later on as local vars again - just for testing!!
    uint32_t _clausesBefore;
    uint32_t _variablesBefore;
    uint32_t _binaryClausesBefore;
    uint32_t _ternaryClausesBefore;
    uint32_t _addedClauses;
    uint32_t _addedBinaryClauses;
    uint32_t _addedTernaryClauses;

    //for coding clause estimation in standard mode
    double _binaryTopClauses;
    uint64_t _ternaryTopClauses;
    uint64_t _binaryBottomClauses;
    uint64_t _ternaryBottomClauses;

    uint32_t _satSolverCalls;

    // partial status variables
    uint64_t _highestBucketMultiplicator;
    uint64_t _currentBucketMultiplicator;
    // the value calculated highestBucketMultiplicator * bucketInfo[1];
    uint64_t _estimatedSatWeight;
    uint64_t _diffToSatWeight;
    std::vector<uint32_t> _collectedAssumptions;
  };
}

#endif
