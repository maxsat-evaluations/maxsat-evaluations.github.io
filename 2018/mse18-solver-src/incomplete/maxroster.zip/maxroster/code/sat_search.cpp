/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include "maxsat.h"
#include "maxsat2.h"
#include <iostream>
namespace Glucose {
	void Solver::add_card_clause(SPECIAL_CLAUSE*nb)
	{


		vec<Lit> ps;

		uint64_t u = (uint64_t)nb;
		unsigned u1 = u;
		unsigned u2 = u >> 32;

		ps.push(toLit(u1));
		ps.push(toLit(u2));



		CRef cr = ca.alloc(ps, false, nb->get_type());//learnt atmost andor
		nb->my_cref = cr;
		nb->attach_port(*this, cr);


		clauses.push(cr);



	}
	void Solver::add_weight_clause(WEIGHT_AGGREGATE*nb)
	{
		weight_root = nb;

		vec<Lit> ps;

		uint64_t u = (uint64_t)nb;
		unsigned u1 = u;
		unsigned u2 = u >> 32;

		ps.push(toLit(u1));
		ps.push(toLit(u2));



		CRef cr = ca.alloc(ps, false, nb->get_type());//learnt atmost andor
		nb->my_cref = cr;


		clauses.push(cr);



	}
	void Solver::attach_pos_port(Lit L, CRef cr)
	{
		int n = nVars();
		int c = clauses.size();
		int s1 = watches[L].size();
		watches[L].push(Watcher(cr, lit_Undef));
		int s = watches[L].size();
		int m = 0;



	}
	void CARD_ADDER_BOTTOM::attach_port(Solver&S, CRef cr) {


		counter = 0;
		my_cref = cr;
		int neg_counter = 0;
		for (int i = 0;i < inputs.size();i++) {
			Lit L = inputs[i];
			if (S.value(var(L)) == l_True) {
				counter++;
				continue;
			}
			if (S.value(var(L)) == l_False) {
				neg_counter++;
				continue;
			}
			S.attach_pos_port(L, cr);
		}
		for (int i = 0;i < counter;i++) {
			Lit L = linkingVar[i];
			S.uncheckedEnqueue(L, CRef_Undef);
		}


		for (int i = counter;i < linkingVar.size();i++) {
			Lit L = linkingVar[i];
			S.attach_neg_port(L, cr);
		}
	}
	void CARD_ADDER_BOTTOM::attach_solver(Solver&S) {

		S.add_card_clause(this);

	}
	void CARD_NODE::attach_port(Solver&S, CRef cr) {
		if (!troot) return;

		for (int i = 0;i < troot->linkingVar.size();i++) {
			Lit L = troot->linkingVar[i];

			S.attach_pos_port(L, cr);
		}

	}
	void CARD_ADDER::attach_solver(Solver&S) {


		for (int i = 0;i < inputs.size();i++) {
			inputs[i]->attach_solver(S);
		}

		S.add_card_clause(this);
	}


	void CARD_NODE::attach_solver(Solver&S) {

		S.add_card_clause(this);
#ifdef USE_CARD_ADDER
		if (troot)troot->attach_solver(S);
#endif




	}
	void WEIGHT_AGGREGATE::attach_solver(Solver&S) {

		S.add_weight_clause(this);
		for (int i = 0;i < cards.size();i++) {
			cards[i]->attach_solver(S);//S.add_card_clause(cards[i]);
		}


		recal(S);


	}
	void CARD_ADDER::attach_port(Solver&S, CRef cr) {

		counter = 0;
		my_cref = cr;
		for (int i = 0;i < inputs.size();i++) {
			for (int j = 0;j < inputs[i]->linkingVar.size();j++) {
				Lit L = inputs[i]->linkingVar[j];
				if (S.value(var(L)) == l_True) {
					counter++;
					continue;
				}
				if (S.value(var(L)) == l_False) {

					continue;
				}
				S.attach_pos_port(L, cr);
			}
		}
		for (int i = 0;i < counter;i++) {
			Lit L = linkingVar[i];
			if (S.value(var(L)) == l_Undef) {
				S.uncheckedEnqueue(L, CRef_Undef);
			}
		}
		for (int i = counter;i < linkingVar.size();i++) {
			Lit L = linkingVar[i];
			S.attach_neg_port(L, cr);
		}
	}
	void MaxSAT::attach_solver(Solver&S)
	{
		weight_root->attach_solver(S);

	}
#ifdef USE_OLL_MCU3_UNWEIGHT
	void CARD_NODE::print_values(MaxSAT&maxsat,int level)
	{
			troot->print_values(maxsat,level);
		
	}
#endif
	CRef CARD_NODE_BOTH::prop(Solver&S, Lit L, CRef cref)
	{
		Var v = var(L);

		if (!sign(L)) {
			assert(S.value(var(L)) == l_True);//POS SENSE
			update_tcount(S, L);

			if (tcount > UB) {

				parent->set_reason_tcount(S, lit_Undef, S.weight_conflict_reason, true);


				return cref;//parent->cref;
			}

			if (tcount == UB) {

				return parent->update_tcount(S, my_id, tcount*weight, true, cref);

			}
			else {
				return parent->update_tcount(S, my_id, tcount*weight, false, cref);

			}
		}
		else {
			assert(S.value(var(L)) == l_False);//NEG SENSE
			update_fcount(S, L);
			WEIGHT_AGGREGATE_BOTH*wab = dynamic_cast<WEIGHT_AGGREGATE_BOTH*>(parent);

			if (fcount > LB) {

				wab->set_reason_fcount(S, lit_Undef, S.weight_conflict_reason, true);


				return cref;//parent->cref;
			}

			if (fcount == LB) {

				return wab->update_fcount(S, my_id, fcount*weight, true, cref);

			}
			else {
				return wab->update_fcount(S, my_id, fcount*weight, false, cref);

			}



		}

		return CRef_Undef;

	}

	CRef CARD_NODE::prop(Solver&S, Lit L, CRef cref)
	{
		Var v = var(L);


		assert(S.value(var(L)) == l_True);//POS SENSE�������Ȃ�
		update_tcount(S, L);

		if (tcount>UB) {

			parent->set_reason_tcount(S, lit_Undef, S.weight_conflict_reason, true);


			return cref;//parent->cref;
		}

		if (tcount == UB) {

			return parent->update_tcount(S, my_id, tcount*weight, true, cref);

		}
		else {
			return parent->update_tcount(S, my_id, tcount*weight, false, cref);

		}

		return CRef_Undef;

	}

	CRef WEIGHT_AGGREGATE_BOTH::update_fcount(Solver&S, unsigned id, uint64_t tcount, bool deduced, CRef cr)
	{

#ifdef TSUM
		fsum_count(S);
		if (fsum <= LB);
		else {
			set_reason_fcount(S, lit_Undef, S.weight_conflict_reason, true);
			return cr;
		}
#else
		update_fcount_only(id, tcount);
#endif


		for (int i = 0;i <cards.size();i++) {
			CARD_NODE_BOTH*cnb = dynamic_cast<CARD_NODE_BOTH*>(cards[i]);
			assert(cnb);
			bool success = cnb->deduce_if_possible_fcount(S, cr, LB - fsum);
			if (!success) {

				set_reason_fcount(S, lit_Undef, S.weight_conflict_reason, true);

				return cr;
			}



		}


		return CRef_Undef;

	}
	CRef WEIGHT_AGGREGATE::update_tcount(Solver&S, unsigned id, uint64_t tcount, bool deduced, CRef cr)
	{


#ifdef TSUM
		tsum_count(S);
		if (tsum <= UB);
		else {
			set_reason_tcount(S, lit_Undef, S.weight_conflict_reason, true);
			return cr;
		}
#else
		update_tcount_only(id, tcount);
#endif

		if (deduced) {
			//�������ʂ�Deduce�ς̉\��������
			for (int i = id + 1;i < cards.size();i++) {
				uint64_t ub = cards[i]->UB;
				uint64_t tc = cards[i]->tcount;
				if (cards[i]->UB == cards[i]->tcount);//deduce�ς�
				else cards[i]->deduce_if_possible_tcount(S, cr, UB - tsum);

			}
			for (int i = 0;i <= id;i++) {
				bool success = cards[i]->deduce_if_possible_tcount(S, cr, UB - tsum);
				if (!success) {

					set_reason_tcount(S, lit_Undef, S.weight_conflict_reason, true);

					return cr;
				}
			}


		}
		else {
			for (int i = 0;i <cards.size();i++) {
				bool success = cards[i]->deduce_if_possible_tcount(S, cr, UB - tsum);
				if (!success) {

					set_reason_tcount(S, lit_Undef, S.weight_conflict_reason, true);

					return cr;
				}



			}

		}
		return CRef_Undef;
	}
	bool WEIGHT_AGGREGATE::set_UB(Solver&S, uint64_t K)
	{
		recal(S);
		if (tsum > K) return false;
		UB = K;
		for (int i = 0;i <cards.size();i++) {
			bool success = cards[i]->deduce_if_possible_tcount(S, CRef_Undef, UB - tsum);
			if (!success) return false;
		}
		return true;
	}

	bool WEIGHT_AGGREGATE_BOTH::set_LB(Solver&S, uint64_t K) {

		recal(S);
		if (fsum > K) return false;
		LB = K;
		for (int i = 0;i <cards.size();i++) {
			bool success = cards[i]->deduce_if_possible_fcount(S, CRef_Undef, LB - fsum);
			if (!success) return false;
		}
	}

	bool MaxSAT::set_UB(Solver&S, uint64_t K)
	{
		return weight_root->set_UB(S, K);
	}
#ifdef USE_CARD_ADDER


#else
	void MaxSAT::create_unweight_instances_oll(uint64_t& UB) {

			weight_root = new WEIGHT_AGGREGATE();
			vec<Lit> inputs;
			vector<CARD_NODE*> cards;
			int id = 0;
			for (int i = 0;i < vsoft_clauses.size();i++) {
				
				if (!vsoft_clauses[i]->weight) continue;
				if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
					inputs.push(vsoft_clauses[i]->L);
					continue;
				}

				VSoftClauseC* vs = dynamic_cast<VSoftClauseC*>(vsoft_clauses[i]);
				//extend_UB(vs->troot, UB);
				//CARD_NODE*cn = new CARD_NODE(id++, 1, inputs, weight_root, vs->troot);
				//cards.push_back(cn);
				UB -= vs->RHS;
			}

			{
				TNode*troot = genCardinals(inputs, outputs, UB, false);
				CARD_NODE*cn = new CARD_NODE(id++, 1, inputs, weight_root, troot);
				cards.push_back(cn);
			}
			weight_root->cards = cards;
	}
	void MaxSAT::create_unweight_instances_oll() {

		weight_root = new WEIGHT_AGGREGATE();
		vec<Lit> inputs;
		vector<CARD_NODE*> cards;
		int id = 0;
		uint64_t local_upperbound = upperbound;
		uint64_t diff = upperbound - lowerbound;

		for (int i = 0;i < vsoft_clauses.size();i++) {

			if (!vsoft_clauses[i]->weight) continue;
			if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
				inputs.push(vsoft_clauses[i]->L);
				continue;
			}

			VSoftClauseC* vs = dynamic_cast<VSoftClauseC*>(vsoft_clauses[i]);
			extend_UB(vs->troot, vs->RHS + diff);
			
			CARD_NODE*cn = new CARD_NODE(id++, vs->weight, vs->troot->inputs, weight_root,vs->troot);
			cards.push_back(cn);


			local_upperbound -= vs->RHS;
		}

		{
			TNode*troot = genCardinals(inputs, outputs, local_upperbound, false);
			CARD_NODE*cn = new CARD_NODE(id++, 1, inputs, weight_root, troot);
			cards.push_back(cn);
		}
		weight_root->cards = cards;
	}
	lbool MaxSAT::oll_sat_check() {
		vec<Lit> assumptions;
		for (int i = 0;i < vsoft_clauses.size();i++) {
			if (!vsoft_clauses[i]->weight) continue;
			if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) continue;
			vsoft_clauses[i]->set_assumption(*this,assumptions);
		
			
		}
		lbool ret=  solveLimited(assumptions);
		if (ret == l_True) {
			if (disjoint_status == ONCE_SAT) {
				disjoint_status = DISJOINT_DONE;
				printf("c disjoint done.\n");

			}
			uint64_t t = computeCostModel(solver->model);
			if (t < upperbound) {
				upperbound = t;
				best_UB = t;
				printf("o %ld\n", upperbound);
			}
		}


		return ret;
	}
	void MaxSAT::sat_search_oll() {



		
		create_unweight_instances_oll();
		//solver = rebuildSolver();
		attach_solver(*solver);
		set_UB(*solver, upperbound);

	
		lbool ret = l_True;

		while (ret == l_True) {
			
			vec<Lit> assumptions;
			
			ret = solveLimited(assumptions);
			if (ret == l_True) {
				solver->model.copyTo(model);// = solver->model;

			
			

				uint64_t t = computeCostModel(solver->model);
				printf("o=%zd \n", t);
				if (t < best_UB) {
					best_UB = t;
					upperbound = t;
				}


				if (!t) break;
				vec<Lit> lits;

				bool Ret = set_UB(*solver, --t);

				if (!Ret) ret = l_False;

			}

			else {


				break;
			}
		}
		printf("Best UB=%zd\n", upperbound);



	}
	
#endif
	void MaxSAT::sat_search(uint64_t UB) {



		lbool success = model_practice();
		
#ifdef USE_OLL_MCU3_UNWEIGHT
		create_unweight_instances_vclause(UB);
		if(0)
		{
			vec<Lit> assumptions;
			lbool success = searchSATSolver(solver, assumptions);
			assert(success == l_True);
	}
#else
		create_unweight_instances(UB,true,true);//
#endif
												//create_unweight_instances_oll(UB);
									  //solver = rebuildSolver();
		attach_solver(*solver);



		set_UB(*solver, UB);

		uint64_t t_UB;
		if (success == l_True) {
			t_UB = computeCostModel(solver->model);
			printf("Model %zd\n", t_UB);
		}
		else {
			printf("!Model Error\n");
		}
		lbool ret = l_True;

		while (ret == l_True) {
			//solver->set_stoptime(timeout);
			vec<Lit> assumptions;

#ifdef USE_OLL_MCU3_UNWEIGHT
			for (int i = 0;i < vsoft_clauses.size();i++) {
				if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
					//vsoft_clauses[i]->set_assumption(*this,assumptions);
				}	
				//assumptions.push(~vsoft_clauses[i]->L);
			}
#else
			for (int i = 0;i < vsoft_clauses.size();i++) {
				if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) continue;
				//assumptions.push(~vsoft_clauses[i]->L);
			}
#endif
			ret = solveLimited(assumptions);
			if (ret == l_True) {
				solver->model.copyTo(model);// = solver->model;

				int tsum = 0;
				//int64_t sum=weight_root->model_check(model,tsum);

				uint64_t t = computeCostModel(solver->model);
				printf("o=%zd \n", t);
				if (t < best_UB) {
					best_UB = t;
					upperbound = t;
				}


				if (!UB) break;
				vec<Lit> lits;

				bool Ret = set_UB(*solver, --UB);

				if (!Ret) ret = l_False;

			}

			else {


				break;
			}
		}
		printf("Best UB=%zd\n", best_UB);



	}
}	
