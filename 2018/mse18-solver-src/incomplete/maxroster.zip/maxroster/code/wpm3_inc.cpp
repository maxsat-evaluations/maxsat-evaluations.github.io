/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include "maxsat.h"
#include "maxsat2.h"
#include <iostream>
namespace Glucose {

void VSoftClauseC::set_lowerbound_to_clause(MaxSAT&maxsat)
{
	if (lowerbound &&troot->linkingVar.size() >= lowerbound) {
		
		Lit p = troot->linkingVar[lowerbound-1];
		maxsat.addClause(p);

	}

}
VSumC::VSumC(MaxSAT&maxsat, VSumC* old_, int64_t weight_, int RHS_, VSoftClauseC* input_)
{
	type = VSUM;
	lowerbound = RHS_;
	RHS = RHS_;
	weight = weight_;
	input = input_;

	old = old_;
	if (!old) {
		troot = input->troot;
		L = lit_Undef;
	}else {
		vec<Lit> linkingVar;
		troot=maxsat.mergeCardinals(input->troot, old->troot, linkingVar, RHS);
		troot->set_base(this);
		if (troot->linkingVar.size() >= lowerbound) {
			maxsat.addClause(troot->linkingVar[lowerbound - 1]);
		}
		maxsat.extend_UB(troot, RHS);
		if (troot->linkingVar.size()>RHS) L = troot->linkingVar[RHS];
		else L = lit_Undef;
		//old->weight = 0;
		//old->updateRHS(maxsat, RHS);
		
		//updateL();
	}

}
void VSumC::updateRHS(MaxSAT&maxsat, int RHS_) {
	weight = 0;
	RHS =RHS_;
	if (old) {
		old->updateRHS(maxsat, RHS);
	}
}
//#define T2
void VSumC::updateRHS(MaxSAT&maxsat) {
	lowerbound++;

#ifdef TRY2
	RHS++;
#else
	//if (old) {
	//	old->updateRHS(maxsat,RHS);
	//}
	set_RHS(maxsat, lowerbound);
#endif
	
	maxsat.extend_UB(troot, RHS);

	if (troot->linkingVar.size() >= lowerbound) {
		maxsat.addClause(troot->linkingVar[lowerbound - 1]);
	}

	if (troot->linkingVar.size()>RHS) L = troot->linkingVar[RHS];
	else L = lit_Undef;
#ifdef TRY2

#else
	updateL();
#endif	
}
	void VSumC::set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions) {
		if (!weight) return;
		if (L == lit_Undef) return;

		if (troot->linkingVar.size() > RHS) {

			assumptions.push(~L);
			maxsat.add_vsoft_clause_map(L, this);
		}

	}
	
	//root_node��Left�Ƃ���Right�ɒǉ�Node(from-to)�𐶐����V����Node�𐶐�����
	//K �g���͂Ȃ���Ă�����̂Ƃ���
	TNode* MaxSAT::mergeCardinals(TNode*right, TNode* left, vec<Lit> &linkingVar, unsigned UB)
	{


		//int inputSize = from_to.size();//������́Ato+1�ɂȂ�
		linkingVar.clear();

		vec<Lit> linkingAlpha;
		vec<Lit> linkingBeta;


		
		int l_lb = left->get_lb();
		int r_lb = right->get_lb();
		if (l_lb) {
			extend_UB(left, UB);
			extend_UB(right, UB - l_lb);

		}
		else if (r_lb) {
			extend_UB(left, UB - r_lb);
			extend_UB(right,UB);

		}
		else {
			extend_UB(left, UB);
			extend_UB(right,UB);
		}

		//���m�[�h
		//extend_UB(left, UB);//�܂�K���g������
		//extend_UB(right, UB);
									//	if (child->inputs.size()>UB) assert(child->UB == UB);
		
		for (size_t i = 0;i< left->linkingVar.size();i++) {
			linkingAlpha.push(left->linkingVar[i]);
		}
		for (size_t i = 0;i< right->linkingVar.size();i++) {
			linkingBeta.push(right->linkingVar[i]);
		}
		
		vec<Lit> inputs;
		inputs = left->inputs;
		for (int i = 0;i< right->inputs.size();i++) {
			inputs.push(right->inputs[i]);
		}
		int inputSize = inputs.size();
		TNode*node = new TNode(left, right, linkingVar, inputs, UB);
		//�V�m�[�h��Var�����@
		for (int i = 0; i < inputSize && i <= UB; i++) {
			if (i>node->imax) node->imax = i;
			Lit L = new_literal();
			linkingVar.push(L);//Lit(S.newVar()));
			newSATVariable(solver);

		}

		//�V�m�[�h��Clause����	
		for (int sigma = 0; sigma <= inputSize && sigma <= UB + 1; sigma++) {
			for (int alpha = 0; alpha <= linkingAlpha.size() && alpha <= UB + 1; alpha++) {
				for (int beta = 0;beta <= linkingBeta.size() && beta <= UB + 1;beta++) {


					if ((alpha + beta) != sigma) continue;
					assert(alpha + beta == sigma);
					int a = alpha - 1;
					int b = beta - 1;
					int s = sigma - 1;
					vec<Lit> lits;

					if (sigma != 0) {
						if (alpha != 0)	lits.push(~linkingAlpha[a]);
						if (beta != 0)   lits.push(~linkingBeta[b]);
						lits.push(linkingVar[s]);
						tnode_clauses.push(lits);
						addClause(lits);
					}
					if (sigma != inputSize && sigma != UB + 1) {
						lits.clear();
						if (alpha != linkingAlpha.size()) lits.push(linkingAlpha[a + 1]);
						if (beta != linkingBeta.size()) lits.push(linkingBeta[b + 1]);
						lits.push(~linkingVar[s + 1]);
						tnode_clauses.push(lits);
						addClause(lits);
					}

				}
			}
		}

		//copy linkingVar 
		node->linkingVar.clear();
		for (size_t i = 0;i< linkingVar.size();i++) {
			node->linkingVar.push(linkingVar[i]);
		}
		return node;

	}

	
	
	
	
	
	
	

TNode* MaxSAT::merge_cardinals(vec<VSoftClauseC*>& inputs, int UB)
{
	if (inputs.size() == 0) return 0;
	if (inputs.size() == 1) {

		extend_UB(inputs[0]->troot, UB);
		return inputs[0]->troot;
	
	}else if (inputs.size() == 2) {

		
		TNode*right = inputs[0]->troot;
		TNode*left = inputs[1]->troot;

		vec<Lit> linkingVar;
		TNode*troot = mergeCardinals(right, left, linkingVar, UB);
		return troot;


	}else {
		int middle = inputs.size() / 2;
		
		vec <VSoftClauseC*> from, to;
		for (int i = 0;i<middle;i++) {
			from.push(inputs[i]);
		}
		for (int i = middle;i< inputs.size();i++) {
			to.push(inputs[i]);
		}
		TNode*left = merge_cardinals(from, UB);
		TNode*right = merge_cardinals(to, UB);

		vec<Lit> linkingVar;
		TNode*troot = mergeCardinals(right, left, linkingVar, UB);
		return troot;

	}
	



}



#ifdef USE_OLL_MCU3_UNWEIGHT
void MaxSAT::unweighted_vclause_sat_search(int UB)
{
	create_unweight_instances_vclause(UB);
	sat_search(UB);

}
void MaxSAT::create_unweight_instances_vclause(unsigned UB)
{
	vec<VSoftClauseBase*> bvec;
	vec<VSoftClauseC*> cvec;
	vec<VSoftClauseC*> dvec;
	for (int i = 0;i < vsoft_clauses.size();i++) {
		if (vsoft_clauses[i]->type == VSoftClauseBase::Constraint)
		{
			VSoftClauseC*sc = dynamic_cast<VSoftClauseC*>(vsoft_clauses[i]);
			if (sc->lowerbound) {
				dvec.push(sc);
			}
			else if (!sc->is_updated()){
				cvec.push(sc);
			}
		}else if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
			if (vsoft_clauses[i]->weight) {
				bvec.push(vsoft_clauses[i]);
			}
		}
	}
	

	weight_root = new WEIGHT_AGGREGATE();
	vector<CARD_NODE*> cards;
	unsigned id = 0;
	TNode*left  =merge_cardinals(dvec, UB);

	CARD_NODE*cn = new CARD_NODE(id++, 1, left->inputs, weight_root, left);
	cards.push_back(cn);
	int right_ub = UB - dvec.size();
//#define TX

#ifdef TX
	if (bvec.size()) {
		VSoftClauseC*vc = new VSoftClauseC(*this, bvec, 1, 0);
		extend_UB(vc->troot, right_ub);
		cvec.push(vc);
	}

#endif

	
	if (right_ub&& cvec.size())
	{
		TNode*right = merge_cardinals(cvec, right_ub);
		CARD_NODE*cn = new CARD_NODE(id++, 1, right->inputs, weight_root, right);
		cards.push_back(cn);
	}
#ifndef TX
	if (bvec.size()) {
		VSoftClauseC*vc = new VSoftClauseC(*this, bvec, 1, 0);
		extend_UB( vc->troot, right_ub);
		CARD_NODE*cn = new CARD_NODE(id++, 1, vc->troot->inputs, weight_root,vc->troot);
		cards.push_back(cn);

	}
#endif
	weight_root->UB = UB;
	weight_root->cards = cards;


}
#endif

void TNode::set_base(VSoftClauseBase*b) {
	base = b;
}
int TNode::get_lb() {


	if (!base) {
		int sum = 0;
		if (left) sum += left->get_lb();
		if (right) sum += right->get_lb();
		if (sum) {
			int m = 0;
		}
		return sum;

	}
	

	return base->get_lowerbound();
	
}

int VSumC::set_RHS(MaxSAT&maxsat,int maxRHS)
{
	int sum = 0;
	if (old) sum=old->set_RHS(maxsat,maxRHS);
	sum += input->RHS;
	if (input->RHS > 1) {
		int m = 0;
	}
	if (sum <= maxRHS) {
		RHS = sum;
	}else RHS = maxRHS;
	return sum;
}
uint64_t MaxSAT::core_analysis_oll2_oll_mcu3_unweight(vec<Lit> & conflicts, vec<Lit>&assumptions, bool free_phase)
{
	//printf("conflicts.size=%d %d\n", conflicts.size(),solver->nLearnts());
	//if (lowerbound >= 30&& lowerbound<=32) {
	//	int m = 0;
	//}
	uint64_t min_cost = compute_min_oll_cost(conflicts);
	//
		
			conflict_minimize(conflicts);
	//		trim(conflicts);
		

	vec<VSoftClauseSeqLE*> vc_vec;
	vec<VSoftClauseBase*> vb_vec;

	map<int, vec<Lit> > cmap;

	for (int i = 0;i < conflicts.size();i++) {
		Lit L = conflicts[i];
		std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
		if (im == vsoft_clause_map.end()) assert(0);
		else {
			VSoftClauseBase*vs = (*im).second;
			if (vs->type == VSoftClauseBase::AssumptionVar) {
				vb_vec.push(vs);
			}
			else {
				map<int, vec<Lit> >::iterator ix = cmap.find(vs->get_id());
				if (ix == cmap.end()) {
					vec<Lit> t;
					t.push(L);
					cmap[vs->id] = t;
				}
				else {
					(*ix).second.push(L);
				}
			}
		}
	}
	vec<VSoftClauseC*> cvec;
	set<VSumC*> vsumcs;
	map<int, vec<Lit> >::iterator im;
	
	if (cmap.size() == 1) {
		int m = 0;
	}

	
	for (im = cmap.begin(); im != cmap.end();im++) {
		VSoftClauseBase* vs = get_vsoft_clause_base((*im).first);
		if (vs->weight == min_cost) {
			if (vs->type == VSoftClauseBase::Constraint) {
				
				VSoftClauseC*VSC = dynamic_cast<VSoftClauseC*>(vs);
				VSC->updateRHS(*this);
				
				//cvec.push(VSC);
			}
			else {
			//	assert(vs==last_vsumc);
				assert(vs->type == VSoftClauseBase::VSUM);
				VSumC* vsumc = dynamic_cast<VSumC*>(vs);
				vsumcs.insert(vsumc);
				//VSoftClauseSeqLE*VSC = dynamic_cast<VSoftClauseSeqLE*>(vs);
				//VSC->updateRHS(*this, VSC->RHS + 1);

				//cvec.push(VSC);

			}

		}
		else {
			assert(0);
		}
	}
	if (vb_vec.size()) {
		vec<VSoftClauseBase*> inputs;
		for (int i = 0;i < vb_vec.size();i++) {
			if (vb_vec[i]->weight == min_cost) {
				vb_vec[i]->weight = 0;//vmin�̕��͎���assumption����Ȃ�
				inputs.push(vb_vec[i]);
			}
			else {
				//assert(0);
			}
		}
		
		int local_lowerbound = 0;
		if (free_phase) local_lowerbound = 1;
#ifdef SAT3
		VSoftClauseC*vs = new VSoftClauseC(*this, vb_vec, min_cost, local_lowerbound, false);
#else
		VSoftClauseC*vs = new VSoftClauseC(*this, vb_vec, min_cost,local_lowerbound,true);
#endif
		add_vsoft_clause(vs);
		cvec.push(vs);


	}
	
	/*
	if (!last_vsumc) {//�����݂��Ȃ�
		assert(cvec.size() == 1);
		last_vsumc = new VSumC(*this, last_vsumc,min_cost,1, cvec[0]);
		add_vsoft_clause(last_vsumc);
	}
	else {
		
	

		if (cvec.size()) {
			assert(cvec.size() == 1);
			set<VSumC*>::iterator ix;
			for (ix=vsumcs.begin();ix!=vsumcs.end();ix++){
#ifdef TRY2
				(*ix)->updateRHS(*this);
#endif
			}
			last_vsumc->set_RHS(*this, last_vsumc->lowerbound + 1);
			last_vsumc = new VSumC(*this, last_vsumc, min_cost,last_vsumc->lowerbound+1, cvec[0]);
			add_vsoft_clause(last_vsumc);
#ifdef TRY2

#else
			last_vsumc->updateL();
#endif
		}else {
			
			set<VSumC*>::iterator ix;
			for (ix = vsumcs.begin();ix != vsumcs.end();ix++) {
				if ((*ix) != last_vsumc) {
#ifdef TRY2
					(*ix)->updateRHS(*this);
#endif
				}
			}
			//last_vsumc->set_RHS(*this, last_vsumc->lowerbound + 1);
			last_vsumc->updateRHS(*this);
			
		}
	}
	*/
	if (free_phase)		set_oll2_assumptions_free_phase(assumptions);
	else set_oll2_assumptions(assumptions);
	//	int sum = 0;
	//	for (int i = 0;i < assumptions.size();i++) {
	//		sum += assumptions[i].x;
	//		printf("%d %d ",i, assumptions[i].x);
	//	}

	//	printf("assumptions size=%d %d\n", assumptions.size(),sum);
	return min_cost;//min_cost;
}


}	
