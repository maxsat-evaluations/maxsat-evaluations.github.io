/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include "maxsat.h"
#include "maxsat2.h"
#include <iostream>
namespace Glucose {
	VSoftClauseBase* VSoftClauseBase::split_weight(MaxSAT&maxsat, uint64_t min_weight, bool inc)
	{
		weight -= min_weight;
		assert(weight);
		Var v = var(L);
		if (maxsat.solver->value(v) != l_Undef) {
			int m = 0;

		}
		{
			Lit L = maxsat.new_literal();
			if (inc) maxsat.newSATVariable(maxsat.solver);
			VSoftClauseBase*vcb = new VSoftClauseBase(L, min_weight, idx);
			if (inc) vcb->send_clause(maxsat);

			return vcb;
		}
	}
	VSoftClauseBase* VSoftClause::split_weight(MaxSAT&maxsat, uint64_t min_weight)
	{
		assert(weight > min_weight);
		weight -= min_weight;
		VSoftClause*vsc = new VSoftClause(elements, min_weight);
		vsc->RHS = RHS;

		return vsc;

	}

	void VSoftClauseBase::set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions) {
		if (L == lit_Undef) return;

		if (weight) {
			assumptions.push(~L);
			maxsat.add_vsoft_clause_map(L, this);
		}
	}
	void VSoftClause::set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions) {
		if (!weight) return;
		if (L == lit_Undef) return;

		if (troot->linkingVar.size() > RHS) {
			Lit L = troot->linkingVar[RHS];
			Var v = var(L);
			if (v == 0x14c) {
				int m = 0;
			}
			assumptions.push(~L);
			maxsat.add_vsoft_clause_map(L, this);

		}

	}
	void MaxSAT::set_oll_assumptions(vec<Lit>& assumptions, bool gen_vsoft_clause)
	{
		assumptions.clear();
		vsoft_clause_map.clear();
		for (int i = 0;i < vsoft_clauses.size();i++) {
			if (vsoft_clauses[i]->is_hard());
			else if (vsoft_clauses[i]->weight >= currentWeight) {
				if (gen_vsoft_clause)
					vsoft_clauses[i]->set_assumption(*this, assumptions);
				else if (vsoft_clauses[i]->type == VSoftClause::AssumptionVar) {
					vsoft_clauses[i]->set_assumption(*this, assumptions);
				}
			}
		}

	}
	void VSoftClause::rebuild(MaxSAT&maxsat)
	{
		vec<Lit> inputs;
		for (int i = 0;i < elements.size();i++) {
			VSoftCardLit &VS = elements[i];
			Lit L = VS.base->get_lit(VS.no);
			inputs.push(L);
		}
		if (troot) delete troot;
		troot = 0;
		vec<Lit> linkingVar;
		troot = maxsat.genCardinals(inputs, linkingVar, RHS, false);
	}
	uint64_t MaxSAT::compute_min_oll_cost(vec<Lit>& conflicts)
	{
		uint64_t coreCost = UINT64_MAX;

		for (int i = 0; i < conflicts.size(); i++)
		{
			Lit L = conflicts[i];
			std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
			if (im == vsoft_clause_map.end()) assert(0);
			else {

				uint64_t weight = (*im).second->weight;
				if (weight < coreCost) {
					coreCost = weight;

				}
			}
		}
		return coreCost;

	}
	uint64_t MaxSAT::core_analysis_oll(vec<Lit> & conflicts, vec<Lit>&assumptions, bool gen_vsoft_clause)
	{
		assert(conflicts.size());

		uint64_t min_cost = compute_min_oll_cost(conflicts);

		vec<VSoftCardLit> vs_vec;
		for (int i = 0;i < conflicts.size();i++) {
			Lit L = conflicts[i];
			std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
			if (im == vsoft_clause_map.end()) assert(0);
			else {
				VSoftClauseBase*vs = (*im).second;
				int n = vs->get_n(L);
				if (vs->weight == min_cost) {
					VSoftCardLit VS(vs, n);
					vs_vec.push(VS);
					vs->updateRHS();
				}
				else {
					assert(vs->weight > min_cost);
					VSoftClauseBase*vmin = vs->split_weight(*this, min_cost);
					assert(vmin->weight == min_cost);
					VSoftCardLit VS(vmin, n);
					vs_vec.push(VS);
					vmin->updateRHS();
					add_vsoft_clause(vmin);
				}
			}

		}
		if (conflicts.size() > 1) {
			VSoftClause*VS = new VSoftClause(vs_vec, min_cost);
			add_vsoft_clause(VS);
		}

		solver = rebuildSolveroll();

		set_oll_assumptions(assumptions, gen_vsoft_clause);
		return min_cost;
	}
#ifdef SIMP_SOLVER
	SimpSolver * MaxSAT::rebuildSolveroll() {
#else
	Solver * MaxSAT::rebuildSolveroll() {
#endif
		if (solver&& solver->Model.size()) {
			solver->Model.copyTo(model);
		}
		Solver * S = newSATSolver();
		S->print_model=print_model;

		if (nbInitialVariables) {
			S->set_nbInitialVariables(nbInitialVariables);
			if (model.size()) {
				model.copyTo(S->Model);
			}
		}
		int n = nVars();
		for (int i = 0; i < nVars(); i++) {

			newSATVariable(S);

		}
		solver=S;
		for (int i = 0; i < nHard(); i++) {
#ifdef SIMP_SOLVER
			SimpSolver*SS = dynamic_cast<SimpSolver*>(S);
			bool success = SS->addClause(hardClauses[i].clause);
#else
			bool success = addClause(hardClauses[i].clause);
#endif
			assert(success);
		}
#ifdef SIMP_SOLVER
		SimpSolver*SS = dynamic_cast<SimpSolver*>(S);
		solver = SS;
#else
		solver = S;
#endif
#ifdef USE_MO1
		
		for (int i = 0; i < nSoft(); i++) {
			vec<Lit> clause;
			softClauses[i].clause.copyTo(clause);
			Var v = var(softClauses[i].assumptionVar);
			if (v == 611) {
				int m = 0;
			}
			clause.push(softClauses[i].assumptionVar);

			addClause(clause);
		}
	
		for (int i = 0;i < tnode_clauses.size();i++) {
			addClause(tnode_clauses[i]);
		}

#endif


		




		for (int i = 0; i < vsoft_clauses.size(); i++) {
			if (vsoft_clauses[i]->weight >= currentWeight || !vsoft_clauses[i]->weight) {
				if (vsoft_clauses[i]->type == VSoftClause::AssumptionVar) {
					vec<Lit> clause;
					int idx = vsoft_clauses[i]->idx;
					Lit L = vsoft_clauses[i]->L;
					softClauses[idx].clause.copyTo(clause);
					clause.push(L);//softClauses[i].assumptionVar);
#ifdef SIMP_SOLVER
					SimpSolver*SS = dynamic_cast<SimpSolver*>(S);
					bool success = SS->addClause(clause);//hardClauses[i].clause);
#else
					addClause(clause);
#endif
				}
				else {
					vsoft_clauses[i]->rebuild(*this);

				}
			}
		}
#ifdef SIMP_SOLVER
		return dynamic_cast<SimpSolver*>(S);
#else
		return S;
#endif
	}
	uint64_t MaxSAT::computeCostModel_oll(vec<lbool> &currentModel) {


		failed_lits.clear();

		assert(currentModel.size() != 0);
		uint64_t currentCost = 0;
		count_map_initialize();

		int tsum = 0;

		for (int i = 0; i < nHard(); i++) {
			bool unsatisfied = true;
			if (i == 643) {
				int m = 0;
			}
			for (int j = 0; j < hardClauses[i].clause.size(); j++) {

				Var v = var(hardClauses[i].clause[j]);


				assert(var(hardClauses[i].clause[j]) < currentModel.size());
				if ((sign(hardClauses[i].clause[j]) && currentModel[var(hardClauses[i].clause[j])] == l_False) ||
					(!sign(hardClauses[i].clause[j]) && currentModel[var(hardClauses[i].clause[j])] == l_True)) {
					unsatisfied = false;

					break;
				}
			}
			assert(!unsatisfied);
		}

		for (int k = 0; k < vsoft_clauses.size(); k++) {
			if (vsoft_clauses[k]->type != VSoftClauseBase::AssumptionVar) continue;

			bool unsatisfied = true;
			int i = vsoft_clauses[k]->idx;
			for (int j = 0; j < softClauses[i].clause.size(); j++) {



				assert(var(softClauses[i].clause[j]) < currentModel.size());
				if ((sign(softClauses[i].clause[j]) && currentModel[var(softClauses[i].clause[j])] == l_False) ||
					(!sign(softClauses[i].clause[j]) && currentModel[var(softClauses[i].clause[j])] == l_True)) {
					unsatisfied = false;

					break;
				}
			}

			if (unsatisfied) {


				uint64_t w = softClauses[i].weight;
				if (!softClauses[i].splited) {
					uint64_t ow = softClauses[i].oweight;
					map<uint64_t, int>::iterator im = count_map.find(ow);
					if (im == count_map.end()) {
						count_map[ow] = 1;
					}
					else (*im).second++;
				}
				currentCost += w;
				tsum++;

			}

		}
		if (0) {
			map<uint64_t, int>::iterator im;
			uint64_t v = 0;
			for (im = count_map.begin();im != count_map.end();im++) {
				v += (*im).first*(*im).second;
				printf("c weight=%zd %d\n", (*im).first, (*im).second);
			}
			printf("c total=%zd\n", v);
		}
		return currentCost;
	}
	void MaxSAT::trim(vec<Lit>& conflict)
	{

		vec<Lit> assumptions;
		if (conflict.size() <= 1) return;
		int osize = conflict.size();
		int counter = 0;

		do {
			counter++;
			assumptions.clear();
			for (int i = 0; i < conflict.size(); i++) assumptions.push(~conflict[i]);
			lbool status = searchSATSolver(solver, assumptions);
			assert(status == l_False);


			if (conflict.size() <= 1) return;
		} while (assumptions.size() > conflict.size());
		if (counter > 1) printf("c trim %d %d\n", osize, conflict.size());
	}
	uint64_t MaxSAT::find_next_weight_oll() {
		uint64_t nextWeight = 1;
		for (int i = 0;i < vsoft_clauses.size();i++) {
			if (vsoft_clauses[i]->is_hard()) continue;
			if (vsoft_clauses[i]->weight > nextWeight && vsoft_clauses[i]->weight < currentWeight)
				nextWeight = vsoft_clauses[i]->weight;
		}

		return nextWeight;

	}
	void MaxSAT::make_oll_weight_map()
	{
	//	printf("c original weight max=%d nSoft=%d\n", currentWeight, nSoft());
		map<uint64_t, vec<Lit> > wmap;
		int avar = 0;
		int cvar = 0;
		for (int i = 0;i < vsoft_clauses.size();i++) {
			if (vsoft_clauses[i]->is_hard()) continue;

			if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
				avar++;
			}
			else cvar++;
			uint64_t weight = vsoft_clauses[i]->weight;
			Lit L = vsoft_clauses[i]->L;
			map<uint64_t, vec<Lit> > ::iterator im = wmap.find(weight);
			if (im == wmap.end()) {
				vec<Lit> v;
				v.push(L);
				wmap[weight] = v;
			}
			else (*im).second.push(L);


		}
		map<uint64_t, vec<Lit> > ::reverse_iterator ir;
	//	printf("c weight map size=%d avar=%d cvar=%d avar+cvar=%d\n", wmap.size(), avar, cvar, avar + cvar);
	//	for (ir = wmap.rbegin();ir != wmap.rend();ir++) {
	//		printf("c weight=%d  %d\n", (*ir).first, (*ir).second.size());
	//	}

	}
	uint64_t MaxSAT::oll_lowerbound_search(uint64_t UB) {


		for (int i = 0;i < nSoft();i++) {
			uint64_t w = softClauses[i].weight;
			Lit L = softClauses[i].assumptionVar;
			VSoftClauseBase*vs = new VSoftClauseBase(L, w, i);
			add_vsoft_clause(vs);


		}
		maxWeight = currentWeight;
		currentWeight = get_min_weight_in_vsoft_clauses();

		solver = rebuildSolveroll();








		lbool res = l_True;




		best_UB = UB;

		vec<Lit> assumptions;
		set_oll_assumptions(assumptions);

		uint64_t LB = 0;
		while (true) {




			res = searchSATSolver(solver, assumptions);
			if (res == l_True) {

				uint64_t cost = computeCostModel(solver->model);
				if (cost < UB)
				{
					upperbound=cost;
					UB = cost;
					best_UB = upperbound;
					solver->saveModel();
					printf("o %" PRIu64 "\n", upperbound);
					//solver->saveModel();
					//printf("o %" PRIu64 "\n", UB);
				}
				currentWeight = maxWeight;
				make_oll_weight_map();
				return LB;



			}
			else if (res == l_False) {
				trim(solver->conflict);
				int core_size = solver->conflict.size();


				uint64_t coreCost = core_analysis_oll(solver->conflict, assumptions, false);//vsoft clause assumptionを生成しない
				LB += coreCost;
				printf("c LB : %-12" PRIu64 " CS : %-12d W  : %-12zd\n", LB,
					core_size, coreCost);

				printf("c LB=%zd\n", LB);
			}
		}
		//assert(_CrtCheckMemory);



	}


	
	
	
}	
