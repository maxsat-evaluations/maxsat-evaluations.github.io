/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include "maxsat.h"
#include "maxsat2.h"

namespace Glucose {
	
uint64_t MaxSAT::get_next_weight(uint64_t weight)
{
	map<uint64_t, int>::reverse_iterator im;
	uint64_t last_weight = weight_root->cards[weight_root->cards.size() - 1]->weight;
	if (weight == last_weight) return 1;

	for (im = count_map.rbegin();im != count_map.rend();im++) {
		uint64_t w = (*im).first;
		if ((*im).first == weight) {
			
			if (weight== last_weight) {
				return (*im).first;
			}
			else {
				map<uint64_t, int>::reverse_iterator ix = im;
				ix++;
				

				if ((*ix).second == 0) {
					weight = (*ix).first;
					continue;
				}
				weight= (*ix).first;
				return weight;
			}
		}
	}
	return 1;


}
void MaxSAT::inc_search(uint64_t UB_) {

	

	best_UB =UB_;

	printf("c incsat o=%zd\n", best_UB);


	lbool success = model_practice();


	weight_root = new WEIGHT_AGGREGATE();
	weight_root->UB = best_UB;
	//weightを分類
	map<uint64_t, vec<Lit> > weight_map;
	for (int i = 0;i < nSoft();i++) {
		uint64_t w = softClauses[i].weight;
		map<uint64_t, vec<Lit> > ::iterator im = weight_map.find(w);
		Lit L = softClauses[i].assumptionVar;
		if (im == weight_map.end()) {
			vec<Lit> dummy;
			dummy.push(L);
			dummy.copyTo(weight_map[w]);// = dummy;
		}
		else {
			(*im).second.push(L);
		}
	}

	map<uint64_t, vec<Lit> > ::reverse_iterator im;

	int id = 0;
	int inputs_size = 0;
	int outputs_size = 0;

	for (im = weight_map.rbegin();im != weight_map.rend();im++) {
		uint64_t weight = (*im).first;
		vec<Lit> & inputs = (*im).second;
		inputs_size += inputs.size();
		vec<Lit>outputs;
#ifdef USE_CARD_ADDER
		CARD_ADDER_BASE*troot = genCardAdder(inputs, outputs, best_UB / weight, true);
#else
		TNode*troot = genCardinals(inputs, outputs, best_UB / weight, false);

#endif
		CARD_NODE*cn = new CARD_NODE(id, weight, inputs, weight_root, troot);
		outputs_size += outputs.size();
		weight_root->cards.push_back(cn);
		printf("c weight=%ld\n", weight);


		if (id == 0) {
			solver->add_weight_clause(weight_root);
		}
		id++;
		
		cn->attach_solver(*solver);
		//weight_root->recal(*solver);


		{	solver = rebuildSolver();
		solver->add_weight_clause(weight_root);
		for (int i = 0;i < weight_root->cards.size();i++) {
			CARD_NODE*cn = weight_root->cards[i];
			cn->attach_solver(*solver);


		}
		}

		
		weight_root->UB = best_UB;
		for (int i = 0;i < weight_root->cards.size();i++) {
			CARD_NODE*cn = weight_root->cards[i];
			cn->UB = -1;
			cn->tcount = 0;
		}
		
		set_UB(*solver, best_UB);
		bool ret = solve();
		assert(ret);
		uint64_t tsum = 0;

		uint64_t UB = weight_root->model_check(solver->model, tsum);
		
	

		while (ret) {
		//	if (id == weight_map.size())				solver->setPropBudget(100000000);
		//	else solver->setPropBudget(100000);
			ret = solve();
			if (ret) {

				//	if (id !=weight_map.size())
				UB = weight_root->model_check(solver->model, tsum);

				uint64_t costUB = computeCostModel(solver->model);

				if (costUB < best_UB) {
					//printf("o=%zd\n", costUB);
					upperbound = costUB;
					best_UB = upperbound;
					solver->saveModel();
					printf("o %" PRIu64 "\n", upperbound);
					//solver->model.copyTo(model);// = solver->model;
					//solver->save_model();
					weight_root->save_state();
				}


				if (!UB) break;
				vec<Lit> lits;
				
				ret = set_UB(*solver, UB - 1);
			


			}
			else {
				if (id == weight_map.size()) {

					break;
				}

				//solver->reset(model);
				if (0)
				{	solver = rebuildSolver();
				solver->add_weight_clause(weight_root);
				for (int i = 0;i < weight_root->cards.size();i++) {
					CARD_NODE*cn = weight_root->cards[i];
					cn->attach_solver(*solver);
					
					
				}
			//	weight_root->restore_state();
				}
				else {
			//		solver->restore_model();
			//		weight_root->restore_state();
				}
			//	set_UB(*solver, UB);
				
				success = model_practice();
			//	assert(success == l_True);
			//	solver->reset();
				break;
			}
		}
	}
	assert(nSoft() == inputs_size);
	//printf("Best UB=%zd conflicts=%d\n", best_UB, solver->conflicts);
	//printStats1(*solver, ts);


}
void MaxSAT::inc_search_total(uint64_t UB_) {



	best_UB = UB_;

	printf("c incsat o=%zd\n", best_UB);


	lbool success = model_practice();


	weight_root = new WEIGHT_AGGREGATE();
	weight_root->UB = best_UB;
	//weightを分類
	map<uint64_t, vec<Lit> > weight_map;
	for (int i = 0;i < nSoft();i++) {
		uint64_t w = softClauses[i].weight;
		map<uint64_t, vec<Lit> > ::iterator im = weight_map.find(w);
		Lit L = softClauses[i].assumptionVar;
		if (im == weight_map.end()) {
			vec<Lit> dummy;
			dummy.push(L);
			dummy.copyTo(weight_map[w]);// = dummy;
		}
		else {
			(*im).second.push(L);
		}
	}
	solver = rebuildSolver();
	map<uint64_t, vec<Lit> > ::reverse_iterator im;

	int id = 0;
	int inputs_size = 0;
	int outputs_size = 0;

	for (im = weight_map.rbegin();im != weight_map.rend();im++) {
		uint64_t weight = (*im).first;
		vec<Lit> & inputs = (*im).second;
		inputs_size += inputs.size();
		vec<Lit>outputs;
#ifdef USE_CARD_ADDER
		CARD_ADDER_BASE*troot = genCardAdder(inputs, outputs, best_UB / weight, true);
#else
		TNode*troot = genCardinals(inputs, outputs, best_UB / weight, false);

#endif
		CARD_NODE*cn = new CARD_NODE(id, weight, inputs, weight_root, troot);
		outputs_size += outputs.size();
		weight_root->cards.push_back(cn);
		printf("c weight=%ld\n", weight);


		if (id == 0) {
			solver->add_weight_clause(weight_root);
		}
		id++;

		cn->attach_solver(*solver);
		//weight_root->recal(*solver);


		{	
		solver->add_weight_clause(weight_root);
		for (int i = 0;i < weight_root->cards.size();i++) {
			CARD_NODE*cn = weight_root->cards[i];
			cn->attach_solver(*solver);


		}
	}


		weight_root->UB = best_UB;
		for (int i = 0;i < weight_root->cards.size();i++) {
			CARD_NODE*cn = weight_root->cards[i];
			cn->UB = -1;
			cn->tcount = 0;
		}
	}
		set_UB(*solver, best_UB);
		bool ret = solve();
		assert(ret);
		uint64_t tsum = 0;

		uint64_t UB = weight_root->model_check(solver->model, tsum);



		while (ret) {
			//	if (id == weight_map.size())				solver->setPropBudget(100000000);
			//	else solver->setPropBudget(100000);
			ret = solve();
			if (ret) {

				//	if (id !=weight_map.size())
				//UB = weight_root->model_check(solver->model, tsum);

				uint64_t costUB = computeCostModel(solver->model);

				if (costUB < best_UB) {
					//printf("o=%zd\n", costUB);
					upperbound = costUB;
					best_UB = upperbound;
					solver->saveModel();
					printf("o %" PRIu64 "\n", upperbound);
					//solver->model.copyTo(model);// = solver->model;
					//solver->save_model();
					weight_root->save_state();
				}


				//if (!UB) break;
				vec<Lit> lits;

				ret = set_UB(*solver, costUB - 1);



			}
			else {
				
				
				break;
			}
		
	}
	assert(nSoft() == inputs_size);
	//printf("Best UB=%zd conflicts=%d\n", best_UB, solver->conflicts);
	//printStats1(*solver, ts);


}

}
