/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
//#define SIMP_SOLVER

#define MAXSAT

#ifdef MAXSAT
#define CARD_CNT

#define ANA_CLEAR
#endif
#define USE_SKIP_WEIGHT


#define LEAVES_MAX_D (20)
#define USE_ASSUMPTION
#define TIME_OUT_MINUTES (4)
#define TIME_OUT_SECONDS_ON_DISJOINT_STEP (30)
#define TIME_OUT_SECONDS_ON_DISJOINT_STEP_LE2 (60)
#define CHB_THRESHOLD  (1500000)  
#define DOUBLE_REDUCE
#define TSUM
#define CORE_STRAT
#define CORE_STRAT_THRESHOLD (130000)
#define FORCE_SAT_SOLVING_THRESHOLD (15)
#define RATIO_THRESHOLD (0.158)
//#define WRITE_FILE
//#define RECAL_TRY

#define INC
#define HARDNING
//#define OLL
#define OLL2
#define OLL2_INC
#define NO_SEND_VSOFTCLAUSEC
#define OLL_LOWER
#define WPM_LOWER
//#define QUICK_SORT_ENABLE 
#define INC_OLL
#define Glucose Minisat
//#define Minisat Glucose
#define MINISAT
///#define USE_SEQ_LE
#define USE_OLL_MCU3
#define USE_OLL_MCU3_TOTALIZER
//#define USE_MO1
//#define CCMIN0
//#define NDEBUG
#define USE_OLL_MCU3_UNWEIGHT
#ifdef USE_OLL_MCU3_UNWEIGHT
#define SAT0
#define TO_SAT_TIME_STEP (1) //UNSAT BASE����SAT�@BASE�ɕύX����}�b�N�X����

#endif
//#define TRY2
//#define TRY1
#define APPLY_ASSUMPTION_TRY
//#define USE_CARD_SAT_UNWEIGHT
#ifdef USE_CARD_SAT_UNWEIGHT
#define USE_CARD_ADDER

#undef USE_OLL_MCU3_UNWEIGHT
//#undef TSUM
#endif
//#define USE_SAT_TOTAL
//#define USE_UNSAT
//#define NO_ANSER

#ifdef USE_CARD_ADDER
#define CCMIN1

#endif
