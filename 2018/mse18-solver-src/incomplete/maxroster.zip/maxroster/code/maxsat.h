/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#pragma once
#include "define.h"
#include "core/SolverTypes.h"
#include "simp/SimpSolver.h"
#include "mtl/Vec.h"
#include "ramp.h"
#include <stdio.h>
#include <vector>
#include <set>
#include <map>
#include <ostream>
#include <string>
using namespace std;
namespace Glucose {
	class Solver;
	class SimpSolver;
	class VSoftClauseBase;
	struct CARD_NODE;
	struct WEIGHT_AGGREGATE;
	struct CARD_ADDER;
	struct CARD_ADDER_BOTTOM;
	
	class CardinalityConstraint {
		friend ostream& operator<<(ostream& out, const CardinalityConstraint& cc) { return out << cc.toString(); }
	public:
		inline CardinalityConstraint() : bound(0) {}
		inline CardinalityConstraint(CardinalityConstraint& cc) : bound(cc.bound), loosable(cc.loosable) { cc.lits.moveTo(lits); }
		~CardinalityConstraint() { lits.clear(); trail.clear(); }

		inline void clear() { lits.clear(); bound = 0; }
		string toString() const;

		inline int size() const { return lits.size(); }
		inline void shrink_(int n) { lits.shrink_(n); }
		inline void pop() { lits.pop(); }

		vec<Lit> lits;
		int bound;
		int loosable;
		vec<Lit> trail;
	};
	
	class Hard {

	public:
		Hard(vec<Lit>& hard) {
			hard.copyTo(clause);
		}

		Hard() {}
		~Hard() {}

		vec<Lit> clause;        // Hard clause

	};

	class Soft {

	public:
		Soft(vec<Lit>& soft, uint64_t w) {
			soft.copyTo(clause);
			oweight = w;
			weight = w;
			splited = false;
			if (w != weight) assert(0);

		}
		Soft(vec<Lit>& soft, uint64_t w, Lit as, vec<Lit> &relax) {
			soft.copyTo(clause);
			weight = w;
			assumptionVar = as;
			splited = false;
#if defined (USE_WBO) || defined (USE_MSU3)
			relax.copyTo(relaxationVars);
#endif
		}
		void set_split()
		{
			splited = true;
		}
		Soft() {
			splited = false;
		
		}
		~Soft() {
			clause.clear();
#if defined(USE_WBO) || defined (USE_MSU3)
			relaxationVars.clear();
#endif
		}

		vec<Lit> clause;         // Soft clause
		uint64_t weight;              // Weight of the soft clause
		uint64_t oweight;
		Lit assumptionVar;       // Assumption variable used for retrieving the core
		bool splited;
#if defined(USE_WBO) || defined (USE_MSU3)
		vec<Lit> relaxationVars;
#endif

	};
	typedef struct abc {
		int sigma;
		int alpha;
		int beta;
		abc() {
			sigma = 0;
			alpha = 0;
			beta = 0;

		}
		abc(int s, int a, int b) {
			sigma = s;
			alpha = a;
			beta = b;

		}
		bool operator ==(const struct abc &a)const {
			if (sigma == a.sigma && alpha == a.alpha && beta == a.beta) return true;
			else return false;

		}
		bool operator < (const struct abc& a)const {

			if (sigma> a.sigma) return false;
			else if (sigma< a.sigma) return true;
			else if (alpha>a.alpha) return false;
			else if (alpha<a.alpha) return true;
			else if (beta>a.beta) return false;
			else if (beta<a.beta) return true;
			return false;//==

		}


	};
class TNode {

public:
	TNode() {
		left = 0;
		right = 0;
		base = 0;
	}
	TNode(TNode*left_, TNode*right_, vec<Lit> & link_vec,vec<Lit>&inputs_,  int UB_) {
		left = left_;
		right = right_;
		inputs_.copyTo(inputs);
		for (size_t i = 0;i< link_vec.size();i++) {
			linkingVar.push(link_vec[i]);
		}
	
	
		UB = UB_;
		base = 0;
		imax = 0;
	}
	~TNode() {
		if (left) delete left;
		left = 0;
		if (right) delete right;
		right = 0;


	}
	
	void detach_pos_port(Solver&S, CRef cr);
	void attach_pos_port(Solver&S, CRef cr);
	int get_unsatisfied_litrals(Solver&S);
	void save_state() {}
	void restore_state(){}

	void set_left(TNode* l) { left = l; }
	void set_right(TNode*r) { right = r; }

//vsoft_clause
	void set_base(VSoftClauseBase*);
	int get_lb();

	void print(MaxSAT&maxsat);

	void print() {
		printf("%x", this);
		
		for (int i = 0;i< linkingVar.size();i++) {
			printf("%d ", linkingVar[i]);
		}
		printf("\n");
		if (left) {
			left->print();
		}
		if (right) {
			right->print();
		}

	}
	void set_RHS(int RHS) {
		if (RHS < inputs.size()&& RHS>UB) {
			UB = RHS;
		}
	}
	void print_values(MaxSAT&maxsat, int level);

/*	int print_values(Solver&S,int level) {
		string s = "";
		int tcount = 0;
		for (int i = 0;i < linkingVar.size();i++) {
			Var v = var(linkingVar[i]);
			if (S.value(v) == l_True) {
				s += "1";
				tcount++;
			}
			else if (S.value(v) == l_False) {
				s += "0";
			}
			else s += "z";
		}
	//	if (((!left && !right) || level==0) && tcount)
		
		int left_count = 0;
		int right_count = 0;
		if (left) left_count=left->print_values(S,level+1);
		if (right) right_count=right->print_values(S,level+1);
		if ((left_count + right_count) > tcount) {
			printf("Level=%d %d:%s L=%d R=%d\n", level, tcount, s.c_str(), left_count, right_count);
			if (left_count) printf("left[0]=%x\n", left->linkingVar[0].x);
			if (right_count) printf("left[0]=%x\n", right->linkingVar[0].x);

		}
		return tcount;
	}
	*/

	int imax;
	std::set<abc> abc_set;

	TNode* left;
	TNode* right;
	
	vec <Lit> linkingVar;
	vec <Lit> inputs;
	VSoftClauseBase* base;

	int UB;

};
class VSoftClauseBase{
		public:
			enum Type{AssumptionVar,Constraint,MCU3,SEQ_CONSTRAINT,SEQ_MOST_ONE,VSUM};

			VSoftClauseBase(Lit L_,uint64_t w,int i){
				L=L_;
				type=AssumptionVar;
				RHS=0;	
				weight = w;
				idx = i;
				id = -1;
			}
			VSoftClauseBase() {
				L = lit_Undef;
				type = Constraint;
				RHS = 0;
				weight = 0xffffffffffffffffUL;// _UI64_MAX;
				idx = 0;
				id = -1;
			}
			virtual int get_lowerbound() { return 0; }
			virtual void set_lowerbound_to_clause(MaxSAT&maxsat) {}
			void set_id(int i) { id = i; }
			int get_id() const { return id; }
			virtual bool is_orig() { return false; }
			virtual int value_check(MaxSAT&maxsat,int& inputs) { return 0; }
			virtual void value_check(MaxSAT&maxsat) {  }
			virtual void send_clause(MaxSAT&maxsat);
			void updateRHS(){ RHS++;}
			bool is_hard() {
				if (type == AssumptionVar && RHS) return true;
				else return false;
			}
			bool has_weight() { return weight!=0; }
			virtual void set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions); 
			virtual void rebuild(MaxSAT&maxsat){}
			virtual Lit get_lit(int n) { assert(n == 0); return L; }
			virtual int get_n(Lit L) {  return 0; }
			virtual VSoftClauseBase* split_weight(MaxSAT&maxsat,uint64_t weight,bool inc=false);
			virtual Lit get_most_lit() { assert(0); return lit_Undef; }

			Lit L;
			Type type;
			int RHS;
			int idx;
			int id;
			uint64_t weight;


};	
struct VSoftCardLit {
	VSoftCardLit(VSoftClauseBase*b,unsigned n) {
		base = b;
		no = n;
	}
	VSoftCardLit() {
		base = 0;
		no = 0;
	}
	
	VSoftClauseBase* base;
	unsigned no;

};
class MaxSAT;
class SeqLE;
class SeqLEMo1;
class VSoftClauseSeqLE;
class VSumC;
class VSoftPM :public VSoftClauseBase {
	public:

		VSoftPM(MaxSAT&maxsat,TNode*t,int RHS_);
		VSoftPM(MaxSAT&maxsat, VSoftPM*p, TNode*t,int target_UB=0);
		VSoftPM(MaxSAT&maxsat, TNode*t);
		int get_lowerbound() { return lowerbound; }
		void set_lowerbound(int t) { lowerbound = t; }
	void set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions);
	void update_RHS(MaxSAT&maxsat);
	void update_RHS(MaxSAT&maxsat,TNode*right);
	TNode* troot;
	int lowerbound;
	

};

class VSoftClauseC :public VSoftClauseBase {

	public:

	

		VSoftClauseC(MaxSAT&maxsat, TNode*t, int64_t weight_, int RHS_);
		VSoftClauseC(MaxSAT&maxsat, vec<VSoftClauseC*>&vc_vec,vec<VSoftClauseBase*>& vb_vec, int64_t weight_);
		VSoftClauseC(MaxSAT&maxsat, vec<VSoftClauseBase*>&vb_vec, int64_t weight_,int lowerbound_=0,bool gen_troot=true);
		VSoftClauseC(MaxSAT&maxsat,int64_t weight_, vec<VSoftClauseBase*>&vb_vec );
		
		int get_unsatisfied_litrals(Solver&S) {
			return troot->get_unsatisfied_litrals(S);
		}
		void value_check(MaxSAT&maxsat);
		void set_lowerbound_to_clause(MaxSAT&maxsat);
		void gen_cardinals(MaxSAT&maxsat,int UB);

		virtual Lit get_most_lit() {
			if (troot->linkingVar.size() >= RHS) {
				return troot->linkingVar[RHS - 1];
			}
			return lit_Undef;
		}
		bool is_updated() { return RHS > 1; }
		void set_orig() { orig = true; }
		void reset_orig() { orig = false; }
		bool is_orig() { return orig; }

	bool is_troot_parent() { return vclauses.size(); }
	void merge_cardinals(MaxSAT&maxsat, vec<VSoftClauseBase*> &vc);
	void updateRHS(MaxSAT&maxsat);
	int get_lowerbound() { return lowerbound; }
	void rebuild(MaxSAT&maxsat);
	void set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions);
	virtual VSoftClauseBase* split_weight(MaxSAT&maxsat, uint64_t weight,bool inc=false);
	//void set_vsumc_parent(VSumC*c) { vsumc_parent = c; }
	//VSumC* get_vsumc_parent() { return vsumc_parent; }
	TNode* troot;
	vec<VSoftClauseBase*> vclauses;
	//VSumC* vsumc_parent;
	bool orig;
	int lowerbound;
};
class VSumC :public VSoftClauseBase {
public:

	VSumC(MaxSAT&maxsat, VSumC* old_, int64_t weight_, int RHS_, VSoftClauseC* input_);


	void set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions);
	virtual Lit get_most_lit() {
		if (troot->linkingVar.size() >= RHS) {
			return troot->linkingVar[RHS - 1];
		}
		return lit_Undef;
	}
	void updateL() {
		if (troot->linkingVar.size() > RHS) L = troot->linkingVar[RHS];
		else L = lit_Undef;
		if (old) old->updateL();
	}
	void updateRHS(MaxSAT&maxsat);
	void updateRHS(MaxSAT&maxsat, int RHS_);
	int set_RHS(MaxSAT&maxsat, int maxRHS);
	
	VSoftClauseC* input;
	TNode* troot;
	VSumC* old;
	int lowerbound;

};
class VSoftClauseSeqLE :public VSoftClauseBase {

public:



	VSoftClauseSeqLE(MaxSAT&maxsat, SeqLE*t, int64_t weight_, int RHS_);
	VSoftClauseSeqLE(MaxSAT&maxsat, vec<VSoftClauseSeqLE*>&vc_vec, vec<VSoftClauseBase*>& vb_vec, int64_t weight_);
	void updateRHS(MaxSAT&maxsat, int K);
	virtual Lit get_most_lit();
	


	void set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions);
	virtual VSoftClauseBase* split_weight(MaxSAT&maxsat, uint64_t weight, bool inc = false);
	SeqLE* seq;
	vec<VSoftClauseBase*> vclauses;

};
class VSoftClauseSeqLEMo1 :public VSoftClauseBase {

public:


	VSoftClauseSeqLEMo1(MaxSAT&maxsat, SeqLEMo1*t, int64_t weight_);
	VSoftClauseSeqLEMo1(MaxSAT&maxsat, VSoftClauseBase*parent_, vec<VSoftClauseBase*>& vb_vec, int64_t weight_);

	void rebuild(MaxSAT&maxsat);
	bool is_root() { return !sub; }
	VSoftClauseSeqLEMo1*split_clause(MaxSAT&maxsat, vec<Lit> &v);
	int value_check(MaxSAT&maxsat,int &inputs);
	void set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions);
	virtual VSoftClauseBase* split_weight(MaxSAT&maxsat, uint64_t weight, bool inc = false);
	Lit get_most_lit();
	SeqLEMo1* seq;
	vec<VSoftClauseBase*> vclauses;
	VSoftClauseBase* parent;
	bool sub;

};


class VSoftClause:public VSoftClauseBase{
	
		public:		
			VSoftClause(vec<VSoftCardLit> &e_,int64_t weight_){
				weight = weight_;
				e_.copyTo(elements);
				troot = 0;
				RHS = 1;
			}		
			void rebuild(MaxSAT&maxsat);
			
			Lit get_lit(int n) {
				if (!troot) return lit_Error;
				if (troot->linkingVar.size() <= n) return lit_Error;
				return troot->linkingVar[n];

			}
			int get_n(Lit L) {
				if (!troot) {
					assert(0);
					return -1;
				}else {
					for (int i = 0;i < troot->linkingVar.size();i++) {
						if (L == troot->linkingVar[i]) return i;
					}
					assert(0);
					return -1;
				}

			}
			void set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions);
			virtual VSoftClauseBase* split_weight(MaxSAT&maxsat, uint64_t weight);

			TNode*troot;
			vec<VSoftCardLit> elements;
		
	};	
class SeqLE {
public:
	SeqLE(MaxSAT&maxsat,vec<Lit>inputs_, int K_);
	SeqLE() {}
	void genK_constraints(MaxSAT&maxsat,int K);
	void add_clause(MaxSAT&maxsat,Lit L1, Lit L2,Lit L3);
	void add_clause(MaxSAT&maxsat,Lit L1,Lit L2);
	void add_clause(MaxSAT&maxsat,Lit L);
	Lit drawS(MaxSAT&ma,int i, int j);
	Lit drawi(int i);
	void allocate_vars(MaxSAT&maxsat,int K_);
	void updateK(MaxSAT&maxsat,int K_);
	virtual void set_assumption(vec<Lit>&assumption) {}
	virtual Lit get_most_lit();

	int K;
	vec<Lit> inputs;
	vec<vec<Lit> > ovec;
	vec<Lit> output_var_vec;
 };

class SeqLEMo1:public SeqLE
{
public:
	
	SeqLEMo1(MaxSAT&maxsat, vec<Lit>inputs_);
	SeqLEMo1(vec<Lit> inputs_,vec<vec<Lit> > ovec_,vec<Lit> out) {
		K = 2;
		inputs_.copyTo(inputs);
		ovec_.copyTo(ovec);
		out.copyTo(output_var_vec);
	}
	void set_assumption(MaxSAT&maxsat, VSoftClauseSeqLEMo1*mo,vec<Lit>&assumptions);
	void rebuild(MaxSAT&maxsat,bool alloc=true);
	Lit get_most_lit() { return output_var_vec[0]; }
	SeqLEMo1* splitClause(Lit first);
	int value_check(MaxSAT&maxsat,int & inputs);
};

class MaxSAT {

public:

	enum TYPE { _UNWEIGHTED_ = 0, _WEIGHTED_ };
	enum CONFLICT_TYPE { ASSUMPTION_ONLY, HAS_VSUM, ASSUMPTIONS_AND_CONSTRAINTS };
	enum DISJOINT_STATUS { NOT_SAT, ONCE_SAT, DISJOINT_DONE };
	

	MaxSAT() {


		clear();
	}

	~MaxSAT() {
		if (solver) delete solver;

	}
	CONFLICT_TYPE ctype;
	
	int nVars();                                        // Number of variables.
	int nSoft();                                        // Number of soft clauses.
	int nHard();                                        // Number of hard clauses.
	void newVar();                                      // New variable.

	void addHardClause(vec<Lit>& lits);                              // Add a new hard clause.
	void addSoftClause(uint64_t weight, vec<Lit>& lits);                  // Add a new soft clause.
	void addSoftClause(uint64_t weight, vec<Lit>& lits, vec<Lit>& vars);  // Add a new soft clause with predefined relaxation variables.  
	Lit newLiteral(bool sign = false);                               // Make a new literal.
	Lit newLiteral_not_decided(bool sign = false);
	void setProblemType(TYPE type);                      // Set problem type.
	TYPE getProblemType();                               // Get problem type.

	void updateSumWeights(uint64_t weight);                  // Update initial 'ubCost'.
	void setCurrentWeight(uint64_t weight);                  // Set initial 'currentWeight'.
	void setHardWeight(uint64_t weight);                     // Set initial 'hardWeight'.
	void setInitialTime(double initial);                // Set initial time.
	void timer_start();
	void readfile();
	virtual void search();                              // MaxSAT search.
	
	void inc_search(uint64_t UB_);
	void inc_search_total(uint64_t UB_);
	void oll2_search_inc(uint64_t UB);
	void unweight_search();
	void unweight_card_search();
	void oll2_search_oll_mcu3(uint64_t UB);
	void value_check();
	void wpm3_search_inc(uint64_t UB);
	void sat_search(uint64_t UB);
	void sat_search_oll();

	uint64_t oll_lowerbound_search(uint64_t UB);
	uint64_t oll_lowerbound_search_inc(uint64_t UB);
	uint64_t wpm_lowerbound_search_inc(uint64_t UB);

	void make_oll_weight_map();

	void write_file();
	void open_file();
	void weight_sat_search();
	void unweight_unsat_search();
	void totalizer_weight_unsat_search_incremental();
	void wpm3();
	void wpm3_noninc();
	uint64_t computeCostCore(vec<Lit> &conflict);
	uint64_t computeCostCore2(vec<Lit> &conflict);
	CARD_NODE* computeMinCardNode(vec<Lit> &conflict);
	CARD_NODE* computeMinCardNode_lit(vec<Lit> &conflict);
	vec<CARD_NODE*> computeMinCardNode_vec(vec<Lit> &conflict, uint64_t minW);
	uint64_t get_card_min_weight(vec<Lit> &conflict);
	void core_analysis(vec<Lit> & conflict, vec<Lit>& assumptions, vec<bool>& active);
	uint64_t core_analysis_noninc(vec<Lit> & conflict, vec<Lit>&assumptions, vec<bool>& active);
	uint64_t core_analysis_noninc_lit(vec<Lit> & conflict, vec<Lit>&assumptions, vec<bool>& active);
	uint64_t core_analysis_oll(vec<Lit> & conflict, vec<Lit>&assumptions, bool gen_vsoft_clause = true);
	uint64_t core_analysis_oll2(vec<Lit> & conflict, vec<Lit>&assumptions);
	uint64_t core_analysis_oll2_inc(vec<Lit> & conflict, vec<Lit>&assumptions, bool free_phase = false);
	uint64_t core_analysis_oll2_seq_inc(vec<Lit> & conflict, vec<Lit>&assumptions, bool free_phase = false);
	uint64_t core_analysis_oll2_oll_mcu3(vec<Lit> & conflict, vec<Lit>&assumptions, bool free_phase = false);
	uint64_t core_analysis_oll2_oll_mo1(vec<Lit> & conflict, vec<Lit>&assumptions, bool free_phase = false);
	uint64_t core_analysis_oll2_oll_mcu3_unweight(vec<Lit> & conflict, vec<Lit>&assumptions, bool free_phase = false);
	void unweighted_non_repeat_search();
	void unweighted_vclause_sat_search(int UB);
	void mcu3_set_assumptions(vec<Lit>&assumptions);

	uint64_t core_analysis_wpm3_inc(vec<Lit> & conflict, vec<Lit>&assumptions, bool free_phase = false);
	uint64_t unweighted_disjoint_core_analysis_mcu3(vec<Lit> & conflict, vec<Lit>&assumptions);

	uint64_t findNextWeight(uint64_t w);
	void updateCurrentWeight();
	uint64_t findNextWeightDiversity(uint64_t w);

	void get_weight_lits(vec<Lit>& conflict, map<uint64_t, vec<Lit> > & weight_lits, uint64_t minW, vec<bool>&active);

	void weight_sat_search_incremental();
	uint64_t free_search();
	uint64_t disjoint_search();
	uint64_t non_repeat_search(std::set<Lit> & conflict_set);
	uint64_t weight_search(uint64_t ucost);
	uint64_t weight_search_bmo();

	lbool model_practice(bool use_assumption=false);
	bool isBMO(bool catche);




	void add_most_one(Solver&S, vec<Lit>&inputs);

	void printAnswer(int type);                         // Print the answer.

	void show_activity();
	Var get_next_var();
	void normalSearch();
	int get_assumptions(int counter, vec<Lit> & assumptions);
#ifdef SIMP_SOLVER
	SimpSolver*rebuildSolver(bool send_soft = true);
#else
	Solver*rebuildSolver(bool send_soft = true);
#endif	
	void send_clauses(Solver*S, bool send_soft = true);

	void initRelaxation();
	void initAssumptions();

	bool assumption_UB(int K, set<Lit>& conflict_set);



	//Totalizer

	void create_weight_instance(uint64_t UB, bool create_card_adder = true, bool send = false);
	void create_unweight_instances(unsigned UB, bool create_card_adder = true, bool send = false);
	void create_unweight_instances_vclause(unsigned UB);
	void create_unweight_instances_oll(uint64_t& UB);
	void create_unweight_instances_oll();

	Lit gen_one_output(Lit L);
	void attach_solver(Solver&S);

	void convert_weight_map(map<unsigned, vec<Lit> > & Map);
	void gen_weight_vec(Solver&S);
	TNode* genCardinals(vec<Lit> & from_to, vec<Lit> &linkingVar, unsigned UB, bool send_lator = true);
	void   GenCardinals(vec<Lit> & from_to, vec<Lit> &linkingVar, uint64_t UB);
	void   GenCardinalsLeftRight(vec<Lit> & left, vec<Lit>&right, vec<Lit> &linkingVar, uint64_t UB);

	CARD_ADDER_BASE*genCardAdder(vec<Lit> & from_to, vec<Lit> &linkingVar, unsigned UB, bool send = false);
	TNode* genPT_layer(TNode*left, TNode*right, vec<Lit> & from_to, vec<Lit> &linkingVar, unsigned UB, bool send_later = true);
	TNode* gen_arranged_copy(TNode*left,unsigned UB);

	TNode* mergeCardinals(TNode*right, TNode*left, vec<Lit> &linkingVar, unsigned UB);

	void  extend_UB(TNode* node, unsigned newUB);

	void add_core(map<uint64_t, vec<Lit> > &weight_cores);
	void totalizer_add_core(map<uint64_t, vec<Lit> > &weight_cores);
	void  extend_UB(Solver&S, CARD_ADDER_BASE* node, unsigned newUB);

	CARD_ADDER_BASE*genCardAdder(int depth, vec<Lit>&core, uint64_t UB, CARD_ADDER*old_root = 0);
	CARD_ADDER_BOTTOM*genCardBottom(vec<Lit>&core, uint64_t UB);
	Lit new_literal();


	TNode* merge_cardinals(vec<VSoftClauseC*>& v, int UB);
//for debuggging	
	FILE * test_f;
	string test_file;

	void add_clause(Lit);
	void add_clause(Lit, Lit);
	void add_clause(Lit, Lit, Lit);
	vec<Lit> outputs;
	vec<Lit> relax_variabls;
	vec<int> not_decided_variables;

	std::map<int, int> relax_index_map;

	enum STRATEGY { RAMP, FREE_SAT, DISJOINT };
	STRATEGY sofar_best_strategy;

	std::vector<vec<Lit > > cores;
	vec<Lit> failed_lits;//computeCostModelで格納
	string filename;
	int64_t best_UB;
	int nbofCurrentSoft;
	RAMP::Ramp *ramp;
	VSumC*last_vsumc;
	DISJOINT_STATUS disjoint_status;
	bool model_saving;
	bool print_model;
	bool get_model_saving() const { return model_saving; }
	void set_model_saving() { model_saving = true; }
	void reset_model_saving() { model_saving = false; }
	void print_model_enable() { print_model = true; }
	bool use_simp;
	void clear() {
		test_f = 0;
		print_model = false;
		reset_model_saving();
		disjoint_status = NOT_SAT;
		nbVars = 0;
		hardWeight = UINT64_MAX;
		problemType = _UNWEIGHTED_;

		nbSoft = 0;
		nbHard = 0;
		use_simp=false;

		currentWeight = 1;

		ubCost = UINT64_MAX;
		lbCost = 0;

		// Statistics
		nbSymmetryClauses = 0;
		nbCores = 0;
		nbSatisfiable = 0;
		sumSizeCores = 0;


		weight_root = 0;


		outputs.clear();
		relax_variabls.clear();
		model.clear();
		solver = 0;
		nbInitialVariables = 0;
		nbInitialVariablesB = 0;
		card_id = 0;
		best_UB = -1L;
		ramp = 0;
		last_vsumc = 0;
	}
	void clear2() {
		disjoint_status = NOT_SAT;
		//nbVars = 0;
		outputs.clear();
		relax_variabls.clear();
		model.clear();
		if (solver) delete solver;
		solver = 0;
		//	assumptions.clear();
		last_vsumc = 0;
	}
#ifdef SIMP_SOLVER
	 SimpSolver*solver;
#else
	 Solver * solver;
#endif
	int nbr_of_relaxed_variables;
	int nbInitialVariables;
	vec<Soft> softClauses;                              // Stores the soft clauses of the MaxSAT formula.
	vec<Hard> hardClauses;                              // Stores the hard clauses of the MaxSAT formula.   
	vec<lbool> model;   													//
	uint64_t hardWeight;                                     // Weight of the hard clauses.
	bool set_UB(Solver&S, uint64_t K);
	VSoftClauseBase*get_vsoft_clause_base(int id) {
		assert(id < vsoft_clauses.size());
		return vsoft_clauses[id];
	}
	lbool   solveLimited (const vec<Lit>& assumps){
		if (use_simp){
			SimpSolver*ss=dynamic_cast<SimpSolver*>(solver);
			return ss->solveLimited(assumps);
		}		
		return solver->solveLimited(assumps);
	}
		
		uint64_t get_next_weight(uint64_t weight);
		uint64_t ramp_seach(int timeout);

		//core strat
		void core_strat_search(uint64_t);
		uint64_t computeCostModel();
		void ub_check(vec<lbool>&Model) {
			uint64_t cost = computeCostModel(Model);
			assert(cost == best_UB);
		}
		void updateUpperBound();
		void updateLowerBound(int64_t );
		lbool progressionMinimize(int64_t limit);
		
		lbool trim();
		lbool sat_solve(double t=10000); 
		void removeSoftLiteralsAtLevelZero();
		lbool core_strat_search_main();
		void hardening();
		void setAssumptions(int64_t limit);
		int64_t computeConflictWeight() const;
		int64_t computeNextLimit(int64_t limit) const;
		bool addConstraint(CardinalityConstraint& cc);
		void (MaxSAT::*corestrat)(int64_t);
		void corestrat_one(int64_t limit);
		void corestrat_one_neg(int64_t limit);
		void corestrat_kdyn(int64_t limit);
		void corestrat_pmres(int64_t limit);

		//oll
		CONFLICT_TYPE get_conflict_type(vec<Lit> &conflicts,vec<VSoftClauseBase*> & cvec);
		void conflict_minimize(vec<Lit>&conflicts);
		void conflict_minimize(vec<Lit>& conflicts, vec<VSoftClauseBase*>& cvec,bool do_trim=true);
		void minimize_upperbound_oll();

		lbool progressionMinimize(int64_t limit, vec<Lit>&conflict);
		void add_vsoft_clause(VSoftClauseBase*v) { 
			assert(v->get_id() == -1);
			v->set_id(vsoft_clauses.size());
			vsoft_clauses.push(v); }
		VSoftClauseC *get_orig_vsoft_clause(uint64_t cost);

		void add_vsoft_clause_map(Lit L, VSoftClauseBase*v) { vsoft_clause_map[L] = v; }
		lbool oll_sat_check();
		uint64_t get_min_weight_in_vsoft_clauses() {
			uint64_t w = 0xffffffffffffffffUL;//_UI64_MAX;
			for (int i = 0;i < vsoft_clauses.size();i++) {
				if (vsoft_clauses[i]->is_hard());
				else {
					if (w <= vsoft_clauses[i]->weight);
					else {
						w = vsoft_clauses[i]->weight;

					}
				}

			}
			return w;
		}
		uint64_t get_min_weight_in_vsoft_clauses2() {
			uint64_t w = 0xffffffffffffffffUL;// _UI64_MAX;
			for (int i = 0;i < vsoft_clauses.size();i++) {
				if (!vsoft_clauses[i]->has_weight());
				else {
					if (w <= vsoft_clauses[i]->weight);
					else {
						w = vsoft_clauses[i]->weight;

					}
				}

			}
			return w;
		}

		void set_oll_assumptions(vec<Lit>&assumptions,bool gen_vsoft_clause=true);
		void set_oll2_assumptions(vec<Lit>&assumptions);
		void set_disjoint_core_assumptions(vec<Lit>&assumptions);

		void set_oll2_assumptions_free_phase(vec<Lit>&assumptions);
#ifdef SIMP_SOLVER
		SimpSolver*rebuildSolveroll();
#else
		Solver* rebuildSolveroll();
#endif
		void send_soft_clauses();
	bool addClause(vec<Lit> & lits){
			if (use_simp ){
				SimpSolver*ss=dynamic_cast<SimpSolver*>(solver);	
				 return ss->addClause(lits);
			}	 
			return solver->addClause(lits);	
			;
		}	
		bool addClause(Lit L){
			vec<Lit> lits;
			lits.push(L);
			return addClause(lits);	
			
		}	
		uint64_t compute_min_oll_cost(vec<Lit>& conflict);
		uint64_t computeCostModel_oll(vec<lbool> &currentModel);
		void trim(vec<Lit>& conflict);
		uint64_t find_next_weight_oll();
		void newSATVariable(Solver *S); // Creates a new variable in the SAT solver.
		VSoftPM* get_VSoftPM() {
			for (int i = 0;i < vsoft_clauses.size();i++) {
				if (vsoft_clauses[i]->type == VSoftClauseBase::Constraint) return dynamic_cast<VSoftPM*>(vsoft_clauses[i]);

			}
			return 0;


		}
		void add_tnode_clause(vec<Lit> &lits) {
			tnode_clauses.push(lits);

		}
		void printModel();
		int64_t lowerbound;
  protected:
	  int orderWeights_size;
	  uint64_t currentWeight,maxWeight;
    // MaxSAT database
     // Number of variables of the initial MaxSAT formula.
	 int nbInitialVariablesB;
	 int card_id;
	 vec<vec<Lit> > tnode_clauses;
	
	vec<Lit> assumption_lits;
	map<uint64_t, int> count_map;
	map<uint64_t, int> initial_weight_map;

    // Interface with the SAT solver
    //
	void count_map_initialize();
	void create_initial_weight_map();
	bool judge_use_of_core_strat();

    Solver * newSATSolver();                                                      // Creates a SAT solver.
   
	void newSATVariable_not_decided(Solver*S);
	bool solve(){
		if (use_simp){
			SimpSolver*ss=dynamic_cast<SimpSolver*>(solver);	
			 return ss->solve();
		}else {
			return solver->solve();
		}		
	}	
	lbool searchSATSolver(Solver *S, vec<Lit>& assumptions, double timeout=100000.0);     // Solves the formula that is currently loaded in the SAT solver.
	void unsat_linear_search();
	void UNSAT_linear_search();
	
	std::map<Lit, int> coreMapping;                      // Maps the assumption literal to the number of the soft clause.
	//vec<Lit> assumptions;                               // Stores the assumptions to be used in the extraction of the core.
	std::set<int> relaxed_soft_set;
	std::set<int> relaxed_delta_set;

	//oll
	vec<VSoftClauseBase*> vsoft_clauses;
	std::map<Lit, VSoftClauseBase*> vsoft_clause_map;

    // Properties of the MaxSAT formula 
    //
  
    TYPE problemType;                                    // Stores the type of the MaxSAT problem.
    int nbVars;                                         // Number of variables used in the SAT solver.
    int nbSoft;                                         // Number of soft clauses.
    int nbHard;                                         // Number of hard clauses.
   
                                  // Stores the best satisfying model.

    // Statistics
    //
    int nbCores;                                        // Number of cores.
    int nbSymmetryClauses;                              // Number of symmetry clauses.
    uint64_t sumSizeCores;                              // Sum of the sizes of cores.
    int nbSatisfiable;                                  // Number of satisfiable calls.

    // Bound values
    //
    uint64_t ubCost;                                    // Upper bound value.
    uint64_t lbCost;                                    // Lower bound value.

    // Others
    
    double initialTime;                                 // Initial time.
    int verbosity;                                      // Controls the verbosity of the solver.
	//core strat
	int64_t upperbound;
	
	vec<Lit> assumptions;
	vec<Lit> softLiterals;
	map<Var, int64_t> weights;
	vec<Lit> conflict;
    // Utils for model management
    //
    void saveModel(vec<lbool> &currentModel);                                     // Saves a Model.
    uint64_t computeCostModel(vec<lbool> &currentModel, bool model_comp=false);  // Compute the cost of a model.
	

	void get_hitting_set(vec<lbool> & model, std::map<int, int>& rev_map, std::vector<int>&hittingSet);

	WEIGHT_AGGREGATE*weight_root;
    // Utils for printing
    //
                                    // Print the best satisfying model.
														// Greater than comparator.
	bool static greaterThan(int i, int j) { return (i > j); }
	
  };
}
