#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#ifdef _WIN32
#include <time.h>
#else
#include <sys/times.h> //these two h files are for linux
#include <unistd.h>
#endif
#include <string.h>
#include <climits>
#include <ctime>

#include "myHeap.h"

#include "ramp.h"

using namespace std;
int main(int argc, char* argv[]) {
	RAMP::Ramp* ramp = new RAMP::Ramp();


	return ramp->main(argc, argv);


}