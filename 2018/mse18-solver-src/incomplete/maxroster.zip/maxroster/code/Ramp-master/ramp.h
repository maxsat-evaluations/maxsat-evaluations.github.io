#pragma once
#include <stdint.h>
#include "define.h"
#include "mybijection.h"

#define ans_op_mode

#define reset_mode

//#define dec_hard_weight_mode

#define bad_var_cscc_mode

#define score_make_mode

//#define unlock_all_neighbor_mode
//#define unlock_add_to_1_mode
//#define unlock_mis_to_0_mode

//#define age_init_0
#define age_init_i
typedef int64_t LL;

// Define a data structure for a literal in the SAT problem.
struct lit 
{
  
    int var_num;		//variable num, begin with 1
	int clause_num :24;		//clause num, begin with 0
    int sense  :8;			//is 1 for true literals, 0 for false literals.
};
namespace Minisat {
	class MaxSAT;

}
namespace RAMP{
	class HeapGreedyCand;

class Ramp{
public:
	Ramp() {
		second1= 1000000.0;
		time_convergence = 3.0;
		time_limit = 6;
		comp_time = 0.0;
		rx = 1;
	}

	int seed = 10;;
	double second1;
	long rx  ;
	int rand() { rx = rx* 214013 + 2531011; return(int)(rx >> 16) & 32767; }


	void srand(long s) { rx = s;  }

	//Visual C++           A = 214013, C = 2531011, F = 0, S = 1�B

int time_limit ;//295;
const int print_speed = 50000;
double time_convergence ;
int answer_writed = 0;

int flag_weighted = 0;

#ifdef bad_var_cscc_mode
Bijection *ptr_to_bad_var;
int greedy = 1;
#endif

//cutoff
LL  max_flips = 20000000000000ll;
LL	flip_bound = 0;
LL 	step = 1;
int trie = 1;

#ifdef last_second_flip_time_mode
LL *last_second_flip_time;
#endif

#ifdef dec_hard_weight_mode
LL last_achieved_weight_unsat;
#endif


/*parameters of the instance*/
int     var_n;		//var index from 1 to var_n
int     clause_n;	//clause index from 0 to clause_n-1

/* literal arrays */				
lit**	var_lit;//[MAX_VARS];				//var_lit[i][j] means the j'th literal of var i.
int*	var_lit_count;//[MAX_VARS];        //amount of literals of each var
lit**	clause_lit;//[MAX_CLAUSES];		//clause_lit[i][j] means the j'th literal of clause i.
int*		clause_lit_count;//[MAX_CLAUSES]; 	// amount of literals in each clause			
			
/* Information about the variables. */
LL*     score;//[MAX_VARS];				
LL*		last_flip_time;//[MAX_VARS];
//int*		conf_change;//[MAX_VARS];
int**	var_neighbor;//[MAX_VARS];
int*		var_neighbor_count;//[MAX_VARS];

/* Information about the clauses */	
LL weight_unsat_best;
double time_best = 0;
LL step_best = 0;
int trie_best = 0;
LL weight_unsat;
LL weight_hard;
LL*     weight;//[MAX_CLAUSES];		
int*    sat_n;//[MAX_CLAUSES];			
int*	sat_var;//[MAX_CLAUSES];
int p1 = 6000;
int init_try = 1;
double comp_time ;//double(stop.tms_utime - start.tms_utime + stop.tms_stime - start.tms_stime) / sysconf(_SC_CLK_TCK);

LL total_flip_time;


//unsat clauses stack
Bijection *ptr_to_c0;

#ifdef score_make_mode
int*	score_make;//[MAX_VARS];		//a varible appears in how many unsat clauses
#endif

HeapGreedyCand *pHeapGreedyCand;
	#ifdef ans_op_mode
Bijection *ptr_to_ans;
#endif
void Write_answer();
/* Information about solution */
char* value;//[MAX_VARS];	//the current solution, with 1's for True variables, and 0's for False variables
char* value_best;//[MAX_VARS];

bool heap_worse(const int &a, const int &b);

void free_memory();
int build_instance(char *filename);
bool build_instance(Glucose::MaxSAT&maxsat);
uint64_t search(Glucose::MaxSAT&maxsat, int timeout);

void build_neighbor_relation();
void init();
void flip_3SAT(int flipvar);

int pick_var_3SAT();
void set_functions();
void decrease_hard_weight();
void local_search(LL flip_bound);

int Check();
int verify_sol();
void Ans_update(int flipvar);
int main(int argc, char* argv[]);
void print_solution();


void save_model(Minisat::MaxSAT&maxsat);

};	


}