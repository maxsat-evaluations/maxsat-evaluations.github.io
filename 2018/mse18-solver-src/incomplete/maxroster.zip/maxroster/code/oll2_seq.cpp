/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include "maxsat.h"
#include "maxsat2.h"
#include <iostream>
namespace Glucose {
	Lit  SeqLE::get_most_lit() {
		if (output_var_vec.size() > (K-2)) {
			return output_var_vec[K - 2];
		}
		else {
			assert(0);
			return lit_Undef;
		}
	}
	void SeqLE::add_clause(MaxSAT&maxsat, Lit L) {
		assert(L != lit_Undef);
		vec<Lit> lits;
		lits.push(L);
		//maxsat.add_tnode_clause(lits);
		bool success = maxsat.addClause(L);
		assert(success);
	}
	void SeqLE::add_clause(MaxSAT&maxsat, Lit L1, Lit L2) {
		vec<Lit> lits;
		if (L1 != lit_Undef) lits.push(L1);
		if (L2 != lit_Undef) lits.push(L2);
		//maxsat.add_tnode_clause(lits);
		bool success = maxsat.addClause(lits);
		assert(success);
	}
	void SeqLE::add_clause(MaxSAT&maxsat, Lit L1, Lit L2, Lit L3) {
		vec<Lit> lits;
		if (L1 != lit_Undef) lits.push(L1);
		if (L2 != lit_Undef) lits.push(L2);
		if (L3 != lit_Undef) lits.push(L3);

		//maxsat.add_tnode_clause(lits);
		bool success = maxsat.addClause(lits);
		assert(success);
	}
	Lit SeqLE::drawS(MaxSAT&maxsat, int i, int j) {

		if (i == 2 && j == 1) {
			int m = 0;
		}
		allocate_vars(maxsat, j);

		return ovec[j - 1][i - 1];

	}
	Lit SeqLE::drawi(int i) {
		return inputs[i - 1];
	}
	void SeqLE::allocate_vars(MaxSAT&maxsat, int K_)
	{
		while (ovec.size() < K_) {
			vec<Lit> line;
			for (int i = 1;i <= inputs.size();i++) {
				if (i < K_) {
					line.push(lit_Undef);//Dummy
					continue;
				}
				Lit L = maxsat.new_literal();
				if (L.x == 1862 || L.x == 1868 || L.x == 1814) {
					int m = 0;
				}
				line.push(L);
				maxsat.newSATVariable(maxsat.solver);
			}
			ovec.push(line);

		}


	}

	void SeqLE::genK_constraints(MaxSAT&maxsat, int  K_) {

		int j = K_;
		assert(K_ >= 2);
		allocate_vars(maxsat, K_);
		int N = inputs.size();
		for (int i = K_;i <= inputs.size();i++) {

			//Si,j=Si-1,j-1 Xj + Si-1,j
			//	if (i == 1) {
			//		// Si,j=0;
			//		add_clause(maxsat,~drawS(maxsat,i, j));// (K-1)
			//	}
			//	else {




			add_clause(maxsat, ~drawS(maxsat, i - 1, j - 1), ~drawi(i), drawS(maxsat, i, j));//!Si-1,j-1 !Xj     Si,j
			add_clause(maxsat, ~drawS(maxsat, i - 1, j), drawS(maxsat, i, j));//!Si-1,j           Si,j
			add_clause(maxsat, drawS(maxsat, i - 1, j - 1), drawS(maxsat, i - 1, j), ~drawS(maxsat, i, j));	//Si-1,j-1 Si-1,j !Si,j
			add_clause(maxsat, drawi(i), drawS(maxsat, i - 1, j), ~drawS(maxsat, i, j));//Xj       Si-1,j !Si,j
																						//	}
		}
		output_var_vec.push(drawS(maxsat, N, j));
	}


	SeqLE::SeqLE(MaxSAT&maxsat, vec<Lit>inputs_, int K_) {
		inputs_.copyTo(inputs);
		K = K_;
		assert(K == 2);
		allocate_vars(maxsat, 1);


		int N = inputs.size();
		for (int j = 1;j <= K;j++) {
			if (j == 1) {
				for (int i = 1;i <= N;i++) {

					if (i == 1) {//X==S
								 //SのDRAWをやめるとSがマイナスになりえるので、QMAXの扱いが面倒になる-
						add_clause(maxsat, ~drawi(i), drawS(maxsat, i, 1));
						add_clause(maxsat, drawi(i), ~drawS(maxsat, i, 1));

					}
					else {
						add_clause(maxsat, ~drawi(i), drawS(maxsat, i, 1));	//~Sn-1 | Sn;  ~Xn | Sn;  Sn-1 | Xn | ~Sn;
						add_clause(maxsat, ~drawS(maxsat, i - 1, 1), drawS(maxsat, i, 1));
						add_clause(maxsat, drawi(i), drawS(maxsat, i - 1, 1), ~drawS(maxsat, i, 1));
					}


				}
				output_var_vec.push(drawS(maxsat, N, j));
			}
			else {
				genK_constraints(maxsat, j);

			}
		}
		//Sk,k & Xk+1 ==0;
		//Sk+1,k & Xk+2==0;
		//...
		//Sn-1,k & Xn==0;



		//	for (int i=K+1;i<=N;i++){
		//		add_clause(-drawS(i-1,K),-drawi(i));//	~Sn-1 | ~Xn;
		//
		//		}





		//	for (int j = 1;j <= K;j++) {
		//		output_var_vec.push(drawS(maxsat,N, j));//Zeroベースにする
		//	}



	}
Lit VSoftClauseSeqLE::get_most_lit() {
	return seq->get_most_lit();
}
void VSoftClauseC:: merge_cardinals(MaxSAT&maxsat, vec<VSoftClauseBase*> &vc)
{
	RHS++;

	vec<Lit> inputs;
	TNode*right = 0;
	for (int i = 0;i < vc.size();i++) {
		vclauses.push(vc[i]);
		Lit L=vc[i]->get_most_lit();
		inputs.push(L);
		
	}

	{
		vec<Lit> linkingVar;
		right = maxsat.genCardinals(inputs, linkingVar, RHS, false);
	}
	vec<Lit> linkingVar;
	troot = maxsat.mergeCardinals(right, troot, linkingVar, RHS);
	
	if (troot->linkingVar.size()>RHS) L = troot->linkingVar[RHS];
	else L = lit_Undef;
}

void VSoftClauseSeqLE::updateRHS(MaxSAT&maxsat, int RHS_) {
	assert(RHS_ > RHS);
	if (seq->inputs.size() == 2) {
		int m = 0;
	}
	RHS = RHS_;
	
	seq->updateK(maxsat, RHS+1);
	if (seq->output_var_vec.size() > RHS) {
		L = seq->output_var_vec[RHS ];
	//	if (L.x == 1868|| L.x==1814|| L.x==1862) {
	//		int m = 0;
	//	}
	}
	else {
		L = lit_Undef;
	}

}
void VSoftClauseC::updateRHS(MaxSAT&maxsat) {
	RHS++;
	maxsat.extend_UB(troot, RHS);

	if (troot->linkingVar.size()>RHS) L = troot->linkingVar[RHS];
	else L = lit_Undef;
}

VSoftClauseC *MaxSAT::get_orig_vsoft_clause(uint64_t w) {
	for (int i = 0;i < vsoft_clauses.size();i++) {
		if (vsoft_clauses[i]->type == VSoftClauseBase::Constraint
			&& vsoft_clauses[i]->weight == w&& vsoft_clauses[i]->is_orig()) return dynamic_cast<VSoftClauseC*>(vsoft_clauses[i]);
	}
	return 0;
}

SeqLEMo1* SeqLEMo1::splitClause(Lit first) {

	vec<Lit>& o1=ovec[1];
	int first_i = -1;
	for (int i = 0;i < o1.size();i++) {
		if (o1[i] != first) {
			continue;
		}
		first_i = i;
		break;
	}
	if (first_i == inputs.size() - 1) {
		int m = 0;
	}
	//if (first_i == 1) first_i = 2;
	//if (first_i == 1 && inputs.size() == 52) first_i = 2;

	assert(first_i > 0);
	assert(ovec.size() == 2);
	assert(inputs.size() == ovec[0].size());
	assert(inputs.size() == ovec[1].size());

	vec<Lit> inputs2, new_inputs;
	vec < vec<Lit> > ovec2, new_ovec;
	vec<Lit> out2;

	for (int i = 0;i < first_i;i++) {
		Var v = var(inputs[i]);
		if (v == 571) {
			int m = 0;
		}
		inputs2.push(inputs[i]);
		
	}
	for (int i = first_i;i < inputs.size();i++) {
		new_inputs.push(inputs[i]);
	}
	
	for (int j = 0;j < ovec.size();j++) {
		vec<Lit> lits;
		for (int i = 0;i < first_i;i++) {
			lits.push(ovec[j][i]);
		}
		ovec2.push(lits);
		vec<Lit> lits2;
		for (int i = first_i;i < ovec[j].size();i++) {
			lits2.push(ovec[j][i]);
		}
		new_ovec.push(lits2);
	}
	
	out2.push(ovec2[0][first_i - 1]);

	SeqLEMo1*seq2 = new SeqLEMo1(inputs2, ovec2, out2);
	new_inputs.copyTo(inputs);
	new_ovec.copyTo(ovec);
	return seq2;

}

VSoftClauseSeqLEMo1*VSoftClauseSeqLEMo1::split_clause(MaxSAT&maxsat, vec<Lit> &v)
{
	set<Lit> slits;
	for (int i = 0;i < v.size();i++) {
		slits.insert(v[i]);
	}
	set<Lit> ::iterator is = slits.begin();
	Lit first = (*is);
	SeqLEMo1*seq2=seq->splitClause(first);

	VSoftClauseSeqLEMo1*new_ins = new VSoftClauseSeqLEMo1(maxsat, seq2, weight);
	return new_ins;

}
uint64_t MaxSAT::core_analysis_oll2_oll_mo1(vec<Lit> & conflicts, vec<Lit>&assumptions, bool free_phase)
{
	
	uint64_t min_cost = compute_min_oll_cost(conflicts);
	//conflict_minimize(conflicts);
		if (free_phase) 
			trim(conflicts);


	vec<VSoftClauseSeqLE*> vc_vec;
	vec<VSoftClauseBase*> vb_vec;

	map<int, vec<Lit> > cmap;

	for (int i = 0;i < conflicts.size();i++) {
		Lit L = conflicts[i];
		std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
		if (im == vsoft_clause_map.end()) assert(0);
		else {
			VSoftClauseBase*vs = (*im).second;
			if (vs->type == VSoftClauseBase::AssumptionVar) {
				vb_vec.push(vs);
			}
			else {
				map<int, vec<Lit> >::iterator ix = cmap.find(vs->get_id());
				if (ix == cmap.end()) {
					vec<Lit> t;
					t.push(L);
					cmap[vs->id] = t;
				}
				else {
					(*ix).second.push(L);
				}
			}
		}
	}
	vec<VSoftClauseBase*> cvec;

	map<int, vec<Lit> >::iterator im;
	VSoftClauseC* croot = 0;
	if (cmap.size() == 1) {
		int m = 0;
	}

	
	for (im = cmap.begin(); im != cmap.end();im++) {
		VSoftClauseBase* vs = get_vsoft_clause_base((*im).first);
		if (vs->weight == min_cost) {
			if (vs->type == VSoftClauseBase::Constraint) {
				continue;
			}
			else {
				assert(vs->type == VSoftClauseBase::SEQ_MOST_ONE);

				VSoftClauseSeqLEMo1*VSC = dynamic_cast<VSoftClauseSeqLEMo1*>(vs);
				map<int, vec<Lit> >::iterator ix = cmap.find(vs->get_id());
				vec<Lit> &V = (*ix).second;

				VSoftClauseSeqLEMo1*s=VSC->split_clause(*this, V);
				add_vsoft_clause(s);
				cvec.push(s);

			}

		}else {
			assert(0);
		}
	}
	if (vb_vec.size()) {
		vec<VSoftClauseBase*> inputs;
		for (int i = 0;i < vb_vec.size();i++) {
			if (vb_vec[i]->weight == min_cost) {
				vb_vec[i]->weight = 0;//vminの方は次回assumptionされない
				inputs.push(vb_vec[i]);
			}else {
				assert(0);
			}
		}
		vec<VSoftClauseSeqLE*> dummy;
		VSoftClauseSeqLEMo1*mo = new VSoftClauseSeqLEMo1(*this,0,  vb_vec, min_cost);
		add_vsoft_clause(mo);
		cvec.push(mo);


	}


	if (!get_orig_vsoft_clause(min_cost)) {//が存在しない

		croot = new VSoftClauseC(*this, min_cost, cvec);
		croot->set_orig();
		add_vsoft_clause(croot);
	}
	else {

		croot = get_orig_vsoft_clause(min_cost);

		if (cvec.size()) {
			assert(croot);
			croot->merge_cardinals(*this, cvec);

		}
		else {
			croot->updateRHS(*this);

		}
	}
	if (!free_phase) {
		solver = rebuildSolveroll();
	}
	if (free_phase)		set_oll2_assumptions_free_phase(assumptions);
	else set_oll2_assumptions(assumptions);
	return min_cost;
}

int SeqLEMo1::value_check(MaxSAT&maxsat, int& Inputs) {
	int sum = 0;
	vec<int> vs;
	for (int i = 0;i < inputs.size();i++) {
		Var v = var(inputs[i]);
		if (v == 611|| v==612 ||v==623 || v==642||v==721) {
			int m = 0;
		}
		if (maxsat.solver->model[v] == l_True) {
			sum++;
			vs.push(v);
		}
	}
	Inputs += inputs.size();
	if (vs.size()) {
		printf("sum=%d %d\n", sum,vs[0]);
	}
	else {
		int m = 0;
	}
	return sum;
}

int VSoftClauseSeqLEMo1::value_check(MaxSAT&maxsat,int& inputs) {
	return seq->value_check(maxsat,inputs);
}
uint64_t MaxSAT::core_analysis_oll2_oll_mcu3(vec<Lit> & conflicts, vec<Lit>&assumptions, bool free_phase)
{
	//printf("conflicts.size=%d %d\n", conflicts.size(),solver->nLearnts());
	//if (lowerbound >= 30&& lowerbound<=32) {
	//	int m = 0;
	//}
		uint64_t min_cost = compute_min_oll_cost(conflicts);
		conflict_minimize(conflicts);
	//	if (free_phase) 
	//		trim(conflicts);


		vec<VSoftClauseSeqLE*> vc_vec;
		vec<VSoftClauseBase*> vb_vec;

		map<int, vec<Lit> > cmap;

		for (int i = 0;i < conflicts.size();i++) {
			Lit L = conflicts[i];
			std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
			if (im == vsoft_clause_map.end()) assert(0);
			else {
				VSoftClauseBase*vs = (*im).second;
				if (vs->type == VSoftClauseBase::AssumptionVar) {
					vb_vec.push(vs);
				}else {
					map<int, vec<Lit> >::iterator ix = cmap.find(vs->get_id());
					if (ix == cmap.end()) {
						vec<Lit> t;
						t.push(L);
						cmap[vs->id] = t;
					}else{
						(*ix).second.push(L);
					}
				}
			}
		}
		vec<VSoftClauseBase*> cvec;
		
		map<int, vec<Lit> >::iterator im;
		VSoftClauseC* croot = 0;
		if (cmap.size() == 1) {
			int m = 0;
		}

		VSoftClauseC*orig = get_orig_vsoft_clause(min_cost);
		for (im = cmap.begin(); im != cmap.end();im++) {
			VSoftClauseBase* vs = get_vsoft_clause_base((*im).first);
			if (vs->weight == min_cost) {
				if (vs->type == VSoftClauseBase::Constraint) {
					//croot = dynamic_cast<VSoftClauseC*>(vs);
					
					if(vs == orig) continue;//ORIGなので、最後にupdateすることにして、ここではしない
					VSoftClauseC*VSC = dynamic_cast<VSoftClauseC*>(vs);
					VSC->updateRHS(*this);
					cvec.push(VSC);
				}else {
					assert(vs->type == VSoftClauseBase::SEQ_CONSTRAINT);
					
					VSoftClauseSeqLE*VSC = dynamic_cast<VSoftClauseSeqLE*>(vs);
					VSC->updateRHS(*this,VSC->RHS + 1);

					cvec.push(VSC);
					
				}
				
			}else {
				VSoftClauseC*orig = get_orig_vsoft_clause(min_cost);
				if (orig) {
					assert(orig != vs);
				}
				assert(vs->weight > min_cost);
				VSoftClauseBase*vmin = vs->split_weight(*this, min_cost, true);
				assert(vmin->weight == min_cost);
				add_vsoft_clause(vmin);//Mar.15.2017
				if (vs->type == VSoftClauseBase::Constraint) {
					//croot = dynamic_cast<VSoftClauseC*>(vs);
					VSoftClauseC*VSC = dynamic_cast<VSoftClauseC*>(vmin);
					VSC->updateRHS(*this);
					cvec.push(VSC);
					
				}
				else {
					
					VSoftClauseSeqLE*VSC = dynamic_cast<VSoftClauseSeqLE*>(vmin);
					VSC->updateRHS(*this, VSC->RHS + 1);//vmin分についてupdate
					cvec.push(VSC);
				
				}
			}
		}
		if (vb_vec.size()) {
			vec<VSoftClauseBase*> inputs;
			for (int i = 0;i < vb_vec.size();i++) {
				if (vb_vec[i]->weight == min_cost) {
					vb_vec[i]->weight = 0;//vminの方は次回assumptionされない
					inputs.push(vb_vec[i]);
				}
				else {
					assert(vb_vec[i]->weight > min_cost);
					VSoftClauseBase*vmin = vb_vec[i]->split_weight(*this, min_cost, true);
					assert(vmin->weight == min_cost);
					vmin->weight = 0;//vminの方は次回assumptionされない
					inputs.push(vmin);
				}
			}
//#define T1
			if (lowerbound >= 29) {
				int m = 0;
			}
#ifdef USE_OLL_MCU3_TOTALIZER
			VSoftClauseC*vs=new VSoftClauseC(*this, vb_vec, min_cost);
			add_vsoft_clause(vs);
			cvec.push(vs);
#else
			vec<VSoftClauseSeqLE*> dummy;
			VSoftClauseSeqLE*mo = new VSoftClauseSeqLE(*this, dummy, vb_vec, min_cost);
			add_vsoft_clause(mo);
			cvec.push(mo);
#endif

		}


		if (!get_orig_vsoft_clause(min_cost)) {//が存在しない
			
			croot = new VSoftClauseC(*this,  min_cost,cvec);
			croot->set_orig();
			add_vsoft_clause(croot);
		}
		else {
			
			croot = get_orig_vsoft_clause(min_cost);
			
			if (cvec.size()) {
				assert(croot);
				croot->merge_cardinals(*this, cvec);

			}else {
				croot->updateRHS(*this);
			
			}
		}

		if (free_phase)		set_oll2_assumptions_free_phase(assumptions);
		else set_oll2_assumptions(assumptions);
	//	int sum = 0;
	//	for (int i = 0;i < assumptions.size();i++) {
	//		sum += assumptions[i].x;
	//		printf("%d %d ",i, assumptions[i].x);
	//	}

	//	printf("assumptions size=%d %d\n", assumptions.size(),sum);
		return min_cost;//min_cost;
	}
	void TNode::print(MaxSAT&maxsat) {
	//	if (right) right->print(maxsat);
		int isum = 0;
		int osum = 0;
		for (int i = 0;i < inputs.size();i++) {
			Var v = var(inputs[i]);
			if (maxsat.solver->model[v] == l_True) {
				printf("1");
				isum++;
			}
			else {
				if (maxsat.solver->model[v] == l_False) printf("0");
				else printf("z");
			}
		}
		printf("--");
		for (int i = 0;i < linkingVar.size();i++) {
			Var v = var(linkingVar[i]);
			if (maxsat.solver->model[v] == l_True) {
				printf("1");
				osum++;
			}
			else {
				if (maxsat.solver->model[v] == l_False) printf("0");
				else printf("z");
			}
		}
		printf(": isum=%d osum=%d\n",isum,osum);
	}
	void VSoftClauseC::value_check(MaxSAT&maxsat) {
		printf(" id=%d ", id);
		troot->print(maxsat);

	}
	void MaxSAT::value_check() {
		int sum = 0;
		int inputs = 0;
		for (int i = 0;i < vsoft_clauses.size();i++) {
			if (vsoft_clauses[i]->type == VSoftClauseBase::SEQ_MOST_ONE) {
				sum+=vsoft_clauses[i]->value_check(*this,inputs);
			}
			if (vsoft_clauses[i]->type == VSoftClauseBase::Constraint)
			{
				vsoft_clauses[i]->value_check(*this);
			}
		}
		printf("total %d errors. of %dinputs \n", sum,inputs);



	}
	void MaxSAT::oll2_search_oll_mcu3(uint64_t UB) {

		upperbound = UB;
		lowerbound = 0;
		solver = rebuildSolver(true);

		for (int i = 0;i < nSoft();i++) {
			uint64_t w = softClauses[i].weight;
			Lit L = softClauses[i].assumptionVar;
#ifdef SIMP_SOLVER
			Var v = var(L);
			solver->setFrozen(v, true);
#else			
			if (use_simp){
				Var v = var(L);
				dynamic_cast<SimpSolver*>(solver)->setFrozen(v, true);	
			}
#endif
			VSoftClauseBase*vs = new VSoftClauseBase(L, w, i);
			vs->send_clause(*this);
			add_vsoft_clause(vs);


		}
		//	if (currentWeight == 1) {
		//
		//		wpm3_search_inc(UB);
		//		return;
		//	}

#ifdef OLL_LOWER
#ifdef USE_FREE_SAT
		{
			vec<Lit> assumptions;
			searchSATSolver(solver, assumptions);
			uint64_t cost = computeCostModel(solver->model);
			if (cost < best_UB) {
				
				upperbound = cost;
				best_UB = upperbound;
				solver->saveModel();
				printf("o %" PRIu64 "\n", upperbound);
			}
		}
#endif
		lowerbound = oll_lowerbound_search_inc(UB);
		//unweighted_non_repeat_search()
		//sat_search(upperbound);
		////return;

#endif

		//	inc_search(upperbound);
		//	return;



		lbool res = l_True;

		best_UB = upperbound;






		vec<Lit> assumptions;
		set_oll2_assumptions(assumptions);


		while (true) {



			res = searchSATSolver(solver, assumptions);
			if (res == l_True) {
				uint64_t cost = computeCostModel(solver->model);
				
				if (cost < upperbound) {
					
					upperbound = cost;
					best_UB = upperbound;
					solver->saveModel();
					printf("o %" PRIu64 "\n", upperbound);
					
				}
#ifdef TRY2
				break;
#endif

				if (lowerbound >= upperbound) {





					solver->saveModel();
					break;

				}
				else {
					currentWeight = find_next_weight_oll();
					uint64_t cost = computeCostModel(solver->model);
					if (cost < upperbound)
					{

						best_UB = cost;
						upperbound = cost;
						solver->saveModel();
						printf("o %" PRIu64 "\n", upperbound);
					}
#ifdef USE_OLL_MCU3_UNWEIGHT
					printf("c cost=%d\n", cost);
					break;
#endif
					if (lowerbound == upperbound)
					{
						best_UB = upperbound;

						printf("c LB = UB\n");
						//printAnswer(_OPTIMUM_);
						//exit(_OPTIMUM_);
						break;
					}
					//solver = rebuildSolveroll();
					set_oll2_assumptions(assumptions);
				}


			}
			else if (res == l_False) {


				assert(solver->conflict.size());
#ifdef USE_OLL_MCU3_UNWEIGHT
				uint64_t coreCost = core_analysis_oll2_oll_mcu3_unweight(solver->conflict, assumptions);
#else
				uint64_t coreCost = core_analysis_oll2_oll_mcu3(solver->conflict, assumptions);
#endif
				int core_size = solver->conflict.size();
				lowerbound += coreCost;
				printf("c LB : %-12" PRIu64 " CS : %-12d W  : %-12zd\n", lowerbound,
					core_size, coreCost);

				printf("c LB=%zd\n", lowerbound);
			}
		}
		//	assert(_CrtCheckMemory);



	}
	Lit VSoftClauseSeqLEMo1::get_most_lit() {
		return seq->get_most_lit();

	}


	VSoftClauseSeqLEMo1::VSoftClauseSeqLEMo1(MaxSAT&maxsat, SeqLEMo1*t, int64_t weight_) {
		weight = weight_;
		sub = false;
		seq = t;
		L = seq->output_var_vec[0];
		type=SEQ_MOST_ONE;
		
	}
	VSoftClauseSeqLEMo1::VSoftClauseSeqLEMo1(MaxSAT&maxsat, VSoftClauseBase*parent_, vec<VSoftClauseBase*>& vb_vec, int64_t weight_)
	{
		weight = weight_;
		parent = parent_;
		sub = true;

		RHS = 1;
		vec<Lit> inputs;

		for (int i = 0;i < vb_vec.size();i++) {
			inputs.push(vb_vec[i]->L);
		}
		seq = new SeqLEMo1(maxsat, inputs);
		L = seq->output_var_vec[0];

		type = SEQ_MOST_ONE;
	}

	void SeqLEMo1::rebuild(MaxSAT&maxsat,bool alloc) {
		K = 2;
		assert(K == 2);
		
		

		if (alloc) {
			output_var_vec.clear();
			ovec.clear();

			allocate_vars(maxsat, 1);
		}else {
			output_var_vec.clear();

		}

		int N = inputs.size();
		for (int j = 1;j <= K;j++) {
			if (j == 1) {
				for (int i = 1;i <= N;i++) {

					if (i == 1) {//X==S

						add_clause(maxsat, ~drawi(i), drawS(maxsat, i, 1));
						add_clause(maxsat, drawi(i), ~drawS(maxsat, i, 1));

					}
					else {
						add_clause(maxsat, ~drawi(i), drawS(maxsat, i, 1));	//~Sn-1 | Sn;  ~Xn | Sn;  Sn-1 | Xn | ~Sn;
						add_clause(maxsat, ~drawS(maxsat, i - 1, 1), drawS(maxsat, i, 1));
						add_clause(maxsat, drawi(i), drawS(maxsat, i - 1, 1), ~drawS(maxsat, i, 1));
					}


				}
				output_var_vec.push(drawS(maxsat, N, j));
			}
			else {
				if(alloc) allocate_vars(maxsat, 2);
				int N = inputs.size();
				for (int i = 2;i <= N;i++) {//AND Gate 
					add_clause(maxsat, ~drawi(i), ~drawS(maxsat, i - 1, 1) , drawS(maxsat, i, 2));
					add_clause(maxsat,  drawi(i),  ~drawS(maxsat, i, 2));
					add_clause(maxsat,              drawS(maxsat, i - 1, 1), ~drawS(maxsat, i, 2));
				}
			}
		}

	}
	SeqLEMo1::SeqLEMo1(MaxSAT&maxsat, vec<Lit>inputs_) {
		
		inputs_.copyTo(inputs);
		rebuild(maxsat);
		
	}
	
	void SeqLEMo1::set_assumption(MaxSAT&maxsat, VSoftClauseSeqLEMo1*mo,vec<Lit>&assumptions)
	{
		int N = inputs.size();
		for (int i = 2;i <= N;i++) {
			Lit L=drawS(maxsat,i, 2);
			assumptions.push(~L);
			maxsat.add_vsoft_clause_map(L, mo);
		}
	}

	void VSoftClauseSeqLEMo1::rebuild(MaxSAT&maxsat)
	{
		if (id > 181) {
			int m = 0;

		}
			seq->rebuild(maxsat,false);
		
		Lit l = seq->output_var_vec[0];
		assert(L == l);
		
	}
	void VSoftClauseSeqLEMo1::set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions) {
		if (!weight) return;
		if (L == lit_Undef) return;
		if (id == 182) {
			int m = 0;
		}
		seq->set_assumption(maxsat,this,assumptions);

	}
	void VSoftClauseSeqLE::set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions) {
		if (!weight) return;
		if (L == lit_Undef) return;

		if (seq->output_var_vec.size() > RHS) {

			assumptions.push(~L);
			maxsat.add_vsoft_clause_map(L, this);

		}
		else {
			assert(0);
		}

	}
	VSoftClauseBase* VSoftClauseSeqLEMo1::split_weight(MaxSAT&maxsat, uint64_t min_weight, bool inc)
	{
		weight -= min_weight;
		assert(weight);

		VSoftClauseSeqLEMo1*vsc = new VSoftClauseSeqLEMo1(maxsat, seq, min_weight);
		return vsc;

	}
	VSoftClauseBase* VSoftClauseSeqLE::split_weight(MaxSAT&maxsat, uint64_t min_weight, bool inc)
	{
		weight -= min_weight;
		assert(weight);

		VSoftClauseSeqLE*vsc = new VSoftClauseSeqLE(maxsat, seq, min_weight, RHS);


		return vsc;


	}
	

	VSoftClauseSeqLE::VSoftClauseSeqLE(MaxSAT&maxsat, SeqLE*t, int64_t weight_, int RHS_) {
		weight = weight_;
		type = SEQ_CONSTRAINT;

		seq = t;
		assert(seq);
		RHS = RHS_;


		//if (seq->K <= RHS) {
			seq->updateK(maxsat, RHS + 1);
		//}
		if (seq->output_var_vec.size() > RHS) {
			L = seq->output_var_vec[RHS];
		}
		else L = lit_Undef;



	}
	VSoftClauseSeqLE::VSoftClauseSeqLE(MaxSAT&maxsat, vec<VSoftClauseSeqLE*>&vc_vec, vec<VSoftClauseBase*>&vb_vec, int64_t weight_) {
		weight = weight_;
		type = SEQ_CONSTRAINT;

		RHS = 1;
		vec<Lit> inputs;
		for (int i = 0;i < vc_vec.size();i++) {
			inputs.push(vc_vec[i]->L);
		}
		for (int i = 0;i < vb_vec.size();i++) {
			inputs.push(vb_vec[i]->L);
		}
		seq = new SeqLE(maxsat, inputs, RHS + 1);


		if (seq->output_var_vec.size() > RHS) {
			L = seq->output_var_vec[RHS];
			if (L.x == 1868) {
				int m = 0;

			}
		}
		else L = lit_Undef;

	}

	

	void SeqLE::updateK(MaxSAT&maxsat, int K_) {
		if (K_ > K) {//SeqLEは、複数のインスタンス間で共通なので複数回呼ばれる可能性がある
			for (int i = K + 1;i <= K_;i++) {
				if (i > inputs.size()) {
					continue;
				}
				genK_constraints(maxsat, i);
			}
			K = K_;
		}
	}




}	
