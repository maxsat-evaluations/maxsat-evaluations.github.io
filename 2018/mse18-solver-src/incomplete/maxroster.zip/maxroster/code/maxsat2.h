/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#pragma once
#include "maxsat.h"
#include "core/SolverTypes.h"
#include "core/Solver.h"
#include "simp/SimpSolver.h"


#include <string>
#include <vector>
#include <set>
#include <map>
using namespace std;

namespace Glucose {

struct WEIGHT_AGGREGATE;
struct CARD_ADDER;


struct weight_lim
{
	uint64_t weight;
	int limit;
};





struct CARD_ADDER_BASE :public SPECIAL_CLAUSE
{
	
	
	virtual int calc_counter(Solver&S) {assert(0); return 0;	}
	
	virtual void Recal(Solver&S) {//input true��(=counter) ��K�̍ăZ�b�g

		
		assert(0);
	}
	virtual void print_values(Solver&S,int level){}
	virtual void attach_port(Solver&S, CRef cr) {}
	virtual void attach_solver(Solver&S) {};
	
	int get_output_reason(Solver&S, vec<Lit>&reason) {
		int c = 0;
		for (int i = linkingVar.size() - 1;i >= 0;i--) {
			Lit L = linkingVar[i];
			if (S.value(var(L)) == l_True) {
				c = i + 1;
				reason.push(L);
				return c;
			}
		}
		return c;

	}
	int get_outputs(Solver&S) {
			int c= 0;
			for (int i = linkingVar.size() - 1;i >= 0;i--) {
				Lit L = linkingVar[i];
				if (S.value(var(L)) == l_True) {
					c = i+1;
					return c;
				}
			}
			return c;
		
	}
	virtual Clause::Type get_type() { return Clause::CARDADDERBOTTOM; }
	Lit output_deduce(Solver&S, CRef cref, int diff) {
		int c=get_outputs(S);
		K = c+ diff;
		assert(K >= 0);
		if (K < linkingVar.size()) {
			Lit L = linkingVar[K];
			if (S.value(var(L)) == l_Undef) {
				S.uncheckedEnqueue(~L, cref);
				return lit_Undef;
			}
			else if (S.value(var(L)) == l_True) {
				return L;
			}
		}
		return lit_Undef;
	}
	virtual int get_depth() {
		assert(0); return 0;
	}
	virtual CARD_ADDER* get_unfilled_leave() {
		 return 0;
	}
	void detach_pos_port(Solver&S,CRef cr);
	void attach_pos_port(Solver&S, CRef cr);
	virtual uint64_t model_check(vec<lbool> & model) { return 0; }

	static const int LEAVES_MAX = LEAVES_MAX_D;

	int get_outputs() { return linkingVar.size(); }
	virtual int get_inputs() { assert(0); return 0; }
	void set_parent(SPECIAL_CLAUSE*p) { parent = p; }
	void set_card_id(int id_) { id = id_; }
	virtual void save_state() {
		if (id == 8) {
			int m = 0;
		}
		save_K = K;
		save_counter = counter;

	}
	virtual void restore_state() {
		K = save_K;
		counter = save_counter;

	}
	

	vec<Lit> linkingVar;
	uint64_t counter,save_counter;
	uint64_t K,save_K;
	SPECIAL_CLAUSE*parent;
	int id;
	//CRef my_cref;
	
};	




struct CARD_ADDER :public CARD_ADDER_BASE
{

	CARD_ADDER(vector<CARD_ADDER_BASE*>&inputs_, vec<Lit>&outputs_) {
		inputs = inputs_;//POS SENSE only
		outputs_.copyTo(linkingVar);// = outputs_;//NEG SENSE only
		counter = 0;
		K = 0x7fffffff;//linkingVar.size();
		parent = 0;
		id++;
		my_cref = CRef_Undef;
		for (int i = 0;i < inputs.size();i++) {
			inputs[i]->set_parent(this);
		}
	}
	void print_values(Solver&S,int level)
	 {
		string s = "";
		int tcount = 0;
		for (int i = 0;i < linkingVar.size();i++) {
			Var v = var(linkingVar[i]);
			if (S.value(v) == l_True) {
				s += "1";
				tcount++;
			}
			else if (S.value(v) == l_False) {
				s += "0";
			}
			else s += "z";
		}
		printf("level=%d %s\n",level,s.c_str());
		for (int i = 0;i < inputs.size();i++) {
			inputs[i]->print_values(S, level+1);
		}
		
	}
	Clause::Type get_type() { return Clause::CARDADDER; }
	virtual int calc_counter(Solver&S) {
		counter = 0;
		for (int i = 0;i < inputs.size();i++) {
			counter += inputs[i]->calc_counter(S);
		}
		return counter;
	}
	uint64_t model_check(vec<lbool>&model){
		assert(0);
		return 0;
	}
	


	CRef prop(Solver&S, Lit L, CRef cref)
	{
		if (sign(L)) {//Neg
			return propK(S, L, cref);

		}
		else return propC(S, L, cref);


	}
	
	CRef propK(Solver&S, Lit L, CRef cref)
	{
		Var v = var(L);
		if (v == 0x1b5) {
			int m = 0;

		}
		assert(sign(L));
		K = 0x7fffffff;
		for (int i = 0;i< linkingVar.size();i++) {
			if (S.value(var(linkingVar[i])) ==l_False) 
			{
					K = i;
					break;
				
			}

		}

		//�Ȃ����K�v
		counter = 0;
		
		for (int i = 0;i < inputs.size();i++) {
			counter += inputs[i]->get_outputs(S);
		}


		assert(K<linkingVar.size());
		if (counter>K) {
			set_reason(S, S.weight_conflict_reason);
			return cref;
		}else {
			assert(K>=counter);
			for (int i = 0;i < inputs.size();i++) {
				Lit L = inputs[i]->output_deduce(S, cref, K - counter);
				if (L != lit_Undef) {
					set_reason(S, S.weight_conflict_reason);
					S.weight_conflict_reason.push(L);
					return cref;
				}
			}
		}
		return CRef_Undef;
	}

	

	CRef propC(Solver&S, Lit L, CRef cref)
	{
	
		if (id==0x20) {
			int m = 0;
		}
		counter = 0;
	//	bool learnt_reason = S.learnt_reason(L);
	//	if (learnt_reason) {
	//		int m = 0;
	//	}
		for (int i = 0;i < inputs.size();i++) {
			counter += inputs[i]->get_outputs(S);
		}
		K = 0x7fffffff;
		for (int i = 0;i< linkingVar.size();i++) {
			Var v = var(linkingVar[i]);

			if (S.value(v) == l_False) {
				K = i;
				break;
			}
		}
		if (K < counter) {
			
			set_reason(S,S.weight_conflict_reason);
			return cref;
		}else if (K >= counter) {


			for (int i = 0;i < inputs.size();i++) {
				Lit L=inputs[i]->output_deduce(S, cref,K-counter);
				if (L!=lit_Undef) {
					set_reason(S, S.weight_conflict_reason);
					S.weight_conflict_reason.push(L);
					return cref;
				}
			}
			assert(counter);
			for (int i = 0;i < counter;i++) {
				Lit L = linkingVar[i];
				Var v = var(L);
				if (S.value(v) == l_False) {
					set_reason(S, S.weight_conflict_reason);
					return cref;
				}
				else if (S.value(v) == l_Undef) {
					S.uncheckedEnqueue(L, cref);
				}
			}
	/*		if (counter <= linkingVar.size()) {
				int i = counter - 1;
				Lit L = linkingVar[i];
				if (L.x == 0x3313) {
					int m = 0;
				}
				Var v = var(linkingVar[i]);
				if (S.value(v) == l_False) {
					set_reason(S, S.weight_conflict_reason);
					return cref;

				}
				else if (S.value(v) == l_Undef) {
					if (parent&& parent->get_type()==Clause::CARD_CLAUSE&& counter>=16) {
						
						
							int m = 0;
						
					}
					S.uncheckedEnqueue(L, cref);
				}
			}
*/


		}
		return CRef_Undef;
	}
	
	

	void set_reason(Solver&S, vec<Lit>& reason, Lit L = lit_Undef) {//k<c �Ƃ�����
		if (id == 0x0c) {
		//	Lit L1=inputs[0]->linkingVar[0];
		//	lbool c1 = S.value(var(L1));
		//	Lit L2 = inputs[1]->linkingVar[0];
		//	lbool c2 = S.value(var(L2));
			int m = 0;
		}

		reason.clear();
		int c = 0;
		for (int i = 0;i < inputs.size();i++) {
			c += inputs[i]->get_output_reason(S, reason);
		}
		//if (L != lit_Undef && !sign(L)) return;

		//K = linkingVar.size();
		int k = 0x7fffffff;
		for (int i = 0;i< linkingVar.size();i++) {
			Var v = var(linkingVar[i]);
			if (L != lit_Undef && var(L) == v) continue;
			if (S.value(v) == l_False) {
				k = i;
				reason.push(~linkingVar[i]);
				break;
			}
		}
//		if (L  != lit_Undef) assert(k >= c);
//		else assert(k < c);
		

	}
	void attach_port(Solver&S, CRef cr);
	void attach_solver(Solver&S);
	void attach_solver1(Solver&S);
	void attach_solver_last(Solver&S);
	void Recal(Solver&S) {//input true��(=counter) ��K�̍ăZ�b�g
		for (int i = 0;i < inputs.size();i++) {
			inputs[i]->Recal(S);

		}
		counter = 0;
		for (int i = 0;i < inputs.size();i++) {
			counter += inputs[i]->get_outputs(S);
			
		}
		K = 0x7fffffff;
		for (int i = 0;i< linkingVar.size();i++) {
			Var v = var(linkingVar[i]);
			
			if (S.value(v) == l_False) {
				K = i;
				break;
			}
		}
		
	}
	virtual int get_inputs() {
		int n = 0;
		for (int i = 0;i < inputs.size();i++) {
			n += inputs[i]->get_outputs();

		}
		return n;
	}
	virtual int get_depth() {
		int n = 0;
		for (int i = 0;i < inputs.size();i++) {
			n = inputs[i]->get_depth();
			break;
		}
		return n + 1;
	}
	CARD_ADDER* get_unfilled_leave() {
		CARD_ADDER* temp=inputs[inputs.size() - 1]->get_unfilled_leave();//�E�[��FILL�@IN����Ă��Ȃ�NODE���������炻��
		if (!temp) {
			if (inputs.size() >= LEAVES_MAX) {//�������g��LEAVES�@MAX��������A���̃��x���ȉ��ɂ�UNFILLED�@NODE�͂Ȃ�
				assert(inputs.size() == LEAVES_MAX);
				return 0;
			}	else return this;//�����͂܂��]�T������
		}else return temp;
	}
	void push_back(CARD_ADDER_BASE* cab) {
		inputs.push_back(cab);
		cab->set_parent(this);

	}
	void restore_state() {
		CARD_ADDER_BASE::restore_state();
		for (int i = 0;i < inputs.size();i++) {
			inputs[i]->restore_state();
		}

	}
	void save_state() {
		CARD_ADDER_BASE::save_state();
		for (int i = 0;i < inputs.size();i++) {
			inputs[i]->save_state();
		}
	}
	vector < CARD_ADDER_BASE* > inputs;
	
	
};

struct CARD_ADDER_BOTTOM :public CARD_ADDER_BASE
{

	CARD_ADDER_BOTTOM(vec<Lit>&inputs_,vec<Lit>&outputs_) {
		inputs_.copyTo(inputs);// = inputs_;//POS SENSE only
		outputs_.copyTo(linkingVar);// = outputs_;//NEG SENSE only
		counter = 0;
		K = 0x7fffffff;//linkingVar.size();
		parent = 0;
		id++;
		if (id == 61) {
			int m = 0;
		}
		my_cref = CRef_Undef;
	}
	void print_values(Solver&S,int level)
	 {
		string s = "";
		int tcount = 0;
		for (int i = 0;i < linkingVar.size();i++) {
			Var v = var(linkingVar[i]);
			if (S.value(v) == l_True) {
				s += "1";
				tcount++;
			}
			else if (S.value(v) == l_False) {
				s += "0";
			}
			else s += "z";
		}
		printf("level=%d %s\n",level,s.c_str());
	}	
	CRef propK(Solver&S, Lit L, CRef cref)
	{
		assert(sign(L));

		K = 0x7fffffff;
		for (int i = 0;i< linkingVar.size();i++) {
			if (S.value(var(linkingVar[i])) == l_False)
			{
				K = i;
				break;

			}

		}
		//�Ȃ����K�v
		counter = 0;
		for (int i = 0;i < inputs.size();i++) {
		Var v = var(inputs[i]);

		if (S.value(v) == l_True) {
		counter++;

		}
		}



		for (int i = 0;i < linkingVar.size();i++) {
			if (linkingVar[i] == ~L) {
				if (i < K) K = i;
				break;
			}

		}

		
		
		
		assert(K<linkingVar.size());
		if (counter>K) {
			set_reason(S,S.weight_conflict_reason);
			return cref;
		}
		if (K==counter){
			for (int i = 0;i < inputs.size();i++) {
				Lit L = inputs[i];
				Var v = var(inputs[i]);
				if (S.value(v) == l_Undef) {
					S.uncheckedEnqueue(~L, cref);
				}
			}
		}
		return CRef_Undef;
	}	
	CRef prop(Solver&S, Lit L, CRef cref)
	{
		if (sign(L)){//Neg
			return propK(S,L,cref);
			
		}else return propC(S,L,cref);		
		
		
	}
	CRef propC(Solver&S, Lit L, CRef cref)
	{
		if (id == 0x1a) {

			int m = 0;
		}
		counter = 0;
		for (int i = 0;i < inputs.size();i++) {
			Var v = var(inputs[i]);

			if (S.value(v) == l_True) {
				counter++;

			}
		}
		if (counter > K) {
			set_reason(S, S.weight_conflict_reason);
			return cref;
		}
/*
		if (counter>=K) {
			set_reason(S,S.weight_conflict_reason);
			return cref;
		}
		counter++;
	*/	
		if (K==counter){
			for (int i = 0;i < inputs.size();i++) {
				Lit L = inputs[i];
				Var v = var(inputs[i]);
				if (S.value(v) == l_Undef) {
					S.uncheckedEnqueue(~L, cref);
				}
			}
		}
		for (int i = 0;i < counter ;i++) {
			Lit L = linkingVar[i];
			Var v = var(L);
			if (S.value(v) == l_False) {
				set_reason(S, S.weight_conflict_reason);
				return cref;
			}	else if (S.value(v) == l_Undef) {
				S.uncheckedEnqueue(L, cref);
			}
		}
/*		if (counter<= linkingVar.size()){
			int i=counter-1;
			Lit L = linkingVar[i];
			Var v = var(linkingVar[i]);
			if (S.value(v) == l_False) {
				set_reason(S, S.weight_conflict_reason);
				return cref;
				
			}else if (S.value(v)==l_Undef){
				S.uncheckedEnqueue(L, cref);
			}		
		}*/	
		
		return CRef_Undef;
	}
	
	
	
	Clause::Type get_type() { return Clause::CARDADDERBOTTOM; }
	void set_reason(Solver&S,vec<Lit>& reason, Lit L = lit_Undef ) {//k<c �Ƃ�����
		reason.clear();
		int c = 0;
		if (L != lit_Undef) {//Conflict�łȂ�
			for (int i = 0;i < inputs.size();i++) {
				Var v = var(inputs[i]);
				if (L != lit_Undef && var(L) == v) continue;
				if (S.value(v) == l_True) {
					c++;
					reason.push(inputs[i]);
				}
			}

			if (sign(L)) {//����������inputs��Deduce�����B�܂�K==C �Ȃ������ƂɂȂ�
				assert(c < linkingVar.size());
				Var v = var(linkingVar[c]);
				
				assert(S.value(v) == l_False);
				reason.push(~linkingVar[c]);
			}else {//�v���X��������@inputs�@ACTIVE�v���ɂ��
			/*	int k = 0x7fffffff;
				for (int i = 0;i< linkingVar.size();i++) {
					Var v = var(linkingVar[i]);
					if (S.value(v) == l_False) {
						k = i;
						reason.push(~linkingVar[i]);
						break;
					}
				}
				int ii = -1;
				for (int i = 0;i < linkingVar.size();i++) {
					if (L == linkingVar[i]) ii = i;
				}
				assert(k >= c);*/
			}
			return;
		}
		c = 0;
		for (int i = 0;i < inputs.size();i++) {
			Var v = var(inputs[i]);
			if (L != lit_Undef && var(L) == v) continue;
			if (S.value(v) ==l_True) {
				c++;
				reason.push(inputs[i]);
			}
		}
		//K= linkingVar.size();
		int k = 0x7fffffff;
		for (int i=0;i< linkingVar.size();i++){
			Var v = var(linkingVar[i]);
			if (S.value(v) ==l_False) {
				k = i;
				reason.push(~linkingVar[i]);
				break;
			}
		}
		if (L != lit_Undef) assert(k >= c);
		else  assert(k < c);
		
		
	}
	void Recal(Solver&S) {
		
		counter = 0;
		for (int i = 0;i < inputs.size();i++) {
			Var v = var(inputs[i]);
			
			if (S.value(v) == l_True) {
				counter++;
			
			}
		}
		int c = 0;
		int ct = 0;
		for (int i = 0;i< linkingVar.size();i++) {
			Var v = var(linkingVar[i]);
			if (S.value(v) == l_True) {
				c=i+1;
				ct++;
			}
			
			
		}
//	assert(counter == c);
	//	assert(counter == ct);
		K = 0x7fffffff;
		for (int i = 0;i< linkingVar.size();i++) {
			Var v = var(linkingVar[i]);
			if (S.value(v) == l_False) {
				K = i;
			
				break;
			}
		}
		




	}
	
	int calc_counter(Solver&S) {
		counter = 0;
		for (int i = 0;i < inputs.size();i++) {
			Var v = var(inputs[i]);
			if (S.value(v) == l_True) {
				counter++;
			}
		}
		return counter;
	}
	virtual int get_depth() {
		return 1;
	}
	
	void attach_port(Solver&S,CRef cr);
	void attach_solver(Solver&S);
	virtual int get_inputs() {
		return inputs.size();
	}
	uint64_t model_check(vec<lbool> & model) {
		int c = 0;
		for (int i = 0;i < inputs.size();i++) {
			Var v = var(inputs[i]);
			if (model[v] == l_True) c++;

		}
		for (int i = 0;i < linkingVar.size();i++) {
			Var v = var(linkingVar[i]);
			if (i < c) {
				
				assert(model[v] == l_True);
			}else assert(model[v] == l_False);
		}
		return c;
	}
	
	vec<Lit> inputs;
	
};
		
struct MOST_ONE :public SPECIAL_CLAUSE
{

	MOST_ONE(vec<Lit>&inputs_) {
		inputs_.copyTo(inputs);// = inputs_;
		counter = 0;

	}
	CRef prop(Solver&S, Lit L, CRef cref)
	{
		if (counter) {
			set_reason(S,S.weight_conflict_reason);
			return cref;
		}
		counter++;
		for (int i = 0;i < inputs.size();i++) {
			Lit L = inputs[i];
			Var v = var(inputs[i]);
			if (S.value(v) == l_Undef) {
				S.uncheckedEnqueue(~L, cref);
			}
		}
		return CRef_Undef;
	}
	Clause::Type get_type() { return Clause::MOSTONE; }
	void set_reason(Solver&S,vec<Lit>& reason, Lit L = lit_Undef) {
		reason.clear();
		for (int i = 0;i < inputs.size();i++) {
			Var v = var(inputs[i]);
			if (L != lit_Undef && var(L) == v) continue;

			if (S.value(v) ==l_True) {
				reason.push(inputs[i]);
			}
		}
	}
	void Recal(Solver&S) {
		counter = 0;
		for (int i = 0;i < inputs.size();i++) {
			Var v = var(inputs[i]);
			if (S.value(v) == l_True) {
				counter++;
			}
		}

	}
	void attach_port(Solver&S,CRef cr);

	
	
	
	vec<Lit> inputs;
	int counter;

};

struct CARD_NODE:public SPECIAL_CLAUSE
{
#ifdef USE_CARD_ADDER
	CARD_NODE(unsigned id, uint64_t weight_, vec<Lit>& inputs_, WEIGHT_AGGREGATE*wa, CARD_ADDER_BASE*troot_) {
#else
	CARD_NODE(unsigned id,uint64_t weight_,vec<Lit>& inputs_,WEIGHT_AGGREGATE*wa,TNode*troot_){
#endif
		my_id = id;
		weight=weight_;
		inputs_.copyTo(inputs);// = inputs_;
		troot = troot_;
		if (troot)
			UB = troot->linkingVar.size();//inputs.size();
		parent=wa;	
		tcount=0;
		//assumption_lb = 0;
		
	}	

	virtual CRef prop(Solver&S, Lit L, CRef cref);
	Clause::Type get_type() { return Clause::CARD_CLAUSE; }
	uint64_t model_check(vec<lbool>&model) {
#ifdef USE_CARD_ADDER
		if (troot) {

			uint64_t w=troot->model_check(model);
			return w*weight;
		}
#endif
		return 0;
	}
	uint64_t get_max_UB() {

		if (!troot) return 0;
		return troot->linkingVar.size()*weight;
	}
	virtual uint64_t get_max_LB() {
		return 0;
		if (!troot) return 0;
		return troot->linkingVar.size()*weight;
	}
	virtual void recal(Solver&S, uint64_t &t, uint64_t &f) {}

	 uint64_t recal(Solver&S) {
		tcount = 0;
		if (!troot) return 0;
#ifdef USE_CARD_ADDER
		
		 troot->Recal(S);
#endif
		

		for (int i = 0;i < troot->linkingVar.size();i++) {
			Var v = var(troot->linkingVar[i]);
			if (S.value(v) == l_True) {
				set_tcount(i + 1);
			}
		}
//		assert(troot->counter == tcount);
		return tcount*weight;


	}
	void set_reason_tcount(Solver&S,Lit L, vec<Lit>&conflicts, Lit l = lit_Undef) {
		if (tcount ){//&& tcount< troot->linkingVar.size()) {
			Lit LL = get_lit(tcount-1);
			Var Tv = var(LL);
			assert(S.value(Tv) == l_True);
			conflicts.push(LL);
	
		}
	}
	virtual void set_reason_fcount(Solver&S, Lit L, vec<Lit>&conflicts, Lit l = lit_Undef) {

	}
	Lit get_lit(int bit) {

		return troot->linkingVar[bit];

	}
	Var getTmax(Lit L) {
		assert(!sign(L));
		Var v = var(L);
		return v - var(troot->linkingVar[0]);
	}
	Var getFmin(Lit L) {
		assert(sign(L));
		Var v = var(L);
		return var(troot->linkingVar[troot->linkingVar.size()-1])-v;
	}
	void set_tcount(uint64_t v) {
		tcount = v;
	}
	
	bool update_tcount(Solver&S,Lit L) {

		int v = getTmax(L);
		if (v >=tcount) {
			set_tcount(v + 1);
			return true;
		}
		return false;
	}
	virtual bool update_fcount(Solver&S, Lit L) {
		return false;
	}
	virtual bool deduce_if_possible_fcount(Solver&S, CRef cr, uint64_t cost_difference)
	{
		assert(0);
		return false;
	}
	bool deduce_if_possible_tcount(Solver&S, CRef cr, uint64_t cost_difference)
	{


		assert((int64_t)cost_difference >= 0);
		uint64_t margin = cost_difference / weight;

		
		UB = tcount + margin;
		if (!troot) return true;


		for (size_t i = UB;i < troot->linkingVar.size();i++) {
			Lit L = troot->linkingVar[i];
			if (S.value(var(L)) == l_Undef) {
				Lit V = ~L;
				Var VV = var(V);
				if (var(V) == 0x1b5) {
					int m = 0;

				}
				S.uncheckedEnqueue(~L, cr);
			}
			else if (S.value(var(L)) == l_False) break;
			else if (S.value(var(L)) == l_True) {
				
				return false;
				assert(0);
			}
		}
		return true;
	}
	
	
	void get_card_set(set<CARD_NODE*>& card_set) {
		card_set.insert(this);
		for (int i = 0;i < children.size();i++) {
			children[i]->get_card_set(card_set);
		}
	}
	
	
	void save_state() {
		UB_save = UB;
		tcount_save = tcount;
		for (int i = 0;i < children.size();i++) {
			children[i]->save_state();
		}
		if (troot) {
			troot->save_state();
		}
	}
	void restore_state() {
		UB = UB_save;
		tcount = tcount_save;
		for (int i = 0;i < children.size();i++) {
			children[i]->restore_state();
		}
		if (troot) troot->restore_state();
	}
	void print_UB();
	void print_LB();
	uint64_t model_check(vec<lbool>& model, bool input_check);
	void attach_solver(Solver&S);
	virtual void attach_port(Solver&S,CRef cr);
	void print_values(MaxSAT&maxsat,int level);
	CARD_NODE* split(WEIGHT_AGGREGATE&maxsat,uint64_t w);
	unsigned my_id;
	uint64_t weight;
	vec<Lit> inputs;

	int64_t tcount,tcount_save;
	uint64_t UB,UB_save;
	vec<CARD_NODE*> children;
//	vec<int> children_registered_lb;
	WEIGHT_AGGREGATE*parent;
	//CRef cref;
#ifdef USE_CARD_ADDER
	CARD_ADDER_BASE*troot;
#else
	TNode* troot;
#endif



};
struct CARD_NODE_BOTH :public CARD_NODE
{
#ifdef USE_CARD_ADDER
	CARD_NODE_BOTH(unsigned id, uint64_t weight_, vec<Lit>& inputs_, WEIGHT_AGGREGATE*wa, CARD_ADDER_BASE*troot_)
		:CARD_NODE(id, weight_, inputs_, wa, troot_)
	{
#else
	CARD_NODE_BOTH(unsigned id, uint64_t weight_, vec<Lit>& inputs_, WEIGHT_AGGREGATE*wa, TNode*troot_)
		:CARD_NODE(id, weight_, inputs_, wa, troot_)
	{
#endif


	}
	CRef prop(Solver&S, Lit L, CRef cref);
	//void attach_port(Solver&S, CRef cr);
	void set_fcount(uint64_t v) {
		fcount = v;
	}
	uint64_t get_max_LB() {
		return get_max_UB();
	}
	void recal(Solver&S,uint64_t &tsum, uint64_t &fsum) {
		tcount = 0;
		fcount = 0;
		if (!troot) return ;
#ifdef USE_CARD_ADDER

		troot->Recal(S);
#endif

		bool f = false;
		for (int i = 0;i < troot->linkingVar.size();i++) {
			Var v = var(troot->linkingVar[i]);
			if (S.value(v) == l_True) {
				set_tcount(i + 1);
			}
			if (!f&& S.value(v) == l_False) {
				f = true;
				set_fcount(troot->linkingVar.size() - i);
			}
		}
		tsum = tcount;
		fsum = fcount;

	}
	bool update_fcount(Solver&S, Lit L) {

		int v = getFmin(L);
		if (v >= fcount) {
			set_fcount(v + 1);
			return true;
		}
		return false;
	}
	bool deduce_if_possible_fcount(Solver&S, CRef cr, uint64_t cost_difference)
	{
		assert((int64_t)cost_difference >= 0);
		uint64_t margin = cost_difference / weight;


		LB = fcount + margin;
		if (!troot) return true;


		for (int i = troot->linkingVar.size() - 1;i >= troot->linkingVar.size()-(1+LB);i--) {
			Lit L = troot->linkingVar[i];
			if (S.value(var(L)) == l_Undef) {
				Lit V = ~L;
				Var VV = var(V);
				
				S.uncheckedEnqueue(L, cr);
			}
			else if (S.value(var(L)) == l_True) break;
			else if (S.value(var(L)) == l_False) {

				return false;
				assert(0);
			}
		}
		return true;
	}
	void set_reason_fcount(Solver&S, Lit L, vec<Lit>&conflicts, Lit l = lit_Undef) {
		if (fcount) {//&& tcount< troot->linkingVar.size()) {
			int size=troot->linkingVar.size();
			Lit LL = get_lit(size-(fcount));
			Var Tv = var(LL);
			assert(S.value(Tv) == l_False);
			conflicts.push(~LL);

		}
	}
	int64_t fcount;
	uint64_t LB;
};

struct WEIGHT_AGGREGATE: public SPECIAL_CLAUSE
{

	WEIGHT_AGGREGATE() {
		tsum = 0;
		UB = -1;

	}


	Clause::Type get_type() { return Clause::WEIGHT_CLAUSE; }
	void tsum_count(Solver&S) {
		tcounts.clear();
		tsum = 0;
		for (int i = 0;i< cards.size();i++) {
			uint64_t t = cards[i]->recal(S);
			tsum += t;
			tcounts.push_back(t);
		}
	}
	uint64_t model_check(vec<lbool>&model,int &tsum) {
		uint64_t sum = 0;
		tsum = 0;
		for (int i = 0;i < cards.size();i++) {
			uint64_t s=cards[i]->model_check(model);
			if (s) {
				tsum++;
				sum += s;
			}
		}
		return sum;
	}
	virtual bool recal(Solver&S){
		tcounts.clear();
		tsum = 0;
		for (int i=0;i< cards.size();i++){
			uint64_t t=cards[i]->recal(S);
			tsum += t;
			tcounts.push_back(t);
		}	
#ifdef RECAL_TRY
		return true;
#endif
		if (UB == -1) {

			UB = 0;
			for (int i = 0;i < cards.size();i++) {
				UB += cards[i]->get_max_UB();

			}

		}
		else {
	
			int64_t d = UB - tsum;
			if (d < 0) {

				return false;
			}

			for (int i = 0;i < cards.size();i++) {
		
				bool success=cards[i]->deduce_if_possible_tcount(S, CRef_Undef, UB - tsum);
				if (!success) return false;
			}	

			return true;
		
		
		}

		
	}	
	void set_reason_tcount(Solver&S,Lit L,vec<Lit> & conflicts,bool conflict=false) {
#ifdef CARD_CNT
		tsum_count(S);
#endif
		conflicts.clear();
		for (int i = 0;i< cards.size();i++) {
			cards[i]->set_reason_tcount(S, L,conflicts);;
		}

	}
	void print_values(MaxSAT&maxsat,int level) {
		for (int i = 0;i < cards.size();i++) {
			cards[i]->print_values(maxsat,level);
		}
	}
	void update_tcount_only(unsigned id, uint64_t tcount) {

		tsum -= tcounts[id];
		tsum += tcount;
		tcounts[id] = tcount;

	}

	virtual void update_fcount_only(unsigned id, uint64_t tcount) {
		assert(0);
	}

	CARD_NODE* get_card(uint64_t weight) {
		for (int i = 0;i < cards.size();i++) {
			if (weight == cards[i]->weight)return cards[i];
		}
		assert(0);
		return 0;
	}
	CRef update_tcount(Solver&S,unsigned id, uint64_t tcount, bool deduced,CRef cr);
	virtual CRef update_fcount(Solver&S, unsigned id, uint64_t fcount, bool deduced, CRef cr)
	{
		assert(0);
		return CRef_Undef;
	}
	bool set_UB(Solver&S,uint64_t K);
	virtual bool set_LB(Solver&S, uint64_t K) {
		assert(0);
		return false;
	}
	void attach_solver(Solver&S);
	uint64_t model_check(vec<lbool>& model,bool input_check);
	


	vector<uint64_t> subsetSum(vector<uint64_t> set, uint64_t K) {
		vector<vector<uint64_t> > subset;
		vector<uint64_t> phi;
		subset.push_back(phi);

		for (int i = 0;i < set.size();i++) {
			vector<vector<uint64_t> > newSubset;

			for (int j = 0;j < subset.size();j++) {
				vector<uint64_t> subsetElm = subset[j];
				subsetElm.push_back(set[i]);
				uint64_t sum = 0;
				for(int k=0;k<subsetElm.size();k++)
					sum += subsetElm[k];
				if (sum == K)
					return subsetElm;
				newSubset.push_back(subsetElm);
			}
			for (int j = 0;j < newSubset.size();j++) 
				subset.push_back(newSubset[j]);
		}

		return vector<uint64_t>();
	}
	
	
	void save_state() {
		for (int i = 0;i < cards.size();i++) {
			cards[i]->save_state();
		}
		tsum_save = tsum;
		UB_save = UB;
		tcounts_save = tcounts;
	}
	void restore_state() {
		for (int i = 0;i < cards.size();i++) {
			cards[i]->restore_state();
		}
		tsum = tsum_save;
		UB = UB_save;
		tcounts = tcounts_save;
	}
	void save_cards() { cards_save = cards; }
	int  get_cards_save_size() { return cards_save.size(); }
	void restore_cards(int cards_size) {
		assert(cards_size <= cards_save.size());
		cards.clear();
		for (int i = 0;i < cards_size;i++) {
			cards.push_back(cards_save[i]);
		}
	}


	void print_UB();
	void print_LB();
	uint64_t tsum,tsum_save,UB,UB_save;

	vector<CARD_NODE*> cards;
	vector<CARD_NODE*> cards_save;
	
	
	vector<uint64_t> tcounts,tcounts_save;
	//CRef cref;
};
struct WEIGHT_AGGREGATE_BOTH : public WEIGHT_AGGREGATE
{

	WEIGHT_AGGREGATE_BOTH() {
		fsum = 0;
		LB = -1;

	}

	bool recal(Solver&S) {
		tcounts.clear();
		fcounts.clear();
		tsum = 0;
		fsum = 0;
		for (int i = 0;i< cards.size();i++) {
			uint64_t t, f;
			cards[i]->recal(S,t,f);
			tsum += t;
			fsum += f;
			tcounts.push_back(t);
			fcounts.push_back(f);
		}

		if (UB == -1) {

			UB = 0;
			for (int i = 0;i < cards.size();i++) {
				UB += cards[i]->get_max_UB();

			}

		}
		else {

			int64_t d = UB - tsum;
			if (d < 0) {

				return false;
			}

			for (int i = 0;i < cards.size();i++) {

				bool success = cards[i]->deduce_if_possible_tcount(S, CRef_Undef, UB - tsum);
				if (!success) return false;
			}

			return true;


		}
		if (LB == -1) {

			LB = 0;
			for (int i = 0;i < cards.size();i++) {
				LB += cards[i]->get_max_LB();

			}

		}
		else {

			int64_t d = LB - fsum;
			if (d < 0) {

				return false;
			}

			for (int i = 0;i < cards.size();i++) {

				bool success = cards[i]->deduce_if_possible_fcount(S, CRef_Undef, LB - fsum);
				if (!success) return false;
			}

			return true;


		}

	}
	CRef update_fcount(Solver&S, unsigned id, uint64_t fcount, bool deduced, CRef cr);
	
		
	
	void update_fcount_only(unsigned id, uint64_t fcount) {
		fsum -= fcounts[id];
		fsum += fcount;
		fcounts[id] = fcount;
	}
	void fsum_count(Solver&S) {
		fcounts.clear();
		fsum = 0;
		for (int i = 0;i< cards.size();i++) {
			uint64_t t, f;
			cards[i]->recal(S,t,f);
			fcounts.push_back(t);
		}
	}
	void set_reason_fcount(Solver&S, Lit L, vec<Lit> & conflicts, bool conflict = false) {
#ifdef CARD_CNT
		fsum_count(S);
#endif
		conflicts.clear();
		for (int i = 0;i< cards.size();i++) {
			cards[i]->set_reason_fcount(S, L, conflicts);;
		}

	}
	bool set_LB(Solver&S, uint64_t K);
	vector<uint64_t> fcounts;
	uint64_t fsum;
	uint64_t LB;

};

}
