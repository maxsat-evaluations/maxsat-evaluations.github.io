/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include "maxsat.h"
#include "maxsat2.h"
#include <iostream>
namespace Glucose {
	void VSoftPM::set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions) {
		if (weight == 0) return;

		assert(weight == 1);


		if (troot->linkingVar.size() > RHS) {
			L = troot->linkingVar[RHS];
			assumptions.push(~L);
			maxsat.add_vsoft_clause_map(L, this);

		}

	}
	VSoftPM::VSoftPM(MaxSAT&maxsat,VSoftPM*p, TNode*t,int target_UB) {
		p->weight = 0;
		RHS = p->RHS + 1;
		lowerbound = RHS;
		
		vec<Lit> linkingVar;
		if (!target_UB) target_UB = RHS;
		troot = maxsat.mergeCardinals(t,p->troot, linkingVar, target_UB);
		troot->set_base(this);
		if (troot->linkingVar.size() >= lowerbound) {
			maxsat.addClause(troot->linkingVar[lowerbound - 1]);
		}
		type = MCU3;
		weight = 1;
		maxsat.add_vsoft_clause(this);
		L = lit_Undef;
	}
	VSoftPM::VSoftPM(MaxSAT&maxsat, TNode*t, int RHS_) {
		troot = t;
		troot->set_base(this);
		type = MCU3;
		weight = 1;
		RHS = RHS_;
		maxsat.add_vsoft_clause(this);
		L = lit_Undef;
		lowerbound = RHS;
		if (troot->linkingVar.size() >= lowerbound) {
			maxsat.addClause(troot->linkingVar[lowerbound - 1]);
		}
	}
	VSoftPM::VSoftPM(MaxSAT&maxsat, TNode*t) {
		troot = t;
		troot->set_base(this);
		type = MCU3;
		weight = 1;
		RHS = 1;
		maxsat.add_vsoft_clause(this);
		L = lit_Undef;
		lowerbound = 0;
	}

	void VSoftPM::update_RHS(MaxSAT&maxsat)
	{

		maxsat.extend_UB(troot, ++RHS);
		lowerbound = RHS;
		if (troot->linkingVar.size() > RHS) {
			L = troot->linkingVar[RHS];
		}
		if (troot->linkingVar.size() >= lowerbound) {
			maxsat.addClause(troot->linkingVar[lowerbound - 1]);
		}
	//	maxsat.addClause(troot->linkingVar[lowerbound]);

	}
	void VSoftPM::update_RHS(MaxSAT&maxsat,TNode*right)
	{

		maxsat.extend_UB(troot, ++RHS);
		lowerbound = RHS;
		if (!right) return;

		vec<Lit> linkingVar;

		troot=maxsat.mergeCardinals(right, troot, linkingVar, RHS);
		troot->set_base(this);

		if (troot->linkingVar.size() > RHS) {
			L = troot->linkingVar[RHS];
		}
	}

void MaxSAT::set_disjoint_core_assumptions(vec<Lit>& assumptions) {

	assumptions.clear();
	vsoft_clause_map.clear();
	for (int i = 0;i < vsoft_clauses.size();i++) {
		if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) continue;
		vsoft_clauses[i]->set_assumption(*this, assumptions);
	}

}
void MaxSAT::mcu3_set_assumptions(vec<Lit>&assumptions) {
	assumptions.clear();
	vsoft_clause_map.clear();


	for (int i = 0;i < vsoft_clauses.size();i++) {
		if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
			if (vsoft_clauses[i]->weight) {
				
				vsoft_clauses[i]->set_assumption(*this, assumptions);
			}
		}
		else if (vsoft_clauses[i]->type == VSoftClauseBase::MCU3) {

			vsoft_clauses[i]->set_assumption(*this, assumptions);
		}
	}


}

void VSoftClauseC::gen_cardinals(MaxSAT&maxsat,int UB) {

	vec<Lit> linkingVar;
	vec<Lit> inputs;
	for (int j = 0;j < vclauses.size();j++) {
		Lit L = vclauses[j]->L;
		inputs.push(L);
	}
	troot = maxsat.genCardinals(inputs, linkingVar, UB, false);

	assert(troot);
	assert(RHS == 1);
	if (lowerbound) troot->set_base(this);
	if (troot->UB < RHS) {
		maxsat.extend_UB(troot, RHS);

	}
	if (troot->linkingVar.size() > RHS) {
		L = troot->linkingVar[RHS];

	}
	else L = lit_Undef;
	if (lowerbound&& troot->linkingVar.size() >= lowerbound) {
		maxsat.addClause(troot->linkingVar[lowerbound - 1]);
	}
}
#ifdef USE_CARD_SAT_UNWEIGHT
void MaxSAT::unweight_card_search() {
	int UB;
	
	weight_root = new WEIGHT_AGGREGATE();
	
	vector<CARD_NODE*> cards;
	
	int id = 0;
	bool send = true;
	solver = rebuildSolveroll();

	{
		vec<Lit> assumptions;
		lbool ret = solveLimited(assumptions);
		UB = computeCostModel(solver->model);
	}

	for (int i = 0;i < nSoft();i++) {
		uint64_t w = softClauses[i].weight;
		Lit L = softClauses[i].assumptionVar;
		VSoftClauseBase*vs = new VSoftClauseBase(L, w, i);
		vs->send_clause(*this);
		add_vsoft_clause(vs);


	}
	vec<Lit> inputs;
	for (int i = 0;i < nSoft();i++) {
		uint64_t w = softClauses[i].weight;
		Lit L = softClauses[i].assumptionVar;
		inputs.push(L);
	}

	CARD_ADDER_BASE*troot = 0;
	troot = genCardAdder(inputs, outputs, UB, send);

	CARD_NODE*cn = new CARD_NODE(id++, 1, inputs, weight_root, troot);
	cards.push_back(cn);


	weight_root->cards = cards;


	attach_solver(*solver);



	set_UB(*solver, UB);


	lbool ret = l_True;

	while (ret == l_True) {
		//solver->set_stoptime(timeout);
		vec<Lit> assumptions;


		ret = solveLimited(assumptions);
		if (ret == l_True) {
			solver->model.copyTo(model);// = solver->model;

			int tsum = 0;
			//int64_t sum=weight_root->model_check(model,tsum);

			uint64_t t = computeCostModel(solver->model);
		
			if (t < best_UB) {
				best_UB = t;
				upperbound = t;
				solver->saveModel();
				printf("o %" PRIu64 "\n", upperbound);
			}


			if (!UB) break;
			vec<Lit> lits;

			bool Ret = set_UB(*solver, --UB);

			if (!Ret) ret = l_False;

		}

		else {


			break;
		}
	}
	printf("Best UB=%zd\n", best_UB);



}
#endif
void MaxSAT::send_soft_clauses() {

	for (int i = 0;i < nSoft();i++) {
		uint64_t w = softClauses[i].weight;
		Lit L = softClauses[i].assumptionVar;
		VSoftClauseBase*vs = new VSoftClauseBase(L, w, i);
		vs->send_clause(*this);
		add_vsoft_clause(vs);


	}

}
#ifdef USE_OLL_MCU3_UNWEIGHT

void MaxSAT::unweight_search() {

	uint64_t UB;
	uint64_t rampUB = ramp_seach(6);
	printf("c ramp done\n");
	use_simp=true;


	if (rampUB == LLONG_MAX) {
		ramp->free_memory();
		solver = rebuildSolveroll();
		send_soft_clauses();

		UB = nSoft();
	}
	else if (rampUB == LLONG_MIN) {
		solver = rebuildSolveroll();
		send_soft_clauses();
		UB = nSoft();
	}
	else {

		ramp->save_model(*this);

		best_UB = rampUB;
		UB = rampUB;
		ramp->free_memory();
		solver = rebuildSolveroll();
		send_soft_clauses();
		model_practice();
	
	}
	upperbound = UB;
	best_UB = upperbound;
	lowerbound = 0;

	
	

	
#ifdef OLL_LOWER
	
	lowerbound = oll_lowerbound_search_inc(UB);
	printf("c lbsi done\n");
#endif
	if (upperbound == lowerbound) return;
	
	//Phase 1
	
	lbool res = l_True;



	vec<VSoftClauseC*> cvec;
	vec<Lit> bvec;
	for (int i = 0;i < vsoft_clauses.size();i++) {
		VSoftClauseC* vc = dynamic_cast<VSoftClauseC*>(vsoft_clauses[i]);
		if (vc) cvec.push(vc);
		if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
			if (vsoft_clauses[i]->weight) {
				bvec.push(vsoft_clauses[i]->L);
			}

		}

	}
	vector<CARD_NODE*> cards;
	if (lowerbound == 0) {
		solver->reset_ok();
		if (UB != nSoft()) {//RAMPもしくはDisjointで解があった。
			model_practice(true);
		}else {//RAMP、Disjoint両方解がなかったので、Free状態で解を求める
			vec<Lit> assumptions;
			lbool success = searchSATSolver(solver, assumptions);
			if (success == l_True) {
				uint64_t cost = computeCostModel(solver->model,true);
				UB = cost;
				best_UB = UB;
				upperbound = UB;
				printf("o %" PRIu64 "\n", upperbound);
				solver->saveModel();

			}
			else assert(0);

		}
		//Variableが大きすぎる場合は、Repetiveがよいだろう　TODO
		weight_root = new WEIGHT_AGGREGATE();
		
		int id = 0;
		bvec.clear();//途中まで出来ているかもしれない
		for (int i = 0;i < vsoft_clauses.size();i++) {
			VSoftClauseC* vc = dynamic_cast<VSoftClauseC*>(vsoft_clauses[i]);
			if (vc) cvec.push(vc);
			if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
				bvec.push(vsoft_clauses[i]->L);//weightに関係なくすべてが対象
			}

		}
		if (bvec.size())
		{
			vec<Lit> linkingVar;
			int right_UB = best_UB - lowerbound;
			TNode*right = genCardinals(bvec, linkingVar, right_UB, false);
			CARD_NODE*cn = new CARD_NODE(id++, 1, right->inputs, weight_root, right);
			cards.push_back(cn);
		}

	}
	else {

#ifdef SAT3
		weight_root = new WEIGHT_AGGREGATE();
		
		int id = 0;
		int right_UB = best_UB - lowerbound;
		for (int i = 0;i < cvec.size();i++) {
			assert(!cvec[i]->troot);

			cvec[i]->gen_cardinals(*this, right_UB + 1);
			TNode*left = cvec[i]->troot;
			CARD_NODE*cn = new CARD_NODE(id++, 1, left->inputs, weight_root, left);
			cards.push_back(cn);
		}

		vec<Lit> linkingVar;

		TNode*right = genCardinals(bvec, linkingVar, right_UB, false);

		CARD_NODE*cn = new CARD_NODE(id++, 1, right->inputs, weight_root, right);
		cards.push_back(cn);

#else
#ifdef SAT2
		weight_root = new WEIGHT_AGGREGATE();
		
		int id = 0;

		TNode* left = merge_cardinals(cvec, best_UB);
		new VSoftPM(*this, left, best_UB);

		vec<Lit> linkingVar;
		int right_UB = best_UB - lowerbound;
		TNode*right = genCardinals(bvec, linkingVar, right_UB, false);

		left = mergeCardinals(right, left, linkingVar, best_UB);

		CARD_NODE*cn = new CARD_NODE(id++, 1, left->inputs, weight_root, left);
		cards.push_back(cn);



#else

#ifdef SAT1
		//for (int i = 0;i < vsoft_clauses.size();i++) {
		//	vsoft_clauses[i]->set_lowerbound_to_clause(*this);
		//}
		weight_root = new WEIGHT_AGGREGATE();
		
		int id = 0;
		if (cvec.size()) {
			TNode* left = merge_cardinals(cvec, best_UB);
			//Lit L = left->linkingVar[cvec.size()+2];
			//addClause(L);
			CARD_NODE*cn = new CARD_NODE(id++, 1, left->inputs, weight_root, left);
			cards.push_back(cn);
		}
		if (bvec.size())
		{
			vec<Lit> linkingVar;
			int right_UB = best_UB - lowerbound;
			TNode*right = genCardinals(bvec, linkingVar, right_UB, false);
			CARD_NODE*cn = new CARD_NODE(id++, 1, right->inputs, weight_root, right);
			cards.push_back(cn);
		}

#else




#ifdef SAT0
		VSoftPM*disjoint_sum = 0;
		if (1) {
			TNode* right = merge_cardinals(cvec, cvec.size());
			disjoint_sum = new VSoftPM(*this, right, cvec.size());


			vec<Lit> assumptions;
			mcu3_set_assumptions(assumptions);

			clock_t start, stop;

			int solve_counter = 0;
			double diff = 0;
			while (true) {
				res = searchSATSolver(solver, assumptions);
				if (res == l_True) {
					disjoint_sum->set_lowerbound(disjoint_sum->RHS);
					uint64_t cost = computeCostModel(solver->model);
					if (cost < upperbound) {
						best_UB = cost;
						upperbound = cost;
					       // printf("c sa0\n");
						printf("o %" PRIu64 "\n", upperbound);
						solver->saveModel();

					}
					return;
				}
				else if (res == l_False) {
					if (solve_counter == 0) {
						start = clock();
					}
					else {
						stop = clock();
						diff = (double)(stop - start) / CLOCKS_PER_SEC;
						start = clock();

					}
					solve_counter++;
					assert(solver->conflict.size());

					if (0)
					{
						conflict_minimize(solver->conflict);



					}
					solver->conflict.copyTo(conflict);
					vec<Lit> vs_vec;
					for (int i = 0;i < conflict.size();i++) {
						Lit L = conflict[i];
						std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
						if (im == vsoft_clause_map.end()) assert(0);
						else {
							VSoftClauseBase*vs = (*im).second;

							if (vs->type == VSoftClause::AssumptionVar) {
								vs_vec.push(vs->L);//がカウントはされる
								vs->weight = 0;//vminの方は次回assumptionされない
							}
						}
					}

					if (vs_vec.size()) {
						vec<Lit> linkingVar;
						TNode*right = genCardinals(vs_vec, linkingVar, 1, false);

						if (diff > TO_SAT_TIME_STEP) {
							vec<Lit> assumptions;
							model_practice(true);
							lbool ret = solveLimited(assumptions);
							assert(ret == l_True);
							{
								solver->model.copyTo(model);// = solver->model;
															//weight_root->print_values(*this,2);


								uint64_t t = computeCostModel(solver->model);
								//printf("o=%zd \n", t);
								if (t < best_UB) {
									best_UB = t;
									upperbound = t;
									solver->saveModel();
									printf("o %" PRIu64 "\n", upperbound);
									//	UB = t;//TRY
								}
							}


							disjoint_sum = new VSoftPM(*this, disjoint_sum, right, best_UB);
							break;
						}
						else {
							disjoint_sum = new VSoftPM(*this, disjoint_sum, right);
						}
					}
					else {
						printf("c VSoftPM updated\n");
						if (diff > TO_SAT_TIME_STEP) {//TIMEOUTなので、最大限拡張しArrangedCOPYをTNODEとする
							extend_UB(disjoint_sum->troot, best_UB);
							TNode*right = gen_arranged_copy(disjoint_sum->troot, best_UB);
							disjoint_sum = new VSoftPM(*this, right, disjoint_sum->RHS + 1);
							vec<Lit> assumptions;
							model_practice(true);
							lbool ret = solveLimited(assumptions);
							assert(ret == l_True);
							break;
						}
						else {
							disjoint_sum->update_RHS(*this);
						}
					}
					mcu3_set_assumptions(assumptions);


					lowerbound++;
					//printf("c LB=%zd\n", lowerbound);
				}
			}
		}


		printf("c phase 3\n");
		bvec.clear();
		{

			for (int i = 0;i < vsoft_clauses.size();i++) {
				if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
					if (vsoft_clauses[i]->weight) {
						Lit L = vsoft_clauses[i]->L;
						bvec.push(L);
					}
				}
			}
		}

		int right_ub = best_UB - lowerbound;
		//Phase 3
		weight_root = new WEIGHT_AGGREGATE();
		
		unsigned id = 0;
		if (disjoint_sum) {
			//vec<Lit> linkingVar;
			//TNode*right = genCardinals(bvec, linkingVar, right_ub, false);
		//	TNode*right = outside_disjoint->troot;

			TNode*left = disjoint_sum->troot;
			//	vec<Lit> linkingVar2;
			//	left=mergeCardinals(right, left, linkingVar2, best_UB);



			CARD_NODE*cn = new CARD_NODE(id++, 1, left->inputs, weight_root, left);
			cards.push_back(cn);
		}




		if (bvec.size())
		{
			vec<Lit> linkingVar;
			TNode*right = genCardinals(bvec, linkingVar, right_ub, false);

			CARD_NODE*cn = new CARD_NODE(id++, 1, right->inputs, weight_root, right);
			cards.push_back(cn);
		}
#endif
#endif
#endif
#endif
	}//end else
GO:
		weight_root->UB = best_UB;
		weight_root->cards = cards;
		UB = best_UB;

		attach_solver(*solver);



		set_UB(*solver, UB);

		uint64_t t_UB;
		
		lbool ret = l_True;

		while (ret == l_True) {
			//solver->set_stoptime(timeout);
			vec<Lit> assumptions;

			ret = solveLimited(assumptions);
			if (ret == l_True) {
				solver->model.copyTo(model);// = solver->model;
				//weight_root->print_values(*this,2);
				int tsum = 0;
				//int64_t sum=weight_root->model_check(model,tsum);

				uint64_t t = computeCostModel(solver->model);
				//printf("c o=%zd \n", t);
				if (t < best_UB) {
					best_UB = t;
					
					upperbound = t;
					solver->saveModel();
					printf("o %" PRIu64 "\n", upperbound);
				//	UB = t;//TRY
				}


				if (!UB) break;
				vec<Lit> lits;

				bool Ret = set_UB(*solver, --UB);

				if (!Ret) ret = l_False;

			}

			else {


				break;
			}
		}
		//printf("Best UB=%zd\n", best_UB);



	}
#endif



}	
