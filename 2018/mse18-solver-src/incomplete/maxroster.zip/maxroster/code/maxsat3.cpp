/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include "maxsat.h"
#include "maxsat2.h"
#include "core/Solver.h"
#include "core/SolverTypes.h"
#include "MaxTypes.h"
#include "define.h"
#include <algorithm>


#include "simp/SimpSolver.h"
#include <iostream>
#include <stdio.h>
#ifdef _WIN32
#include<Windows.h>
#include <filesystem>//tr2::sys::pathに必要
#else
#include <signal.h>
#include <time.h>
#include <unistd.h>

#endif

Glucose::MaxSAT*mxsolver;
bool free_search_success = false;
bool disjoint_success = false;
bool full_success = false;
#ifdef _WIN32
//現在の時刻をコンソールに表示するコールバック関数
VOID NTAPI TimerCallback(PTP_CALLBACK_INSTANCE Instance,
	PVOID Context,
	PTP_TIMER Timer)
{
	SYSTEMTIME st;
	Glucose::MaxSAT*mx =(Glucose::MaxSAT*) Context;
	//mx->write_file();
	//write(1,"c time handler \n");

	
	
	if (mxsolver->solver) {
		mxsolver->solver->interrupt();
	}
	mx->print_model = true;
	GetLocalTime(&st);
	

	//printf("%02d:%02d:%02d\n",
	//	st.wHour,
	//	st.wMinute,
	//	st.wSecond);

	//if (!free_search_success&& !disjoint_success && !full_success) printf("c *****************No Successful!\n");
	//else if (disjoint_success) printf("c **********Disjoint Success\n");
	//else if (free_search_success) printf("c ********Free Successs\n");
	//exit(0);
}



#else
void timer_handler(int signum) {
	//printf("c time handler\n");
	
	if (mxsolver->solver) {
		mxsolver->solver->interrupt();
	}
	mxsolver->print_model = true;
	
//	if (!mxsolver->get_model_saving()) {
//		mxsolver->write_file();
//	}else 	mxsolver->print_model = true;

	//if (!free_search_success && !disjoint_success && !full_success) printf("c *****************No Successful!\n");
	//else if (disjoint_success) printf("c **********Disjoint Success\n");
	//else if (free_search_success) printf("c ********Free Successs\n");
	//exit(0);
}
#endif

namespace Glucose{
#ifdef MINISAT
	void Solver::NODE_cancelUntil(int level, bool f) {
		

		if (decisionLevel() > level) {
			int lim = trail_lim[level];

			for (int c = trail.size() - 1; c >= trail_lim[level]; c--) {
				Lit p = trail[c];
				Var      x = var(p);
				uint64_t age = conflicts - picked[x];
				if (age > 0) {
					double reward = ((double)conflicted[x]) / ((double)age);
#if BRANCHING_HEURISTIC == LRB
#if ALMOST_CONFLICT
					double adjusted_reward = ((double)(conflicted[x] + almost_conflicted[x])) / ((double)age);
#else
					double adjusted_reward = reward;
#endif
					double old_activity = activity[x];
					activity[x] = step_size * adjusted_reward + ((1 - step_size) * old_activity);
					if (order_heap.inHeap(x)) {
						if (activity[x] > old_activity)
							order_heap.decrease(x);
						else
							order_heap.increase(x);
					}
#endif
					total_actual_rewards[x] += reward;
					total_actual_count[x] ++;
				}
#if ANTI_EXPLORATION
				canceled[x] = conflicts;
#endif



				//ValueのPopBack




#ifdef USE_VECTOR
				set_value(x, l_Undef);
#else
				assigns[x] = l_Undef;
#endif



				if (phase_saving > 1 || (phase_saving == 1) && c > trail_lim.last())
					polarity[x] = sign(trail[c]);
				insertVarOrder(x);
			}
			qhead = trail_lim[level];
			trail.shrink(trail.size() - trail_lim[level]);
			trail_lim.shrink(trail_lim.size() - level);


			if (weight_root) {

				weight_root->recal(*this);

			}
			for (int i = 0;i< special_clauses.size();i++) {
				special_clauses[i]->Recal(*this);
			}
		}
	}
	void Solver::seen_write(Lit Q, CRef cr, int & pathC, vec<Lit>& out_learnt)
	{

		Lit q = ~Q;//学習はInvertする
		int static counter = 0;
		Var v = var(q);
		if (reason(var(q)) == cr) {
			int m = 0;
		}
		bool see = seen[var(q)];
		int lev = level(var(q));
		int clev = decisionLevel();

		assert(lev <= clev);
		if (!seen[var(q)] && level(var(q)) > 0) {
			//	printf("TE:%d %d\n", level(var(q)),var(q));
#if BRANCHING_HEURISTIC == CHB
			last_conflict[var(q)] = conflicts;

#elif	BRANCHING_HEURISTIC == VSIDS
			varBumpActivity(var(q));
#endif
			seen[var(q)] = 1;
#ifdef ANA_CLEAR		
			analyze_toclear.push(q);
#endif
			if (level(var(q)) >= decisionLevel())
				pathC++;
			else {
#ifdef STATICS_MAP
				Var v = var(q);
				map<Var, int>::iterator im = statics_map.find(v);
				if (im == statics_map.end()) {
					statics_map[v] = 1;
				}
				else {
					(*im).second++;
				}
#endif
				out_learnt.push(q);
			}
			//	}


		}



	}
	void Solver::write_weight_conflict(CRef cr, int & pathC, vec<Lit>& out_learnt)
	{
		for (int i = 0;i < weight_conflict_reason.size();i++) {
			Lit q = weight_conflict_reason[i];

			if (q == lit_Error) continue;
			Var v = var(q);


			if (value(var(q)) == l_True) assert(!sign(q));
			else if (value(var(q)) == l_False) assert(sign(q));
			else assert(0);

			seen_write(q, cr, pathC, out_learnt);

		}

	}
	void Solver::write_weight_deduced_reason(Lit Q, CRef cr, int & pathC, vec<Lit>& out_learnt, bool debug)
	{
		lbool l = value(var(Q));
		assert(l != l_Undef);
		assert(l == l_False);

		vec<Lit> reason;
		weight_root->set_reason_tcount(*this, Q, reason);
		for (int i = 0;i < reason.size();i++) {
			Lit q = reason[i];
			if (debug) {
				//	printf("c reason v=%x %d\n", var(q), level(var(q)));

			}

			seen_write(q, cr, pathC, out_learnt);

		}
	}

	bool Solver::NODE_analyze(CRef confl, vec<Lit>& out_learnt, int& out_btlevel)
	{
		int pathC = 0;
		Lit p = lit_Undef;

		// Generate conflict clause:
		//
		out_learnt.push();      // (leave room for the asserting literal)
		int index = trail.size() - 1;
		bool dump = false;
#ifdef CCMIN1
		ccmin_mode = 0;
#endif
		bool wmcu3_assumption_var_used = false;
		if (confl == 0x307) {
			int m = 0;
			dump = true;
		}
		Lit op = lit_Undef;
		do {
			assert(confl != CRef_Undef); // (otherwise should be UIP)
			if (confl == 0x29ef) {
				int m = 0;
			}
			Clause& c = ca[confl];


#if LBD_BASED_CLAUSE_DELETION
			if (c.learnt() && c.activity() > 2)
				c.activity() = lbd(c);
#else
			if (c.learnt())
				claBumpActivity(c);
#endif
			if (c.get_type() == Clause::CARD_CLAUSE) {
				if (p == lit_Undef)	write_weight_conflict(confl, pathC, out_learnt);
				else  write_weight_deduced_reason(p, confl, pathC, out_learnt, dump);

			}
			else if (c.get_type() >= Clause::MOSTONE) {
				if (p == lit_Undef)	write_weight_conflict(confl, pathC, out_learnt);
				else {
					SPECIAL_CLAUSE*sc = c.get_special_clause();
					vec<Lit> reason;
					int dv = decisionLevel();
					sc->set_reason(*this, reason, p);

					for (int i = 0;i < reason.size();i++) {
						Lit q = reason[i];
						seen_write(q, confl, pathC, out_learnt);

					}
				}
			}
			else {
				for (int j = (p == lit_Undef) ? 0 : 1; j < c.size(); j++) {
					Lit q = c[j];
					Var v = var(q);
					Var V = var(p);


					if (!seen[var(q)] && level(var(q)) > 0) {
#if BRANCHING_HEURISTIC == CHB
						last_conflict[var(q)] = conflicts;
#elif BRANCHING_HEURISTIC == VSIDS
						varBumpActivity(var(q));
#endif
						conflicted[var(q)]++;
						seen[var(q)] = 1;
#ifdef ANA_CLEAR
						analyze_toclear.push(q);
#endif					
						if (level(var(q)) >= decisionLevel())
							pathC++;
						else
							out_learnt.push(q);
					}
				}
			}
#ifdef CARD_CNT
			if (p != lit_Undef) {
				Var v = var(p);
				set_value(v, l_Undef);
			}
#endif


			// Select next clause to look at:
			while (!seen[var(trail[index--])]) {
				Var v = var(trail[index + 1]);
#ifdef CARD_CNT
				set_value(v, l_Undef);
#endif
				int l = level(v);
				if (dump) {
					//printf("nv=%x %d\n", v, level(v));
				}
				assert(level(v) == decisionLevel());
				//	if (v >= ordering_variable_start) 	dr_pop(v);

				//printf("NotSeen Loop  var=%d level=%d cref=%d %d index=%d\n", v, level(v), reason(v), decisionLevel(), index);
				if (dump) {
					if (level(v) != decisionLevel()) {
						//	printf("NotSeen Loop  var=%d level=%d cref=%d %d index=%d\n", v, level(v), reason(v), decisionLevel(), index);

						assert(0);//goto exit_loop;//seen問題とりあえず
					}

				}
				l = level(v);

				//assert(level(v) == decisionLevel());

			}
			p = trail[index + 1];
			Var v = var(p);
			///#ifdef CARD_CNT
			//		set_value(v, l_Undef);
			//#endif
			if (dump) {
				//printf("v=%x %d\n", v,level(v));
			}
			//	if (v >= ordering_variable_start) dr_pop(v);
			assert(level(v) == decisionLevel());
			confl = reason(var(p));

			assert(level(var(p)) == decisionLevel());//confl == CRef_Undef);
			if (confl == CRef_Undef) break;

			//また再セットすることがある
			//	seen[var(p)] = 0;
			pathC--;

		} while (pathC > 0);//confl != CRef_Undef);//pathC > 0);
							//	printf("trail lim=%d pathC=%d\n", trail_lim[decisionLevel()],pathC);
		assert(level(var(p)) == decisionLevel());
		out_learnt[0] = ~p;
		//assert(confl == first_cref[decisionLevel()]);
		// Simplify conflict clause:
		//
		int i, j;
#ifdef ANA_CLEAR

#else	
		out_learnt.copyTo(analyze_toclear);
#endif	
		if (ccmin_mode == 2) {
			uint32_t abstract_level = 0;
			for (i = 1; i < out_learnt.size(); i++)
				abstract_level |= abstractLevel(var(out_learnt[i])); // (maintain an abstraction of levels involved in conflict)

			for (i = j = 1; i < out_learnt.size(); i++)
				if (reason(var(out_learnt[i])) == CRef_Undef || !NODE_litRedundant(out_learnt[i], abstract_level))
					out_learnt[j++] = out_learnt[i];

		}
		else if (ccmin_mode == 1) {
			for (i = j = 1; i < out_learnt.size(); i++) {
				Var x = var(out_learnt[i]);

				if (reason(x) == CRef_Undef)
					out_learnt[j++] = out_learnt[i];
				else {
					Clause& c = ca[reason(var(out_learnt[i]))];
					for (int k = 1; k < c.size(); k++)
						if (!seen[var(c[k])] && level(var(c[k])) > 0) {
							out_learnt[j++] = out_learnt[i];
							break;
						}
				}
			}
		}
		else
			i = j = out_learnt.size();

		max_literals += out_learnt.size();
		out_learnt.shrink(i - j);
		tot_literals += out_learnt.size();

		// Find correct backtrack level:
		//

		if (out_learnt.size() == 1)
			out_btlevel = 0;
		else {
			int max_i = 1;
			// Find the first literal assigned at the next-highest level:
			for (int i = 2; i < out_learnt.size(); i++)
				if (level(var(out_learnt[i])) > level(var(out_learnt[max_i])))
					max_i = i;
			// Swap-in this literal at index 1:
			Lit p = out_learnt[max_i];
			out_learnt[max_i] = out_learnt[1];
			out_learnt[1] = p;
			out_btlevel = level(var(p));
		}

#if ALMOST_CONFLICT
		seen[var(p)] = true;
		for (int i = out_learnt.size() - 1; i >= 0; i--) {
			Var v = var(out_learnt[i]);
			CRef rea = reason(v);
			if (rea != CRef_Undef) {
				Clause& reaC = ca[rea];
				for (int i = 0; i < reaC.size(); i++) {
					Lit l = reaC[i];
					if (!seen[var(l)]) {
						seen[var(l)] = true;
						almost_conflicted[var(l)]++;
						analyze_toclear.push(l);
					}
				}
			}
		}
#endif
		for (int j = 0; j < analyze_toclear.size(); j++) seen[var(analyze_toclear[j])] = 0;    // ('seen[]' is now cleared)

#ifdef ANA_CLEAR
		analyze_toclear.clear();
#else																						   //全部クリアする
		for (int i = 0;//		trail_lim[trail_lim.size() - 1];
			i < nVars();i++) {//trail.size();i++) {
			seen[i] = 0;

		}
#endif

		int cd = decisionLevel();
		int l = level(var(out_learnt[0]));
		assert(l == cd);
		if (out_learnt.size() == 1) {
			Var v = var(out_learnt[0]);

		}
		assert(l > out_btlevel);


		return wmcu3_assumption_var_used;

	}

	bool Solver::NODE_litRedundant(Lit p, uint32_t abstract_levels)
	{
		analyze_stack.clear(); analyze_stack.push(p);
		int top = analyze_toclear.size();
		while (analyze_stack.size() > 0) {
			Lit P = analyze_stack.last();
			assert(reason(var(P)) != CRef_Undef);
			Clause& c = ca[reason(var(analyze_stack.last()))]; analyze_stack.pop();

			if (c.get_type() == Clause::NormalClause) {

				for (int i = 1; i < c.size(); i++) {
					Lit p = c[i];
					if (!seen[var(p)] && level(var(p)) > 0) {
						if (reason(var(p)) != CRef_Undef && (abstractLevel(var(p)) & abstract_levels) != 0) {
							seen[var(p)] = 1;
							analyze_stack.push(p);
							analyze_toclear.push(p);
						}
						else {
							for (int j = top; j < analyze_toclear.size(); j++)
								seen[var(analyze_toclear[j])] = 0;
							analyze_toclear.shrink(analyze_toclear.size() - top);
							return false;
						}
					}
				}
			}
			else if (c.get_type() == Clause::CARD_CLAUSE || c.get_type() >= Clause::MOSTONE) {

				vec<Lit> Reason;
				if (c.get_type() == Clause::CARD_CLAUSE) {
					weight_root->set_reason_tcount(*this, P, Reason);
				}
				else {
					SPECIAL_CLAUSE*sc = c.get_special_clause();
					vec<Lit> reason;
					sc->set_reason(*this, reason);

				}

				for (int i = 0;i < Reason.size();i++) {
					Lit q = Reason[i];


					if (q == lit_Error) continue;
					Lit p = ~q;

					if (!seen[var(p)] && level(var(p)) > 0) {
						if (reason(var(p)) != CRef_Undef && (abstractLevel(var(p)) & abstract_levels) != 0) {
							seen[var(p)] = 1;
							analyze_stack.push(p);
							analyze_toclear.push(p);
						}
						else {
							for (int j = top; j < analyze_toclear.size(); j++)
								seen[var(analyze_toclear[j])] = 0;
							analyze_toclear.shrink(analyze_toclear.size() - top);
							return false;
						}
					}
				}

			}
			else {//特殊Clause処理
				assert(0);
			}
		}

		return true;
	}
	void Solver::NODE_analyzeFinal(Lit p, vec<Lit>& out_conflict)
	{
		out_conflict.clear();
		out_conflict.push(p);

		if (decisionLevel() == 0)
			return;

		seen[var(p)] = 1;

		int lm = trail_lim[0];
		for (int i = trail.size() - 1; i >= trail_lim[0]; i--) {
			Lit P = trail[i];
			Var x = var(trail[i]);
			if (seen[x]) {
				if (reason(x) == CRef_Undef) {
					assert(level(x) > 0);
					out_conflict.push(~trail[i]);
				}
				else {
					Clause& c = ca[reason(x)];
					if (c.get_type() == Clause::NormalClause) {

						for (int j = 1; j < c.size(); j++)
							if (level(var(c[j])) > 0)
								seen[var(c[j])] = 1;
					}
					else if (c.get_type() == Clause::CARD_CLAUSE) {

						vec<Lit> reason;
						weight_root->set_reason_tcount(*this, P, reason);
						for (int i = 0;i < reason.size();i++) {
							Lit q = reason[i];
							if (level(var(q)) > 0)
								seen[var(q)] = 1;
						}

					}
					else if (c.get_type() >= Clause::MOSTONE) {
						SPECIAL_CLAUSE*sc = c.get_special_clause();
						vec<Lit> reason;
						sc->set_reason(*this, reason, P);
						for (int i = 0;i < reason.size();i++) {
							Lit q = reason[i];
							if (level(var(q)) > 0)
								seen[var(q)] = 1;
						}



					}
					else {//特殊Clause処理				assert(0);
					}
				}
				seen[x] = 0;
			}
		}

		seen[var(p)] = 0;
	}
	CRef Solver::NODE_propagate()
	{
		CRef    confl = CRef_Undef;
		int     num_props = 0;
		watches.cleanAll();
		if (conflicts == 371) {
			int m = 0;
		}

		while (qhead < trail.size()) {
			static int counter = 0;
			counter++;
			if (counter == 0x6470) {
				int m = 0;

			}
			Lit            p = trail[qhead++];     // 'p' is enqueued fact to propagate.
			vec<Watcher>&  ws = watches[p];
			Var v = var(p);
			//	printf("Prop v=%x %d %x\n", v,level(v),counter);
			if ((v == 0x14e || v == 0x21c) && counter == 0x644a) {
				bool s = sign(p);
				int m = 0;

			}


			Watcher        *i, *j, *end;
			num_props++;

			for (i = j = (Watcher*)ws, end = i + ws.size(); i != end;) {
				// Try to avoid inspecting the clause:
				Lit blocker = i->blocker;
				if (blocker != lit_Undef && value(blocker) == l_True) {
					*j++ = *i++; continue;
				}

				// Make sure the false literal is data[1]:
				CRef     cr = i->cref;


				Clause&  c = ca[cr];
				if (cr == 3825) {
					int m = 0;

				}
				if (c.get_type() != Clause::NormalClause) {
					SPECIAL_CLAUSE*node = c.get_special_clause();
					if (counter == 0x63d6) {
						int m = 0;

					}
					//	printf("PropSC v=%x %d %x\n", v, level(v), counter);
					confl = node->prop(*this, p, cr);

					if (confl != CRef_Undef) {

						qhead = trail.size();
						// Copy the remaining watches:
						while (i < end)
							*j++ = *i++;
						break;
					}
					else {
						//   Keep this watch.

						*j++ = *i++;
						continue;
					}

				}

				Lit      false_lit = ~p;
				if (c[0] == false_lit)
					c[0] = c[1], c[1] = false_lit;
				assert(c[1] == false_lit);
				i++;

				// If 0th watch is true, then clause is already satisfied.
				Lit     first = c[0];
				Watcher w = Watcher(cr, first);
				if (first != blocker && value(first) == l_True) {
					*j++ = w; continue;
				}
				//Lit L = c[1];
				// Look for new watch:
				for (int k = 2; k < c.size(); k++)
					if (value(c[k]) != l_False) {
						c[1] = c[k]; c[k] = false_lit;
						watches[~c[1]].push(w);
						goto NextClause;
					}

				// Did not find watch -- clause is unit under assignment:
				*j++ = w;
				if (value(first) == l_False) {
					confl = cr;
					if (confl == 0x307) {
						int m = 0;
					}
					qhead = trail.size();
					// Copy the remaining watches:
					while (i < end)
						*j++ = *i++;
				}
				else {

					uncheckedEnqueue(first, cr);
				}
			NextClause:;
			}

			ws.shrink(i - j);


		}
		propagations += num_props;
		simpDB_props -= num_props;

		return confl;
	}
	void Solver::NODE_relocAll(ClauseAllocator& to)
	{
		// All watchers:
		//
		// for (int i = 0; i < watches.size(); i++)
		watches.cleanAll();
		for (int v = 0; v < nVars(); v++)
			for (int s = 0; s < 2; s++) {
				Lit p = mkLit(v, s);
				// printf(" >>> RELOCING: %s%d\n", sign(p)?"-":"", var(p)+1);
				vec<Watcher>& ws = watches[p];
				for (int j = 0; j < ws.size(); j++)
					ca.reloc(ws[j].cref, to);
			}

		// All reasons:
		//
		for (int i = 0; i < trail.size(); i++) {
			Var v = var(trail[i]);
			CRef cr = reason(v);
			if (cr != CRef_Undef&&  ca[cr].get_type() != Clause::NormalClause) {
				if (reason(v) != CRef_Undef) {//lockされると破綻する
					ca.reloc(vardata[v].reason, to);
				}

			}
			else {
				if (reason(v) != CRef_Undef && (ca[reason(v)].reloced() || locked(ca[reason(v)])))
					ca.reloc(vardata[v].reason, to);
			}
		}

		if (weight_root) {
			reloc(weight_root, to);
		}

		// All learnt:
		//
		for (int i = 0; i < learnts.size(); i++)
			ca.reloc(learnts[i], to);

		// All original:
		//
		for (int i = 0; i < clauses.size(); i++)
			ca.reloc(clauses[i], to);



	}



	void Solver::reloc(CARD_ADDER_BASE* n, ClauseAllocator& to)
	{
		CRef temp = n->my_cref;
		ca.reloc(n->my_cref, to);

		CARD_ADDER*ca = dynamic_cast<CARD_ADDER*>(n);
		if (ca) {
			for (int i = 0;i < ca->inputs.size();i++) {
				reloc(ca->inputs[i], to);
			}
		}

	}


	
	
void MaxSAT::readfile(){
	
	
	
	FILE*f=fopen("result.txt","r");
	if (!f) {
		printf("can not open the result.txt");
		return;
	}
	uint64_t besto=LLONG_MAX;
	model.clear();	
	open_file();
	nbInitialVariables=nVars();
	int NN=nbInitialVariables*12;
	char*readline=new char[NN];

	while (fgets(readline,NN,f)){
		if (readline[0]=='o'){
			uint64_t t=strtoull(&readline[2],0,10);
			besto=t;
			//printf("besto=%zd\n",besto);
			continue;
		}
		
		
		if (readline[0]=='v'){
			

			try {
				char *p=&readline[2];
				for (int i=0;i<nbInitialVariables;i++ ){
					
					model.push(l_Undef);
				}
				for (int i=0;i<nbInitialVariables;i++ ){
					int t=strtol(p,&p,10);
					if (t>0){
						int v=t-1;
						model[v]=l_True;

					}else if (t<0){
						int v=-t-1;
						model[v]=l_False;
					}else {
						assert(0);
						fprintf(test_f, "assert0 error\n");
						fclose(test_f);
					}	
				}
				uint64_t BEST=computeCostModel(model);
				printf("besto=%zd %zd\n",besto,BEST);
				assert(BEST==besto);
				if (test_f) {
				   
					fprintf(test_f, "%s :%zd\n", test_file.c_str(),BEST);

					fclose(test_f);
				}
				break;
			

			}
			catch (...){

				assert(0);
			}

		}
	}		
}

	void Solver::printModel(bool async_interrupt)
	{
		printf("c model printing. %d\n",Model.size());
		if (Model.size()==0) return;
#ifndef NO_ANSER		
		printf("v ");
		for (int i = 0; i < Model.size(); i++)
		{
		if (Model[i] == l_True)
			printf("%d ", i + 1);
		else
			printf("%d ", -(i + 1));
		}
		printf("\n");
#endif
#ifdef WRITE_FILE
		if (async_interrupt){
			printf("c aync_interrupt done.\n");
			mxsolver->write_file();
				
		}	

#endif		
		fflush(stdout);
		
	}	
void signal_handler(int i){
	printf("c signal.\n");
	if (mxsolver) mxsolver->printModel();
#ifdef WRITE_FILE
	if (mxsolver) mxsolver->write_file();
#endif
	_exit(1);
}
#ifndef _WIN32
sigset_t block, oblock, sigset; 
    struct sigaction sa;
#endif
void signal_setup()
{
#ifdef WRITE_FILE
	if(mxsolver) mxsolver->open_file();
#endif
#ifndef _WIN32
    sigemptyset( &block );
    //sigaddset( &block, SIGINT );
    sigaddset( &block, SIGTERM );

    sa.sa_handler = signal_handler;
    sa.sa_flags |= SA_RESTART;
    sigemptyset( &sa.sa_mask );
    //sigaction( SIGINT,  &sa, 0 );
    sigaction( SIGTERM, &sa, 0 );
#endif
}


	void Solver::saveModel()
	{
#ifndef _WIN32
	   sigprocmask( SIG_BLOCK, &block, &oblock );//SET MASK
#endif
		assert(nbInitialVariables != 0);
		assert(model.size() != 0);

		Model.clear();
		// Only store the value of the variables that belong to the
		// original MaxSAT formula.
		for (int i = 0; i < nbInitialVariables; i++)
			Model.push(model[i]);
		
	//	if (print_model){
	//		printModel();
	//		maxsat->ub_check(Model);
	//	}		
#ifndef _WIN32
	   if( sigpending( &sigset ) == 0 ) {
              if( sigismember( &sigset, SIGTERM )) {	
		 printModel();
		 _exit(1);
	      }
	   }
	   sigprocmask( SIG_SETMASK, &oblock, 0 );//RESET MASK	
#endif		
		
	}
	void Solver::reloc(WEIGHT_AGGREGATE* n, ClauseAllocator& to)
	{
		CRef temp = n->my_cref;

		ca.reloc(n->my_cref, to);



#ifdef USE_CARD_ADDER
		for (int i = 0;i<n->cards.size();i++) {
			CARD_NODE*cn = n->cards[i];
			ca.reloc(cn->my_cref, to);
			CARD_ADDER_BASE*abd = cn->troot;
			if (abd)
				reloc(abd, to);


		}
#else
		for (int i = 0;i < n->cards.size();i++) {
			CARD_NODE*cn = n->cards[i];
			ca.reloc(cn->my_cref, to);
		}


#endif

	}

#endif
template<class B, class MaxSAT>
static uint64_t readClause(B& in, MaxSAT* S, vec<Lit>& lits) {
	int     parsed_lit, var;
	uint64_t weight = 1;
	lits.clear();
	if (S->getProblemType() == MaxSAT::_WEIGHTED_)
		weight = parseUint64(in);

	S->setCurrentWeight(weight); // Updates the maximum weight of soft clauses
	S->updateSumWeights(weight); // Updates the sum of the weights of soft clauses

	for (;;) {
		parsed_lit = parseInt(in);
		if (parsed_lit == 0) break;
		var = abs(parsed_lit) - 1;
		while (var >= S->nVars()) S->newVar();
		lits.push((parsed_lit > 0) ? mkLit(var) : ~mkLit(var));
	}
	return weight;
}

template<class B>
static void skipWhitespaceTAK(B& in) {
	while ((*in >= 9 && *in <= 13) || *in == 32)
		++in;
}

template<class B>
static void skipLineTAK(B& in) {
	for (;;) {
		if (*in == EOF || *in == '\0') return;
		if (*in == '\n') { ++in; return; }
		++in;
	}
}
template<class B>
static int parseIntTAK(B& in) {
	int     val = 0;
	bool    neg = false;
	skipWhitespace(in);
	if (*in == '-') neg = true, ++in;
	else if (*in == '+') ++in;
	if (*in < '0' || *in > '9') printf("c PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
	while (*in >= '0' && *in <= '9')
		val = val * 10 + (*in - '0'),
		++in;
	return neg ? -val : val;
}

template<class B>
static uint64_t parseUint64(B& in) {
	uint64_t     val = 0;
	bool    neg = false;
	skipWhitespace(in);
	if (*in == '-') neg = true, ++in;
	else if (*in == '+') ++in;
	if (*in < '0' || *in > '9') printf("c PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
	while (*in >= '0' && *in <= '9')
		val = val * 10 + (*in - '0'),
		++in;
	return neg ? -val : val;
}
template<class B, class MaxSAT>
static void parse_DIMACS_main(B& in, MaxSAT* S) {
	vec<Lit> lits;
	uint64_t hardWeight = UINT64_MAX;// INT32_MAX;
	for (;;) {
		skipWhitespace(in);
		if (*in == EOF) break;
		else if (*in == 'p') {
			if (eagerMatch(in, "p cnf")) {
				parseIntTAK(in); // Variables
				parseIntTAK(in); // Clauses
			}
			else if (eagerMatch(in, "wcnf")) {
				S->setProblemType(MaxSAT::_WEIGHTED_);
				parseIntTAK(in); // Variables
				parseIntTAK(in); // Clauses
				if (*in != '\r' && *in != '\n') {
					hardWeight = parseUint64(in);
					S->setHardWeight(hardWeight);
				}
			}
			else
				printf("c PARSE ERROR! Unexpected char: %c\n", *in), printf("c UNKNOWN\n"), exit(0);
		}
		else if (*in == 'c' || *in == 'p')
			skipLineTAK(in);
		else {
			uint64_t weight = readClause(in, S, lits);
			if (weight != hardWeight || S->getProblemType() == MaxSAT::_UNWEIGHTED_)
				S->addSoftClause(weight, lits);
			else S->addHardClause(lits);
		}
	}
}
class StreamBufferTAK {
	const int buffer_size = 10000;
	FILE*        in;
	unsigned char buf[10000];
	int           pos;
	int           size;

	void assureLookahead() {
		if (pos >= size) {
			pos = 0;
			size = fread(buf, 1, sizeof(buf), in);
		}
	}

public:
	explicit StreamBufferTAK(FILE* i) : in(i), pos(0), size(0) { assureLookahead(); }

	int  operator *  () const { return (pos >= size) ? EOF : buf[pos]; }
	void operator ++ () { pos++; assureLookahead(); }
	int  position() const { return pos; }
};
// Inserts problem into solver.
//
template<class MaxSAT>
static void parse_DIMACS(FILE *  input_stream, MaxSAT* S) {
	StreamBufferTAK in(input_stream);//TAK
	parse_DIMACS_main(in, S);
}



// Adds a new soft clause to the hard clause database with predefined relaxation
// variables.
void MaxSAT::addSoftClause(uint64_t weight, vec<Lit> &lits, vec<Lit> &vars)
{
	softClauses.push();
	Lit assump = lit_Undef;

	new (&softClauses[softClauses.size() - 1]) Soft(lits, weight, assump, vars);
	nbSoft++;
}
// Prints the best satisfying model. Assumes that 'model' is not empty.
void MaxSAT::printModel()
{
	if (!solver) return;
		
	solver->printModel();
	//assert(nbInitialVariables==solver->Model.size());
#ifdef WRITE_FILE
	if (!solver->Model.size()) return;
	uint64_t t=computeCostModel(solver->Model);
	if (t !=best_UB){
		printf("c ub error! %d %d",t,best_UB);

		fprintf(test_f,"!!!!!!!!!!!!!!!!!!! UB ERROR!!!!! %d %d\n",t,best_UB);

	}
#endif
	//assert(t==best_UB);

/*	if (best_UB < 0) return;
	if (model_saving) {
		print_model = true;
		return;
	}
	assert(model.size() != 0);
#ifdef NO_MODEL_OUTPUT
	return;
#endif
	printf("v ");
	for (int i = 0; i < model.size(); i++)
	{
		if (model[i] == l_True)
			printf("%d ", i + 1);
		else
			printf("%d ", -(i + 1));
	}
	printf("\n");

*/
}
// Returns true if there is a subset of set[] with sum equal to given sum
// Prints the corresponding answer.
void MaxSAT::printAnswer(int type)
{

	//if (verbosity > 0) printStats();

	if (type == _UNKNOWN_ && model.size() > 0) type = _SATISFIABLE_;

	switch (type)
	{
	case _SATISFIABLE_:
		printf("s SATISFIABLE\n");
		printModel();
		break;
	case _OPTIMUM_:
		printf("s OPTIMUM FOUND\n");
		printModel();
		break;
	case _UNSATISFIABLE_:
		printf("s UNSATISFIABLE\n");
		break;
	case _UNKNOWN_:
		printf("s UNKNOWN\n");
		break;
	default:
		printf("c Error: Invalid answer type.\n");
	}
}
/*
void MaxSAT::saveModel(vec<lbool> &currentModel)
{
	set_model_saving();
	assert(nbInitialVariables != 0);
	assert(currentModel.size() != 0);

	model.clear();
	// Only store the value of the variables that belong to the
	// original MaxSAT formula.
	for (int i = 0; i < nbInitialVariables; i++)
		model.push(currentModel[i]);
		
	reset_model_saving();
	if (print_model){
		printModel();
		//write_file();
		print_model=false;	
	}		
		
}*/

TNode* MaxSAT::genCardinals(vec<Lit> & from_to, vec<Lit> & linkingVar, unsigned  UB,bool send_later)
{



	int inputSize = from_to.size();
	if (!inputSize) return 0;

	linkingVar.clear();

	vec<Lit> linkingAlpha;
	vec<Lit> linkingBeta;


	TNode*left = 0;
	TNode*right = 0;

	if (inputSize > 2) {
		int middle = inputSize / 2;
		vec <Lit> from, to;
		for (int i = 0;i<middle;i++) {
			from.push(from_to[i]);
		}
		for (int i = middle;i< inputSize;i++) {
			to.push(from_to[i]);
		}


		left = genCardinals(from, linkingAlpha, UB,send_later);
		right = genCardinals(to, linkingBeta, UB,send_later);
	}
	else if (inputSize == 2) {
		vec <Lit> from, to;
		from.push(from_to[0]);
		to.push(from_to[1]);


		left = genCardinals(from, linkingAlpha, UB,send_later);
		right = genCardinals(to, linkingBeta, UB,send_later);
	}
	TNode*node = 0;
	if (inputSize == 1) {
		linkingVar.push(from_to[0]);
		node = new TNode(left, right, linkingVar, from_to, UB);
	}
	else { // inputSize >= 2
		node = genPT_layer(left, right, from_to, linkingVar, UB,send_later);
	}
	
	return node;
}
TNode*MaxSAT::gen_arranged_copy(TNode*left,unsigned UB)
{

	vec<Lit> linkingVar;
	
	int inputSize = left->inputs.size();

	for (int i = 0; i < inputSize && i <= UB; i++) {
		Lit L = new_literal();
		newSATVariable(solver);
#ifdef SIMP_SOLVER
		Var v = var(L);
		solver->setFrozen(v, true);
#else
	if (use_simp){
				Var v = var(L);
				dynamic_cast<SimpSolver*>(solver)->setFrozen(v, true);	
			}		
		
#endif
		Lit A = left->linkingVar[i];
		{
			vec<Lit> lits;
			lits.push(L);
			lits.push(~A);
			tnode_clauses.push(lits);
			addClause(lits);
		}
		{
			vec<Lit> lits;
			lits.push(~L);
			lits.push( A);
			tnode_clauses.push(lits);
			addClause(lits);
		}

		linkingVar.push(L);
	}
	TNode*node = new TNode(left, 0, linkingVar, left->inputs, UB);
	return node;
}
TNode* MaxSAT::genPT_layer(TNode*left, TNode*right, vec<Lit>& fromto, vec<Lit>& linkingVar, unsigned UB,bool send_later)
{
	int inputSize = fromto.size();
	vec<Lit>& linkingAlpha = left->linkingVar;
	vec<Lit>& linkingBeta = right->linkingVar;

	TNode*node = new TNode(left, right, linkingVar, fromto, UB);
	for (int i = 0; i < inputSize && i <= UB; i++) {
		if (i>node->imax) node->imax = i;
		Lit L = new_literal();
		if (!send_later) newSATVariable(solver);
#ifdef SIMP_SOLVER
		Var v = var(L);
		solver->setFrozen(v, true);
#else
	if (use_simp){
				Var v = var(L);
				dynamic_cast<SimpSolver*>(solver)->setFrozen(v, true);	
			}		

#endif
		

		linkingVar.push(L);
	}


	for (int sigma = 0; sigma <= inputSize && sigma <= UB + 1; sigma++) {
		for (int alpha = 0; alpha <= linkingAlpha.size() && alpha <= UB + 1; alpha++) {
			for (int beta = 0;beta <= linkingBeta.size() && beta <= UB + 1;beta++) {


				if ((alpha + beta) != sigma) continue;
				assert(alpha + beta == sigma);
				int a = alpha - 1;
				int b = beta - 1;
				int s = sigma - 1;
				vec<Lit> lits;

				if (sigma != 0) {
					if (alpha != 0)	lits.push(~linkingAlpha[a]);
					if (beta != 0)   lits.push(~linkingBeta[b]);
					lits.push(linkingVar[s]);
					tnode_clauses.push(lits);
					if (send_later);
					else addClause(lits);
				}
				if (sigma != inputSize && sigma != UB + 1) {
					lits.clear();
					if (alpha != linkingAlpha.size()) lits.push(linkingAlpha[a + 1]);
					if (beta != linkingBeta.size()) lits.push(linkingBeta[b + 1]);
					lits.push(~linkingVar[s + 1]);
					tnode_clauses.push(lits);
					if (send_later);
					else addClause(lits);
				}



			}
		}
	}
	linkingVar.copyTo(node->linkingVar);
	return node;

}





uint64_t MaxSAT::weight_search_bmo() {

	map<uint64_t, vec<Lit> > weight_map;
	map<Lit, unsigned> lit_idx_map;
	int longest = 0;
	vector<bool > actives;
	for (int i = 0;i < nSoft();i++) {
		unsigned w = softClauses[i].weight;
		actives.push_back(false);
		map<uint64_t, vec<Lit> > ::iterator im = weight_map.find(w);
		Lit L = softClauses[i].assumptionVar;
		lit_idx_map[L] = i;
		if (im == weight_map.end()) {
			vec<Lit> dummy;
			dummy.push(L);
			weight_map[w] = dummy;

		}
		else {
			if ((*im).second.size() > longest) {
				longest = (*im).second.size();

			}
			(*im).second.push(L);
		}
	}
	bool isbmo = isBMO(false);
	map<uint64_t, vec<Lit> > ::iterator im = weight_map.end();
	im--;
	uint64_t current_weight = (*im).first;
	while (true) {
		vec<Lit> assumptions;

		for (int i = 0;i < nSoft();i++) {
			Lit L = softClauses[i].assumptionVar;

			if (softClauses[i].weight >= current_weight && !actives[i]) {

				assumptions.push(~L);
			}
		}
		lbool res = searchSATSolver(solver, assumptions);
		if (res == l_False) {
			for (int i = 0;i < solver->conflict.size();i++) {
				Lit L = solver->conflict[i];
				map<Lit, unsigned>::iterator ix = lit_idx_map.find(L);
				if (ix == lit_idx_map.end()) assert(0);
				else {
					unsigned idx = (*ix).second;
					uint64_t weight = softClauses[idx].weight;
					if (isbmo) {
						if (weight == current_weight) actives[idx] = true;
					}
					else {
						if (weight >= current_weight) actives[idx] = true;

					}
				}
			}
		}
		else {
			uint64_t UB = computeCostModel(solver->model, true);
			if (UB < best_UB) {
				upperbound = UB;
				best_UB = upperbound;
				solver->saveModel();
				printf("o %" PRIu64 "\n", upperbound);
				//
				//model = solver->model;
			}
			if (im == weight_map.begin()) break;
			im--;
			current_weight = (*im).first;

		}
	}
	return best_UB;
}
uint64_t MaxSAT::weight_search(uint64_t best_UB1)
{
	map<uint64_t, vec<Lit> > weight_map;

	int longest = 0;
	for (int i = 0;i < nSoft();i++) {
		uint64_t w = softClauses[i].weight;
		map<uint64_t, vec<Lit> > ::iterator im = weight_map.find(w);
		Lit L = softClauses[i].assumptionVar;
		if (im == weight_map.end()) {
			vec<Lit> dummy;
			dummy.push(L);
			weight_map[w] = dummy;
		}
		else {
			if ((*im).second.size() > longest) {
				longest = (*im).second.size();

			}
			(*im).second.push(L);
		}
	}
	printf("c weight_map.size=%zd\n", weight_map.size());
	map<uint64_t, vec<Lit> > ::iterator im = weight_map.end();
	im--;
	uint64_t highest_weight = (*im).first;


	int counter = 0;
	set<int> skip_weight;
	while (true) {
		vec<Lit> assumptions;

		for (int i = 0;i < nSoft();i++) {
			Lit L = softClauses[i].assumptionVar;

			if (softClauses[i].weight >= highest_weight) {
				set<int>::iterator ix = skip_weight.find(softClauses[i].weight);
				if (ix == skip_weight.end()) {
					assumptions.push(~L);
				}
			}
		}
		lbool res = searchSATSolver(solver, assumptions);
		if (res == l_False) {
#ifdef USE_SKIP_WEIGHT		
			skip_weight.insert(highest_weight);
			if (im == weight_map.begin()) break;
			im--;
			highest_weight = (*im).first;
#else			
			break;
#endif			

		}
		else {
			counter++;
			uint64_t UB = computeCostModel(solver->model, true);
			if (UB < best_UB) {
				printf("c ws=%zd\n", UB);
				best_UB = UB;
				upperbound = UB;
				solver->saveModel();
				printf("o %" PRIu64 "\n", upperbound);
				//model = solver->model;
			}
			if (im == weight_map.begin()) break;
			im--;
			highest_weight = (*im).first;

		}
	}
	return best_UB;
}






CARD_ADDER_BASE* MaxSAT::genCardAdder(vec<Lit> & from_to, vec<Lit> &linkingVar, unsigned UB, bool send)
{
	int inputSize = from_to.size();
	linkingVar.clear();

	vec<Lit> linkingAlpha;
	vec<Lit> linkingBeta;


	CARD_ADDER_BASE*left = 0;
	CARD_ADDER_BASE*right = 0;

	if (inputSize >= CARD_ADDER_BASE::LEAVES_MAX * 2) {

		int part_size = inputSize / CARD_ADDER_BASE::LEAVES_MAX;
		int lit_idx = 0;

		vector<CARD_ADDER_BASE*> inputs;
		for (int i = 0;i < CARD_ADDER_BASE::LEAVES_MAX;i++) {

			if (i == CARD_ADDER_BASE::LEAVES_MAX - 1) {
				part_size = inputSize - part_size* (CARD_ADDER_BASE::LEAVES_MAX - 1);
			}
			vec<Lit> lit_inputs, outputs;
			for (int j = 0;j < part_size;j++) {
				lit_inputs.push(from_to[lit_idx++]);
			}
			inputs.push_back(genCardAdder(lit_inputs, outputs, UB, send));



		}

		/*
		int middle = inputSize / 2;
		vec <Lit> from, to;
		for (int i = 0;i<middle;i++) {
		from.push(from_to[i]);
		}
		for (int i = middle;i< inputSize;i++) {
		to.push(from_to[i]);
		}


		left = genCardAdder(from, linkingAlpha, UB);
		right = genCardAdder(to, linkingBeta, UB);
		*/
		for (int i = 0; i < inputSize && i <= UB; i++) {

			Lit L = new_literal();
			if (send) newSATVariable(solver);
			Var v = var(L);


			linkingVar.push(L);
		}
		/*
		inputs.push_back(left);
		inputs.push_back(right);
		*/

		CARD_ADDER*ca = new CARD_ADDER(inputs, linkingVar);
		ca->set_card_id(card_id++);
		for (int i = 0;i < inputs.size();i++) {
			inputs[i]->set_parent(ca);
		}
		/*	left->set_parent(ca);
		right->set_parent(ca);*/
		return ca;


	}
	else {
		assert(inputSize <= CARD_ADDER_BASE::LEAVES_MAX * 2);
		assert(inputSize >= 1);//2);
		for (int i = 0; i < inputSize && i <= UB; i++) {

			Lit L = new_literal();
			if (send) newSATVariable(solver);
			//newSATVariable(solver);

			Var v = var(L);


			linkingVar.push(L);
		}
		CARD_ADDER_BOTTOM*cab = new CARD_ADDER_BOTTOM(from_to, linkingVar);
		if (card_id == 61) {
			int m = 0;
		}
		cab->set_card_id(card_id++);
		return cab;

	}


}


CARD_ADDER_BOTTOM*MaxSAT::genCardBottom(vec<Lit>&core, uint64_t UB) {

	CARD_ADDER_BOTTOM*cab = 0;

	vec<Lit>linkingVar;
	for (int i = 0; i < core.size() && i <= UB; i++) {
		Lit L = new_literal();
		newSATVariable(solver);
		Var v = var(L);
		linkingVar.push(L);
	}
	cab = new CARD_ADDER_BOTTOM(core, linkingVar);
	cab->set_card_id(card_id++);
	return cab;
}
CARD_ADDER_BASE*MaxSAT::genCardAdder(int depth, vec<Lit>&core, uint64_t UB, CARD_ADDER*old_root) {

	CARD_ADDER_BASE*cab = genCardBottom(core, UB);
	depth--;

	while (depth >= 1) {
		vector<CARD_ADDER_BASE*> inputs;
		if (depth == 1 && old_root) {
			inputs.push_back(old_root);
		}
		inputs.push_back(cab);
		vec<Lit>linkingVar;
		int input_size = 0;
		for (int i = 0;i < inputs.size();i++) {
			input_size += inputs[i]->linkingVar.size();
		}

		for (int i = 0; i < input_size && i <= UB; i++) {
			Lit L = new_literal();
			newSATVariable(solver);
			Var v = var(L);
			linkingVar.push(L);
		}
		CARD_ADDER*ca = new CARD_ADDER(inputs, linkingVar);
		ca->set_card_id(card_id++);
		cab->set_parent(ca);
		cab = ca;
		depth--;
	}
	return cab;
}
void MaxSAT::create_unweight_instances(unsigned UB, bool create_card_adder,bool send)
{
#define DIV1
#ifdef DIV1
	int div = 1;
#else
	int div = 32;
#endif
	weight_root = new WEIGHT_AGGREGATE();
	if (nSoft() < div * 4) {
		div = 1;
	}
	int N = nSoft();
	int c = nSoft() / div+1;//cより1個多くする。最後のDivは、cより小さくなる
	
	vector<CARD_NODE*> cards;

	for (int id = 0;id < div;id++) {
			vec<Lit> inputs;
			for (int i = 0;i <c;i++) {
				int I = id*c + i;
				if (I == nSoft()) {
					break;
				}
				Lit L = softClauses[I].assumptionVar;
				inputs.push(L);
			}
			assert(inputs.size());
			vec<Lit>outputs;
#ifdef USE_CARD_ADDER
			CARD_ADDER_BASE*troot = 0;
			if (create_card_adder) troot=genCardAdder(inputs, outputs, UB,send);
#else
			TNode*troot = 0;
			if(create_card_adder) troot=genCardinals(inputs, outputs, UB,false);
#endif
			CARD_NODE*cn = new CARD_NODE(id, 1, inputs, weight_root,troot);
			cards.push_back(cn);

	}
	weight_root->cards = cards;
	int n = 0;
	for (int i = 0;i < cards.size();i++) {
		n += cards[i]->inputs.size();
	}
	assert(n == N);



}
void MaxSAT::create_weight_instance(uint64_t UB, bool create_card_adder,bool send)
{
	

	weight_root = new WEIGHT_AGGREGATE();
	weight_root->UB = UB;
	//weightを分類
	map<uint64_t, vec<Lit> > weight_map;
	for (int i = 0;i < nSoft();i++) {
		uint64_t w  = softClauses[i].weight;
		map<uint64_t, vec<Lit> > ::iterator im = weight_map.find(w);
		Lit L = softClauses[i].assumptionVar;
		if (im == weight_map.end()) {
			vec<Lit> dummy;
			dummy.push(L);
			dummy.copyTo(weight_map[w]);// = dummy;
		}
		else {
			(*im).second.push(L);
		}
	}
	if (weight_map.size() == 1) {

		create_unweight_instances(UB,create_card_adder,send);
		return;
	}
	//convert_weight_map(weight_map);


//	weight_root = new WEIGHT_AGGREGATE();
	
//	weight_root->UB = UB;
	//下層LayerをDraw
	map<uint64_t, vec<Lit> > ::reverse_iterator im;
	vector<CARD_NODE*> cards;
	int id = 0;
	int inputs_size = 0;
	int outputs_size = 0;

	for (im = weight_map.rbegin();im != weight_map.rend();im++) {
		uint64_t weight = (*im).first;
		vec<Lit> & inputs = (*im).second;
		inputs_size += inputs.size();
		vec<Lit>outputs;
#ifdef USE_CARD_ADDER
		CARD_ADDER_BASE*troot = 0;
		if(create_card_adder)troot=genCardAdder(inputs, outputs, UB/weight,send);

#else
		TNode*troot = 0;
		if (create_card_adder) troot = genCardinals(inputs, outputs, UB/weight,false);
#endif
		CARD_NODE*cn = new CARD_NODE(id, weight, inputs, weight_root,troot);
		outputs_size += outputs.size();
		cards.push_back(cn);
		id++;
	}
	assert(nSoft() == inputs_size);
//	assert(nSoft() == outputs_size);
	weight_root->cards = cards;

}
uint64_t CARD_NODE::model_check(vec<lbool>& model, bool input_check) {
	uint64_t sum = 0;
	if (input_check) {
		for (int i = 0;i < inputs.size();i++) {
			Var v =var(inputs[i]);
			if (model[v] == l_True) sum++;

		}
		return sum*weight;
	}else {
		uint64_t sum = 0;
		for (int i = 0;i < troot->linkingVar.size();i++) {
			Var v = var(troot->linkingVar[i]);
			if (model[v] == l_True) {
				sum = (i + 1)*weight;
			}
		}
		return sum;
	}

}
uint64_t WEIGHT_AGGREGATE::model_check(vec<lbool>& model, bool input_check) {
	uint64_t sum = 0;
	for (int i = 0;i < cards.size();i++) {
		sum +=cards[i]->model_check(model, input_check);
	}
	return sum;

}





Lit MaxSAT::newLiteral(bool sign) {
	Lit p = mkLit(nVars(), sign);
	if (p.x == 0x1c4 || p.x==0x1bc || p.x==0x20a || p.x==0x1d8) {
		int m = 0;
	}
	newVar();
	return p;
}
Lit MaxSAT::newLiteral_not_decided(bool sign) {
	Lit p = mkLit(nVars(), sign);

	not_decided_variables.push(nVars());
	newVar();
	return p;
}

void MaxSAT::setProblemType(TYPE type) { problemType = type; }			// Sets the problem type.
MaxSAT::TYPE MaxSAT::getProblemType() { return problemType; }	         		// Return the problem type.

																				// 'ubCost' is initialized to the sum of weights of the soft clauses.
void MaxSAT::updateSumWeights(uint64_t weight) {
	if (weight != hardWeight)
		ubCost += weight;
}

// The initial 'currentWeight' corresponds to the maximum weight of the soft clauses.
void MaxSAT::setCurrentWeight(uint64_t weight) {
	if (weight > currentWeight && weight != hardWeight)
		currentWeight = weight;
}

void MaxSAT::setHardWeight(uint64_t weight) { hardWeight = weight; }			// Sets the weight of hard clauses.
void MaxSAT::setInitialTime(double initial) { initialTime = initial; }		// Sets the initial time.


																			/************************************************************************************************
																			//
																			// SAT solver interface -- simplifying the 'simp' or 'core' use of the SAT solver
																			//
																			************************************************************************************************/

																			// Creates an empty SAT Solver.
Solver * MaxSAT::newSATSolver() {

	if (solver)delete solver;
	solver = 0;
#ifdef SIMP_SOLVER
	Solver *S = new SimpSolver();
#else
	if (use_simp) return new SimpSolver();
	Solver *S = new Solver();
#endif
//	

	return (Solver *)S;
}

// Creates a new variable in the SAT solver.
void MaxSAT::newSATVariable(Solver *S) {
#ifdef SIMP_SOLVER
	Var v = dynamic_cast<SimpSolver*>(S)->newVar();

	if (v >=nbInitialVariables) {
		dynamic_cast<SimpSolver*>(S)->setFrozen(v, true);
	}
#else
	Var v;
	if (use_simp){
		SimpSolver*SS=dynamic_cast<SimpSolver*>(S);
		v=SS->newVar();
		if (v >= nbInitialVariables) {
			SS->setFrozen(v, true);
		}
	}else {	
		v=S->newVar();
	}
#endif
	if (solver) {
		int n = nVars();
		assert(n == v + 1);

	}
}
void MaxSAT::newSATVariable_not_decided(Solver*S)
{
	if (use_simp){
		SimpSolver*SS=dynamic_cast<SimpSolver*>(S);
		SS->newVar(true,false);
		
	}else {	
		S->newVar(true, false);
	}
}

Lit MaxSAT::new_literal()
{

	return newLiteral();


}

int MaxSAT::nVars() { return nbVars; } 		// Returns the number of variables in the working MaxSAT formula.
int MaxSAT::nSoft() { return nbSoft; }		// Returns the number of soft clauses in the working MaxSAT formula.
int MaxSAT::nHard() { return nbHard; } 		// Returns the number of hard clauses in the working MaxSAT formula.
void MaxSAT::newVar() { nbVars++; }			// Increases the number of variables in the working MaxSAT formula.

											// Adds a new hard clause to the hard clause database.
void MaxSAT::addHardClause(vec<Lit>& lits) {
	hardClauses.push();
	new (&hardClauses[hardClauses.size() - 1]) Hard(lits);
	nbHard++;
}

// Adds a new soft clause to the hard clause database.
void MaxSAT::addSoftClause(uint64_t weight, vec<Lit>& lits) {
	softClauses.push();
	vec<Lit> rVars;
	Lit assump = lit_Undef;

	new (&softClauses[softClauses.size() - 1]) Soft(lits, weight);
	nbSoft++;
}


bool MaxSAT::isBMO(bool cache)
{
	std::vector<uint64_t> orderWeights;
	orderWeights_size = 0;
	assert(orderWeights.size() == 0);
	bool bmo = true;
	std::set<int> partitionWeights;
	std::map<int, int> nbPartitionWeights;

	for (int i = 0; i < nSoft(); i++)
	{
		partitionWeights.insert(softClauses[i].weight);
		nbPartitionWeights[softClauses[i].weight]++;
	}

	for (std::set<int>::iterator iter = partitionWeights.begin();
		iter != partitionWeights.end(); ++iter)
	{
		orderWeights.push_back(*iter);
	}

	std::sort(orderWeights.begin(), orderWeights.end(), greaterThan);

	uint64_t totalWeights = 0;
	for (int i = 0; i < (int)orderWeights.size(); i++)
		totalWeights += orderWeights[i] * nbPartitionWeights[orderWeights[i]];

	for (int i = 0; i < (int)orderWeights.size(); i++)
	{
		totalWeights -= orderWeights[i] * nbPartitionWeights[orderWeights[i]];
		if (orderWeights[i] < totalWeights)
		{
			bmo = false;
			break;
		}
	}
	orderWeights_size = orderWeights.size();
	if (!cache) orderWeights.clear();

	return bmo;
}
uint64_t MaxSAT::non_repeat_search(std::set<Lit> & conflict_set)
{
	uint64_t best_LB = -1;


	vec<Lit> assumptions;
	for (int i = 0;i < nSoft();i++) {
		Lit L = softClauses[i].assumptionVar;
		set<Lit> ::iterator im = conflict_set.find(L);
		if (im == conflict_set.end()) {
			assumptions.push(~L);

		}
	}
	map<uint64_t, vec<Lit> > weight_map;
	
	int longest = 0;
	for (int i = 0;i < nSoft();i++) {
		uint64_t w = softClauses[i].weight;
		map<uint64_t, vec<Lit> > ::iterator im = weight_map.find(w);
		Lit L = softClauses[i].assumptionVar;
		if (im == weight_map.end()) {
			vec<Lit> dummy;
			dummy.push(L);
			dummy.copyTo(weight_map[w]);// = dummy;
		}
		else {
			if ((*im).second.size() > longest) {
				longest = (*im).second.size();

			}
			(*im).second.push(L);
		}
	}
	map<uint64_t, unsigned> power_map;

	
	map<uint64_t, vec<Lit> > ::iterator im;
	for (im = weight_map.begin();im != weight_map.end();im++) {
		uint64_t weight = (*im).first;
		uint64_t u = (*im).first;
		u *= (*im).second.size();
		power_map[u] = weight;
	}
	map<uint64_t, unsigned>::reverse_iterator rv = power_map.rbegin();
	


	uint64_t highet_weight = (*rv).second;
	for (int i = 0;i < 100;i++) {
		rv++;
		if (rv == power_map.rend()) {
			rv--;
			break;
		}
	}

	printf("c weights=%zd longest=%zd new weight=%zd \n", weight_map.size(), longest, highet_weight);
	highet_weight = (*rv).second;

	int counter = 0;
	while (counter++<100000) {
		



		lbool res = searchSATSolver(solver, assumptions);
		if (res == l_False) {
			rv++;
			
			if (rv == power_map.rend()) break;
			highet_weight = (*rv).second;
			printf("c new weight=%d\n", highet_weight);

		}else {
			uint64_t LB = computeCostModel(solver->model);
			if (LB < best_LB) {
				printf("c nro=%zd\n", LB);
				best_LB = LB;
			}
			int cost = 0;
			vec<Lit> lits;
			for (int i = 0;i < nSoft();i++) {
				Lit L = softClauses[i].assumptionVar;
				unsigned weight = softClauses[i].weight;
				Var v = var(L);
				if (solver->model[v] == l_True && weight>=highet_weight ) {
					lits.push(~L);
				}
			}
			addClause(lits);
		}
	}
	return best_LB;
}
lbool MaxSAT::model_practice(bool use_assumption)
{
	vec<Lit> assumptions;
	if (model.size() == 0) solver->model.copyTo(model);
	//	assert(nVars() == model.size());
	//	assert(model.size() >= nbInitialVariablesB);
	for (int i = 0;i < model.size();i++)//nbInitialVariablesB;i++)
	{
#ifdef SIMP_SOLVER
		Lit L = mkLit(i, false);
		if (solver->isEliminated(var(L))) {
			continue;
		}
#else
		if (use_simp){
			Lit L = mkLit(i, false);

			if (dynamic_cast<SimpSolver*>(solver)->isEliminated(var(L))) {
				continue;
			}
				
		}		
		
#endif
		if (model[i] == l_True) {
			Lit L = mkLit(i, false);
			
			solver->revar(L);

			if (use_assumption) {
				assumptions.push(L);
			}
		}
		else if (model[i] == l_False) {
			Lit L = mkLit(i, true);
			solver->setPolarity(var(L), true);
			//	assumptions.push(L);
			solver->revar(L);
			if (use_assumption) assumptions.push(L);
		}
		else assert(0);

	}
	if (use_assumption) {
		lbool success=solveLimited(assumptions);
		uint64_t costUB = computeCostModel(solver->model);
		return success;
		assert(success==l_True);
	}
	
	lbool success = l_True;//  searchSATSolver(solver, assumptions);
	
	return success;
	if (success == l_True) {
		uint64_t costUB = computeCostModel(solver->model);
		int m = 0;
	}
	return success;




}


uint64_t MaxSAT::disjoint_search() {
	best_UB = LLONG_MAX;
	
	uint64_t rampUB = ramp_seach(6);
	solver = rebuildSolver();
	if (rampUB == LLONG_MIN);
	else if (rampUB !=LLONG_MAX) {
		ramp->save_model(*this);
		best_UB = rampUB;
		ramp->free_memory();
		model_practice();
		bool ret = solve();
		uint64_t LB = computeCostModel(solver->model);
		assert(LB == best_UB);
		sofar_best_strategy = RAMP;
	}else ramp->free_memory();
	solver = rebuildSolver();

	uint64_t UB = 0;
	
	
	bool ret = solve();
	if (ret) {
		UB = computeCostModel(solver->model);
		free_search_success = true;
		if (UB < best_UB) {
			best_UB = UB;
			upperbound = UB;
			solver->saveModel();
			printf("o %" PRIu64 "\n", upperbound);
			//solver->model.copyTo(model);
			sofar_best_strategy = FREE_SAT;
		}
		printf("c ofl=%zd\n", UB);
#ifdef USE_SAT_TOTAL
		return UB;
#endif
	}
	uint64_t NLB=weight_search(UB);
	return weight_search_bmo();

	if (NLB<UB ) return NLB;
	printf("c disjoint phase\n");


	set<Lit> relaxed_vars_set;
	for (int i = 0;i< nSoft();i++) {
		Lit L = softClauses[i].assumptionVar;
		relaxed_vars_set.insert(L);
	}
	set<Lit> conflict_set;

	

	while (true) {
		vec<Lit> assumptions;



		for (int i = 0;i < nSoft();i++) {
			Lit L = softClauses[i].assumptionVar;
			set<Lit> ::iterator im = conflict_set.find(L);
			if (im == conflict_set.end()) {
				assumptions.push(~L);

			}
		}
		lbool res = searchSATSolver(solver, assumptions);
		if (res == l_False) {
			bool updated = false;
			vec<Lit> core;
			for (int i = 0; i < solver->conflict.size(); i++) {
				Lit L = solver->conflict[i];
				set<Lit> ::iterator im = relaxed_vars_set.find(L);
				if (im != relaxed_vars_set.end()) {
					set<Lit> ::iterator ix = conflict_set.find(L);
					if (ix == conflict_set.end()) {
						updated = true;
						conflict_set.insert(L);
						core.push(L);
					}
				}
			}
			cores.push_back(core);
		}else {
			UB = computeCostModel(solver->model,  true);
//#define NON_REPEAT_SEARCH
#ifdef NON_REPEAT_SEARCH
			if (true){//conflict_set.size() > 1000) {
				non_repeat_search(conflict_set);
			}
#endif
			for (int i = 0;i < cores.size();i++) {
		//		addHardClause(cores[i]);
			}
		//	non_repeat_search(conflict_set);
			return UB;

		}



	}


	

}


uint64_t MaxSAT::free_search() {
	nbInitialVariables = nVars();
	initAssumptions();
	uint64_t UB;



	solver = rebuildSolver();

	bool ret = solve();
	if (ret) {
		UB = computeCostModel(solver->model);
		return UB;
	}
	return -1;
}
void MaxSAT::send_clauses(Solver*S_,bool send_soft ){

#ifdef SIMP_SOLVER
	SimpSolver*S = dynamic_cast<SimpSolver*>(S_);
#else
	Solver*S = S_;
#endif

	for (int i = 0; i < nHard(); i++) {

		bool success = addClause(hardClauses[i].clause);
		assert(success);
	}
	if (send_soft) {
		vec<Lit> clause;
		for (int i = 0; i < nSoft(); i++) {
			clause.clear();
			softClauses[i].clause.copyTo(clause);

			clause.push(softClauses[i].assumptionVar);
		
			addClause(clause);
				
		}
	}
	int h = nHard();
	int s = nSoft();
	//int c=S->get_clause_size();

	for (int i = 0;i < tnode_clauses.size();i++) {
	
		addClause(tnode_clauses[i]);
			
	}

}
#ifdef SIMP_SOLVER
SimpSolver * MaxSAT::rebuildSolver(bool send_soft) {
#else
Solver * MaxSAT::rebuildSolver(bool send_soft) {
#endif
	if (solver&& solver->Model.size()) {
		solver->Model.copyTo(model);
	}
	
	Solver * S = newSATSolver();
	S->set_maxsat(this);
	S->print_model=print_model;
	
	if (nbInitialVariables){
		S->set_nbInitialVariables(nbInitialVariables);
		if (model.size()) {
			model.copyTo(S->Model);
		}
	}
	int n = nVars();
	for (int i = 0; i < nVars(); i++) {

		bool decision_var = true;
		for (int j = 0;j < not_decided_variables.size();j++) {
			if (i == not_decided_variables[j]) {
				decision_var = false;
			}
		}
		if (decision_var)		newSATVariable(S);
		else newSATVariable_not_decided(S);
	}
	solver=S;
	send_clauses(S,send_soft);
#ifdef SIMP_SOLVER
	return dynamic_cast<SimpSolver*>(S);
#else
	return S;
#endif
}

// Solve the formula that is currently loaded in the SAT solver with a set of assumptions and with the option to use preprocessing for 'simp'.
lbool MaxSAT::searchSATSolver(Solver *S, vec<Lit>& assumptions,double timeout) {

	S->setStopTime(timeout);
#ifdef SIMP_SOLVER
	lbool res = dynamic_cast<SimpSolver*>(S)->solveLimited(assumptions);
#else
	if (use_simp){
		return dynamic_cast<SimpSolver*>(S)->solveLimited(assumptions);	
	}
	lbool res = S->solveLimited(assumptions);
#endif
	return res;
}

void MaxSAT::initRelaxation() {
	for (int i = 0; i < nbSoft; i++) {
		Lit l = softClauses[i].assumptionVar;
		relax_variabls.push(l);

	}
}
void CARD_NODE::print_UB() {
	printf("c weight=%zd UB=%zd\n", weight, tcount);

}
void CARD_NODE::print_LB() {
//	printf("c weight=%zd LB=%zd \n", weight, assumption_lb);

}

void MaxSAT::updateCurrentWeight()
{

	//assert(strategy == _WEIGHT_NORMAL_ || strategy == _WEIGHT_DIVERSIFY_);
	//
	//if (strategy == _WEIGHT_NORMAL_)
		currentWeight = findNextWeight(currentWeight);
	//else if (strategy == _WEIGHT_DIVERSIFY_)
	//	currentWeight = findNextWeightDiversity(currentWeight);
}
uint64_t MaxSAT::findNextWeight(uint64_t weight)
{

	uint64_t nextWeight = 1;
	for (int i = 0; i < nSoft(); i++)
	{
		if (softClauses[i].weight > nextWeight && softClauses[i].weight < weight)
			nextWeight = softClauses[i].weight;
	}

	return nextWeight;
}
//output L1=L;
Lit MaxSAT::gen_one_output(Lit L)
{
	Var v = solver->newVar();
	Lit L1 = mkLit(v);

	{
		vec<Lit> lits;
		lits.push(L);
		lits.push(~L1);
		addClause(lits);
	}

	{
		vec<Lit> lits;
		lits.push(~L);
		lits.push(L1);
		addClause(lits);
	}
	return L1;


}
void WEIGHT_AGGREGATE::print_UB()
{
	for (int i = 0;i < cards.size();i++) {
		cards[i]->print_UB();
	}


}
void WEIGHT_AGGREGATE::print_LB()
{

	for (int i = 0;i < cards.size();i++) {
		cards[i]->print_LB();
	}
	/*
	map<uint64_t, CARD_NODE*>::iterator im;
	for (im = card_map.begin();im != card_map.end();im++) {
		(*im).second->print_LB();
	}
	*/

}
void MaxSAT::initAssumptions() {
	nbInitialVariables = nbVars;
	for (int i = 0; i < nbSoft; i++) {
		Lit l = newLiteral();
		softClauses[i].assumptionVar = l;
		coreMapping[l] = i;
		

	}
	nbInitialVariablesB = nbVars;
}
bool MaxSAT::judge_use_of_core_strat() {
	create_initial_weight_map();
	if (initial_weight_map.size() > FORCE_SAT_SOLVING_THRESHOLD) return true;
	if (isBMO(false)) {
		map<uint64_t, int>::iterator im;
		for (im = initial_weight_map.begin();im != initial_weight_map.end();im++) {
			uint64_t w = (*im).first;
			map<uint64_t, int>::iterator ix = count_map.find(w);
			if (ix == count_map.end()) {
				
		
			}else {
				double rate = (*ix).second;
				rate /= (*im).second;
				printf("c rate=%1.2f weight=%ld\n", rate, w);
				if (rate >RATIO_THRESHOLD) return false;


			}
		}
		return true;
	}else return false;


}
void MaxSAT::create_initial_weight_map() {
	
	for (int i = 0; i < nbSoft; i++) {
		uint64_t w = softClauses[i].weight;
		map<uint64_t, int>::iterator im = initial_weight_map.find(w);
		if (im == initial_weight_map.end()) {
			initial_weight_map[w] = 1;

		}else {
			(*im).second++;
		}
	}
}
void MaxSAT::count_map_initialize() {
	count_map.clear();
	if (!weight_root) return;
	for (int i = 0;i < weight_root->cards.size();i++) {
		count_map[weight_root->cards[i]->weight] = 0;
	}


}
uint64_t MaxSAT::computeCostModel(vec<lbool> &currentModel,bool model_comp) {


	failed_lits.clear();

	assert(currentModel.size() != 0);
	uint64_t currentCost = 0;
	count_map_initialize();
	
	int tsum = 0;
/*	uint64_t cost = 0;
	for (int i = 0;i < nSoft();i++) {
		Lit L = softClauses[i].assumptionVar;
		Var v = var(L);
		if (currentModel[v] == l_True) {
			cost += softClauses[i].weight;
		}
	}
	*/
	for (int i = 0; i < nHard(); i++) {
		bool unsatisfied = true;
		if (i == 643) {
			int m = 0;
		}
		for (int j = 0; j < hardClauses[i].clause.size(); j++) {

			Var v=var(hardClauses[i].clause[j]);


			assert(var(hardClauses[i].clause[j]) < currentModel.size());
			if ((sign(hardClauses[i].clause[j]) && currentModel[var(hardClauses[i].clause[j])] == l_False) ||
				(!sign(hardClauses[i].clause[j]) && currentModel[var(hardClauses[i].clause[j])] == l_True)) {
				unsatisfied = false;

				break;
			}
		}
		assert(!unsatisfied);
	}

	for (int i = 0; i < nSoft(); i++) {
		bool unsatisfied = true;


		for (int j = 0; j < softClauses[i].clause.size(); j++) {



			assert(var(softClauses[i].clause[j]) < currentModel.size());
			if ((sign(softClauses[i].clause[j]) && currentModel[var(softClauses[i].clause[j])] == l_False) ||
				(!sign(softClauses[i].clause[j]) && currentModel[var(softClauses[i].clause[j])] == l_True)) {
				unsatisfied = false;

				break;
			}
		}

		
		
		if (unsatisfied) {
			Lit L = softClauses[i].assumptionVar;
			lbool lx = solver->value(var(L));
			Var v = var(L);
			if (var(L) == 611) {
				lbool l = solver->value(var(L));
				int m = 0;
			}
		//	assert(lx == l_True);
			
			failed_lits.push(L);
			if (model_comp) {
				Var v = var(softClauses[i].assumptionVar);

				

				
				assert(currentModel[v] == l_True);
			}
			uint64_t w = softClauses[i].weight;
			if (!softClauses[i].splited) {
				uint64_t ow = softClauses[i].oweight;
				map<uint64_t, int>::iterator im = count_map.find(ow);
				if (im == count_map.end()) {
					count_map[ow] = 1;
				}
				else (*im).second++;
			}
			currentCost +=w ;
			tsum++;
			
		}
		else if (model_comp) {
			Var v = var(softClauses[i].assumptionVar);
			if (v == 9721) {
				int m = 0;
			}
			currentModel[v] = l_False;
		}
		else {

	//		Var v = var(softClauses[i].assumptionVar);
	//		assert(currentModel[v] == l_False);

		}
	}
	if(0)
	for (int i = 0;i < failed_lits.size();i++) {
		Lit L = failed_lits[i];
		printf("%d ", var(L));

	}

	if (0) {
		map<uint64_t, int>::iterator im;
		uint64_t v = 0;
		for (im = count_map.begin();im != count_map.end();im++) {
			v += (*im).first*(*im).second;
			printf("c weight=%zd %d\n", (*im).first, (*im).second);
		}
		printf("c total=%zd\n", v);
	}
	return currentCost;
}



int maxsat_main(int argc, char** argv)
{
	clock_t start, end;
	try {
		start = clock();
		// setUsageHelp("c USAGE: %s [options] <input-file>\n\n");
		if (argc == 1)
			printf("c Reading from standard input... Use '--help' for help.\n");
		FILE* in = (argc == 1) ? fopen(0, "rb") : fopen(argv[1], "rb");
		

		
		if (in == NULL)
			printf("c ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), printf("c UNKNOWN\n"), exit(0);

		
		mxsolver = new Glucose::MaxSAT();
		mxsolver->filename = argv[1];
		
		//mxsolver->timer_start();
	
	

		parse_DIMACS(in, mxsolver);
		fclose(in);//gzclose(in);
	
		if (argc>4){
			mxsolver->readfile();
			exit(0);

		}
		

		//    gzFile in = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
		if (in == NULL)
			printf("c ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), printf("c UNKNOWN\n"), exit(0);

		printf("c ========================================[ Problem Statistics ]===========================================\n");
		printf("c |                                                                                                       |\n");
		signal_setup();
		mxsolver->search();
		end = clock();
		printf("c %.2f(sec) \n",(double)(end-start)/CLOCKS_PER_SEC);

	}
	catch (OutOfMemoryException&) {
		//sleep(1);
		printf("c Error: Out of memory.\n");
		//printf("c UNKNOWN\n");
		mxsolver->printModel();
		printf("c print done\n");
#ifdef WRITE_FILE
		mxsolver->write_file();
		//printf("c write done\n");
#endif
		exit(0);
	}
	
}


void printStats1(Solver&solver)
{
//	LARGE_INTEGER freq_pc, t2;
//	QueryPerformanceCounter(&t2);

//	QueryPerformanceFrequency(&freq_pc);

//	double cpu_time = (t2.QuadPart - t1.QuadPart) / (double)freq_pc.QuadPart;

	//double mem_used = memUsedPeak();
	printf("c %dvars.\n", solver.nVars());

	printf("c restarts              : %lld\n", solver.starts);
	printf("c conflicts             : %lld  \n", solver.conflicts);
	printf("c decisions             : %lld  \n", solver.decisions);
	printf("c propagations          : %lld  \n", solver.propagations);
	printf("c conflict literals     : %lld   (%4.2f %% deleted)\n", solver.tot_literals, (solver.max_literals - solver.tot_literals) * 100 / (double)solver.max_literals);
	//if (mem_used != 0) printf("Memory used           : %.2f MB\n", mem_used);
//		printf("CPU time              : %g s\n", cpu_time);
}
void MaxSAT::open_file() {
	string result;
	
#ifdef _WIN32
	tr2::sys::path path(filename);
	result = path.parent_path().string();

	if (result.empty()) result= "weight_unsat_sat_search.txt";
	else result += "/weight_unsat_sat_search.txt";
	test_file = "./" + path.filename().string();
#else
	string::size_type index = filename.rfind("/");
	
	string path = "";

	if (index == string::npos) {
		result = "./weight_unsat_sat_search.txt";

	}
	else {

		path = filename.substr(0, index);
		result = path + "/weight_unsat_sat_search.txt";
		filename = filename.substr(index + 1);
	}
	test_file = "./" + filename;
#endif
	test_f = fopen(result.c_str(), "a");
	
	

}
void MaxSAT::write_file() {

	

	if (best_UB >= 0) {
		

		if (test_f) {
			
				   
			fprintf(test_f, "%s :%zd\n", test_file.c_str(), best_UB);// filename.c_str(), best_UB);
			fclose(test_f);
		}
	}


}
int TNode::get_unsatisfied_litrals(Solver&S) {
	int sum = 0;
	for (int i=0;i<inputs.size();i++){
		Lit L = inputs[i];
		Var v = var(L);
		if (S.model[v] == l_False) sum++;
	}
	return sum;
}
void MaxSAT::timer_start() {

#ifdef WRITE_FILE
	open_file();
#endif
#ifdef _WIN32
	//スレッドプールタイマーオブジェクトを生成
	PTP_TIMER lpTimer =
		CreateThreadpoolTimer(TimerCallback, this, NULL);


	//SetThreadpoolTimer関数の呼び出し後、3秒後にコールバック関数が呼ばれるようにする
	ULARGE_INTEGER ulRelativeStartTime;
	LONGLONG t = 1000 * 10000;
	t *= TIME_OUT_MINUTES * 60;
	ulRelativeStartTime.QuadPart = (LONGLONG)(-t);// -4 * 60 * 1000 * 10000);//-30000000);//100nano秒単位で指定する

	FILETIME ftStartTime;
	ftStartTime.dwHighDateTime = ulRelativeStartTime.HighPart;
	ftStartTime.dwLowDateTime = ulRelativeStartTime.LowPart;

	//タイマーを登録し、一定間隔でコールバック関数が呼ばれるようにする
	//2秒間隔でコールバック関数が呼ばれるように指定している。
	SetThreadpoolTimer(lpTimer,
		&ftStartTime,
		0,//signal once 60*1000*4,
		0);


#else
	struct sigaction act, oldact;    timer_t tid;
	struct itimerspec itval;
	memset(&act, 0, sizeof(struct sigaction));
	memset(&oldact, 0, sizeof(struct sigaction));
	// シグナルハンドラの登録   
	act.sa_handler = timer_handler;
	act.sa_flags = SA_RESTART;
	if (sigaction(SIGALRM, &act, &oldact) < 0)
	{
		perror("sigaction()");        return;
	}
	// タイマ割り込みを発生させる  
	itval.it_value.tv_sec = TIME_OUT_MINUTES * 60;     // 最初の1回目は5秒後   
	itval.it_value.tv_nsec = 0;
	itval.it_interval.tv_sec = 100000;  // 2回目以降は1秒間隔  
	itval.it_interval.tv_nsec = 0;
	// タイマの作成   
	if (timer_create(CLOCK_REALTIME, NULL, &tid) < 0)
	{
		perror("timer_create");        return;
	}
	//  タイマのセット  
	if (timer_settime(tid, 0, &itval, NULL) < 0)
	{
		perror("timer_settime");        return;
	}


#endif



}
void MaxSAT::search() {

//	LARGE_INTEGER ts;
//	QueryPerformanceCounter(&ts);

	bool bmo = isBMO(false);
	if (bmo) {
		printf("c BMO %d nSoft()=%d\n", orderWeights_size,nSoft());
	}
	else printf("c NonBMO %d nSoft()=%d\n", orderWeights_size,nSoft());
	int64_t  UB = LLONG_MAX;
	initAssumptions();

	if (currentWeight >1) {
		UB=disjoint_search();
	}else {
		UB = nSoft();
		unweight_search();
		goto GO;
	}
	
	best_UB =UB;
	disjoint_success = true;
	
	
	


	if (sofar_best_strategy == RAMP) {
		if (judge_use_of_core_strat()) {
			oll2_search_inc(UB);
		}else {
#ifdef USE_UNSAT
			oll2_search_inc(UB);
#else
#ifdef USE_SAT_TOTAL
			inc_search_total(UB);
#else
			inc_search(UB);
#endif
#endif
		}
	}else if (judge_use_of_core_strat()) {
		oll2_search_inc(UB);
		//core_strat_search(UB);
	}
	else {
		//if (orderWeights_size<=5|| bmo)
#ifdef USE_UNSAT
		oll2_search_inc(UB);
#else
#ifdef USE_SAT_TOTAL
		inc_search_total(UB);
#else
		inc_search(UB);
#endif
#endif
		//else search(UB,10000);
	}



	GO:
	printStats1(*solver);
	full_success = true;
	//weight_root->print_UB();
	printModel();
#ifdef WRITE_FILE
	write_file();
#endif

}
void TNode::print_values(MaxSAT&maxsat, int level) {
	string s = "";
	int tcount = 0;
	Solver&S = *(maxsat.solver);
	for (int i = 0;i < linkingVar.size();i++) {
		Var v = var(linkingVar[i]);
		if (S.value(v) == l_True) {
			s += "1";
			tcount++;
		}
		else if (S.value(v) == l_False) {
			s += "0";
		}
		else s += "z";
	}
	
	if (level) {
		if (left) left->print_values(maxsat, level - 1);
		if (right) right->print_values(maxsat, level - 1);
	}

}
uint64_t MaxSAT::ramp_seach(int timeout)
{
	ramp = new RAMP::Ramp();
	return ramp->search(*this, timeout);


}


void MaxSAT::convert_weight_map(map<unsigned, vec<Lit> > & Map)
{
	//	return;
	if (Map.size() <= 8) return;



	map<unsigned, vec<Lit> > mp = Map;
	map<unsigned, vec<Lit> > ::iterator ix;
	map<double, unsigned> product_map;
	for (ix = mp.begin();ix != mp.end();ix++) {
		uint64_t p = (*ix).first*(*ix).second.size();
		double l = log10(p);

		product_map[l] = (*ix).first;

	}
	map<double, unsigned>::iterator d = product_map.end();
	d--;
	double most = (*d).first;
	d--;
	double second = (*d).first;
	Map.clear();
	if (most - second > 1.0) {//Topが10倍以上違うのならTOPを残し、それ以外をBinaryWeightに変換

		d++;
		ix--;
		(*ix).second.copyTo(Map[(*d).second]);// = (*ix).second;
		mp.erase(ix);

	}
	unsigned c = 1;
	for (ix = mp.begin();ix != mp.end();ix++) {
		unsigned weight = (*ix).first;
		for (int i = 0;i < 32;i++) {
			if ((weight >> i) & 0x01) {
				unsigned binary_weight = c << i;
				map<unsigned, vec<Lit> > ::iterator iy = Map.find(binary_weight);
				if (iy == Map.end()) {
					vec<Lit> v;
					v.copyTo(Map[binary_weight]);// = v;
					iy = Map.find(binary_weight);
				}
				vec<Lit>& v = (*iy).second;
				vec<Lit>& s = (*ix).second;
				for (int j = 0;j < s.size();j++) {
					v.push(s[j]);
				}
			}
		}
	}








}


}
