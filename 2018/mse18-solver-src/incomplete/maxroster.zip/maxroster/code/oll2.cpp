/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial 
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution. 
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include "maxsat.h"
#include "maxsat2.h"
#include <iostream>
namespace Glucose {
	
	void VSoftClauseC::set_assumption(MaxSAT&maxsat, vec<Lit>&assumptions) {
		if (!weight) return;
		if (L == lit_Undef) return;

		if (troot->linkingVar.size() > RHS) {
			Var v = var(L);
			if (v == 4598) {
				int m = 0;
			}

			assumptions.push(~L);
			maxsat.add_vsoft_clause_map(L, this);

		}

	}
	
	void MaxSAT::set_oll2_assumptions(vec<Lit>& assumptions)
	{
		assumptions.clear();
		vsoft_clause_map.clear();
		for (int i = 0;i < vsoft_clauses.size();i++) {
#ifdef HARDNING
			
#ifdef OLL2_INC
			uint64_t w = vsoft_clauses[i]->weight;
			if (!w) continue;
			if (vsoft_clauses[i]->weight + lowerbound > upperbound) {
				VSoftClauseBase*b=vsoft_clauses[i];
				if (vsoft_clauses[i]->L !=lit_Undef)	addClause(~vsoft_clauses[i]->L);
				//traice(maxsat, 30, "Hardening of " << softLiterals[i] << " of weight " << w);
				uint64_t w = vsoft_clauses[i]->weight;
				vsoft_clauses[i]->weight = 0;
				vsoft_clauses[i]->L = lit_Undef;
				continue;

			}
#endif
#endif
			

			if (vsoft_clauses[i]->weight >= currentWeight) {

				vsoft_clauses[i]->set_assumption(*this, assumptions);

			}
			if (lowerbound == 32 && assumptions.size() ==18&& vsoft_clauses[i]->L !=lit_Undef) {
				
				VSoftClauseBase*vs = vsoft_clauses[i];
				int x = vs->L.x;
				int y = assumptions[assumptions.size() - 1].x;
			
				int m = 0;

			}
		}
	}
#ifndef NO_SEND_VSOFTCLAUSEC
	void VSoftClauseC::rebuild(MaxSAT&maxsat)
	{
		int UB=get_maxRHS();
		assert(UB);
		if (troot &&is_troot_parent()) {
			delete troot;
			troot = 0;
		}
		if (vclauses.size()) {
			vec<Lit> inputs;
			for (int i = 0;i < vclauses.size();i++) {
				inputs.push(vclauses[i]->L);
			}
			vec<Lit> linkingVar;
			troot = maxsat.genCardinals(inputs, linkingVar, UB, false);
			set_troot(troot);
		
			
		}
		
		assert(troot);
		
		if (troot->linkingVar.size() > RHS) {
			vec<Lit>lits;
			lits.push(~troot->linkingVar[RHS]);
			lits.push(L);
			bool success=maxsat.addClause(lits);
			assert(success);
		}
	}

	

	uint64_t MaxSAT::core_analysis_oll2(vec<Lit> & conflicts, vec<Lit>&assumptions)
	{
		assert(conflicts.size());

		uint64_t min_cost = compute_min_oll_cost(conflicts);

		vec<VSoftClauseBase*> vs_vec;
		for (int i = 0;i < conflicts.size();i++) {
			Lit L = conflicts[i];
			std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
			if (im == vsoft_clause_map.end()) assert(0);
			else {
				VSoftClauseBase*vs = (*im).second;
				
				if (vs->weight == min_cost) {

					vs->weight = 0;//vmin�̕��͎���assumption����Ȃ�
					vs_vec.push(vs);//���J�E���g�͂����
					if (vs->type == VSoftClause::AssumptionVar) {
						//Nothing to do

					}
					else {
						VSoftClauseC*VSC = dynamic_cast<VSoftClauseC*>(vs);

						Lit l = newLiteral();//�V��������p��BlockingVar
						VSoftClauseC *vs = new VSoftClauseC(VSC, min_cost, l, VSC->RHS + 1);//RHS����オ��
						add_vsoft_clause(vs);

					}

				}
				else {
					assert(vs->weight > min_cost);
					VSoftClauseBase*vmin = vs->split_weight(*this, min_cost);
					assert(vmin->weight == min_cost);
					vmin->weight = 0;//vmin�̕��͎���assumption����Ȃ�
					vs_vec.push(vmin);//���J�E���g�͂����
					add_vsoft_clause(vmin);

					if (vmin->type == VSoftClause::AssumptionVar) {
						//Nothing to do

					}else {
						VSoftClauseC*VSC = dynamic_cast<VSoftClauseC*>(vmin);
					
						Lit l = newLiteral();//�V��������p��BlockingVar
						VSoftClauseC *vs = new VSoftClauseC(VSC, min_cost, l, VSC->RHS + 1);//RHS����オ��
						add_vsoft_clause(vs);

					}


				}
			}

		}
		if (vs_vec.size()==1) {
		
		}else {
		
			Lit L = new_literal();//�V�������񐶐�
			VSoftClauseC*VC = new VSoftClauseC(vs_vec, min_cost, L);
			add_vsoft_clause(VC);

		}

		solver = rebuildSolveroll();

		set_oll2_assumptions(assumptions);
		return min_cost;
	}
	
	
void MaxSAT::oll2_search(uint64_t UB) {


		uint64_t LB = 0;

		for (int i = 0;i < nSoft();i++) {
			uint64_t w = softClauses[i].weight;
			Lit L = softClauses[i].assumptionVar;
			VSoftClauseBase*vs = new VSoftClauseBase(L, w, i);
			add_vsoft_clause(vs);


		}

		solver = rebuildSolveroll();








		lbool res = l_True;

		best_UB = UB;






		vec<Lit> assumptions;
		set_oll2_assumptions(assumptions);


		while (true) {




			res = searchSATSolver(solver, assumptions);
			if (res == l_True) {
				if (currentWeight == get_min_weight_in_vsoft_clauses2())
				{
					//weight_root->print_LB();
					assert(_CrtCheckMemory);
					UB = computeCostModel(solver->model);
					best_UB = UB;
					assert(_CrtCheckMemory);
					printf("c UB=%zd\n", UB);

					solver->saveModel();

					//printAnswer(_OPTIMUM_);


					break;
				}
				else {
					currentWeight = find_next_weight_oll();
					uint64_t cost = computeCostModel(solver->model);
					if (cost < UB)
					{
						UB = cost;
						best_UB=UB;
						upperbound=UB;
						solver->saveModel();
						printf("o %" PRIu64 "\n", UB);
					}

					if (LB == UB)
					{
						printf("c LB = UB\n");
						//printAnswer(_OPTIMUM_);
						//exit(_OPTIMUM_);
						break;
					}
					solver = rebuildSolveroll();
					set_oll2_assumptions(assumptions);
				}


			}
			else if (res == l_False) {
				trim(solver->conflict);
				int core_size = solver->conflict.size();


				uint64_t coreCost = core_analysis_oll2(solver->conflict, assumptions);
				LB += coreCost;
				printf("c LB : %-12" PRIu64 " CS : %-12d W  : %-12zd\n", LB,
					core_size, coreCost);

				printf("c LB=%zd\n", LB);
			}
		}
		assert(_CrtCheckMemory);



	}
#else
void VSoftClauseC::rebuild(MaxSAT&maxsat)
{

	//Nothing to do.
	
}


#endif
}	
