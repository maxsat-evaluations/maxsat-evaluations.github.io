/* Copyright (C) 2017, Sugawara Systems

This license applies to you only if you are a member of a noncommercial
and academic institution, e.g., a university. The license expires as
soon as you are no longer a member of this institution.
For commertial license, please contact nurse-support@sugawara-systems.com.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#include "maxsat.h"
#include "maxsat2.h"
#include <iostream>
namespace Glucose {
	
	void VSoftClauseBase::send_clause(MaxSAT&maxsat) {

		vec<Lit> clause;
		maxsat.softClauses[idx].clause.copyTo(clause);
		clause.push(L);

		bool success=maxsat.addClause(clause);
		assert(success);

	}
	

	
	


	VSoftClauseC::VSoftClauseC(MaxSAT&maxsat, TNode*t, int64_t weight_, int RHS_) {
	
		lowerbound = 0;
		reset_orig();
		weight = weight_;

		troot = t;
		assert(troot);
		RHS = RHS_;

		assert(troot);
		if (troot->UB < RHS) {
			maxsat.extend_UB(troot, RHS);
		
		}
		if (troot->linkingVar.size()>RHS) L = troot->linkingVar[RHS];
		else L = lit_Undef;



	}
	VSoftClauseC::VSoftClauseC(MaxSAT&maxsat, vec<VSoftClauseC*>&vc_vec,vec<VSoftClauseBase*>&vb_vec, int64_t weight_) {
		
		lowerbound = 0;
		weight = weight_;
		reset_orig();

		
		
		RHS = 1;
		TNode*left = 0;
		TNode*right = 0;

		if (vc_vec.size()) {
			vec<Lit> inputs;
			for (int i = 0;i < vc_vec.size();i++) {
				inputs.push(vc_vec[i]->L);
				vclauses.push(vc_vec[i]);
			}
			vec<Lit> linkingVar;
			left = maxsat.genCardinals(inputs, linkingVar, RHS, false);
		}
		if (vb_vec.size()) {
			vec<Lit> inputs;
			for (int i = 0;i < vb_vec.size();i++) {
				inputs.push(vb_vec[i]->L);
				vclauses.push(vb_vec[i]);
			}
			vec<Lit> linkingVar;
			right = maxsat.genCardinals(inputs, linkingVar, RHS, false);
		}
		if (left && right) {
			vec<Lit> linkingVar;
			troot = maxsat.mergeCardinals(right, left, linkingVar, RHS);

		}
		else if (left) {
			troot = left;
		}
		else {
			troot = right;

		}

	

		assert(troot);
		if (troot->UB < RHS) {
			maxsat.extend_UB(troot, RHS);


		}

//#define TRY1
#ifdef TRY1
		if (troot->linkingVar.size() >= RHS&& maxsat.ctype !=MaxSAT::ASSUMPTION_ONLY) {
			maxsat.addClause(troot->linkingVar[RHS - 1]);
		}
#endif

		if (troot->linkingVar.size()>RHS) L = troot->linkingVar[RHS];
		else L = lit_Undef;


	}
	




	void MaxSAT::extend_UB(TNode* node, unsigned newUB)
	{

	//	if (node->get_vsoft_rhs()) {
	//		newUB = node->get_vsoft_rhs();
	//	}

		int inputSize = node->inputs.size();

		if (inputSize >= 2) {
			int l_lb = node->left->get_lb();
			int r_lb = node->right->get_lb();
			if (l_lb) {
				extend_UB(node->left, newUB);
				extend_UB(node->right, newUB-l_lb);

			}else if (r_lb) {
				extend_UB(node->left, newUB-r_lb);
				extend_UB(node->right, newUB );

			}
			else {
				extend_UB(node->left, newUB);
				extend_UB(node->right, newUB);
			}
		}
		else return;



		for (int i = node->imax + 1; i < inputSize && i <= newUB; i++) {
			if (i> node->imax) node->imax = i;
			Lit L = new_literal();
			newSATVariable(solver);

			node->linkingVar.push(L);//new_literal());//Lit(S.newVar()));
		}

		for (int sigma = 0; sigma <= inputSize && sigma <= newUB + 1; sigma++) {
			for (int alpha = 0; alpha <= node->left->linkingVar.size() && alpha <= newUB + 1; alpha++) {
				for (int beta = 0;beta <= node->right->linkingVar.size() && beta <= newUB + 1;beta++) {
					if ((alpha + beta) != sigma) continue;
					std::set<abc>::iterator im = node->abc_set.find(abc(sigma, alpha, beta));
					if (im != node->abc_set.end()) continue;

					assert(alpha + beta == sigma);
					int a = alpha - 1;
					int b = beta - 1;
					int s = sigma - 1;
					vec<Lit> lits;

					if (sigma != 0) {
						if (alpha != 0)	lits.push(~node->left->linkingVar[a]);
						if (beta != 0)   lits.push(~node->right->linkingVar[b]);
						lits.push(node->linkingVar[s]);
						tnode_clauses.push(lits);
						addClause(lits);
					}
					if (sigma != inputSize && sigma != newUB + 1) {
						lits.clear();
						if (alpha != node->left->linkingVar.size()) lits.push(node->left->linkingVar[a + 1]);
						if (beta != node->right->linkingVar.size()) lits.push(node->right->linkingVar[b + 1]);
						lits.push(~node->linkingVar[s + 1]);
						tnode_clauses.push(lits);
						addClause(lits);
					}


					node->abc_set.insert(abc(sigma, alpha, beta));

				}
			}
		}
		node->UB = newUB;
	}
	VSoftClauseBase* VSoftClauseC::split_weight(MaxSAT&maxsat, uint64_t min_weight,bool inc)
	{
		reset_orig();

		weight -= min_weight;
		assert(weight);

		VSoftClauseC*vsc = new VSoftClauseC(maxsat, troot, min_weight, RHS);


		return vsc;
	

	}
	
	void MaxSAT::minimize_upperbound_oll() {
		//�������Ă��Ȃ�VSoftClauseC�𒊏o����
		vec<Lit> assumptions;
		vec<Lit> inputs;
		int local_upperbound = upperbound-lowerbound;
		if (!local_upperbound) return;

		for (int i = 0;i < vsoft_clauses.size();i++) {
			if (!vsoft_clauses[i]->weight) continue;
			if (vsoft_clauses[i]->type == VSoftClauseBase::AssumptionVar) {
				inputs.push(vsoft_clauses[i]->L);
				continue;
			}
			Lit L = vsoft_clauses[i]->L;
			if (L != lit_Undef) {
				Var v = var(L);
				if (solver->model[v] == l_False) {//�������Ă���
					assumptions.push(~L);
					continue;
				}
				//���̐���͖������Ă��Ȃ��B�������Ă��Ȃ��������g�����Đ��񂷂�
				VSoftClauseC* vsc = dynamic_cast<VSoftClauseC*>(vsoft_clauses[i]);
				int RHS = vsc->get_unsatisfied_litrals(*solver);
				extend_UB(vsc->troot, RHS);
				if (vsc->troot->linkingVar.size() > RHS) {
					L = vsc->troot->linkingVar[RHS];
					assumptions.push(~L);
				}
			}
		}
		vec<Lit> outputs;
		TNode*troot=genCardinals(inputs, outputs, local_upperbound,false);
		lbool ret = l_True;
		vec<Lit> Assumptions;
	
		assumptions.copyTo(Assumptions);
		while (true) {
			Lit L = outputs[local_upperbound];
			Assumptions.push(~L);
			ret = solveLimited(Assumptions);
			if (ret == l_True) {
				uint64_t t = computeCostModel(solver->model);
			//	printf("c lo=%d %ld\n", local_upperbound,t);
				if (!local_upperbound) break;
				local_upperbound--;

			}else if (ret == l_False) {
				break;
			}
		}
		

	}


	void MaxSAT::conflict_minimize(vec<Lit>& conflicts, vec<VSoftClauseBase*>& cvec,bool do_trim) {
		vec<Lit> assumptions;
		conflicts.copyTo(conflict);
		for (int i = 0;i < cvec.size();i++) {
			cvec[i]->set_assumption(*this,assumptions);
		
		}
		lbool ret = solveLimited(assumptions);
		if (ret == l_True) {
			
			assumptions.clear();
			if (disjoint_status == ONCE_SAT) {
				disjoint_status = DISJOINT_DONE;
				printf("c disjoint done.\n");

			}
			uint64_t t = computeCostModel(solver->model,true);//, true);
			if (t < upperbound) {
				upperbound = t;
				best_UB = t;
				solver->saveModel();

				printf("o %ld\n", upperbound);
				//value_check();
			}
			//sat_search_oll();
		//	return;
			//minimize_upperbound_oll();
//#define APPLY_ASSUMPTION_TRY

#ifdef APPLY_ASSUMPTION_TRY
			for (int i = 0;i < conflict.size();i++) {
				Lit L = conflict[i];
				std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
				if (im == vsoft_clause_map.find(L)) {
					if ((*im).second->type == VSoftClauseBase::AssumptionVar) {
						assumptions.push(~L);
					}
				}
			}
		
			ret = solveLimited(assumptions);//AssumptionVars Only
			if (ret == l_True) {
				
				if (disjoint_status == ONCE_SAT) {
					disjoint_status = DISJOINT_DONE;
					printf("c disjoint done.\n");

				}
				uint64_t t = computeCostModel(solver->model, true);
				
				if (t < upperbound) {
					upperbound = t;
					best_UB = t;
					solver->saveModel();

					printf("o %ld\n", upperbound);
				}
				conflict.copyTo(conflicts);
				//We can do nothing. �������v��
				//trim(conflicts);//
				return;

			}else {///AssumptionVars������UNSAT
			//	printf("c made assumption only\n");
				
				assumptions.copyTo(conflicts);
				for (int i = 0;i < conflicts.size();i++) {
					conflicts[i] = ~conflicts[i];
				}
				trim(conflicts);
				return;

			}
#else
			conflict.copyTo(conflicts);
			
			trim(conflicts);

#endif
		}else {//AssumptionVar�Ȃ���UNSAT
	//		printf("c made constraints only\n");
		


			assumptions.copyTo(conflicts);
			for (int i = 0;i < conflicts.size();i++) {
				conflicts[i] = ~conflicts[i];
			}
			if (do_trim) {
				trim(conflicts);
			}
			return;

		}
		


	}

	void MaxSAT::conflict_minimize(vec<Lit>& conflicts) {
		vec<VSoftClauseBase*> cvec;
		ctype=get_conflict_type(conflicts, cvec);
		switch (ctype) {
			case ASSUMPTION_ONLY:
			//	printf("c assumption only\n");
#ifdef USE_OLL_MCU3_UNWEIGHT
				//trim(conflicts);
#endif
				return;
			case HAS_VSUM:
			//	printf("c has vsum\n");
				conflict_minimize(conflicts, cvec,false);
				return;
		
			case ASSUMPTIONS_AND_CONSTRAINTS:
			//	printf("c assumptions and constraints\n");
				conflict_minimize(conflicts, cvec);
				return;
		}


	}
	MaxSAT::CONFLICT_TYPE MaxSAT::get_conflict_type(vec<Lit>& conflicts,vec<VSoftClauseBase*>& cvec)
	{
		bool has_vsum = false;
		for (int i = 0;i < conflicts.size();i++) {
			Lit L = conflicts[i];
			std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
			if (im == vsoft_clause_map.find(L)) {
				if ((*im).second->type == VSoftClauseBase::Constraint
			//		||
			//		(*im).second->type == VSoftClauseBase::VSUM
					
					) {
					//VSoftClauseC* vsc = dynamic_cast<VSoftClauseC*>((*im).second);
					cvec.push( (*im).second);
				}
				if ((*im).second->type == VSoftClauseBase::VSUM) {
					cvec.push((*im).second);
					has_vsum = true;
				}
				if ((*im).second->type == VSoftClauseBase::MCU3) {
					cvec.push((*im).second);
					
				}
			}
		}
		if (has_vsum) {
			return HAS_VSUM;
		}
		if (cvec.size() == 0&& !has_vsum) {
			return ASSUMPTION_ONLY;
		}
		
		return ASSUMPTIONS_AND_CONSTRAINTS;
	}

	
	/*
	uint64_t MaxSAT::core_analysis_oll2_inc(vec<Lit> & conflicts, vec<Lit>&assumptions,bool free_phase)
	{

		
		
		uint64_t min_cost = compute_min_oll_cost(conflicts);
		conflict_minimize(conflicts);
		//trim(conflicts);
		
		
		vec<VSoftClauseBase*> vs_vec;
		for (int i = 0;i < conflicts.size();i++) {
			Lit L = conflicts[i];
			std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
			if (im == vsoft_clause_map.end()) assert(0);
			else {
				VSoftClauseBase*vs = (*im).second;

				if (vs->weight == min_cost) {

					vs->weight = 0;//vmin�̕��͎���assumption����Ȃ�

					vs_vec.push(vs);//���J�E���g�͂����
					if (vs->type == VSoftClause::AssumptionVar) {
						//Nothing to do

					}
					else {
						VSoftClauseC*VSC = dynamic_cast<VSoftClauseC*>(vs);

						VSoftClauseC *vs = new VSoftClauseC(*this, VSC->troot, min_cost, VSC->RHS + 1);//RHS����オ��


						add_vsoft_clause(vs);
					}

				}
				else {
					assert(vs->weight > min_cost);
					VSoftClauseBase*vmin = vs->split_weight(*this, min_cost,true);
					assert(vmin->weight == min_cost);


					vmin->weight = 0;//vmin�̕��͎���assumption����Ȃ�
					vs_vec.push(vmin);//���J�E���g�͂����
					add_vsoft_clause(vmin);

					if (vmin->type == VSoftClause::AssumptionVar) {
						//Nothing to do

					}
					else {
						VSoftClauseC*VSC = dynamic_cast<VSoftClauseC*>(vmin);

						VSoftClauseC *vs = new VSoftClauseC(*this, VSC->troot, min_cost, VSC->RHS + 1);//RHS����オ��

						add_vsoft_clause(vs);

					}


				}
			}

		}
		if (vs_vec.size() == 1) {

		}
		else {

			VSoftClauseC*VC = new VSoftClauseC(*this,vs_vec, min_cost);


			add_vsoft_clause(VC);

		}
	//	if (disjoint_status >= ONCE_SAT) {
	//		lbool status = oll_sat_check();//progressionMinimize(min_cost, conflicts);

	//	}
		//solver = rebuildSolveroll();
		if (free_phase)		set_oll2_assumptions_free_phase(assumptions);
		else set_oll2_assumptions(assumptions);
		return min_cost;
	}
	*/
	void MaxSAT::unweighted_non_repeat_search()
	{
		uint64_t c=computeCostModel(solver->model, true);
		vec<Lit> assumptions;
		for (int i = 0;i < vsoft_clauses.size();i++) {
			if (vsoft_clauses[i]->type != VSoftClauseBase::AssumptionVar) continue;
			vsoft_clauses[i]->set_assumption(*this,assumptions);
			
		}


			

		while (true) {


			lbool res = searchSATSolver(solver, assumptions);
			if (res == l_False)break;

			uint64_t cost = computeCostModel(solver->model, true);
			if (cost < upperbound){
				best_UB = cost;
				upperbound = cost;
				solver->saveModel();

				printf("c o=%ld\n", best_UB);
			}
			vec<Lit> inputs;
			for (int i = 0;i < vsoft_clauses.size();i++) {
				if (vsoft_clauses[i]->weight) continue;
				if (vsoft_clauses[i]->type != VSoftClauseBase::AssumptionVar) continue;
				Lit L = softClauses[i].assumptionVar;
				Var v = var(L);
				if (solver->model[v] == l_True) inputs.push(~L);
			}
			assert(cost == inputs.size());
			addClause(inputs);
		}

	}
	uint64_t MaxSAT::core_analysis_oll2_seq_inc(vec<Lit> & conflicts, vec<Lit>&assumptions,  bool free_phase)
	{

		uint64_t min_cost = compute_min_oll_cost(conflicts);
		conflict_minimize(conflicts);
		//trim(conflicts);


		vec<VSoftClauseSeqLE*> vc_vec;
		vec<VSoftClauseBase*> vb_vec;

		for (int i = 0;i < conflicts.size();i++) {
			Lit L = conflicts[i];
			std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
			if (im == vsoft_clause_map.end()) assert(0);
			else {
				VSoftClauseBase*vs = (*im).second;

				if (vs->weight == min_cost) {

					vs->weight = 0;//vmin�̕��͎���assumption����Ȃ�


					if (vs->type == VSoftClause::AssumptionVar) {
						//Nothing to do
						vb_vec.push(vs);//���J�E���g�͂����
					}
					else {
						VSoftClauseSeqLE*VSC = dynamic_cast<VSoftClauseSeqLE*>(vs);
						vc_vec.push(VSC);
						VSoftClauseSeqLE *vs = new VSoftClauseSeqLE(*this, VSC->seq, min_cost, VSC->RHS + 1);//RHS����オ��


						add_vsoft_clause(vs);
					}

				}
				else {
					assert(vs->weight > min_cost);
					VSoftClauseBase*vmin = vs->split_weight(*this, min_cost, true);
					assert(vmin->weight == min_cost);


					vmin->weight = 0;//vmin�̕��͎���assumption����Ȃ�

					add_vsoft_clause(vmin);

					if (vmin->type == VSoftClause::AssumptionVar) {
						//Nothing to do
						vb_vec.push(vmin);
					}
					else {
						VSoftClauseSeqLE*VSC = dynamic_cast<VSoftClauseSeqLE*>(vmin);
						vc_vec.push(VSC);
						VSoftClauseSeqLE *vs = new VSoftClauseSeqLE(*this, VSC->seq, min_cost, VSC->RHS + 1);//RHS����オ��

						add_vsoft_clause(vs);

					}


				}
			}

		}
		uint64_t total_cost = min_cost;
		

		if (vb_vec.size() == 0 && vc_vec.size() == 1) {//Constraint1�݂̂�Nothing
			
		}
		else {



			VSoftClauseSeqLE*VSC = new VSoftClauseSeqLE(*this, vc_vec, vb_vec, min_cost);
			add_vsoft_clause(VSC);
			
		}

		if (free_phase)		set_oll2_assumptions_free_phase(assumptions);
		else set_oll2_assumptions(assumptions);
		return total_cost;//min_cost;
	}
	uint64_t MaxSAT::core_analysis_oll2_inc(vec<Lit> & conflicts, vec<Lit>&assumptions,  bool free_phase)
	{
		
		assert(conflicts.size());
		uint64_t min_cost = compute_min_oll_cost(conflicts);
		bool d = false;
		if (!free_phase) {
			d = true;
		}
		conflict_minimize(conflicts);
		//trim(conflicts);


		vec<VSoftClauseC*> vc_vec;
		vec<VSoftClauseBase*> vb_vec;

		for (int i = 0;i < conflicts.size();i++) {
			Lit L = conflicts[i];
			std::map<Lit, VSoftClauseBase*>::iterator im = vsoft_clause_map.find(L);
			if (im == vsoft_clause_map.end()) assert(0);
			else {
				VSoftClauseBase*vs = (*im).second;

				if (vs->weight == min_cost) {

					vs->weight = 0;//vmin�̕��͎���assumption����Ȃ�

					
					if (vs->type == VSoftClause::AssumptionVar) {
						//Nothing to do
						vb_vec.push(vs);//���J�E���g�͂����
					}
					else {
						VSoftClauseC*VSC = dynamic_cast<VSoftClauseC*>(vs);
						vc_vec.push(VSC);
						VSoftClauseC *vs = new VSoftClauseC(*this, VSC->troot, min_cost, VSC->RHS + 1);//RHS����オ��

						
						add_vsoft_clause(vs);
					}

				}
				else {
					assert(vs->weight > min_cost);
					VSoftClauseBase*vmin = vs->split_weight(*this, min_cost, true);
					assert(vmin->weight == min_cost);


					vmin->weight = 0;//vmin�̕��͎���assumption����Ȃ�
					
					add_vsoft_clause(vmin);

					if (vmin->type == VSoftClause::AssumptionVar) {
						//Nothing to do
						vb_vec.push(vmin);
					}
					else {
						VSoftClauseC*VSC = dynamic_cast<VSoftClauseC*>(vmin);
						vc_vec.push(VSC);
						VSoftClauseC *vs = new VSoftClauseC(*this, VSC->troot, min_cost, VSC->RHS + 1);//RHS����オ��
						
						add_vsoft_clause(vs);

					}


				}
			}

		}
		uint64_t total_cost = min_cost;
		//if (*min2 && (*min2)->weight) total_cost *= 2;

		if (vb_vec.size()==0 && vc_vec.size() == 1) {//Constraint1�݂̂�Nothing
			
		}
		else {
			
	

				VSoftClauseC*VSC = new VSoftClauseC(*this, vc_vec, vb_vec, min_cost);
				add_vsoft_clause(VSC);
			
		}
		
		if (free_phase)		set_oll2_assumptions_free_phase(assumptions);
		else set_oll2_assumptions(assumptions);
		return total_cost;//min_cost;
	}
	VSoftClauseC::VSoftClauseC(MaxSAT&maxsat, int64_t weight_ ,vec<VSoftClauseBase*>&vvec) {
		
		lowerbound = 0;
		weight = weight_;
		reset_orig();

	
		RHS = 1;
		{
			vec<Lit> inputs;
			for (int i = 0;i < vvec.size();i++) {
				inputs.push(vvec[i]->get_most_lit());
			}
			vec<Lit> linkingVar;
			troot = maxsat.genCardinals(inputs, linkingVar, RHS, false);
		}

		assert(troot);
		if (troot->UB < RHS) {
			maxsat.extend_UB(troot, RHS);

		}
		if (troot->linkingVar.size() > RHS) {
			L = troot->linkingVar[RHS];
			Var v = var(L);
			if (v == 4598) {
				int m = 0;
			}
		}
		else L = lit_Undef;


	}
	VSoftClauseC::VSoftClauseC(MaxSAT&maxsat, vec<VSoftClauseBase*>&vvec, int64_t weight_,int local_lowerbound,bool gen_troot) {
		
		lowerbound = local_lowerbound;
		weight = weight_;
		reset_orig();

		vvec.copyTo(vclauses);
		assert(vclauses.size());
		RHS = 1;
		troot = 0;
		if (!gen_troot) return;
		if (vclauses.size()) {
			vec<Lit> inputs;
			for (int i = 0;i < vclauses.size();i++) {
				inputs.push(vclauses[i]->L);
			}
			vec<Lit> linkingVar;
			troot = maxsat.genCardinals(inputs, linkingVar, RHS, false);
//			troot->set_base(this);
		}
		

		assert(troot);
		if(lowerbound) troot->set_base(this);
		if (troot->UB < RHS) {
			maxsat.extend_UB(troot, RHS);

		}
		if (troot->linkingVar.size() > RHS) {
			L = troot->linkingVar[RHS];

		}
		else L = lit_Undef;
//#ifndef SAT1
		if (lowerbound&& troot->linkingVar.size()>=lowerbound) {
			maxsat.addClause(troot->linkingVar[lowerbound-1]);
		}
//#endif
	}
	void MaxSAT::set_oll2_assumptions_free_phase(vec<Lit>& assumptions)
	{
		assumptions.clear();
		vsoft_clause_map.clear();
		for (int i = 0;i < vsoft_clauses.size();i++) {
			if (vsoft_clauses[i]->type != VSoftClauseBase::AssumptionVar) continue;
			if (!vsoft_clauses[i]->weight) continue;


			if (vsoft_clauses[i]->weight >= currentWeight) {

				vsoft_clauses[i]->set_assumption(*this, assumptions);

			}
		}
	}
	uint64_t MaxSAT::oll_lowerbound_search_inc(uint64_t UB) {

		printf("c lbsi\n");
		
		maxWeight = currentWeight;
		currentWeight = get_min_weight_in_vsoft_clauses();

	


		lbool res = l_True;




		best_UB = UB;

		vec<Lit> assumptions;
		set_oll_assumptions(assumptions);

		lowerbound = 0;
		while (true) {
			


			int timeout;
			if (lowerbound <= 2 && lowerbound) timeout = TIME_OUT_SECONDS_ON_DISJOINT_STEP_LE2;
			else timeout = TIME_OUT_SECONDS_ON_DISJOINT_STEP;
		//	timeout = 120;
			res = searchSATSolver(solver, assumptions, timeout);
			if (res == l_Undef) {
				lowerbound = 0;
				return 0;


			}else if (res == l_True) {
				disjoint_status = ONCE_SAT;

				uint64_t cost = computeCostModel(solver->model);
				if (cost < UB)
				{
					UB = cost;
					best_UB = UB;
					upperbound = UB;
					solver->saveModel();
					printf("o %" PRIu64 "\n", UB);
					//value_check();
				}
				currentWeight = maxWeight;
				make_oll_weight_map();
				return lowerbound;



			}
			else if (res == l_False) {
				
				assert(solver->conflict.size());


				uint64_t coreCost;
				
				if(maxWeight==1) coreCost=core_analysis_oll2_oll_mcu3_unweight(solver->conflict, assumptions, true);
				else {
					 coreCost = core_analysis_oll2_inc(solver->conflict, assumptions, true);//vsoft clause assumption�𐶐����Ȃ�

				}

				
				int core_size = solver->conflict.size();
				lowerbound += coreCost;
				printf("c LB : %-12" PRIu64 " CS : %-12d W  : %-12zd\n", lowerbound,
					core_size, coreCost);

				;
			}
		}
		//assert(_CrtCheckMemory);





	}

	void MaxSAT::oll2_search_inc(uint64_t UB) {

		upperbound = UB;
		lowerbound = 0;
		solver = rebuildSolveroll();
		
		for (int i = 0;i < nSoft();i++) {
			uint64_t w = softClauses[i].weight;
			Lit L = softClauses[i].assumptionVar;
			VSoftClauseBase*vs = new VSoftClauseBase(L, w, i);
			vs->send_clause(*this);
			add_vsoft_clause(vs);


		}
		//	if (currentWeight == 1) {
		//
		//		wpm3_search_inc(UB);
		//		return;
		//	}

#ifdef OLL_LOWER
#ifdef USE_FREE_SAT
		{
			vec<Lit> assumptions;
			searchSATSolver(solver, assumptions);
			uint64_t cost = computeCostModel(solver->model);
			if (cost < best_UB) {
				solver->saveModel();
				printf("o %" PRIu64 "\n", cost);
				best_UB = cost;
				upperbound = cost;
			}
		}
#endif
		
		lowerbound = oll_lowerbound_search_inc(UB);
		
			for (int i = 0;i < vsoft_clauses.size();i++) {
				vsoft_clauses[i]->set_lowerbound_to_clause(*this);
			}
		
	//	sat_search(upperbound);
	//	return;
		//inc_search(upperbound);
		//return;
		//unweighted_non_repeat_search()
		//sat_search(upperbound);
		////return;

#endif

	//	inc_search(upperbound);
	//	return;



		lbool res = l_True;

		best_UB = upperbound;






		vec<Lit> assumptions;
		set_oll2_assumptions(assumptions);

		
		while (true) {
			


			res = searchSATSolver(solver, assumptions);
			if (res == l_True) {
				uint64_t cost = computeCostModel(solver->model);
				if (cost < upperbound) {
					best_UB = cost;
					upperbound = cost;
					printf("o %zd\n", cost);
					solver->saveModel();

				}


				if (lowerbound == upperbound) {
					
				
					
					

					break;

				}else {
					currentWeight = find_next_weight_oll();
					uint64_t cost = computeCostModel(solver->model);
					if (cost < upperbound)
					{

						best_UB = cost;
						upperbound = cost;
						solver->saveModel();
						printf("o %" PRIu64 "\n", upperbound);
					}

					if (lowerbound == upperbound)
					{
						best_UB = upperbound;

						printf("c LB = UB\n");
						//printAnswer(_OPTIMUM_);
						//exit(_OPTIMUM_);
						break;
					}
					//solver = rebuildSolveroll();
					set_oll2_assumptions(assumptions);
				}


			}
			else if (res == l_False) {


				assert(solver->conflict.size());
#ifdef USE_SEQ_LE
				uint64_t coreCost = core_analysis_oll2_seq_inc(solver->conflict, assumptions);
#else
				uint64_t coreCost = core_analysis_oll2_inc(solver->conflict,assumptions);
#endif
				int core_size = solver->conflict.size();
				lowerbound += coreCost;
				printf("c LB : %-12" PRIu64 " CS : %-12d W  : %-12zd\n", lowerbound,
					core_size, coreCost);

			//	printf("c LB=%zd\n", lowerbound);
			}
		}
		//	assert(_CrtCheckMemory);



	}

}	
