#!/usr/bin/python
# File:  chk_wmaxsat.py
# Authors:  mikolas, ruben
# Modified on: Wed Jun  7 19:21:53 CDT  2017
# Created on:  Sat Apr 13 15:22:39 WEST 2013
# Copyright (C) 2017, Ruben Martins
# Copyright (C) 2013, Mikolas Janota
import string, sys, re, os, hashlib

lc=0 # line counter

def warning(s):
  global lc
  if lc>0: print 'warning:'+str(lc)+':',s
  else:  print 'warning',s

def error(s):
  global lc
  if lc>0:  print 'error:'+str(lc)+':',s
  else:  print 'error:',s
  sys.exit(100)

def main():
  args=sys.argv
  #if len(args) != 3:
  #  error('2 arguments are expected\nUSAGE: '+args[0]+' SOLUTION FORMULA')

  formula_stream = open(args[2])
  res_stream = open(args[1])
  hash_file = hashlib.md5(open(args[2], 'rb').read()).hexdigest()

  db=dict()
  with open("db.txt") as f:
    for line in f:
      (key, val) = line.split()
      db[key] = int(val)

  m=dict() # model
  o=None   # optimum declared in solution
  s=None   # status
  v=None   # solution
  for l in res_stream:
    l.strip()
    if not l: continue
    if l.find('\tv ')!=-1: # model line
      v=1
      y=l[l.find('v '):len(l)]
      #print y
      for v in y.split()[1:]:
        iv=int(v)
        m[abs(iv)]=iv

    if l.find('\to ')!=-1: # solution line
      y=l[l.find('o '):len(l)]
      spll = y.split()
      if len(spll)!=2: error('o line should have exactly one number')
      o=long(spll[1])
      #print y
    
    if l.find('\ts OPTIMUM FOUND')!=-1: # s line
      print "optimum=true"
      s=1

  if o==None or v==None:
    if s==None:
      print "optimum=false"  
    print 'given_solution=none'
    print 'checker_solution=none'
    print 'hard_clauses=unknown'
    if hash_file in db:
      print 'optimum_solution=',db[hash_file]
    else:
      print 'optimum_solution=unknown'
    print 'checker=ok'
    exit(0)

  if s==None:
    print "optimum=false"

  header_found = False
  lc=0
  optimum_found = 0L
  for l in formula_stream:
    l.strip()
    lc=lc+1
    if not l: continue
    if l[0]=='c': continue
    if not header_found:
      if l[0]!='p': error ('header expected')
      hspl = re.match('p\s+wcnf\s+([0-9]+)\s+([0-9]+)\s+([0-9]+)\s*', l)
      if hspl:
        variable_count=int(hspl.group(1))
        clause_count=int(hspl.group(2))
        top=long(hspl.group(3))
        header_found = True
      else:
        error('parsing p line did not work out')
    else:
      lspl=l.split()
      if len(lspl)<2: error('expected at least two numbers on a clause line')
      cltrue=False
      if int(lspl[len(lspl)-1]) != 0: error('clause not terminated by zero')
      for slit in lspl[1:len(lspl)-1]:
        lit = int(slit)
        var = abs(lit)
        if var in m and m[var]==lit:
          cltrue=True
          break
      if not cltrue:
        w = long(lspl[0])
        if w > top: error ('weight bigger than top found')
        if w==top: 
          print 'hard_clauses=unsatisfied'
          print 'given_solution=unknown'
          print 'checker_solution=unknown'
          if hash_file in db:
            print 'optimum_solution=',db[hash_file]
          else:
            print 'optimum_solution=unknown'
          print 'checker=error'
          exit(0)
        optimum_found = optimum_found + w
  lc=0
  if not header_found: error('no P line found')

  print 'hard_clauses=satisfied'
  print 'given_solution=',o
  print 'checker_solution=',optimum_found
  if optimum_found != o: 
    print 'checker=error'
  else: 
    if s==None:
      if hash_file in db:
        print 'optimum_solution=',db[hash_file]
        if db[hash_file]<=o:
          print 'checker=ok'
        else:
          print 'checker=error'
      else:
        print 'checker=ok'
        print 'optimum_solution=unknown'
    else:
      if hash_file in db:
        print 'optimum_solution=',db[hash_file]
        if o==db[hash_file] or db[hash_file]==-1:
          print 'checker=ok'
        else:
          print 'checker=error'
      else:
        print 'checker=ok'
        print 'optimum_solution=unknown'

if __name__ == "__main__":
  main()
