#!/bin/bash

solution=$1
benchmark=$2

if [ "$#" -ne 2 ]; then
    echo "error: Illegal number of parameters"
    echo "USAGE: ./chk_all.sh <solution_dir> <benchmark_dir>"
    exit 0
fi

for f in $solution/* ; do 
	y=$(basename $f)
	echo $y
	./chk_maxsat.py <$f/* $benchmark/$y
done