/**
 * @file main.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <argp.h>
#include <assert.h>
#include <errno.h>
#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/noSAT-MaxSAT.h>
#include <noSAT-MaxSAT/wcnf.h>
#include <private/logging.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "common.h"
#include "formulas/wcnf.h"
#include "io/MaxSAT22.h"

typedef struct {
  const char* file;
  nsms_params_t params;
} arguments_t;

static void signalHandler(int signal);

static void registerSignalHandlers(void);

// NOLINTNEXTLINE(readability-non-const-parameter)
static error_t parseOpt(int key, char* arg, struct argp_state* state);

static void parseUIntOpt(nsms_uint_t* val, const char* name, const char* arg, struct argp_state* state);

static void setParameters(arguments_t* args, const nsms_wcnf_t* formula);

static void setParamIfNotUserProvided(nsms_uint_t* param, nsms_uint_t value);

static void printResult(const nsms_result_t* result, nsms_uint_t numVariables);

static int run(nsms_wcnf_t* formula, const arguments_t* args);

const char* argp_program_version = "noSAT-MaxSAT";
const char* argp_program_bug_address = "<ole.luebke@tuhh.de>";

static nsms_result_t result = {.status = NSMS_INFEASIBLE, .cost = NSMS_UINT_MAX, .assignment = NULL};
static nsms_uint_t numVariables = 0;
static bool stop = false;

int main(int argc, char** argv) {
  INIT_DURATION_MEAS();

  char doc[] = "Try to solve MaxSAT problem read from FILE using noSAT-MaxSAT";
  char argsDoc[] = "FILE";
  struct argp_option options[] = {
      {"maxTries", 't', "NUM", 0, "Maximum number of retries (outer loop).\nDefault: UINT64_MAX", 0},
      {"maxFlips", 'l', "NUM", 0,
       "Maximum number of flips (inner loop).\nIf not specified, maxFlipsFactor is used to determine this.", 0},
      {"maxRetriesWOImprovement", 'r', "NUM", 0,
       "Maximum number of retries without improvement, before restart with new random assignment is forced", 0},
      {"bmsSize", 'b', "NUM", 0, "Size for Best of Multiple Selection", 0},
      {"hWeightInc", 'h', "NUM", 0, "Hard clause weight increment", 0},
      {"sWeightInc", 's', "NUM", 0, "Soft clause weight increment", 0},
      {"sSmoothProb", 'p', "NUM", 0, "Smoothing probability for soft clause weights\n100000000 = 100%", 0},
      {"sWeightBoundCoef", 'c', "NUM", 0, "Coefficient for calculating soft clause weight bounds (non-partial only)",
       0},
      {"sWeightBoundOffset", 'o', "NUM", 0, "Offset for calculating soft clause weight bounds (non-partial only)", 0},
      {0}};
  struct argp argp = {options, parseOpt, argsDoc, doc, NULL, NULL, NULL};
  arguments_t args = {
      .file = NULL,
      .params = {.maxTries = NSMS_UINT_MAX,
                 .maxFlips = NSMS_UINT_MAX,
                 .maxTriesWOImprovement = NSMS_UINT_MAX,
                 .bmsSize = NSMS_UINT_MAX,
                 .hWeightInc = NSMS_UINT_MAX,
                 .sWeightInc = NSMS_UINT_MAX,
                 .sSmoothProb = NSMS_UINT_MAX,
                 .sWeightBoundCoef = NSMS_UINT_MAX,
                 .sWeightBoundOffset = NSMS_UINT_MAX},
  };

  registerSignalHandlers();

  argp_parse(&argp, argc, argv, 0, NULL, &args);

  int exitCode = 0;

  FILE* inputStream = fopen(args.file, "r");
  if (inputStream) {
    LOG_INFO("c starting to read problem\n");
    START_DURATION_MEAS();
    nsms_uint_t errLine = 0;
    nsms_wcnf_t* formula = wcnfFromMaxSAT22(inputStream, &errLine);
    LOG_INFO_WITH_DURATION("c read problem");
    fclose(inputStream);

    if (formula) {
      setParameters(&args, formula);

      LOG_INFO("c Parameters:\n");
      LOG_INFO("c   maxTries:                " NSMS_UINT_FORMAT "\n", args.params.maxTries);
      LOG_INFO("c   maxRetriesWOImprovement: " NSMS_UINT_FORMAT "\n", args.params.maxTriesWOImprovement);
      LOG_INFO("c   maxFlips:                " NSMS_UINT_FORMAT "\n", args.params.maxFlips);
      LOG_INFO("c   bmsSize:                 " NSMS_UINT_FORMAT "\n", args.params.bmsSize);
      LOG_INFO("c   hWeightInc:              " NSMS_UINT_FORMAT "\n", args.params.hWeightInc);
      LOG_INFO("c   sWeightInc:              " NSMS_UINT_FORMAT "\n", args.params.sWeightInc);
      LOG_INFO("c   sSmoothProb:             " NSMS_UINT_FORMAT "\n", args.params.sSmoothProb);
      LOG_INFO("c   sWeightBoundCoef:        " NSMS_UINT_FORMAT "\n", args.params.sWeightBoundCoef);
      LOG_INFO("c   sWeightBoundOffset:      " NSMS_UINT_FORMAT "\n", args.params.sWeightBoundOffset);

      LOG_INFO("c running on a formula with " NSMS_UINT_FORMAT " variables and " NSMS_UINT_FORMAT
               " clauses (" NSMS_UINT_FORMAT " hard + " NSMS_UINT_FORMAT " soft)\n",
               formula->numVariables, formula->numClauses, formula->numHardClauses,
               formula->numClauses - formula->numHardClauses);

      exitCode = run(formula, &args);

      deleteWCNF(formula);
      formula = NULL;
    } else {
      if (errLine) {
        fprintf(stderr, "c Syntax error on line " NSMS_UINT_FORMAT ".\n", errLine);
      } else {
        fprintf(stderr, "c Ran out of memory while parsing.\n");
      }
    }
  } else {
    fprintf(stderr, "c Could not open file \"%s\".\n", args.file);
  }

  return exitCode;
}

static void signalHandler(int signal) {
  switch (signal) {
    case SIGINT:  // fall-through
    case SIGTERM:
      /* printResult(&result, numVariables);
      exit(EXIT_SUCCESS); */
      stop = true;
      break;
    default:
      break;
  }
}

static void registerSignalHandlers(void) {
  // NOLINTNEXTLINE(performance-no-int-to-ptr)
  if (signal(SIGTERM, signalHandler) == SIG_ERR) {
    fprintf(stderr, "c Failed to register SIGTERM handler\n");
    exit(EXIT_FAILURE);
  }
  // NOLINTNEXTLINE(performance-no-int-to-ptr)
  if (signal(SIGINT, signalHandler) == SIG_ERR) {
    fprintf(stderr, "c Failed to register SIGINT handler\n");
    exit(EXIT_FAILURE);
  }
}

static error_t parseOpt(int key, char* arg, struct argp_state* state) {
  arguments_t* const arguments = state->input;

  switch (key) {
    case 't':
      parseUIntOpt(&arguments->params.maxTries, "maxTries", arg, state);
      break;
    case 'l':
      parseUIntOpt(&arguments->params.maxFlips, "maxFlips", arg, state);
      break;
    case 'r':
      parseUIntOpt(&arguments->params.maxTriesWOImprovement, "maxRetriesWOImprovement", arg, state);
      break;
    case 'b':
      parseUIntOpt(&arguments->params.bmsSize, "bmsSize", arg, state);
      if (arguments->params.bmsSize < 1) {
        argp_error(state, "bmsSize should be >= 1");
      }
      break;
    case 'h':
      parseUIntOpt(&arguments->params.hWeightInc, "hWeightInc", arg, state);
      break;
    case 's':
      parseUIntOpt(&arguments->params.sWeightInc, "sWeightInc", arg, state);
      break;
    case 'p':
      parseUIntOpt(&arguments->params.sSmoothProb, "sSmoothProb", arg, state);
      if (arguments->params.sSmoothProb > 100000000) {  // NOLINT(readability-magic-numbers)
        argp_error(state, "0 <= sSmoothProb <= 100000000");
      }
      break;
    case 'c':
      parseUIntOpt(&arguments->params.sWeightBoundCoef, "sWeightBoundCoef", arg, state);
      break;
    case 'o':
      parseUIntOpt(&arguments->params.sWeightBoundOffset, "sWeightBoundOffset", arg, state);
      break;
    case ARGP_KEY_ARG:
      if (state->arg_num >= 1) {
        argp_usage(state);
      }
      arguments->file = arg;
      break;
    case ARGP_KEY_END:
      if (!arguments->file) {
        argp_usage(state);
      }
      break;
    default:
      return ARGP_ERR_UNKNOWN;
  }

  return EXIT_SUCCESS;
}

static void parseUIntOpt(nsms_uint_t* val, const char* name, const char* arg, struct argp_state* state) {
  if (arg == NULL) {
    argp_error(state, "Missing value for %s", name);
    return;
  }
  *val = strtoull(arg, NULL, NSMS_DECIMAL_SYSTEM_BASE);
  if (errno == ERANGE) {
    argp_error(state, "Could not parse %s: %s", name, arg);
  }
}

static void setParamIfNotUserProvided(nsms_uint_t* param, nsms_uint_t value) {
  if (*param == NSMS_UINT_MAX) {
    *param = value;
  }
}

static void setParameters(arguments_t* args, const nsms_wcnf_t* formula) {
  nsms_params_t defaultParams;
  nsms_params(formula, &defaultParams);

  args->params.isPartial = defaultParams.isPartial;
  args->params.isWeighted = defaultParams.isWeighted;

  setParamIfNotUserProvided(&args->params.maxTries, defaultParams.maxTries);
  setParamIfNotUserProvided(&args->params.maxTriesWOImprovement, defaultParams.maxTriesWOImprovement);
  setParamIfNotUserProvided(&args->params.maxFlips, defaultParams.maxFlips);
  setParamIfNotUserProvided(&args->params.bmsSize, defaultParams.bmsSize);
  setParamIfNotUserProvided(&args->params.hWeightInc, defaultParams.hWeightInc);
  setParamIfNotUserProvided(&args->params.sWeightInc, defaultParams.sWeightInc);
  setParamIfNotUserProvided(&args->params.sSmoothProb, defaultParams.sSmoothProb);
  setParamIfNotUserProvided(&args->params.sWeightBoundCoef, defaultParams.sWeightBoundCoef);
  setParamIfNotUserProvided(&args->params.sWeightBoundOffset, defaultParams.sWeightBoundOffset);
}

static void printResult(const nsms_result_t* result, nsms_uint_t numVariables) {
  static const char* const msgs[NSMS_STATUS_COUNT] = {"OPTIMUM FOUND", "SATISFIABLE", "UNSATISFIABLE", "UNKNOWN"};

  assert(result->status >= 0 && result->status < NSMS_STATUS_COUNT);
  const char* const msg = msgs[result->status];

  printf("s %s\n", msg);
  if (result->status != NSMS_INFEASIBLE && result->status != NSMS_UNSAT) {
    printf("o " NSMS_UINT_FORMAT "\n", result->cost);

    if (wcnfVariablesToMaxSAT22(stdout, result->assignment, numVariables)) {
      fputs("c Failed to write result.\n", stderr);
    }
  }
}

static int run(nsms_wcnf_t* formula, const arguments_t* args) {
  static const int ret[NSMS_STATUS_COUNT] = {30, 10, 20, 0};

  nsms_init();

  nsms_memoryReq_t detailMemReq;
  const nsms_uint_t memReq = nsms_calcMemoryRequirements(formula, &detailMemReq);
  void* memory = malloc(memReq);

  result.assignment = malloc(formula->numVariables * sizeof(bool));
  numVariables = formula->numVariables;

  if (memory && result.assignment) {
    nsms_solve(formula, &args->params, memory, &detailMemReq, &result, NULL, &stop);
    printResult(&result, formula->numVariables);
  } else {
    fputs("c Out of memory\n", stderr);
  }

  if (memory) {
    free(memory);
    memory = NULL;
  }
  if (result.assignment) {
    free(result.assignment);
    result.assignment = NULL;
  }

  assert(result.status >= 0 && result.status < NSMS_STATUS_COUNT);
  return ret[result.status];
}
