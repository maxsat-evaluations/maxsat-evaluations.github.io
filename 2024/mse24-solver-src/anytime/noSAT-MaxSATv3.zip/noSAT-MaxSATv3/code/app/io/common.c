/**
 * @file common.c
 * @author Ole Lübke
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "common.h"

#include <ctype.h>
#include <noSAT-MaxSAT/common.h>
#include <stdbool.h>

#include "../common.h"

#define DECIMAL_SYSTEM_LARGEST_DIGIT (NSMS_DECIMAL_SYSTEM_BASE - 1)

bool addDigit(nsms_uint_t* num, char digit) {
  bool error = false;

  if (isdigit(digit)) {
    *num *= NSMS_DECIMAL_SYSTEM_BASE;
    *num += digit - '0';
  } else {
    error = true;
  }

  return error;
}

bool isNonNewlineSpace(char character) {
  return isspace(character) && character != '\n';
}

nsms_uint_t numDigits(nsms_uint_t num) {
  int digitCount = 1;
  while (num > DECIMAL_SYSTEM_LARGEST_DIGIT) {
    num /= NSMS_DECIMAL_SYSTEM_BASE;
    ++digitCount;
  }
  return digitCount;
}
