/**
 * @file MaxSAT22.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "MaxSAT22.h"

#include <ctype.h>
#include <limits.h>
#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/wcnf.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../common.h"
#include "formulas/wcnf.h"

typedef enum { PARSE_RESULT_OK = 0, PARSE_RESULT_ERROR, PARSE_RESULT_OOM } parseResult_t;

/**
 * @brief Advances pointer until next non-whitespace character
 *
 * @param str
 */
void skipWhitespace(char** str);

/**
 * @brief Counts the number of clauses in the stream
 *
 * @param stream
 * @return nsms_uint_t
 */
nsms_uint_t findNumClauses(FILE* stream);

/**
 * @brief Reads the next unsigned integer from string and advances str to behind the number
 *
 * @param str
 * @param num
 * @return true In case of error
 * @return false Otherwise
 */
bool readUInt(char** str, nsms_uint_t* num);

/**
 * @brief Count the number of literals in a clause line
 *
 * @param str Needs to point AFTER the weight
 * @return nsms_uint_t
 */
nsms_uint_t findNumLiterals(char* str);

/**
 * @brief Allocates more space so formula can hold newNumVariables variables
 *
 * @param newNumVariables
 * @param formula
 * @return true In case of OOM
 * @return false Otherwise
 */
bool allocateMoreVariables(nsms_uint_t newNumVariables, nsms_wcnf_t* formula);

/**
 * @brief Parses a clause line
 *
 * @param line
 * @param formula
 * @return true
 * @return false
 */
parseResult_t parseClause(char* line, nsms_wcnf_t* formula);

/**
 * @brief Adds pointers to their respective literals to all variables of the formula
 *
 * @param formula
 * @return true In case of OOM
 * @return false Otherwise
 */
bool addLitPtrsToVars(nsms_wcnf_t* formula);

nsms_wcnf_t* wcnfFromMaxSAT22(FILE* stream, nsms_uint_t* errLine) {
  nsms_wcnf_t* formula = calloc(1, sizeof(nsms_wcnf_t));

  nsms_uint_t lineNo = 0;
  bool error = false;

  if (!formula) {
    return NULL;
  }

  formula->numClauses = findNumClauses(stream);
  if (formula->numClauses == 0) {
    return formula;
  }

  formula->clauses = calloc(formula->numClauses, sizeof(nsms_wcnf_clause_t));
  if (formula->clauses) {
    formula->numClauses = 0;  // for later indexing
    formula->numHardClauses = 0;

    char* line = NULL;
    size_t numChars;
    while (getline(&line, &numChars, stream) != -1 && !error) {
      lineNo += 1;

      const parseResult_t parseResult = parseClause(line, formula);
      if (parseResult != PARSE_RESULT_OK) {
        error = true;
        if (parseResult == PARSE_RESULT_OOM) {
          lineNo = 0;
        }
        break;
      }
    }

    free(line);
  } else {
    error = true;
  }

  if (!error && addLitPtrsToVars(formula)) {
    lineNo = 0;
    error = true;
  }

  if (error) {
    *errLine = lineNo;
    deleteWCNF(formula);
    formula = NULL;
  }

  return formula;
}

bool wcnfToMaxSAT22(FILE* stream, const nsms_wcnf_t* formula) {
  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* const clause = (formula->clauses + clauseIdx);
    if (nsms_isWCNFClauseHard(clause)) {
      if (fputs("h ", stream) == EOF) {
        return true;
      }
    } else {
      if (fprintf(stream, NSMS_UINT_FORMAT " ", clause->weight) < 0) {
        return true;
      }
    }

    for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
      const nsms_wcnf_literal_t* const literal = clause->literals + litIdx;
      if (nsms_wcnf_sign(literal)) {
        if (fputc('-', stream) == EOF) {
          return true;
        }
      }
      if (fprintf(stream, NSMS_UINT_FORMAT " ", nsms_wcnf_var(literal) + 1) < 0) {
        return true;
      }
    }

    if (fputs("0\n", stream) == EOF) {
      return true;
    }
  }

  return false;
}

bool wcnfVariablesToMaxSAT22(FILE* stream, const bool* variables, nsms_uint_t numVariables) {
  if (fputs("v ", stream) == EOF) {
    return true;
  }

  for (nsms_uint_t varIdx = 0; varIdx < numVariables; ++varIdx) {
    const char value = variables[varIdx] ? '1' : '0';
    if (fputc(value, stream) == EOF) {
      return true;
    }
  }

  if (fputc('\n', stream) == EOF) {
    return true;
  }

  return false;
}

void skipWhitespace(char** str) {
  while (isspace(**str) && **str != 0) {
    ++*str;
  }
}

nsms_uint_t findNumClauses(FILE* stream) {
  char* line = NULL;
  size_t numChars = 0;
  nsms_uint_t numClauses = 0;

  while (getline(&line, &numChars, stream) != -1) {
    if (line[0] != 'c' && strlen(line) > 0) {
      numClauses += 1;
    }
  }

  free(line);
  rewind(stream);

  return numClauses;
}

bool readUInt(char** str, nsms_uint_t* num) {
  if (*str[0] == 'h') {
    *num = NSMS_HARD_CLAUSE_COST;
    *str += 1;
  } else {
    *num = strtoull(*str, str, NSMS_DECIMAL_SYSTEM_BASE);
    if (*num == ULLONG_MAX) {
      return true;
    }
  }
  return false;
}

nsms_uint_t findNumLiterals(char* str) {
  // count literals by counting spaces in line
  nsms_uint_t numLits = 0;
  for (; *str != '\n'; ++str) {
    if (isspace(*str)) {
      numLits += 1;
      skipWhitespace(&str);
    }
  }
  return numLits;
}

bool allocateMoreVariables(nsms_uint_t newNumVariables, nsms_wcnf_t* formula) {
  nsms_wcnf_variable_t* const new_vars = realloc(formula->variables, newNumVariables * sizeof(nsms_wcnf_variable_t));
  if (!new_vars) {
    return PARSE_RESULT_OOM;
  }

  formula->variables = new_vars;

  // init freshly allocated variables
  for (nsms_uint_t varIdx = formula->numVariables; varIdx < newNumVariables; ++varIdx) {
    formula->variables[varIdx].literals = NULL;
    formula->variables[varIdx].numLiterals = 0;
  }

  formula->numVariables = newNumVariables;

  return PARSE_RESULT_OK;
}

parseResult_t parseClause(char* line, nsms_wcnf_t* formula) {
  if (line[0] == 'c' || strlen(line) == 0) {  // comment line
    return PARSE_RESULT_OK;
  }

  nsms_wcnf_clause_t* clause = formula->clauses + formula->numClauses;

  if (readUInt(&line, &clause->weight)) {
    return PARSE_RESULT_ERROR;
  }

  // ignore 0-weight soft clauses
  if (clause->weight == 0) {
    return PARSE_RESULT_OK;
  }

  formula->numClauses += 1;

  if (nsms_isWCNFClauseHard(clause)) {
    formula->numHardClauses += 1;
  }

  skipWhitespace(&line);

  clause->numLiterals = findNumLiterals(line);
  if (clause->numLiterals == 0) {
    return PARSE_RESULT_OK;
  }

  clause->literals = calloc(clause->numLiterals, sizeof(nsms_wcnf_literal_t));
  if (!clause->literals) {
    return PARSE_RESULT_OOM;
  }
  clause->numLiterals = 0;  // for later indexing

  // read variables
  while (*line != '0') {
    // read negation flag
    const bool negated = *line == '-';
    if (negated) {
      line += 1;
    }

    // read var num
    const nsms_uint_t variable;
    if (readUInt(&line, (nsms_uint_t*)&variable)) {
      return PARSE_RESULT_ERROR;
    }

    // check if new #vars maximum
    if (variable > formula->numVariables) {
      if (allocateMoreVariables(variable, formula)) {
        return PARSE_RESULT_OOM;
      }
    }

    // taken care of by allocateMoreVariables
    // NOLINTNEXTLINE(clang-analyzer-core.NullDereference, clang-analyzer-core.uninitialized.Assign)
    formula->variables[variable - 1].numLiterals += 1;

    // construct literal
    nsms_wcnf_literal_t* literal = clause->literals + clause->numLiterals++;
    literal->clause = clause;
    literal->lit = nsms_wcnf_mkLit(variable - 1, negated);

    skipWhitespace(&line);
  }

  return PARSE_RESULT_OK;
}

bool addLitPtrsToVars(nsms_wcnf_t* formula) {
  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* clause = formula->clauses + clauseIdx;

    for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
      nsms_wcnf_literal_t* literal = clause->literals + litIdx;

      nsms_wcnf_variable_t* variable = formula->variables + nsms_wcnf_var(literal);

      if (!variable->literals) {
        variable->literals = malloc(variable->numLiterals * sizeof(nsms_wcnf_literal_t*));
        variable->numLiterals = 0;  // for later indexing
        if (!variable->literals) {
          return true;
        }
      }

      variable->literals[variable->numLiterals++] = literal;
    }
  }

  return false;
}
