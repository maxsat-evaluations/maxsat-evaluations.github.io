/**
 * @file wcnf.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief Functions for creating and deleting WCNF cormulas
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef FORMULAS_WCNF_H
#define FORMULAS_WCNF_H

#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/wcnf.h>
#include <stdbool.h>

/**
 * @brief Allocates memory for a WCNF formula.
 *
 * @param numVariables The total number of variables of the formula.
 * @param numClauses The total number of clauses of the formula.
 * @return nsms_formula_t* A pointer to a new formula, or NULL in case of error.
 */
nsms_wcnf_t* newWCNF(nsms_uint_t numVariables, nsms_uint_t numClauses);

/**
 * @brief Deletes the memory for a WCNF formula and its variables, clauses, and literals.
 *
 * @param formula The formula to delete.
 */
void deleteWCNF(nsms_wcnf_t* formula);

/**
 * @brief Allocates memory for literals of a clause.
 *
 * @param clause The clause to add the literals to.
 * @param numLiterals The number of literals.
 * @return true In case of error.
 * @return false When no error occurred.
 */
bool newWCNFLiterals(nsms_wcnf_clause_t* clause, nsms_uint_t numLiterals);

#endif
