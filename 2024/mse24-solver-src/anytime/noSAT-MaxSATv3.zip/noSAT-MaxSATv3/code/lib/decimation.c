/**
 * @file decimation.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "noSAT-MaxSAT/common.h"
#include "noSAT-MaxSAT/preprocessing.h"
#include "noSAT-MaxSAT/wcnf.h"
#include "private/align.h"
#include "private/rng.h"

typedef struct {
  nsms_uint_t numUnassignedVars;
  nsms_wcnf_variable_t** unassignedVars;
  nsms_uint_t* unassignedVarsIdx;

  nsms_uint_t numHardUnitClauses;
  const nsms_wcnf_literal_t** hardUnitClauses;
  nsms_uint_t* hardUnitClausesIdx;

  nsms_uint_t numSoftUnitClauses;
  const nsms_wcnf_literal_t** softUnitClauses;
  nsms_uint_t* softUnitClausesIdx;

  nsms_uint_t* prevDeciStep;
  bool* clauseRemoved;
  nsms_uint_t* numLiterals;
} memory_t;

/**
 * @brief Calculates detailed memory requirements
 *
 * @param formula
 * @param out
 */
static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_decimation_memoryReq_t* out);

/**
 * @brief Calculates where pointers in out should point to
 *
 * @param mem
 * @param memReq
 * @param out
 */
static void initMemory(void* mem, const nsms_decimation_memoryReq_t* memReq, memory_t* out);

/**
 * @brief
 *
 * @param formula
 * @param mem
 * @param reusePrevious
 */
static void initAlgorithm(const nsms_wcnf_t* formula, memory_t* mem, bool reusePrevious);

/**
 * @brief
 *
 * @param mem
 * @return nsms_wcnf_variable_t*
 */
static nsms_wcnf_variable_t* pickVariable(const memory_t* mem, const nsms_wcnf_t* formula, nsms_uint_t bmsSize);

/**
 * @brief
 *
 * @param mem
 * @param bmsSize
 * @param hard
 * @return const nsms_wcnf_literal_t*
 */
static const nsms_wcnf_literal_t* pickUnitClause(const memory_t* mem, nsms_uint_t bmsSize, bool hard);

/**
 * @brief
 *
 * @param formula
 * @param mem
 * @param variable
 */
static void simplify(const nsms_wcnf_t* formula, const nsms_wcnf_variable_t* variable, memory_t* mem);

/**
 * @brief Returns the first satisfied literal in the given clause
 *
 * @param clause
 * @param mem
 * @return const nsms_wcnf_literal_t*
 */
static const nsms_wcnf_literal_t* findUnitLiteral(const nsms_wcnf_clause_t* clause, const memory_t* mem);

/**
 * @brief
 *
 * @param varIdx
 * @param formula
 * @param mem
 */
static void remUnassignedVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem);

/**
 * @brief
 *
 * @param literal
 * @param formula
 * @param mem
 */
static void addUnitClause(const nsms_wcnf_literal_t* literal, const nsms_wcnf_t* formula, memory_t* mem);

/**
 * @brief
 * @param literal
 * @param formula
 * @param mem
 */
static void remUnitClause(const nsms_wcnf_literal_t* literal, const nsms_wcnf_t* formula, memory_t* mem);

nsms_uint_t nsms_decimation_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_decimation_memoryReq_t* memReq) {
  calcMemoryReq(formula, memReq);
  return memReq->unassignedVarsMemReq + memReq->unassignedVarsIdxMemReq + memReq->hardUnitClausesMemReq +
         memReq->hardUnitClausesIdxMemReq + memReq->softUnitClausesMemReq + memReq->softUnitClausesIdxMemReq +
         memReq->prevDeciStepMemReq + memReq->clauseRemovedMemReq + memReq->numLiteralsMemReq;
}

void nsms_decimation(const nsms_wcnf_t* formula, void* memory, const nsms_decimation_memoryReq_t* memReq,
                     nsms_uint_t bmsSize, bool reusePrevious, const bool* stop) {
  memory_t mem;
  initMemory(memory, memReq, &mem);

  initAlgorithm(formula, &mem, reusePrevious);

  for (nsms_uint_t iteration = 0; iteration < formula->numVariables && !*stop; ++iteration) {
    nsms_wcnf_variable_t* pickedVar = NULL;

    const bool hardUnitClausesExist = mem.numHardUnitClauses > 0;
    const bool softUnitClausesExist = mem.numSoftUnitClauses > 0;
    if (hardUnitClausesExist || softUnitClausesExist) {
      const nsms_wcnf_literal_t* const pickedLit = pickUnitClause(&mem, bmsSize, hardUnitClausesExist);
      pickedVar = formula->variables + nsms_wcnf_var(pickedLit);
      pickedVar->value = !nsms_wcnf_sign(pickedLit);
    } else {
      pickedVar = pickVariable(&mem, formula, bmsSize);
    }

    const nsms_uint_t pickedVarIdx = pickedVar - formula->variables;
    remUnassignedVar(pickedVarIdx, formula, &mem);
    mem.prevDeciStep[pickedVarIdx] = iteration;
    simplify(formula, pickedVar, &mem);
  }
}

static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_decimation_memoryReq_t* out) {
  out->unassignedVarsMemReq = align(formula->numVariables * sizeof(nsms_wcnf_variable_t*));
  out->unassignedVarsIdxMemReq = align(formula->numVariables * sizeof(nsms_uint_t));

  out->hardUnitClausesMemReq = align(formula->numClauses * sizeof(nsms_wcnf_literal_t*));
  out->hardUnitClausesIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->softUnitClausesMemReq = align(formula->numClauses * sizeof(nsms_wcnf_literal_t*));
  out->softUnitClausesIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->prevDeciStepMemReq = align(formula->numVariables * sizeof(nsms_uint_t));
  out->clauseRemovedMemReq = align(formula->numClauses * sizeof(bool));
  out->numLiteralsMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
}

static void initMemory(void* mem, const nsms_decimation_memoryReq_t* memReq, memory_t* out) {
  out->numUnassignedVars = 0;
  out->unassignedVars = mem;
  out->unassignedVarsIdx = (nsms_uint_t*)((uint8_t*)out->unassignedVars + memReq->unassignedVarsMemReq);

  out->numHardUnitClauses = 0;
  out->hardUnitClauses =
      (const nsms_wcnf_literal_t**)((uint8_t*)out->unassignedVarsIdx + memReq->unassignedVarsIdxMemReq);
  out->hardUnitClausesIdx = (nsms_uint_t*)((uint8_t*)out->hardUnitClauses + memReq->hardUnitClausesMemReq);

  out->numSoftUnitClauses = 0;
  out->softUnitClauses =
      (const nsms_wcnf_literal_t**)((uint8_t*)out->hardUnitClausesIdx + memReq->hardUnitClausesIdxMemReq);
  out->softUnitClausesIdx = (nsms_uint_t*)((uint8_t*)out->softUnitClauses + memReq->softUnitClausesMemReq);

  out->prevDeciStep = (nsms_uint_t*)((uint8_t*)out->softUnitClausesIdx + memReq->softUnitClausesIdxMemReq);
  out->clauseRemoved = (bool*)((uint8_t*)out->prevDeciStep + memReq->prevDeciStepMemReq);
  out->numLiterals = (nsms_uint_t*)((uint8_t*)out->clauseRemoved + memReq->clauseRemovedMemReq);
}

static void initAlgorithm(const nsms_wcnf_t* formula, memory_t* mem, bool reusePrevious) {
  mem->numUnassignedVars = formula->numVariables;
  for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {
    nsms_wcnf_variable_t* const variable = formula->variables + varIdx;
    mem->unassignedVars[varIdx] = variable;
    mem->unassignedVarsIdx[varIdx] = varIdx;
    if (!reusePrevious) {
      mem->prevDeciStep[varIdx] = NSMS_UINT_MAX;
    }
  }

  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;

    mem->hardUnitClausesIdx[clauseIdx] = NSMS_UINT_MAX;
    mem->softUnitClausesIdx[clauseIdx] = NSMS_UINT_MAX;
    mem->clauseRemoved[clauseIdx] = false;
    mem->numLiterals[clauseIdx] = clause->numLiterals;

    if (clause->numLiterals == 1) {
      addUnitClause(clause->literals, formula, mem);
    }
  }
}

static nsms_wcnf_variable_t* pickVariable(const memory_t* mem, const nsms_wcnf_t* formula, nsms_uint_t bmsSize) {
  nsms_wcnf_variable_t* variable = mem->unassignedVars[randIdx(mem->numUnassignedVars)];
  nsms_uint_t variablePrevDeciStep = mem->prevDeciStep[variable - formula->variables];
  for (nsms_uint_t i = 1; i < bmsSize; ++i) {
    nsms_wcnf_variable_t* candidateVariable = mem->unassignedVars[randIdx(mem->numUnassignedVars)];
    nsms_uint_t candidatePrevDeciStep = mem->prevDeciStep[candidateVariable - formula->variables];
    if (candidatePrevDeciStep > variablePrevDeciStep) {
      variablePrevDeciStep = candidatePrevDeciStep;
      variable = candidateVariable;
    }
  }

  return variable;
}

static const nsms_wcnf_literal_t* pickUnitClause(const memory_t* mem, nsms_uint_t bmsSize, bool hard) {
  nsms_uint_t numUnitClauses;
  const nsms_wcnf_literal_t** unitClauses;

  if (hard) {
    numUnitClauses = mem->numHardUnitClauses;
    unitClauses = mem->hardUnitClauses;
  } else {
    numUnitClauses = mem->numSoftUnitClauses;
    unitClauses = mem->softUnitClauses;
  }

  const nsms_wcnf_literal_t* literal = unitClauses[randIdx(numUnitClauses)];
  nsms_uint_t litVarPrevDeciStep = mem->prevDeciStep[nsms_wcnf_var(literal)];
  for (nsms_uint_t i = 1; i < bmsSize; ++i) {
    const nsms_wcnf_literal_t* candidateLiteral = unitClauses[randIdx(numUnitClauses)];
    const nsms_uint_t candiatePrevDeciStep = mem->prevDeciStep[nsms_wcnf_var(candidateLiteral)];
    if (candiatePrevDeciStep > litVarPrevDeciStep) {
      litVarPrevDeciStep = candiatePrevDeciStep;
      literal = candidateLiteral;
    }
  }

  return literal;
}

static void simplify(const nsms_wcnf_t* formula, const nsms_wcnf_variable_t* variable, memory_t* mem) {
  for (nsms_uint_t litIdx = 0; litIdx < variable->numLiterals; ++litIdx) {
    const nsms_wcnf_literal_t* const literal = variable->literals[litIdx];
    const nsms_wcnf_clause_t* const clause = literal->clause;
    const nsms_uint_t clauseIdx = clause - formula->clauses;

    if (clauseIdx >= formula->numClauses) {
      continue;  // the clause is out of range, may happen when solving hard clauses only
    }

    if (!mem->clauseRemoved[clauseIdx]) {
      if (nsms_isWCNFLiteralSatisfied(literal, formula)) {
        mem->clauseRemoved[clauseIdx] = true;

        if (mem->numLiterals[clauseIdx] == 1) {
          remUnitClause(literal, formula, mem);
        }
      } else {
        mem->numLiterals[clauseIdx] -= 1;

        if (mem->numLiterals[clauseIdx] == 1) {
          const nsms_wcnf_literal_t* unitLiteral = findUnitLiteral(clause, mem);
          // NULL check b/c finding the lit. with unass. var. may fail when var. occurs in clause multiple times
          if (unitLiteral) {
            addUnitClause(unitLiteral, formula, mem);
          } else {
            mem->clauseRemoved[clauseIdx] = true;
          }
        } else if (mem->numLiterals[clauseIdx] == 0) {
          mem->clauseRemoved[clauseIdx] = true;
          remUnitClause(literal, formula, mem);
        }
      }
    }
  }
}

static const nsms_wcnf_literal_t* findUnitLiteral(const nsms_wcnf_clause_t* clause, const memory_t* mem) {
  for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
    if (mem->unassignedVarsIdx[nsms_wcnf_var(clause->literals + litIdx)] < NSMS_UINT_MAX) {
      return clause->literals + litIdx;
    }
  }
  return NULL;
}

static void remUnassignedVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem) {
  const nsms_uint_t replaceIdx = mem->unassignedVarsIdx[varIdx];

  mem->unassignedVarsIdx[varIdx] = NSMS_UINT_MAX;
  mem->numUnassignedVars -= 1;

  if (mem->numUnassignedVars > 0 && replaceIdx < mem->numUnassignedVars) {
    nsms_wcnf_variable_t* const moveVar = mem->unassignedVars[mem->numUnassignedVars];
    mem->unassignedVars[replaceIdx] = moveVar;
    mem->unassignedVarsIdx[moveVar - formula->variables] = replaceIdx;
  }
}

static void addUnitClause(const nsms_wcnf_literal_t* literal, const nsms_wcnf_t* formula, memory_t* mem) {
  nsms_uint_t* numUnitClauses;
  const nsms_wcnf_literal_t** unitClauses;
  nsms_uint_t* unitClausesIdx;

  if (nsms_isWCNFClauseHard(literal->clause)) {
    numUnitClauses = &mem->numHardUnitClauses;
    unitClauses = mem->hardUnitClauses;
    unitClausesIdx = mem->hardUnitClausesIdx;
  } else {
    numUnitClauses = &mem->numSoftUnitClauses;
    unitClauses = mem->softUnitClauses;
    unitClausesIdx = mem->softUnitClausesIdx;
  }

  unitClauses[*numUnitClauses] = literal;
  unitClausesIdx[literal->clause - formula->clauses] = *numUnitClauses;
  *numUnitClauses += 1;
}

static void remUnitClause(const nsms_wcnf_literal_t* literal, const nsms_wcnf_t* formula, memory_t* mem) {
  const nsms_uint_t clauseIdx = literal->clause - formula->clauses;

  nsms_uint_t* numUnitClauses;
  const nsms_wcnf_literal_t** unitClauses;
  nsms_uint_t* unitClausesIdx;

  if (nsms_isWCNFClauseHard(literal->clause)) {
    numUnitClauses = &mem->numHardUnitClauses;
    unitClauses = mem->hardUnitClauses;
    unitClausesIdx = mem->hardUnitClausesIdx;
  } else {
    numUnitClauses = &mem->numSoftUnitClauses;
    unitClauses = mem->softUnitClauses;
    unitClausesIdx = mem->softUnitClausesIdx;
  }

  const nsms_uint_t replaceIdx = unitClausesIdx[clauseIdx];

  unitClausesIdx[clauseIdx] = NSMS_UINT_MAX;
  *numUnitClauses -= 1;

  if (*numUnitClauses > 0 && replaceIdx < *numUnitClauses) {
    const nsms_wcnf_literal_t* const moveLit = unitClauses[*numUnitClauses];
    unitClauses[replaceIdx] = moveLit;
    unitClausesIdx[moveLit->clause - formula->clauses] = replaceIdx;
  }
}
