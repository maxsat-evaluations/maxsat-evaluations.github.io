/**
 * @file noSAT-MaxSAT.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "noSAT-MaxSAT/noSAT-MaxSAT.h"

#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "noSAT-MaxSAT/common.h"
#include "noSAT-MaxSAT/preprocessing.h"
#include "noSAT-MaxSAT/wcnf.h"
#include "private/align.h"
#include "private/common.h"
#include "private/fixedprec.h"
#include "private/logging.h"
#include "private/nonpartial.h"
#include "private/partial.h"
#include "private/rng.h"
#include "private/types.h"

/**
 * @brief Calculates detailed memory requirements
 *
 * @param formula
 * @param out
 */
static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_memoryReq_t* out);

/**
 * @brief Calculates where pointers in out should point to
 *
 * @param mem
 * @param memReq
 * @param cfg
 * @param formula
 * @param out
 */
static void initMemory(void* mem, const nsms_memoryReq_t* memReq, const nsms_wcnf_t* formula, memory_t* out);

/**
 * @brief Copies weights from formula to weights
 *
 * @param formula
 * @param cfg
 * @param mem
 * @param avgSoftClauseWeight
 */
static void initWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem,
                        unsigned_fixedprec_t avgSoftClauseWeight);

/**
 * @brief Updates the algorithm's output
 *
 * @param result
 * @param variables
 * @param numVariables
 * @param infeasible
 * @param cost
 *
 * @return Whether the current assignment is better than the previous best assignment
 */
static bool updateResult(nsms_result_t* result, const nsms_wcnf_variable_t* variables, nsms_uint_t numVariables,
                         bool infeasible, nsms_uint_t cost);

typedef bool (*clausePredicate_t)(const nsms_wcnf_clause_t*);

/**
 * @brief In-place moves the clauses fulfilling the predicate to the front of the clauses array
 *
 * @param formula
 * @param clausePredicate
 * @return The number of clauses fulfilling the predicate
 */
static nsms_uint_t moveClausesFirst(const nsms_wcnf_t* formula, clausePredicate_t clausePredicate);

/**
 * @brief Preprocesses the formula for solving
 *
 * Checks for empty hard clauses
 * Removes duplicate literals from clauses (those can cause crashes)
 * Removes tautologies
 *
 * @param formula
 * @return true if the formula  has empty hard clauses, false otherwise
 */
static bool prepare(nsms_wcnf_t* formula);

/**
 * @brief Analyzes hard clauses to determine the total weight of empty soft clauses, the average soft clause weight, and
 * the fixed precision shift
 *
 * @param formula
 * @param cfg
 * @param mem
 * @param avgSoftClauseWeight
 * @param totalWeightOfEmptySoftClauses
 * @param numEmptySoftClauses
 */
static void analyzeSoftClauses(nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem,
                               unsigned_fixedprec_t* avgSoftClauseWeight, nsms_uint_t* totalWeightOfEmptySoftClauses,
                               nsms_uint_t* numEmptySoftClauses);

/**
 * @brief Calculates the cost of the current assignment
 * @note The current assignment must be feasible
 *
 * @param formula
 */
static nsms_uint_t calcCost(const nsms_wcnf_t* formula);

static const fixedprec_shift_t FIXEDPREC_SAFETY_BITS = 32;

void nsms_init(void) {
  rngInit();
}

nsms_uint_t nsms_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_memoryReq_t* memReq) {
  calcMemoryReq(formula, memReq);
  return memReq->weightsMemReq + memReq->numSatLiteralsMemReq + memReq->scoresMemReq + memReq->satVarsMemReq +
         memReq->decreasingVarMemReq + memReq->decreasingVarsIdxMemReq + memReq->falsifiedHardClausesMemReq +
         memReq->falsifiedHardClausesIdxMemReq + memReq->falsifiedSoftClausesMemReq +
         memReq->falsifiedSoftClausesIdxMemReq + memReq->highWeightSoftClausesMemReq +
         memReq->hightWeightSoftClausesIdxMemReq + memReq->tunedWeightsMemReq + memReq->varFlipCountMemReq +
         memReq->decimationMemReq;
}

void nsms_solve(nsms_wcnf_t* formula, const nsms_params_t* cfg, void* memory, const nsms_memoryReq_t* memReq,
                nsms_result_t* result, const bool* initModel, const bool* stop) {
  INIT_DURATION_MEAS();

  START_DURATION_MEAS();
  if (prepare(formula)) {
    result->status = NSMS_UNSAT;
    return;
  }
  LOG_VERBOSE_WITH_DURATION("c prepared formula");

  if (cfg->isPartial) {
    const nsms_uint_t numHardClauses = moveClausesFirst(formula, nsms_isWCNFClauseHard);
    assert(numHardClauses == formula->numHardClauses);
    ((void)numHardClauses);  // suppress -Wunused-variable
  }

  memory_t mem;
  initMemory(memory, memReq, formula, &mem);

  const variable_initializer_t initVars = cfg->isPartial ? p_initVars : np_initVars;

  unsigned_fixedprec_t avgSoftClauseWeight = UFIXEDPREC(0);
  nsms_uint_t totalWeightOfEmptySoftClauses = 0;
  nsms_uint_t numEmptySoftClauses = 0;
  analyzeSoftClauses(formula, cfg, &mem, &avgSoftClauseWeight, &totalWeightOfEmptySoftClauses, &numEmptySoftClauses);
  LOG_VERBOSE("c found " NSMS_UINT_FORMAT " empty soft clauses with total weight " NSMS_UINT_FORMAT "\n",
              numEmptySoftClauses, totalWeightOfEmptySoftClauses);

  result->status = NSMS_INFEASIBLE;
  result->cost = NSMS_UINT_MAX;

  if (initModel) {
    useAssignment(formula->numVariables, initModel, formula->variables);
    updateResult(result, formula->variables, formula->numVariables, !isFeasible(formula), calcCost(formula));
  } else {
    // make sure we don't branch on uninitialized variable values by initializing all vars to false
    for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {
      formula->variables[varIdx].value = false;
    }
  }

  nsms_uint_t cost;
  bool reuseDecimation = false;
  bool skipNextRestart = false;
  nsms_uint_t triesWOImprovement = 0;

  mem.numFalsifiedHardClauses = NSMS_UINT_MAX;  // so done(...) check below is false on first check
  for (nsms_uint_t try = 0; try < cfg->maxTries && !done(&mem, result) && !*stop; ++try) {
    LOG_VERBOSE("c try " NSMS_UINT_FORMAT "\n", try);

    if (!skipNextRestart) {
      const bool forceRandomAssignment = triesWOImprovement >= cfg->maxTriesWOImprovement;
      if (forceRandomAssignment) {
        LOG_VERBOSE("c restarting with random assignment\n");
      }

      START_DURATION_MEAS();
      initVars(formula, cfg, &mem, memReq, result, initModel, &reuseDecimation, forceRandomAssignment, stop);
      LOG_TRACE_WITH_DURATION("c initialized variables");

      START_DURATION_MEAS();
      nsms_decimation(formula, mem.decimationMem, &memReq->detailedDecimationMemReq, cfg->bmsSize, reuseDecimation,
                      stop);
      reuseDecimation = true;
      LOG_TRACE_WITH_DURATION("c performed decimation");

      START_DURATION_MEAS();
      initWeights(formula, cfg, &mem, avgSoftClauseWeight);
      LOG_TRACE_WITH_DURATION("c initialized weights");

      START_DURATION_MEAS();
      initAlgo(formula, &mem, &cost);
      cost += totalWeightOfEmptySoftClauses;
      LOG_TRACE_WITH_DURATION("c initialized algorithm");
    } else {
      LOG_VERBOSE("c skipping restart\n");
    }

    skipNextRestart = false;
    bool solutionImproved = false;

    for (nsms_uint_t flip = 0; flip < cfg->maxFlips && !done(&mem, result) && !*stop; ++flip) {
      const bool infeasible = mem.numFalsifiedHardClauses > 0;
      solutionImproved = updateResult(result, formula->variables, formula->numVariables, infeasible, cost);
      skipNextRestart = skipNextRestart || solutionImproved;

      // LOG_TRACE("c current cost is " NSMS_UINT_FORMAT " (%s)\n", cost, infeasible ? "infeasible" : "feasible");

      nsms_wcnf_variable_t* variableToFlip = selectVariable(formula, cfg, &mem);
      flipVariable(variableToFlip, formula, &mem, &cost);
    }

    solutionImproved =
        updateResult(result, formula->variables, formula->numVariables, mem.numFalsifiedHardClauses > 0, cost);
    skipNextRestart = skipNextRestart || solutionImproved;

    if (skipNextRestart) {
      triesWOImprovement = 0;
    } else {
      triesWOImprovement += 1;
    }
  }

  formula->numClauses += numEmptySoftClauses;
}

void nsms_params(const nsms_wcnf_t* formula, nsms_params_t* params) {
  /* NuWLS parameter values from
   * Yi Chu, Shaowei Cai, Chuan Luo, NuWLS-c-2023: Solver Description. MaxSAT Evaluation 2023 (source code)
   */

  params->maxTries = NSMS_UINT_MAX;
  params->maxFlips = 10000000;  // NOLINT(readability-magic-numbers)
  params->isPartial = formula->numHardClauses > 0;
  params->isWeighted = false;

  const nsms_uint_t numSoftClauses = formula->numClauses - formula->numHardClauses;
  nsms_uint_t softClauseCnt = 0;
  if (numSoftClauses > 0) {
    for (nsms_uint_t i = 0; i < formula->numClauses; ++i) {
      const nsms_wcnf_clause_t* const clause = formula->clauses + i;
      if (!nsms_isWCNFClauseHard(clause)) {
        if (clause->weight != 1) {
          params->isWeighted = true;
          break;
        }

        if (++softClauseCnt == numSoftClauses) {
          break;
        }
      }
    }
  }

  params->maxTriesWOImprovement = params->isPartial ? 3 : 2;  // NOLINT(readability-magic-numbers)

  if (!params->isWeighted) {
    params->sWeightInc = 1;  // NOLINT(readability-magic-numbers)
    params->hWeightInc = 1;  // NOLINT(readability-magic-numbers)

    if (formula->numHardClauses == 0) {
      params->bmsSize = 94;              // NOLINT(readability-magic-numbers)
      params->sSmoothProb = 200000;      // NOLINT(readability-magic-numbers)
      params->sWeightBoundCoef = 397;    // NOLINT(readability-magic-numbers)
      params->sWeightBoundOffset = 550;  // NOLINT(readability-magic-numbers)
    } else {
      params->bmsSize = 50;            // NOLINT(readability-magic-numbers)
      params->sSmoothProb = 0;         // NOLINT(readability-magic-numbers)
      params->sWeightBoundCoef = 0;    // NOLINT(readability-magic-numbers)
      params->sWeightBoundOffset = 0;  // NOLINT(readability-magic-numbers)
    }
  } else {
    if (formula->numHardClauses == 0) {
      params->bmsSize = 22;             // NOLINT(readability-magic-numbers)
      params->hWeightInc = 0;           // NOLINT(readability-magic-numbers)
      params->sWeightInc = 3;           // NOLINT(readability-magic-numbers)
      params->sSmoothProb = 100000;     // NOLINT(readability-magic-numbers)
      params->sWeightBoundCoef = 1000;  // NOLINT(readability-magic-numbers)
      params->sWeightBoundOffset = 10;  // NOLINT(readability-magic-numbers)
    } else {
      params->bmsSize = 50;            // NOLINT(readability-magic-numbers)
      params->hWeightInc = 5;          // NOLINT(readability-magic-numbers)
      params->sWeightInc = 0;          // NOLINT(readability-magic-numbers)
      params->sSmoothProb = 0;         // NOLINT(readability-magic-numbers)
      params->sWeightBoundCoef = 0;    // NOLINT(readability-magic-numbers)
      params->sWeightBoundOffset = 0;  // NOLINT(readability-magic-numbers)
    }
  }
}

static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_memoryReq_t* out) {
  out->weightsMemReq = align(formula->numClauses * sizeof(unsigned_fixedprec_t));
  out->numSatLiteralsMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->scoresMemReq = align(formula->numVariables * sizeof(score_t));
  out->satVarsMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->decreasingVarMemReq = align(formula->numVariables * sizeof(nsms_uint_t));
  out->decreasingVarsIdxMemReq = align(formula->numVariables * sizeof(nsms_uint_t));

  out->falsifiedHardClausesMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->falsifiedHardClausesIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->falsifiedSoftClausesMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->falsifiedSoftClausesIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->highWeightSoftClausesMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->hightWeightSoftClausesIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->tunedWeightsMemReq = align(formula->numClauses * sizeof(unsigned_fixedprec_t));

  out->varFlipCountMemReq = align(formula->numVariables * sizeof(nsms_uint_t));

  out->decimationMemReq = align(nsms_decimation_calcMemoryRequirements(formula, &out->detailedDecimationMemReq));
}

static void initMemory(void* mem, const nsms_memoryReq_t* memReq, const nsms_wcnf_t* formula, memory_t* out) {
  out->weights = mem;
  out->numSatLiterals = (nsms_uint_t*)((uint8_t*)out->weights + memReq->weightsMemReq);
  out->scores = (score_t*)((uint8_t*)out->numSatLiterals + memReq->numSatLiteralsMemReq);
  out->satVars = (nsms_uint_t*)((uint8_t*)out->scores + memReq->scoresMemReq);

  out->numDecreasingVars = 0;
  out->decreasingVars = (nsms_uint_t*)((uint8_t*)out->satVars + memReq->satVarsMemReq);
  out->decreasingVarsIdx = (nsms_uint_t*)((uint8_t*)out->decreasingVars + memReq->decreasingVarMemReq);

  out->numFalsifiedHardClauses = 0;
  out->falsifiedHardClauses = (nsms_uint_t*)((uint8_t*)out->decreasingVarsIdx + memReq->decreasingVarsIdxMemReq);
  out->falsifiedHardClausesIdx =
      (nsms_uint_t*)((uint8_t*)out->falsifiedHardClauses + memReq->falsifiedHardClausesMemReq);

  out->numFalsifiedSoftClauses = 0;
  out->falsifiedSoftClauses =
      (nsms_uint_t*)((uint8_t*)out->falsifiedHardClausesIdx + memReq->falsifiedSoftClausesIdxMemReq);
  out->falsifiedSoftClausesIdx =
      (nsms_uint_t*)((uint8_t*)out->falsifiedSoftClauses + memReq->falsifiedSoftClausesMemReq);

  out->numHighWeightSoftClauses = 0;
  out->highWeightSoftClauses =
      (nsms_uint_t*)((uint8_t*)out->falsifiedSoftClausesIdx + memReq->falsifiedSoftClausesIdxMemReq);
  out->highWeightSoftClausesIdx =
      (nsms_uint_t*)((uint8_t*)out->highWeightSoftClauses + memReq->highWeightSoftClausesMemReq);

  out->tunedWeights =
      (unsigned_fixedprec_t*)((uint8_t*)out->highWeightSoftClausesIdx + memReq->hightWeightSoftClausesIdxMemReq);

  out->varFlipCounts = (nsms_uint_t*)((uint8_t*)out->tunedWeights + memReq->tunedWeightsMemReq);
  // initialize here for global count instead of in initAlgo (try-local count)
  for (nsms_uint_t varIdx = 0; varIdx < memReq->varFlipCountMemReq / sizeof(nsms_uint_t); ++varIdx) {
    out->varFlipCounts[varIdx] = 0;
  }

  out->decimationMem = (void*)((uint8_t*)out->varFlipCounts + memReq->varFlipCountMemReq);

  out->numSoftClauses = formula->numClauses - formula->numHardClauses;
}

static void initWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem,
                        unsigned_fixedprec_t avgSoftClauseWeight) {
  if (cfg->isPartial && cfg->isWeighted) {
    pw_initWeights(formula, mem, avgSoftClauseWeight);
  } else if (cfg->isPartial) {
    puw_initWeights(formula, mem);
  } else if (cfg->isWeighted) {
    npw_initWeights(formula, cfg, mem, avgSoftClauseWeight);
  } else {
    npuw_initWeights(formula, cfg, mem);
  }
}

static bool updateResult(nsms_result_t* result, const nsms_wcnf_variable_t* variables, nsms_uint_t numVariables,
                         bool infeasible, nsms_uint_t cost) {
  if (!infeasible && cost < result->cost) {
    saveAssignment(numVariables, variables, result->assignment);  // save currently best assignment
    result->cost = cost;
    result->status = cost == 0 ? NSMS_OPTIMUM_FOUND : NSMS_UNKNOWN;
    LOG_VERBOSE("o " NSMS_UINT_FORMAT "\n", result->cost);
    return true;
  }
  return false;
}

static nsms_uint_t moveClausesFirst(const nsms_wcnf_t* formula, clausePredicate_t clausePredicate) {
  // in-place sorting clauses to beginning of array
  nsms_uint_t numClauses = 0;
  nsms_uint_t lastClauseIdx = 0;

  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;

    if (clausePredicate(clause)) {
      numClauses += 1;
      continue;
    }

    // search next clause
    nsms_wcnf_clause_t* nextClause = NULL;
    for (nsms_uint_t nextClauseSearchIdx = (clauseIdx > lastClauseIdx ? clauseIdx : lastClauseIdx) + 1;
         nextClauseSearchIdx < formula->numClauses; ++nextClauseSearchIdx) {
      nsms_wcnf_clause_t* candidate = formula->clauses + nextClauseSearchIdx;
      if (clausePredicate(candidate)) {
        lastClauseIdx = nextClauseSearchIdx;
        nextClause = candidate;
        break;
      }
    }

    if (!nextClause) {
      break;  // all clauses found
    }

    // swap places
    const nsms_wcnf_clause_t tmp = *clause;
    *clause = *nextClause;
    *nextClause = tmp;

    // update back pointers
    fixLitToClausePtrs(clause);
    fixLitToClausePtrs(nextClause);

    numClauses += 1;
  }

  return numClauses;
}

bool prepare(nsms_wcnf_t* formula) {
  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    const bool isHard = nsms_isWCNFClauseHard(clause);

    if (nsms_cleanClause(formula, clause)) {
      removeClause(clauseIdx--, formula->clauses, formula->numClauses--);
      if (isHard) {
        formula->numHardClauses -= 1;
      }
    }

    if (isHard && nsms_isWCNFClauseEmpty(clause)) {
      return true;
    }
  }

  return false;
}

static void analyzeSoftClauses(nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem,
                               unsigned_fixedprec_t* avgSoftClauseWeight, nsms_uint_t* totalWeightOfEmptySoftClauses,
                               nsms_uint_t* numEmptySoftClauses) {
  /* loop over soft clauses to
   *   calculate total weight and determine shift value for fixed precision arithmetic
   *   calculate average soft clause weight for NuWLS 2023 tuned weight calculation (cf. initWeights)
   *   find empty soft clauses
   */
  nsms_uint_t totalWeight = 0;
  *totalWeightOfEmptySoftClauses = 0;
  *numEmptySoftClauses = 0;

  for (nsms_uint_t clauseIdx = formula->numHardClauses; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    assert(!nsms_isWCNFClauseHard(clause));
    assert(totalWeight <= totalWeight + clause->weight);
    totalWeight += clause->weight;

    // if soft clause is empty, note its weight and ignore it from now on
    if (clause->numLiterals == 0) {
      *totalWeightOfEmptySoftClauses += clause->weight;

      // move clause to end of array ...
      const nsms_uint_t moveIdx = formula->numClauses - *numEmptySoftClauses - 1;
      const nsms_wcnf_clause_t moveClause = formula->clauses[moveIdx];
      formula->clauses[moveIdx] = *clause;
      formula->clauses[clauseIdx] = moveClause;

      *numEmptySoftClauses += 1;
      clauseIdx -= 1;
      formula->numClauses -= 1;  // ... and ignore it
    }
  }

  mem->fixedprecShift = cfg->isWeighted ? fixedprec_determineMaxShift(totalWeight, FIXEDPREC_SAFETY_BITS) : 0;
  LOG_INFO("c fixed precision shift is %u bits\n", mem->fixedprecShift);

  *avgSoftClauseWeight =
      mem->numSoftClauses > 0
          ? fixedprec_udiv(fixedprec_uto(totalWeight, mem->fixedprecShift),
                           fixedprec_uto(mem->numSoftClauses, mem->fixedprecShift), mem->fixedprecShift)
          : UFIXEDPREC(0);
  mem->numSoftClauses -= *numEmptySoftClauses;
#ifndef FIXEDPREC_FLOATING
  LOG_INFO("c average soft clause weight is " NSMS_UINT_FORMAT "\n",
           fixedprec_ufrom(*avgSoftClauseWeight, mem->fixedprecShift));
#else
  LOG_INFO("c average soft clause weight is %f\n", fixedprec_ufrom(avgSoftClauseWeight, mem.fixedprecShift));
#endif
}

static nsms_uint_t calcCost(const nsms_wcnf_t* formula) {
  nsms_uint_t cost = 0;

  for (nsms_uint_t clauseIdx = formula->numHardClauses; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    assert(!nsms_isWCNFClauseHard(clause));

    bool sat = false;
    for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
      const nsms_wcnf_literal_t* literal = clause->literals + litIdx;

      if (nsms_isWCNFLiteralSatisfied(literal, formula)) {
        sat = true;
        break;
      }
    }

    if (!sat) {
      cost += clause->weight;
    }
  }

  return cost;
}
