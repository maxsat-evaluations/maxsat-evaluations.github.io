/**
 * @file partial.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2024
 *
 */

#include "private/partial.h"

#include <assert.h>
#include <stdbool.h>

#include "noSAT-MaxSAT/common.h"
#include "noSAT-MaxSAT/noSAT-MaxSAT.h"
#include "noSAT-MaxSAT/preprocessing.h"
#include "noSAT-MaxSAT/wcnf.h"
#include "private/common.h"
#include "private/fixedprec.h"
#include "private/logging.h"
#include "private/types.h"

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 * @param memReq
 * @param result
 * @param initModel
 * @param forceRandom
 * @param reuseDecimation
 * @param stop
 */
static void solveHard(nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem, const nsms_memoryReq_t* memReq,
                      const nsms_result_t* result, const bool* initModel, bool forceRandom, bool* reuseDecimation,
                      const bool* stop);

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 */
static void increaseHardWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem);

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 */
static void w_increaseSoftWeights(const nsms_wcnf_t* formula, memory_t* mem);

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 */
static void uw_increaseSoftWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem);

void p_initVars(nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem, const nsms_memoryReq_t* memReq,
                nsms_result_t* result, const bool* initModel, bool* reuseDecimation, bool forceRandomAssignment,
                const bool* stop) {
  if (!isFeasible(formula)) {
    const nsms_uint_t origNumClauses = formula->numClauses;
    formula->numClauses = formula->numHardClauses;

    nsms_params_t params;
    params.maxTries = cfg->maxTries;
    params.maxFlips = cfg->maxFlips;
    nsms_params(formula, &params);

    solveHard(formula, &params, mem, memReq, result, initModel, forceRandomAssignment, reuseDecimation, stop);

    formula->numClauses = origNumClauses;
  }
}

void pw_initWeights(const nsms_wcnf_t* formula, memory_t* mem, unsigned_fixedprec_t avgSoftClauseWeight) {
  const unsigned_fixedprec_t one = fixedprec_uto(1, mem->fixedprecShift);

  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numHardClauses; ++clauseIdx) {
    assert(nsms_isWCNFClauseHard(formula->clauses + clauseIdx));
    mem->weights[clauseIdx] = one;
  }

  for (nsms_uint_t clauseIdx = formula->numHardClauses; clauseIdx < formula->numClauses; ++clauseIdx) {
    assert(!nsms_isWCNFClauseHard(formula->clauses + clauseIdx));
    mem->tunedWeights[clauseIdx] =
        fixedprec_udiv(fixedprec_uto(formula->clauses[clauseIdx].weight, mem->fixedprecShift), avgSoftClauseWeight,
                       mem->fixedprecShift);
    mem->weights[clauseIdx] = UFIXEDPREC(0);
  }
}

void puw_initWeights(const nsms_wcnf_t* formula, memory_t* mem) {
  const unsigned_fixedprec_t one = fixedprec_uto(1, mem->fixedprecShift);

  for (nsms_uint_t i = 0; i < formula->numClauses; ++i) {
    mem->weights[i] = one;
  }
}

void p_updateWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem) {
  increaseHardWeights(formula, cfg, mem);
  if (mem->numFalsifiedHardClauses == 0) {
    if (cfg->isWeighted) {
      w_increaseSoftWeights(formula, mem);
    } else {
      uw_increaseSoftWeights(formula, cfg, mem);
    }
  }
}

static void solveHard(nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem, const nsms_memoryReq_t* memReq,
                      const nsms_result_t* result, const bool* initModel, bool forceRandom, bool* reuseDecimation,
                      const bool* stop) {
  INIT_DURATION_MEAS();
  START_DURATION_MEAS();

  // basically nsms_solve
  for (nsms_uint_t try = 0; try < cfg->maxTries && !done(mem, result) && !*stop; ++try) {
    initVars(formula, result, initModel, forceRandom);

    nsms_decimation(formula, mem->decimationMem, &memReq->detailedDecimationMemReq, cfg->bmsSize, *reuseDecimation,
                    stop);
    *reuseDecimation = true;

    puw_initWeights(formula, mem);

    nsms_uint_t cost;
    initAlgo(formula, mem, &cost);

    for (nsms_uint_t flip = 0; flip < cfg->maxFlips && !done(mem, result) && !*stop; ++flip) {
      nsms_wcnf_variable_t* variableToFlip = selectVariable(formula, cfg, mem);
      flipVariable(variableToFlip, formula, mem, &cost);
    }
  }

  // NOLINTNEXTLINE (bugprone-branch-clone)
  if (done(mem, result)) {
    LOG_TRACE_WITH_DURATION("c successfully solved hard clauses");
  } else {
    LOG_TRACE_WITH_DURATION("c couldn't solve hard clauses");
  }
}

static void increaseHardWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem) {
  LOG_TRACE("c increasing " NSMS_UINT_FORMAT " hard clause weights\n", mem->numFalsifiedHardClauses);

  const unsigned_fixedprec_t increase = fixedprec_uto(cfg->hWeightInc, mem->fixedprecShift);

  for (nsms_uint_t i = 0; i < mem->numFalsifiedHardClauses; ++i) {
    // for each falsified hard clause
    const nsms_uint_t clauseIdx = mem->falsifiedHardClauses[i];
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;

    // increment the weight
    mem->weights[clauseIdx] = fixedprec_uadd(mem->weights[clauseIdx], increase);

    for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
      // for all variables of the clause
      const nsms_wcnf_literal_t* const literal = clause->literals + litIdx;
      // increase the score by the increment
      const nsms_uint_t varIdx = nsms_wcnf_var(literal);
      mem->scores[varIdx] = fixedprec_sadd(mem->scores[varIdx], fixedprec_utos(increase));
      addDecreasingVar(varIdx, mem);
    }
  }
}

static void w_increaseSoftWeights(const nsms_wcnf_t* formula, memory_t* mem) {
  LOG_TRACE("c increasing " NSMS_UINT_FORMAT " soft clause weights\n", mem->numSoftClauses);

  // for each soft clause ...
  for (nsms_uint_t clauseIdx = formula->numHardClauses; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    assert(!nsms_isWCNFClauseHard(clause));

    const unsigned_fixedprec_t increase = mem->tunedWeights[clauseIdx];
    // LOG_TRACE("c increasing weight of soft clause " NSMS_UINT_FORMAT " by " NSMS_UINT_FORMAT "\n", clauseIdx,
    //           fixedprec_ufrom(mem->tunedWeights[clauseIdx], mem->fixedprecShift));

    // ... increase the weight
    mem->weights[clauseIdx] = fixedprec_uadd(mem->weights[clauseIdx], increase);

    updateScores(clauseIdx, clause, fixedprec_utos(increase), mem);
  }
}

static void uw_increaseSoftWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem) {
  LOG_TRACE("c increasing " NSMS_UINT_FORMAT " soft clause weights\n", mem->numSoftClauses);

  const unsigned_fixedprec_t sWeightInc = fixedprec_uto(cfg->sWeightInc, mem->fixedprecShift);

  // for each soft clause ...
  for (nsms_uint_t clauseIdx = formula->numHardClauses; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    assert(!nsms_isWCNFClauseHard(clause));

    const unsigned_fixedprec_t increase = sWeightInc;

    // ... increase the weight
    mem->weights[clauseIdx] = fixedprec_uadd(mem->weights[clauseIdx], increase);

    updateScores(clauseIdx, clause, fixedprec_utos(increase), mem);
  }
}
