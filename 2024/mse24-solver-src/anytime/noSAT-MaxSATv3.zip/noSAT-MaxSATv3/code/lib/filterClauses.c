/**
 * @file filterClauses.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "noSAT-MaxSAT/common.h"
#include "noSAT-MaxSAT/preprocessing.h"
#include "noSAT-MaxSAT/wcnf.h"
#include "private/common.h"

nsms_uint_t nsms_filterClauses(nsms_wcnf_clause_t* clauses, nsms_uint_t numClauses,
                               const nsms_clause_predicate_t* predicates, nsms_uint_t numPredicates) {
  nsms_uint_t numRemovedClauses = 0;

  for (nsms_uint_t clauseIdx = 0; clauseIdx < numClauses; ++clauseIdx) {
    for (nsms_uint_t predIdx = 0; predIdx < numPredicates; ++predIdx) {
      if (predicates[predIdx](clauses + clauseIdx)) {
        removeClause(clauseIdx, clauses, numClauses);
        numClauses -= 1;
        numRemovedClauses += 1;
        break;
      }
    }
  }

  return numRemovedClauses;
}
