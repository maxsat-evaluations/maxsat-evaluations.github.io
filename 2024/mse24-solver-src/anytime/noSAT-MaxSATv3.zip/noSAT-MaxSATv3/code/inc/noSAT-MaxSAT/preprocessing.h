/**
 * @file preprocessing.h
 * @author Ole Lübke
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_PREPROCESSING_H
#define NSMS_PREPROCESSING_H

#include <stdbool.h>

#include "noSAT-MaxSAT/common.h"
#include "noSAT-MaxSAT/wcnf.h"

typedef bool (*nsms_clause_predicate_t)(const nsms_wcnf_clause_t*);

typedef struct {
  nsms_uint_t unassignedVarsMemReq, unassignedVarsIdxMemReq, hardUnitClausesMemReq, hardUnitClausesIdxMemReq,
      softUnitClausesMemReq, softUnitClausesIdxMemReq, prevDeciStepMemReq, clauseRemovedMemReq, numLiteralsMemReq;
} nsms_decimation_memoryReq_t;

/**
 * @brief Calculate memory requirements for decimation
 *
 * @param formula The formula the decimation will be run on
 * @param memReq Pointer to a structure to save detailed memory requirement information
 * @return nsms_uint_t Memory requirements in bytes
 */
nsms_uint_t nsms_decimation_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_decimation_memoryReq_t* memReq);

/**
 * @brief Run unit-clause propagation to find an advantageous initial variable assignment
 *
 * @param formula The formula to run decimation on
 * @param memory Memory block of size calculated by nsms_decimation_calcMemoryRequirements
 * @param memReq Obtained from nsms_decimation_calcMemoryRequirements
 * @param bmsSize Bucket size for random selection
 * @param reusePrevious Whether to reuse previously generated information to steer away the procedure from the variable
 * assignment that was generated during the previous run
 * @param stop Pointer to Boolean value that, when set to true, terminates the alg. asap
 */
void nsms_decimation(const nsms_wcnf_t* formula, void* memory, const nsms_decimation_memoryReq_t* memReq,
                     nsms_uint_t bmsSize, bool reusePrevious, const bool* stop);

/**
 * @brief Filters clauses according to the given predicates
 *
 * @param clauses The clauses array to filter
 * @param numClauses The length of the clauses array
 * @param predicates The predicate functions; if a predicate returns true for a clause, the clause is removed
 * @param numPredicates The length of the predicates array
 * @return nsms_uint_t The number of removed clauses
 */
nsms_uint_t nsms_filterClauses(nsms_wcnf_clause_t* clauses, nsms_uint_t numClauses,
                               const nsms_clause_predicate_t* predicates, nsms_uint_t numPredicates);

#endif
