/**
 * @file wcnf.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief Types for representing a MaxSAT instance in WCNF and associated functions
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_FORMULAS_WCNF_H
#define NSMS_FORMULAS_WCNF_H

#include <assert.h>
#include <stdbool.h>

#include "noSAT-MaxSAT/common.h"

#define NSMS_HARD_CLAUSE_COST NSMS_UINT_MAX

struct nsms_wcnf_literal_s;
struct nsms_wcnf_clause_s;

/**
 * @brief Type for variables
 *
 */
typedef struct {
  bool value;                                   ///> The truth value of the variable
  nsms_uint_t numLiterals;                      ///> The number of literals the variable occurs in
  const struct nsms_wcnf_literal_s** literals;  ///> Pointers to the literal the variable occurs in
} nsms_wcnf_variable_t;

/**
 * @brief A literal, i.e., a possibly negated variable
 *
 */
typedef struct nsms_wcnf_literal_s {
  nsms_uint_t lit;                          ///> The bottom bit is the sign, the remaining bits are the variable index
  const struct nsms_wcnf_clause_s* clause;  ///> Pointer to the clause the literal is part of
} nsms_wcnf_literal_t;

/**
 * @brief Helper function to construct the `lit` field of an nsms_wcnf_literal_t
 *
 * @param varIdx The index of the literal's variable
 * @param sign Whether the literal is negated
 */
static inline nsms_uint_t nsms_wcnf_mkLit(nsms_uint_t varIdx, bool sign) {
  return (varIdx << 1) | sign;
}

/**
 * @brief Get the variable index of a literal
 *
 * @param lit
 */
static inline nsms_uint_t nsms_wcnf_var(const nsms_wcnf_literal_t* lit) {
  return lit->lit >> 1;
}

/**
 * @brief Get the sign of a literal
 *
 * @param lit
 */
static inline bool nsms_wcnf_sign(const nsms_wcnf_literal_t* lit) {
  return lit->lit & 1;
}

/**
 * @brief A weighted CNF clause
 *
 */
typedef struct nsms_wcnf_clause_s {
  nsms_uint_t weight;             ///< The weight of the clause, 0 for hard clauses, >= 1 for soft clauses
  nsms_uint_t numLiterals;        ///< The number of literals in the clause
  nsms_wcnf_literal_t* literals;  ///< Array which hold the literals
} nsms_wcnf_clause_t;

/**
 * @brief A formula in WCNF, i.e., a conjunction of weighted clauses
 *
 */
typedef struct {
  nsms_uint_t numVariables;         ///< The total number of variables of the formula
  nsms_uint_t numClauses;           ///< The total number of clauses of the formula
  nsms_uint_t numHardClauses;       ///< The number of hard clauses in the formula
  nsms_wcnf_variable_t* variables;  ///< Array which hold the variables
  nsms_wcnf_clause_t* clauses;      ///< Array which holds the clauses
} nsms_wcnf_t;
/**
 * @brief Checks whether a literal is satisfied
 *
 * @param literal The literal to check
 * @param formula The associated formula
 * @return true When the literal is satisfied
 * @return false Otherwise
 */
static inline bool nsms_isWCNFLiteralSatisfied(const nsms_wcnf_literal_t* literal, const nsms_wcnf_t* formula) {
  return formula->variables[nsms_wcnf_var(literal)].value != nsms_wcnf_sign(literal);
}

/**
 * @brief Checks whether a clause is hard
 *
 * @param clause The clause to check
 * @return true When the clause is hard
 * @return false Otherwise
 */
static inline bool nsms_isWCNFClauseHard(const nsms_wcnf_clause_t* clause) {
  return clause->weight == NSMS_HARD_CLAUSE_COST;
}

/**
 * @brief Checks whether a clause is empty
 *
 * @param clause The clause to check
 * @return true When the clause is empty
 * @return false Otherwise
 */
static inline bool nsms_isWCNFClauseEmpty(const nsms_wcnf_clause_t* clause) {
  return clause->numLiterals == 0;
}

/**
 * @brief Removes the literal at the given index
 *
 * @param formula The formula the clause is part of
 * @param clause The clause to remove the literal from
 * @param litIdx The index of the literal in the clause
 */
static inline void nsms_removeLiteralAt(nsms_wcnf_t* formula, nsms_wcnf_clause_t* clause, nsms_uint_t litIdx) {
  assert(litIdx < clause->numLiterals);
  assert((nsms_uint_t)(clause - formula->clauses) < formula->numClauses);

  const nsms_wcnf_literal_t* const litToRemove = clause->literals + litIdx;
  const nsms_wcnf_literal_t* const litToMove = clause->literals + clause->numLiterals - 1;

  {  // remove pointer to literal from var
    const nsms_uint_t varIdx = nsms_wcnf_var(litToRemove);
    nsms_wcnf_variable_t* const var = formula->variables + varIdx;
    {
      nsms_uint_t varLitIdx;
      for (varLitIdx = 0; varLitIdx < var->numLiterals; ++varLitIdx) {
        const nsms_wcnf_literal_t* const varLit = var->literals[varLitIdx];
        if (varLit == litToRemove) {
          var->literals[varLitIdx] = var->literals[var->numLiterals - 1];
          break;
        }
      }
      assert(varLitIdx < var->numLiterals);
      var->numLiterals -= 1;
    }
  }

  if (litToRemove != litToMove) {  // update pointer to moved literal from var
    const nsms_uint_t varIdx = nsms_wcnf_var(litToMove);
    nsms_wcnf_variable_t* const var = formula->variables + varIdx;
    {
      nsms_uint_t varLitIdx;
      for (varLitIdx = 0; varLitIdx < var->numLiterals; ++varLitIdx) {
        const nsms_wcnf_literal_t* const varLit = var->literals[varLitIdx];
        if (varLit == litToMove) {
          var->literals[varLitIdx] = litToRemove;
          break;
        }
      }
      assert(varLitIdx < var->numLiterals);
    }
  }

  clause->literals[litIdx] = *litToMove;
  clause->numLiterals -= 1;
}

/**
 * @brief Removes duplicate literals from a clause and checks whether it is a tautology
 *
 * @param formula The formula the clause is part of
 * @param clause The clause to clean
 * @return true When the clause is a tautology
 * @return false Otherwise
 */
static inline bool nsms_cleanClause(nsms_wcnf_t* formula, nsms_wcnf_clause_t* clause) {
  assert((nsms_uint_t)(clause - formula->clauses) < formula->numClauses);

  for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
    const nsms_wcnf_literal_t* lit = clause->literals + litIdx;
    for (nsms_uint_t cmpIdx = litIdx + 1; cmpIdx < clause->numLiterals; ++cmpIdx) {
      const nsms_wcnf_literal_t* cmp = clause->literals + cmpIdx;
      if (nsms_wcnf_var(lit) == nsms_wcnf_var(cmp)) {
        if (nsms_wcnf_sign(lit) != nsms_wcnf_sign(cmp)) {
          return true;
        }
        nsms_removeLiteralAt(formula, clause, cmpIdx--);
      }
    }
  }
  return false;
}

/**
 * @brief Count the number of satisfied literals in a clause
 *
 * @param clause The clause to check
 * @param formula The associated formula
 * @return nsms_uint_t The number of satisfied literals in the clause
 */
static inline nsms_uint_t nsms_countSatLiterals(const nsms_wcnf_clause_t* clause, const nsms_wcnf_t* formula) {
  nsms_uint_t count = 0;
  for (nsms_uint_t l = 0; l < clause->numLiterals; ++l) {
    const nsms_wcnf_literal_t* const literal = clause->literals + l;
    if (nsms_isWCNFLiteralSatisfied(literal, formula)) {
      count += 1;
    }
  }
  return count;
}

#endif
