/**
 * @file noSAT-MaxSAT.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_H
#define NSMS_H

#include <stdbool.h>

#include "noSAT-MaxSAT/common.h"
#include "noSAT-MaxSAT/preprocessing.h"
#include "noSAT-MaxSAT/wcnf.h"

/**
 * @brief Holds the status of incomplete MaxSAT solving
 *
 */
typedef enum {
  NSMS_OPTIMUM_FOUND = 0,  //!< The hard clauses are satisfiable and the optimum cost has been found
  NSMS_UNKNOWN,            //!< The hard clauses are satisfiable but the optimum cost is unknown
  NSMS_UNSAT,              //!< The hard clauses are unsatisfiable
  NSMS_INFEASIBLE,         //!< The hard clauses may or may not be satisfiable
  NSMS_STATUS_COUNT        //!< Not an actual status, just the number of possible status
} nsms_status_t;

/**
 * @brief Holds the result of incomplete MaxSAT solving
 *
 */
typedef struct {
  nsms_status_t status;  //!< The solution status
  nsms_uint_t cost;      //!< The solution cost (sum of weights of clauses falsified by the solution)
  bool* assignment;      //!< The solution assignment, memory must be allocated by user
} nsms_result_t;

/**
 * @brief Holds parameters of the algorithm
 *
 */
typedef struct {
  nsms_uint_t maxTries; /*!< The maximum number of restarts (i.e., how often a new initial assignment is generated) */
  nsms_uint_t maxTriesWOImprovement; /*!< The maximum number of tries without improvement before restart with a new
                                        random assignment is forced */
  nsms_uint_t maxFlips; /*!< The maximum number of variable flips the algorithm performs within one iteration (total
                             no. of iterations <= maxTries * maxFlips) */
  nsms_uint_t bmsSize;  /*!< The number of decreasing variables selected for "best from multiple selections" strategy */
  nsms_uint_t hWeightInc;         /*!< Weight increment for hard clauses during clause reweighting */
  nsms_uint_t sWeightInc;         /*!< Weight increment for soft clauses during clause reweighting */
  nsms_uint_t sWeightBoundCoef;   /*!< Coefficient for calculating soft weight upper bound for non-partial instances */
  nsms_uint_t sWeightBoundOffset; /*!< Offset for calculating soft weight upper bound for non-partial instances */
  nsms_uint_t sSmoothProb;        /*!< Smoothing probability for soft clauses (100000000 == 100%) */

  bool isPartial;  /*!< True if there are hard clauses, false otherwise */
  bool isWeighted; /*!< False if all soft clauses have weight 1, true otherwise */
} nsms_params_t;

/**
 * @brief Memory requirements
 */
typedef struct {
  nsms_uint_t weightsMemReq, numSatLiteralsMemReq, scoresMemReq, satVarsMemReq, decreasingVarMemReq,
      decreasingVarsIdxMemReq, falsifiedHardClausesMemReq, falsifiedHardClausesIdxMemReq, falsifiedSoftClausesMemReq,
      falsifiedSoftClausesIdxMemReq, highWeightSoftClausesMemReq, hightWeightSoftClausesIdxMemReq, tunedWeightsMemReq,
      varFlipCountMemReq, decimationMemReq;
  nsms_decimation_memoryReq_t detailedDecimationMemReq;
} nsms_memoryReq_t;

/**
 * @brief Initializes the library
 *
 */
void nsms_init(void);

/**
 * @brief Calculates memory requirements for the algorithm
 *
 * @param formula The formula the algorithm is supposed to run on
 * @param memReq
 * @return bsat_uint_t The number of bytes required to run the algorithm on the formula
 */
nsms_uint_t nsms_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_memoryReq_t* memReq);

/**
 * @brief Tries to solve MaxSAT instance
 *
 * @param formula The formula to try to solve
 * @param cfg @see nsms_params_t
 * @param memory A memory block of sufficient size (calculate with nsms_calcMemoryRequirements)
 * @param memReq @see nsms_memoryReq_t
 * @param result @see nsms_result_t
 * @param initModel Pointer to a model from which local search should start or NULL
 * @param stop Pointer to a Boolean value that, when set to true, causes the procedure to terminate asap
 */
void nsms_solve(nsms_wcnf_t* formula, const nsms_params_t* cfg, void* memory, const nsms_memoryReq_t* memReq,
                nsms_result_t* result, const bool* initModel, const bool* stop);

/**
 * @brief Calculates default parameters based on the given formula
 *
 * @param formula
 * @param params
 */
void nsms_params(const nsms_wcnf_t* formula, nsms_params_t* params);

#endif
