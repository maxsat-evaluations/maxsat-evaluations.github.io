# noSAT-MaxSAT

Incomplete anytime MaxSAT solver that does not use a SAT solver and is perhaps suitable for embedded real-time systems.

## Build Instructions

Building is only tested on GNU/Linux.
The main reason is that noSAT-MaxSAT requires [GNU Argp](https://www.gnu.org/software/libc/manual/html_node/Argp.html).
Building on macOS could be possible with [argp-standalone](https://formulae.brew.sh/formula/argp-standalone).
For Windows users, we recommend setting up the
[Windows subsytem for Linux (WSL)](https://learn.microsoft.com/en-us/windows/wsl/install).

1. Clone the repository: `git clone git@collaborating.tuhh.de:cda7728/boundedsat.git`
   It has two subrepositories *doc* (solver description) and *dep/check* (testing library) which are not required.
2. noSAT-MaxSAT uses [CMake](https://cmake.org/) as its build system
   and provides [CMake presets](https://cmake.org/cmake/help/latest/manual/cmake-presets.7.html) for different build
   configurations.
   Available presets are listed in *CMakePresets.json*.

### Command Line

1. Decide which preset you want to build (in the following, `release` is used as an example).
2. `cmake -S . --preset=release`
   This generates the build files in a new directory `build/release`.
3. `cmake --build build/release`
   This starts the actual build.

Alternatively, there is a makefile that automates these steps.
The default build target is `release-loginfo`,
but there are many more predefined configurations that can be found in the makefile.
To build the default target using the makefile, just run `make`.
To build another target, e.g., `debug-logverbose`, run `make debug-logverbose`.
To remove any and all build artifacts (i.e., the build directory), run `make clean`.

### VSCode

For users of [VSCode](https://code.visualstudio.com/) we recommend following
[Microsoft's guide](https://code.visualstudio.com/docs/languages/cpp) on using the editor with C/C++.
Additionally, the [CMake Tools extension](https://marketplace.visualstudio.com/items?itemName=ms-vscode.cmake-tools)
should be installed which provides GUI elements for selecting presets and executing the build.

### neovim

For users of [neovim](https://neovim.io/) we recommend setting up neovim's language server protocol (LSP) client for C/C++
using the [nvim-lspconfig plugin](https://github.com/neovim/nvim-lspconfig).
For debugging, [nvim-dap](https://github.com/mfussenegger/nvim-dap) can be used.
