char *glb_filename = nullptr;
int glb_cutoff_time = 60;
long long BKS;

// int p1_hd_count_threshold;
// int p1_h_inc;
// double p1_soft_increase_ratio;
// float p1_rdprob;
// float p1_rwprob;
// int p2_hd_count_threshold;
// int p2_h_inc;
// double p2_soft_increase_ratio;
// float p2_rdprob;
// float p2_rwprob;
int p_sc_num;
int p_sv_num;

long long cut_round;
double improve_ratio;
