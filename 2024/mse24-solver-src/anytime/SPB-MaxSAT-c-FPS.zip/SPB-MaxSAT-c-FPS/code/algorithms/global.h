extern char *glb_filename;
extern long long BKS;
extern int glb_cutoff_time;
extern long long BKS;
// extern int p1_hd_count_threshold;
// extern int p1_h_inc;
// extern double p1_soft_increase_ratio;
// extern float p1_rdprob;
// extern float p1_rwprob;
// extern int p2_hd_count_threshold;
// extern int p2_h_inc;
// extern double p2_soft_increase_ratio;
// extern float p2_rdprob;
// extern float p2_rwprob;
extern int p_sc_num;
extern int p_sv_num;

extern long long cut_round;
extern double improve_ratio;
