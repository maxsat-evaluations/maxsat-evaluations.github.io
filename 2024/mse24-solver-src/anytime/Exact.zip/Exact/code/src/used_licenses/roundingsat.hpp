
#pragma once
namespace licenses {
extern const char* roundingsat;
}
