
#pragma once
namespace licenses {
extern const char* COPYING;
}
