[![Build & Test](https://github.com/chrjabs/rustsat/actions/workflows/tools.yml/badge.svg)](https://github.com/chrjabs/rustsat/actions/workflows/tools.yml)
[![crates.io](https://img.shields.io/crates/v/rustsat-tools)](https://crates.io/crates/rustsat-tools)
[![docs.rs](https://img.shields.io/docsrs/rustsat-tools)](https://docs.rs/rustsat-tools)
[![License](https://img.shields.io/crates/l/rustsat-tools)](../LICENSE)

<!-- cargo-rdme start -->

# rustsat-tools - Tools for and with the RustSAT Library

This crate contains tools for and built on the RustSAT library.

<!-- cargo-rdme end -->
