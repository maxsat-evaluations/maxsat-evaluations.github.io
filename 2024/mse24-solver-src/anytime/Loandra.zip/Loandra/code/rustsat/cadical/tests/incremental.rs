rustsat_solvertests::incremental_tests!(rustsat_cadical::CaDiCaL);
