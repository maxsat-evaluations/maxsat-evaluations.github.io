mod core {
    rustsat_solvertests::phasing_tests!(rustsat_glucose::core::Glucose);
}

mod simp {
    rustsat_solvertests::phasing_tests!(rustsat_glucose::simp::Glucose);
}
