### README for the NuWLS-c Solver

### MaxSAT Evaluation 2024
./NuWLS-c-IBR_static <input-file>
