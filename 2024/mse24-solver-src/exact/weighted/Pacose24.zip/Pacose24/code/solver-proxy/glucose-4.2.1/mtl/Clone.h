#ifndef GLUCOSE_421_Glucose_Clone_h
#define GLUCOSE_421_Glucose_Clone_h


namespace Glucose421 {

    class Clone {
        public:
          virtual Clone* clone() const = 0;
    };
};

#endif
