#ifndef MAXPP_UTILITY_HPP
#define MAXPP_UTILITY_HPP

#include <iostream>
#include <random>
#include "global.hpp"

namespace maxPreprocessor {
int litFromDimacs(int lit);
int litToDimacs(int lit);
}
#endif