#include "Solver.h"

using namespace Minisat;

void Solver::cancelLAcontextUntil(int level) {
  if (currentNbLAcontexts == 0) {
    assert(currentNbCores==0 && costByLA==0);
    return;
  }
    LAcontext& cntxt=LAcontexts[currentNbLAcontexts-1];
     //cntxt is the context under use with relations between cores and softlits (inCore)
    if (cntxt.level <= level) {
        //cntxt should still be in use, but the value of some soft lits was canceled
        restoreCoreLock(unLockVars_lim[level]);
        restoreCoreTrueLits(trueLockedLits_lim[level]);
        assert(checkCostByLA());
    }
    else {
        //cntxt should be canceled (relation cores and softlits should be canceled)
        // and a previous one (if any) enters in use 
        cancelLastContext(true);
        int i;
        //localize the next LA context to use
        for(i=currentNbLAcontexts-1; i>=0 && LAcontexts[i].level > level; i--);
        if (i>=0) {
            //the ith LA context enters in use, relations bewteen cores and soft lits
            // should be set
            LAcontext& cntxt=LAcontexts[i];
            currentNbLAcontexts =i+1; 
            currentNbCores=cntxt.coresEnd;
            for(int j=cntxt.coresBeg; j<cntxt.coresEnd; j++) {
                Core& core=cores[j];
                assert(core.id==j);
                core.lock=core.subCoreIds.size();
                core.nbTrue = 0;
                vec<Lit>& lits = core.lits;
                for(int k=0; k<lits.size(); k++) {
                    Lit p = lits[k];
                    litLock[var(p)]++; 	unlockVar[var(p)] = var_Undef;
                    inCore[var(p)] = j;
                }
            }
            assert(cntxt.costByLA == cntxt.coresEnd-cntxt.coresBeg);
            costByLA = cntxt.costByLA;
            assert(unLockVars.size()>=unLockVars_lim[level] && unLockVars_lim[level] >= cntxt.unLockVarsBeg);
            assert(trueLockedLits.size()>=trueLockedLits_lim[level] && trueLockedLits_lim[level] >= cntxt.trueLockedLitsBeg);
            unLockVars.shrink_(unLockVars.size()-unLockVars_lim[level]);
            trueLockedLits.shrink_(trueLockedLits.size()-trueLockedLits_lim[level]);
            //softlits falsified until level should be taken into account
            for(int j=cntxt.unLockVarsBeg; j<unLockVars.size(); j++) {
                Var x=unLockVars[j];
                decrmentCoreLock(getLockedVarCore(x));
                costByLA--;
                assert(costByLA>=0);
                if (getCoreLock(inCore[x]) == 0) {
                    int coreIndex=getLockedVarCore(x);
                    vec<int>& myCoreIds = cores[coreIndex].subCoreIds;
                    for(int k=0; k<myCoreIds.size(); k++) {
                        int subCoreIndex=myCoreIds[k];
                        vec<Lit>& lits=cores[subCoreIndex].lits;
                        for(int i=0; i<lits.size(); i++)
                            addFreeLit(lits[i]);
                    }
                }
            }
            assert(checkCostByLA());
            for(int j=cntxt.trueLockedLitsBeg; j<trueLockedLits.size(); j++) {
                Var x=var(trueLockedLits[j]);
                incrementCoreNbTrue(inCore[x]);
            }
        }
        else {//no context available for level, all LAcontexts should be cancelled
            unLockVars.shrink_(unLockVars.size());
            trueLockedLits.shrink_(trueLockedLits.size());
            currentNbLAcontexts=0;
            currentNbCores=0;
            costByLA=0;
        }
    }
}

// the last LA context will not be used. 
// The relation between cores and sotflits should be canceled
void Solver::cancelLastContext(bool clear){
    LAcontext& cntxt=LAcontexts[currentNbLAcontexts-1];
    for(int i=cntxt.coresBeg; i<cntxt.coresEnd; i++) {
        Core& core=cores[i];
        vec<Lit>& lits = core.lits;
        for(int k=0; k<lits.size(); k++) {
            Lit p = lits[k];
            assert(inCore[var(p)] == core.id);
            litLock[var(p)] = 0; 	unlockVar[var(p)] = var_Undef;
            inCore[var(p)] = NON;
            addFreeLit(p);
        }
    }
    if (clear) {
        //this LAcontext is completely canceled (otherwise it can enter in use after backtracking)
        currentNbCores = cntxt.coresBeg;
        currentNbLAcontexts--;
        unLockVars.shrink(unLockVars.size() - cntxt.unLockVarsBeg);
        trueLockedLits.shrink(trueLockedLits.size() - cntxt.trueLockedLitsBeg);
    }
}

// The new LA context is going to become the current one in use.
Solver::LAcontext& Solver::allocNewLAcontext() {
    if (currentNbLAcontexts == LAcontexts.size())
        LAcontexts.push();
    LAcontext& cntxt=LAcontexts[currentNbLAcontexts];
    cntxt.level=decisionLevel();
    cntxt.unLockVarsBeg=unLockVars.size();
    cntxt.trueLockedLitsBeg=trueLockedLits.size();
    cntxt.coresBeg=currentNbCores;
  //  cntxt.unLockVars_lim.shrink_(cntxt.unLockVars_lim.size());
  //  cntxt.unLockVars_lim.push(unLockVars.size());
   // costByLA=0;
   cntxt.conflicts = conflicts;
   cntxt.decisions = decisions;
   cntxt.lookahead = LOOKAHEAD;
    currentNbLAcontexts++;
    return cntxt;
}

Solver::Core& Solver::allocNewCore() {
    if (currentNbCores == cores.size())
        cores.push();
    Core& core=cores[currentNbCores];
    core.id = currentNbCores;
    core.finalId = currentNbCores;
    core.lock=0; core.nbTrue=0;
    core.subCoreIds.shrink_(core.subCoreIds.size());
    core.subCoreIds.push(currentNbCores);
    core.lits.shrink_(core.lits.size());
    core.reasons.shrink_(core.reasons.size());
   // core.unlockLits.shrink_(core.unlockLits.size());
    currentNbCores++;
    return core;
}

void Solver::cancelLastCore() {
    currentNbCores--;
}

/********************************************************************************/

/* void Solver::setContextForLA(){
    int debut=getCoresDebut();
    for(int i=debut; i<cores.size(); i++) {
        Core& core=cores[i];
        vec<Lit>& lits = core.lits;
        for(int k=0; k<lits.size(); k++) {
            Lit p = lits[k];
            litLock[var(p)] = 0; 	unlockVar[var(p)] = var_Undef;
            inCore[var(p)] = NON;
        }
    }
}
 */
/* void Solver::restoreCores() {
    int debut=getCoresDebut();
    for(int i=debut; i<cores.size(); i++) {
        Core& core=cores[i];
        vec<Lit>& lits = core.lits;
        for(int k=0; k<lits.size(); k++) {
            Lit p = lits[k];
            litLock[var(p)]++; 	unlockVar[var(p)] = var_Undef;
            inCore[var(p)] = core.id;
        }
    }
} */

/* void Solver::cancelCoresUntil(int level) {
    if (LAcontexts.size() == 0)
        return;
    int i, debut;
    for(i=LAcontexts.size() - 1; i>=0 && level<LAcontexts[i].level; i--);
    if (i<0) {
        debut=0;
        LAcontexts.clear();
    }
    else {
        debut=LAcontexts[i].coresEnd;
        LAcontexts.shrink(LAcontexts.size() - i - 1);
    }
    for(i=debut; i<cores.size(); i++) {
        Core& core=cores[i];
        vec<Lit>& lits = core.lits;
        for(int k=0; k<lits.size(); k++) {
            Lit p = lits[k];
            litLock[var(p)] = 0; 	unlockVar[var(p)] = var_Undef;
            inCore[var(p)] = NON;
        }
    }
    cores.shrink(cores.size() - debut);
}

void Solver::cancelCoresUntilBeginning() {
    LAcontexts.clear();
    for(int i=0; i<cores.size(); i++) {
        Core& core=cores[i];
        vec<Lit>& lits = core.lits;
        for(int k=0; k<lits.size(); k++) {
            Lit p = lits[k];
            litLock[var(p)] = 0; 	unlockVar[var(p)] = var_Undef;
            inCore[var(p)] = NON;
        }
    }
    cores.shrink(cores.size());
}

 */
