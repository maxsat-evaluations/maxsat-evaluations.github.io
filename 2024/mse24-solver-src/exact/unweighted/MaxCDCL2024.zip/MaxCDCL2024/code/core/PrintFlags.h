#define printFinalSolution
// #define printFailLiteralDetectionData 
/* #define printElimVarsData */
// #define printVivificationData 
// #define printReduceDBdata 
/* #define printBackWardSubsumeData */
#define printIncompatibilities
