#include "core/Solver.h"
#include "mtl/Sort.h"
#include "utils/System.h"

#include "core/PrintFlags.h"

using namespace Minisat;

//#define printDetail

int Solver::furtherLookahead(int confls2find, LAcontext& cntxt, vec<Lit>& toHarden) {
  static double coef2 = 1;
  int nbConfl=0;
  vec<int> isets2, isets3; //isets4, isets5;

  for(int i=cntxt.coresBeg; i<cntxt.coresEnd; i++) {
    if (getCoreLock(i)==1) {
      int coreSize=cores[i].lits.size();
      if (coreSize == 2)
	      isets2.push(i);
      else if (coreSize == 3)
	      isets3.push(i);
      // else if  (coreSize == 4)
      // 	      isets4.push(i);
      // else if  (coreSize == 5)
      // 	      isets5.push(i);
    }
  }
  
  if (isets2.size()+isets3.size() < confls2find)
    return nbConfl;
  int quotient=(isets2.size()+isets3.size())/confls2find;
  
  for(int i=0; i<isets3.size(); i++)
    isets2.push(isets3[i]);
  // for(int i=0; i<isets4.size(); i++)
  //    isets2.push(isets4[i]);
  // for(int i=0; i<isets5.size(); i++)
  //    isets2.push(isets5[i]);

  Q2s.growTo(quotient+1, Q(0, 0));
  Q& q2=Q2s[quotient];

  bool toDo; int rate=0;
  if (drand(random_seed) < 0.01)
    toDo=true;
  else {
    if (nbFurtherLA > 20) {
      rate = (nbSuccFurtherLA * 100)/nbFurtherLA;
      if (rate > 75) {
	      coef2 += 0.1;
	      //  printf("succRate %d, coef %5.2f\n", rate, coef);
      }
      else if (rate < 60 && coef2 > 0.5) {
	      coef2 -= 0.1;
	      //  printf("succRate %d, coef %5.2f\n", rate, coef);
      }
    }
    toDo = (drand(random_seed) < (1 - (q2.no- coef2*q2.yes)));
  }
  if (!toDo) {
    skipLA2++;
    return nbConfl;
  }
  nbFurtherLA++; totalConfls2find += confls2find;

  nbConfl += furtherLookahead3(isets2, confls2find-nbConfl);
  if (nbConfl >= confls2find) {
    nbSuccFurtherLA++; conflsFound+=nbConfl;

    q2.yes += stepSizeLB*(1-q2.yes);
    q2.no *= (1-stepSizeLB);
      
    return nbConfl;
  }

  q2.no += stepSizeLB*(1-q2.no);
  q2.yes *= (1-stepSizeLB);

  if (nbConfl > 0 && confls2find == nbConfl+1) {
    int i, j;
    for(i=0, j=0; i<toHarden.size(); i++) {
      Lit p=toHarden[i];
      if(inCore[var(p)]==NON)
        toHarden[j++]=p;
    }
    toHarden.shrink(i-j);
  }
  return nbConfl;
}

/* int Solver::furtherLookahead2(vec<int>& isets2, int confls2find) {
  int savedInvolvedLits=involvedLits.size(), nbConfl=0;
  for(int i=0; i<isets2.size(); i++) {
    if (getCoreLock(isets2[i]) > 1)
      continue;
    int nbUseful=1;
    for(int k=i+1; k<isets2.size(); k++)
      if (getCoreLock(isets2[i]) == 1)
        nbUseful++;
    if (nbUseful + nbConfl < confls2find)
      return nbConfl;
    vec<Lit>& core=cores[isets2[i]].lits;
    vec<Lit> lits;
    bool findCore=true;
    assert(core.size() == 2);
    for(int j=0; j<2; j++) {
      assert( inCore[var(core[j])] == isets2[i]);
      inCore[var(core[j])] = NON;
      int other = (j==0) ? 1 : 0;
      if(propagateSoftLitForLK(softLits[var(core[j])], lits) &&
	       (value(softLits[var(core[other])]) == l_False ||
	        propagateSoftLitForLK(~softLits[var(core[other])], lits))) {
	      while (1) {
	        Var v = pickAuxiVar();
	        if (v == var_Undef) {
	          findCore=false;
	          break;
	        }
	        if (!propagateSoftLitForLK(softLits[v], lits)) 
	          break; //a core is found for softLits[var(core[j])] in lits
	      }
      }
      inCore[var(core[j])] = isets2[i];
      restoreCoreLitLock(0);
      for(int ii=trailRecord; ii< trail.size(); ii++) {
	      Var v=var(trail[ii]);
	      assigns[v] = l_Undef;
	      if (auxiVar(v))
	        insertAuxiVarOrder(v);
      }
      trail.shrink(trail.size() - trailRecord);
      qhead = trailRecord;
      if (!findCore) {
	      for(int i=savedInvolvedLits; i<involvedLits.size(); i++) {
	        involved[var(involvedLits[i])] = 0;
	      }
	      involvedLits.shrink(involvedLits.size() - savedInvolvedLits);
	      break;
      }
    }
    if (!findCore)
      continue;
    // a core is found
    savedInvolvedLits=involvedLits.size();
    cores.push();
    vec<Lit>& newCoreLits=getCoreOwnLits(cores.size()-1);
    newCoreLits.clear();
   // isetsLits.init(nbIsets); isetsLits[nbIsets].clear();
    counter++;
    for(int j=0; j<lits.size(); j++)
      if (seen2[var(lits[j])] != counter) {
	      newCoreLits.push(lits[j]);
	      seen2[var(lits[j])] = counter;
      }
    setCore(cores.size()-1);
    nbConfl++;
    if (nbConfl >= confls2find)
      return nbConfl;
  }
  return nbConfl;
} */

bool Solver::propagateSoftLitForLK(Lit p, Core& core) {
  vec<Lit> out_learnt;
  uncheckedEnqueueForLK(p);
  CRef confl = propagateForLK();
  if (confl != CRef_Undef || falseVar != var_Undef) {
    if (confl != CRef_Undef)
      falseVar = var_Undef;
    else 
      confl = reason(falseVar);
    lookbackResetTrail(confl, falseVar, core, true);
    falseVar = var_Undef;
    return false;
  }
  else
    return true;
}

int Solver::furtherLookahead3(vec<int>& isetIndexes, int confls2find) {
  int nbConfl=0;
  for(int i=0; i<isetIndexes.size(); i++) {
    if (getCoreLock(isetIndexes[i]) > 1)
      continue;
    int nbUseful=1;
    for(int k=i+1; k<isetIndexes.size(); k++)
      if (getCoreLock(isetIndexes[i]) == 1)
        nbUseful++;
    if (nbUseful + nbConfl < confls2find)
      return nbConfl;

    Core& newCore=allocNewCore();
    if (testCore(isetIndexes[i], newCore)) {
      nbConfl++;
      if (nbConfl >= confls2find)
	      return nbConfl;
    }
    else cancelLastCore();
  }
  return nbConfl;
}

bool Solver::testCore(int coreIndex, Core& newCore) {
  vec<Lit>& coreLits=getCoreOwnLits(coreIndex);
  vec<Lit> lits;
  bool findNewCore=true;
  for(int j=0; j<coreLits.size(); j++) {
    assert(inCore[var(coreLits[j])] == coreIndex);
    inCore[var(coreLits[j])] = NON;
    if (propagateSoftLitForLK(~softLits[var(coreLits[j])], newCore)) {
      //insert other variables of the core into the heap to propagate the soft lits
      for(int k=0; k<coreLits.size(); k++) 
	      if (k!=j && value(coreLits[k]) == l_Undef) {
	        insertAuxiVarOrder(var(coreLits[k]));
	        inCore[var(coreLits[k])] = NON;
	      }
      while (1) {
	      Var v = pickAuxiVar();
	      if (v == var_Undef) {
	        findNewCore=false;
	        break;
	      }
	      if (!propagateSoftLitForLK(softLits[v], newCore)) 
	        break; //a core is found for ~softLits[var(core[j])] in lits
      }
      for(int k=0; k<coreLits.size(); k++) 
	      inCore[var(coreLits[k])] = coreIndex;
    }
    else inCore[var(coreLits[j])] = coreIndex;
    for(int ii=trailRecord; ii< trail.size(); ii++) {
      Var v=var(trail[ii]);
      assigns[v] = l_Undef;
      if (auxiVar(v))
	      insertAuxiVarOrder(v);
    }
    trail.shrink(trail.size() - trailRecord);
    qhead = trailRecord;

    restoreCoreLitLockForLK(unLockVarsRecord);

    if (!findNewCore) {
      return false;
    }
  }
  // a core is found,first purge dulicate lits, then set core
  purgeVec(newCore.lits);
  purgeVec(newCore.reasons);
  setCore(newCore); //nbIsets++;
  return true;
}
