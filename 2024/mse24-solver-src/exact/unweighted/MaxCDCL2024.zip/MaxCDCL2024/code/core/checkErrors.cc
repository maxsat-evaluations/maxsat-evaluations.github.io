#include "core/Solver.h"
#include "mtl/Sort.h"
#include "utils/System.h"

#include "core/PrintFlags.h"

using namespace Minisat;


// to Check the order of another heap, just replace activity_VSIDS by another heap and
// put the inverse of corresponding comparator of the heap
bool Solver::checkHeapOrder(int i) {
  Heap<VarOrderLt>& myHeap = order_heap_VSIDS;
  vec<double>& myData=activity_VSIDS;
  if (2*i+1 < myHeap.size() && (myData[myHeap[i]] < myData[myHeap[2*i+1]] || !checkHeapOrder(2*i+1)))
    return false;
  if (2*i+2 < myHeap.size() && (myData[myHeap[i]] < myData[myHeap[2*i+2]] || !checkHeapOrder(2*i+2)))
    return false;
  return true;
}

#define myFalse 0
#define myTrue 1
#define myNone -1

bool Solver::checkClauses(vec<CRef>& cs) {
  vec<int> myValue;
  myValue.growTo(nVars());

  for(int i=0; i<nVars(); i++)
    if (value(i)==l_True)
      myValue[i]=myTrue;
    else if (value(i)==l_False)
      myValue[i]=myFalse;
    else   myValue[i]=myNone;
  
  myValue[216399]=myTrue;
  myValue[188037]=myTrue;
  myValue[90431]=myTrue;
  myValue[76210]=myTrue;
  myValue[178269]=myTrue;
  myValue[202808]=myTrue;
  myValue[113833]=myTrue;
  myValue[135397]=myTrue;
  
  // myValue[1]=myFalse;
  // myValue[2]=myFalse;
  // myValue[6]=myFalse;
  // myValue[5]=myFalse;
  // myValue[12]=myFalse;
  // myValue[11]=myFalse;
  // myValue[10]=myFalse;
  // myValue[8]=myFalse;
  // myValue[13]=myFalse;
  // myValue[9]=myFalse;
  // myValue[14]=myFalse;
  // myValue[15]=myFalse;
  // myValue[16]=myFalse;
  // myValue[18]=myFalse;
  // myValue[19]=myFalse;
  // myValue[17]=myFalse;
  // myValue[20]=myFalse;
  // myValue[21]=myFalse;
  // myValue[22]=myFalse;
  // myValue[24]=myFalse;
  // myValue[38]=myFalse;
  // myValue[39]=myFalse;
  // myValue[64]=myFalse;
  // myValue[61]=myFalse;
  // myValue[63]=myFalse;
  // myValue[52]=myFalse;
  // myValue[50]=myFalse;
  // myValue[49]=myFalse;
  // myValue[43]=myFalse;
  // myValue[44]=myFalse;
  // myValue[42]=myFalse;

  bool toRepeat=false;
  do {
    toRepeat=false;
    for(int i=0; i<cs.size(); i++) {
      Clause& c=ca[cs[i]];
      if (c.mark()==1)
	continue;
      Lit p=lit_Undef;
      bool sat=false;
      bool unit=true;
      for(int j=0; j<c.size(); j++) {
	if (myValue[var(c[j])] == myNone) {
	  if (p==lit_Undef)
	    p=c[j];
	  else {
	    unit=false;
	    break;
	  }
	}
	else if (myValue[var(c[j])]^sign(c[j])==myTrue) {
	  sat=true;
	  break;
	}
      }
      if (!sat) {
	if (p == lit_Undef)
	  return false;
	else if (unit) {
	  toRepeat=true;
	  myValue[var(p)] = !sign(p);
	}
      }
    }
  } while(toRepeat);
  return true;
}
