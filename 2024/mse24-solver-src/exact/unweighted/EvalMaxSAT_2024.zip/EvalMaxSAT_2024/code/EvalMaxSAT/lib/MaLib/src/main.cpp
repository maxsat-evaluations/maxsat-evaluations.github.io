
void empty_for_MaLib() {
}

