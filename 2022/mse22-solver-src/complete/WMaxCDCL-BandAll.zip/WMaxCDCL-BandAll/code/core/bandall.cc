#include "mtl/Sort.h"
#include "core/Solver.h"
#include "utils/System.h"
#include "float.h"

#define SC_NUM 20
#define BACKWARD_STEP 21
#define GAMMA 0.9
#define ALPHA 1.0
#define MAX_CLAUSE_SCORE 1000
#define MULTI_NUMS 10
#define SAMPLE_GOOD_NUMS 50

#define mypop(stack) stack[--stack##_fill_pointer]
#define mypush(item, stack) stack[stack##_fill_pointer++] = item

const float MY_RAND_MAX_FLOAT = 10000000.0;
const int MY_RAND_MAX_INT = 10000000;
const float BASIC_SCALE = 0.0000001; //1.0f/MY_RAND_MAX_FLOAT;
const int USING_NEIGHBOR_MODE = 3;// 1. using 2. don't use 3. depends on ins
const int SATLIKE_TIME_LIMIT = 15;

using namespace Minisat;

void Solver::settings()
{
    if (problem_weighted == 1)
    {
        large_clause_count_threshold = 0;
        soft_large_clause_count_threshold = 0;

        rdprob = 0.01;
        hd_count_threshold = 15;
        rwprob = 0.1;
        smooth_probability = 0.01;

        if ((top_clause_weight / num_sclauses) > 10000)
        {
            h_inc = 300;
            softclause_weight_threshold = 500;
        }
        else
        {
            h_inc = 3;
            softclause_weight_threshold = 0;
        }

        if (num_vars > 2000)
        {
            rdprob = 0.01;
            hd_count_threshold = 15;
            rwprob = 0.1;
            smooth_probability = 0.0001;
        }
    }
    else
    {

        large_clause_count_threshold = 0;
        soft_large_clause_count_threshold = 0;

        rdprob = 0.01;
        hd_count_threshold = 42;
        rwprob = 0.091;
        smooth_probability = 0.000003;

        h_inc = 1;
        softclause_weight_threshold = 400;

        if (num_vars < 1100) //for somall instances
        {
            h_inc = 1;
            softclause_weight_threshold = 0;
            rdprob = 0.01;
            hd_count_threshold = 15;
            rwprob = 0;
            smooth_probability = 0.01;
            return;
        }
    }
}

void Solver::allocate_memory()
{
    int malloc_var_length = num_vars + 10;
    int malloc_clause_length = malloc_var_length + nClauses() + nLearnts();

    var_lit = new Bandlit *[malloc_var_length];
    var_lit_count = new int[malloc_var_length];
    clause_lit = new Bandlit *[malloc_clause_length];
    clause_lit_count = new int[malloc_clause_length];

    score1 = new long long[malloc_var_length];  score2 = new long long[malloc_var_length];
    var_neighbor = new int *[malloc_var_length];
    var_neighbor_count = new int[malloc_var_length];
    time_stamp = new long long[malloc_var_length];
    neighbor_flag = new int[malloc_var_length];
    temp_neighbor = new int[malloc_var_length];

    org_clause_weight = new long long[malloc_clause_length];
    clause_weight = new long long[malloc_clause_length];
    sat_count = new int[malloc_clause_length];
    sat_var = new int[malloc_clause_length];
    clause_selected_count = new long long[malloc_clause_length];
    best_soft_clause = new int[malloc_clause_length];

    hardunsat_stack = new int[malloc_clause_length];
    index_in_hardunsat_stack = new int[malloc_clause_length];
    softunsat_stack = new int[malloc_clause_length];
    index_in_softunsat_stack = new int[malloc_clause_length];

    unsatvar_stack = new int[malloc_var_length];
    index_in_unsatvar_stack = new int[malloc_var_length];
    unsat_app_count = new int[malloc_var_length];

    goodvar_stack = new int[malloc_var_length];  goodvar_stack2 = new int[malloc_var_length];
    already_in_goodvar_stack = new int[malloc_var_length];
    score_change_stack = new int[malloc_var_length];  score_change_stack2 = new int[malloc_var_length];
    if_score_change = new bool[malloc_var_length];

    cur_soln = new int[malloc_var_length];
    best_soln = new int[malloc_var_length];
    local_opt_soln = new int[malloc_var_length];

    large_weight_clauses = new int[malloc_clause_length];
    soft_large_weight_clauses = new int[malloc_clause_length];
    already_in_soft_large_weight_stack = new int[malloc_clause_length];

    best_array = new int[malloc_var_length];
    temp_lit = new int[malloc_var_length];

    selected_clauses = new int[BACKWARD_STEP + 10];
    selected_clauses_hard = new int[BACKWARD_STEP + 10];
    selected_times = new int[malloc_clause_length];
    sampled_clauses = new int[SC_NUM + 10];
    clause_score = new double[malloc_clause_length];

    sel_cs = new int [MULTI_NUMS + 10];
    selected = new int [malloc_var_length];
    best_vars = new int [MULTI_NUMS + 10];
    vars2 = new int [MULTI_NUMS + 10];
    scores = new long long [MULTI_NUMS + 10];
}

void Solver::free_memory()
{
    int i;
    for (i = 0; i < num_clauses; i++)
        delete[] clause_lit[i];

    for (i = 0; i < num_vars; ++i)
    {
        if (value(i) != l_Undef)
            continue;
        delete[] var_lit[i];
        delete[] var_neighbor[i];
    }

    delete[] var_lit;
    delete[] var_lit_count;
    delete[] clause_lit;
    delete[] clause_lit_count;

    delete[] score1;  delete[] score2;
    delete[] var_neighbor;
    delete[] var_neighbor_count;
    delete[] time_stamp;
    delete[] neighbor_flag;
    delete[] temp_neighbor;

    delete[] org_clause_weight;
    delete[] clause_weight;
    delete[] sat_count;
    delete[] sat_var;
    delete[] clause_selected_count;
    delete[] best_soft_clause;

    delete[] hardunsat_stack;
    delete[] index_in_hardunsat_stack;
    delete[] softunsat_stack;
    delete[] index_in_softunsat_stack;

    delete[] unsatvar_stack;
    delete[] index_in_unsatvar_stack;
    delete[] unsat_app_count;

    delete[] goodvar_stack;  delete[] goodvar_stack2;
    delete[] already_in_goodvar_stack;
    delete[] if_score_change;
    delete[] score_change_stack;  delete[] score_change_stack2;

    delete[] cur_soln;
    delete[] best_soln;
    delete[] local_opt_soln;

    delete[] large_weight_clauses;
    delete[] soft_large_weight_clauses;
    delete[] already_in_soft_large_weight_stack;

    delete[] best_array;
    delete[] temp_lit;

    delete[] selected_clauses;
    delete[] selected_clauses_hard;
    delete[] selected_times;
    delete[] sampled_clauses;
    delete[] clause_score;

    delete[] selected;
    delete[] best_vars;
    delete[] vars2;
    delete[] scores;
    delete[] sel_cs;
}

void Solver::build_instance(){
    int v;

    problem_weighted = 0;
    partial = 0;
    num_hclauses = num_sclauses = 0;
    max_clause_length = 0;
    min_clause_length = 100000000;
    top_clause_weight = hardWeight;

    for (v = 0; v < num_vars; ++v)
    {
        if (value(v) != l_Undef)
            continue;
        var_lit_count[v] = 0;
        var_lit[v] = NULL;
        var_neighbor[v] = NULL;
    }

    for (int i = 0; i < num_clauses; ++i)
    {
        for (int j = 0; j < clause_lit_count[i]; ++j)
        {
            v = clause_lit[i][j].var_num;
            var_lit_count[v]++;
        }

        if (org_clause_weight[i] != top_clause_weight)
        {
            if (org_clause_weight[i] != 1)
                problem_weighted = 1;
            total_soft_weight += org_clause_weight[i];
            num_sclauses++;
        }
        else
        {
            num_hclauses++;
            partial = 1;
        }
        //if (clause_lit_count[i] == 1)
        //    unit_clause[unit_clause_count++] = clause_lit[i][0];

        if (clause_lit_count[i] > max_clause_length)
            max_clause_length = clause_lit_count[i];

        if (clause_lit_count[i] < min_clause_length)
            min_clause_length = clause_lit_count[i];

    }

    for (v = 0; v < num_vars; ++v)
    {
        if (value(v) != l_Undef)
            continue;
        var_lit[v] = new Bandlit[var_lit_count[v] + 1];
        var_lit_count[v] = 0; //reset to 0, for build up the array
    }
    //scan all clauses to build up var literal arrays
    for (int i = 0; i < num_clauses; ++i)
    {
        for (int j = 0; j < clause_lit_count[i]; ++j)
        {
            v = clause_lit[i][j].var_num;
            var_lit[v][var_lit_count[v]] = clause_lit[i][j];
            ++var_lit_count[v];
        }
    }

    for (v = 0; v < num_vars; ++v) {
        if (value(v) != l_Undef)
            continue;
        var_lit[v][var_lit_count[v]].clause_num = -1;
    }


    build_neighbor_relation();

    best_soln_feasible = 0;
    opt_unsat_weight = total_soft_weight + 1;
}

void Solver::build_neighbor_relation()
{
    int i, j, count;
    int v, c, n;
    int temp_neighbor_count;

    for(v = 0; v < num_vars; ++v)
        neighbor_flag[v]=0;

    for (v = 0; v < num_vars; ++v)
    {
        if (value(v) != l_Undef)
            continue;

        neighbor_flag[v] = 1;
        temp_neighbor_count = 0;

        for (i = 0; i < var_lit_count[v]; ++i)
        {
            c = var_lit[v][i].clause_num;
            for (j = 0; j < clause_lit_count[c]; ++j)
            {
                n = clause_lit[c][j].var_num;
                if (neighbor_flag[n] != 1)
                {
                    neighbor_flag[n] = 1;
                    temp_neighbor[temp_neighbor_count++] = n;
                }
            }
        }

        neighbor_flag[v] = 0;

        var_neighbor[v] = new int[temp_neighbor_count];
        var_neighbor_count[v] = temp_neighbor_count;

        count = 0;
        for (i = 0; i < temp_neighbor_count; i++)
        {
            var_neighbor[v][count++] = temp_neighbor[i];
            neighbor_flag[temp_neighbor[i]] = 0;
        }
    }
}

void Solver::init()
{
    local_times = 0;
    local_times_hard = 0;
    if_exceed = 0;
    soft_large_weight_clauses_count = 0;
    //Initialize clause information
    for (int c = 0; c < num_clauses; c++)
    {
        already_in_soft_large_weight_stack[c] = 0;
        clause_selected_count[c] = 0;
        clause_score[c] = 1;
        selected_times[c] = 0;

        if (org_clause_weight[c] == top_clause_weight)
            clause_weight[c] = 1;
        else
        {
            clause_weight[c] = org_clause_weight[c];
            if (clause_weight[c] > 1 && already_in_soft_large_weight_stack[c] == 0)
            {
                already_in_soft_large_weight_stack[c] = 1;
                soft_large_weight_clauses[soft_large_weight_clauses_count++] = c;
            }
        }
    }

    //init solution

    for (int v = 0; v < num_vars; v++){
        if (value(v) != l_Undef)
            continue;
        selected[v] = 0;
        time_stamp[v] = 0;
        cur_soln[v] = !polarity[v];
        unsat_app_count[v] = 0;
    }

    //init stacks
    hard_unsat_nb = 0;
    soft_unsat_weight = countedWeight;
    hardunsat_stack_fill_pointer = 0;
    softunsat_stack_fill_pointer = 0;
    unsatvar_stack_fill_pointer = 0;
    large_weight_clauses_count = 0;

    /* figure out sat_count, sat_var and init unsat_stack */
    for (int c = 0; c < num_clauses; ++c)
    {
        sat_count[c] = 0;
        for (int j = 0; j < clause_lit_count[c]; ++j)
        {
            if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)
            {
                sat_count[c]++;
                sat_var[c] = clause_lit[c][j].var_num;
            }
        }
        if (sat_count[c] == 0)
        {
            unsat(c);
        }
    }
    /*figure out score*/
    for (int v = 0; v < num_vars; v++)
    {
        if (value(v) != l_Undef)
            continue;
        score[v] = 0;
        for (int i = 0; i < var_lit_count[v]; ++i)
        {
            int c = var_lit[v][i].clause_num;
            if (sat_count[c] == 0)
                score[v] += clause_weight[c];
            else if (sat_count[c] == 1 && var_lit[v][i].sense == cur_soln[v])
                score[v] -= clause_weight[c];
        }
    }

    //init goodvars stack
    goodvar_stack_fill_pointer = 0;
    score_change_stack_fill_pointer = 0;
    for (int v = 0; v < num_vars; v++)
    {
        if (value(v) != l_Undef)
            continue;
        if_score_change[v] = false;
        if (score[v] > 0)
        {
            already_in_goodvar_stack[v] = goodvar_stack_fill_pointer;
            mypush(v, goodvar_stack);
        }
        else
            already_in_goodvar_stack[v] = -1;
    }

    printf("hard_unsat_nb: %d\tsoft_unsat_weight: %lld\n",hard_unsat_nb,solutionCost+soft_unsat_weight+fixedCostBySearch+derivedCost);
}

void Solver::update_goodvarstack1(int flipvar)
{
    int v;
    //remove the vars no longer goodvar in goodvar stack
    for (int index = goodvar_stack_fill_pointer - 1; index >= 0; index--)
    {
        v = goodvar_stack[index];
        if (score[v] <= 0 || (time_stamp[v] != 0 && step - time_stamp[v] <= tabu_step))
        {
            goodvar_stack[index] = mypop(goodvar_stack);
            already_in_goodvar_stack[goodvar_stack[index]] = index;
            already_in_goodvar_stack[v] = -1;
        }
    }

    //add goodvar
    for (int i = 0; i < var_neighbor_count[flipvar]; ++i)
    {
        v = var_neighbor[flipvar][i];
        if (score[v] > 0 && already_in_goodvar_stack[v] == -1 && (time_stamp[v] == 0 || step - time_stamp[v] > tabu_step))
        {
            already_in_goodvar_stack[v] = goodvar_stack_fill_pointer;
            mypush(v, goodvar_stack);
        }
    }
}

void Solver::update_goodvarstack12(int flipvar)
{
    int v;
    goodvar_stack2_num = 0;
    //remove the vars no longer goodvar in goodvar stack
    //add goodvar
    for (int i = 0; i < var_neighbor_count[flipvar]; ++i)
    {
        v = var_neighbor[flipvar][i];
        if (score2[v] > 0 && (time_stamp[v] == 0 || step - time_stamp[v] > tabu_step))
        {
            goodvar_stack2[goodvar_stack2_num] = v;
            goodvar_stack2_num++;
        }
    }
}

void Solver::update_goodvarstack2(int flipvar)
{
    int v;
    //remove the vars no longer goodvar in goodvar stack
    for (int index = goodvar_stack_fill_pointer - 1; index >= 0; index--)
    {
        v = goodvar_stack[index];
        if (score[v] <= 0 || (time_stamp[v] != 0 && step - time_stamp[v] <= tabu_step))
        {
            goodvar_stack[index] = mypop(goodvar_stack);
            already_in_goodvar_stack[goodvar_stack[index]] = index;
            already_in_goodvar_stack[v] = -1;
        }
    }

    Bandlit *clause_c;
    int c;

    for (int i = 0; i < score_change_stack_fill_pointer; i++)
    {
        int v = score_change_stack[i];

        if (!if_score_change[v])
            continue;

        if_score_change[v] = false;

        if (score[v] > 0 && already_in_goodvar_stack[v] == -1 && (time_stamp[v] == 0 || step - time_stamp[v] > tabu_step))
        {
            already_in_goodvar_stack[v] = goodvar_stack_fill_pointer;
            mypush(v, goodvar_stack);
        }
    }

    if (already_in_goodvar_stack[flipvar] != 0 && score[flipvar] > 0)
    {
        if (goodvar_stack[already_in_goodvar_stack[flipvar]] == flipvar)
        {
            int tem_v = mypop(goodvar_stack);
            goodvar_stack[already_in_goodvar_stack[flipvar]] = tem_v;
            already_in_goodvar_stack[tem_v] = already_in_goodvar_stack[flipvar];
            already_in_goodvar_stack[flipvar] = -1;
        }
    }
}

void Solver::flip(int flipvar)
{
    int i, j, v, c;
    int index;
    Bandlit *clause_c;
    score_change_stack_fill_pointer = 0;
    int org_flipvar_score = score[flipvar];
    cur_soln[flipvar] = 1 - cur_soln[flipvar];

    for (i = 0; i < var_lit_count[flipvar]; ++i)
    {
        c = var_lit[flipvar][i].clause_num;
        clause_c = clause_lit[c];
        if (cur_soln[flipvar] == var_lit[flipvar][i].sense)
        {
            ++sat_count[c];
            if (sat_count[c] == 2) //sat_count from 1 to 2
            {
                score[sat_var[c]] += clause_weight[c];
            }
            else if (sat_count[c] == 1) // sat_count from 0 to 1
            {
                sat_var[c] = flipvar; //record the only true Bandlit's var
                for (j = 0; j < clause_lit_count[c]; j++){
                    v = clause_c[j].var_num;
                    score[v] -= clause_weight[c];
                }
                /*
                for (Bandlit *p = clause_c; (v = p->var_num) != 0; p++)
                {
                    score[v] -= clause_weight[c];
                }
                */
                sat(c);
            }
        }
        else // cur_soln[flipvar] != cur_lit.sense
        {
            --sat_count[c];
            if (sat_count[c] == 1) //sat_count from 2 to 1
            {
                for (j = 0; j < clause_lit_count[c]; j++){
                    v = clause_c[j].var_num;
                    if (clause_c[j].sense == cur_soln[v])
                    {
                        score[v] -= clause_weight[c];
                        sat_var[c] = v;
                        break;
                    }
                }
                /*
                for (Bandlit *p = clause_c; (v = p->var_num) != 0; p++)
                {
                    if (p->sense == cur_soln[v])
                    {
                        score[v] -= clause_weight[c];
                        sat_var[c] = v;
                        break;
                    }
                }
                */
            }
            else if (sat_count[c] == 0) //sat_count from 1 to 0
            {
                for (j = 0; j < clause_lit_count[c]; j++){
                    v = clause_c[j].var_num;
                    score[v] += clause_weight[c];
                }
                /*
                for (Bandlit *p = clause_c; (v = p->var_num) != 0; p++)
                {
                    score[v] += clause_weight[c];
                }
                */
                unsat(c);
            } //end else if
        }     //end else
    }

    //update information of flipvar
    score[flipvar] = -org_flipvar_score;
    update_goodvarstack1(flipvar);
}

void Solver::flip2(int flipvar)
{
    int i, j, v, c;
    int index;
    Bandlit *clause_c;

    int org_flipvar_score = score[flipvar];
    cur_soln[flipvar] = 1 - cur_soln[flipvar];

    for (i = 0; i < var_neighbor_count[flipvar]; i++){
        score2[var_neighbor[flipvar][i]] = score[var_neighbor[flipvar][i]];
    }

    /*
    for (i = 0; i < num_clauses; i++){
      sat_count2[i] = sat_count[i];
      //sat_var[i] = sat_var[i];
    }
    */

    for (i = 0; i < var_lit_count[flipvar]; ++i)
    {
        c = var_lit[flipvar][i].clause_num;
        clause_c = clause_lit[c];

        if (cur_soln[flipvar] == var_lit[flipvar][i].sense)
        {
            //++sat_count2[c];
            int sc = sat_count[c] + 1;
            if (sc == 2) //sat_count from 1 to 2
            {
                score2[sat_var[c]] += clause_weight[c];
            }
            else if (sc == 1) // sat_count from 0 to 1
            {
                //sat_var2[c] = flipvar; //record the only true Bandlit's var
                for (j = 0; j < clause_lit_count[c]; j++){
                    v = clause_c[j].var_num;
                    score2[v] -= clause_weight[c];
                }
                /*
                        for (Bandlit *p = clause_c; (v = p->var_num) != 0; p++)
                        {
                            score2[v] -= clause_weight[c];
                        }*/
                //sat(c);
            }
        }
        else // cur_soln[flipvar] != cur_lit.sense
        {
            //--sat_count2[c];
            int sc = sat_count[c] - 1;
            if (sc == 1) //sat_count from 2 to 1
            {
                for (j = 0; j < clause_lit_count[c]; j++){
                    v = clause_c[j].var_num;
                    if (clause_c[j].sense == cur_soln[v])
                    {
                        score2[v] -= clause_weight[c];
                        //sat_var[c] = v;
                        break;
                    }
                }
                /*
                        for (Bandlit *p = clause_c; (v = p->var_num) != 0; p++)
                        {
                            if (p->sense == cur_soln[v])
                            {
                                score2[v] -= clause_weight[c];
                                //sat_var2[c] = v;
                                break;
                            }
                        }
                */
            }
            else if (sc == 0) //sat_count from 1 to 0
            {
                for (j = 0; j < clause_lit_count[c]; j++){
                    v = clause_c[j].var_num;
                    score2[v] += clause_weight[c];
                }
                /*
                        for (Bandlit *p = clause_c; (v = p->var_num) != 0; p++)
                        {
                            score2[v] += clause_weight[c];
                        }
                */
                //unsat(c);
            } //end else if
        }	 //end else
    }

    //update information of flipvar
    cur_soln[flipvar] = 1 - cur_soln[flipvar];
    score2[flipvar] = -org_flipvar_score;
    update_goodvarstack12(flipvar);
}

bool Solver::verify_sol()
{
    int c, j, flag;
    long long verify_unsat_weight = 0;

    for (c = 0; c < num_clauses; ++c)
    {
        flag = 0;
        for (j = 0; j < clause_lit_count[c]; ++j)
        {
            if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)
            {
                flag = 1;
                break;
            }
        }
        if (flag == 0)
        {
            if (org_clause_weight[c] == top_clause_weight) //verify hard clauses
            {
                return 0;
            }
            else
            {
                verify_unsat_weight += org_clause_weight[c];
            }
        }
    }

    return 0;
}

bool Solver::verify_goodvarstack(int flipvar)
{
    for (int i = 0; i < num_vars; ++i)
    {
        if (value(i) != l_Undef)
            continue;
        if (i == flipvar)
            continue;
        if (score[i] > 0 && already_in_goodvar_stack[i] == -1)
        {
            //cout << "wrong 1 :" << endl;
            //cout << "var is " << i << endl;
        }
        else if (score[i] <= 0 && already_in_goodvar_stack[i] != -1)
        {
            //cout << "wrong 2 :" << endl;
            //cout << "var is " << i << endl;
        }
        if (if_score_change[i] != 0)
        {
            //cout << "wrong 3 :" << endl;
            //cout << "var is " << i << endl;
        }
    }
    if (score[flipvar] > 0 && already_in_goodvar_stack[flipvar] != -1)
    {
        //cout << "wrong flipvar in good var " << flipvar << endl;
        //cout << score[flipvar] << endl;
    }
    return 1;
}

void Solver::update_clause_scores2(long long s) //s����reward
{
    int i, j;

    double stemp;

    long long opt = opt_unsat_weight;

    //cout << "opt: " << opt << endl;

    if (soft_unsat_weight < opt)
        opt = soft_unsat_weight;

    //stemp = ((double) s) / sqrt(soft_unsat_weight - opt + 1);
    stemp = ((double) s) / ((double) (pre_unsat_weight - opt + 1));

    double discount;
    if (local_times < BACKWARD_STEP){
        for (i = 0; i < local_times; i++){
            discount = pow(GAMMA, local_times - 1- i);
            clause_score[selected_clauses[i]] += (discount * ((double) stemp));
            if (abs(clause_score[selected_clauses[i]]) > MAX_CLAUSE_SCORE)
                if_exceed = 1;
        }
    }
    else{
        for (i = 0; i < BACKWARD_STEP; i++){
            if (i == local_times % BACKWARD_STEP)
                continue;
            if (i < local_times % BACKWARD_STEP)
                discount = pow(GAMMA, local_times % BACKWARD_STEP - 1 - i);
            else
                discount = pow(GAMMA, local_times % BACKWARD_STEP + BACKWARD_STEP - 1 - i);
            clause_score[selected_clauses[i]] += (discount * ((double) stemp));
            if (abs(clause_score[selected_clauses[i]]) > MAX_CLAUSE_SCORE)
                if_exceed = 1;
        }
    }
    if (if_exceed){
        for (i = 0; i < num_clauses; i++)
            clause_score[i] = clause_score[i] / 2.0;
        if_exceed = 0;
    }
}

void Solver::update_clause_scores3(long long s) //s is reward
{
    int i, j;

    double stemp;

    //long long opt = opt_unsat_weight;

    //cout << "opt: " << opt << endl;

    //if (soft_unsat_weight < opt)
    //    opt = soft_unsat_weight;

    //stemp = ((double) s) / sqrt(soft_unsat_weight - opt + 1);
    stemp = ((double) s) / ((double) (pre_unsat_hard_nb + 1));

    double discount;
    if (local_times_hard < BACKWARD_STEP){
        for (i = 0; i < local_times_hard; i++){
            discount = pow(GAMMA, local_times_hard - 1- i);
            clause_score[selected_clauses_hard[i]] += (discount * ((double) stemp));
            if (abs(clause_score[selected_clauses_hard[i]]) > MAX_CLAUSE_SCORE)
                if_exceed = 1;
        }
    }
    else{
        for (i = 0; i < BACKWARD_STEP; i++){
            if (i == local_times_hard % BACKWARD_STEP)
                continue;
            if (i < local_times_hard % BACKWARD_STEP)
                discount = pow(GAMMA, local_times_hard % BACKWARD_STEP - 1 - i);
            else
                discount = pow(GAMMA, local_times_hard % BACKWARD_STEP + BACKWARD_STEP - 1 - i);
            clause_score[selected_clauses_hard[i]] += (discount * ((double) stemp));
            if (abs(clause_score[selected_clauses_hard[i]]) > MAX_CLAUSE_SCORE)
                if_exceed = 1;
        }
    }
    if (if_exceed){
        for (i = 0; i < num_clauses; i++){
            if (org_clause_weight[i] == top_clause_weight)
                clause_score[i] = clause_score[i] / 2.0;
        }
        if_exceed = 0;
    }
}

void Solver::unsat(int clause)
{
    if (org_clause_weight[clause] == top_clause_weight)
    {
        index_in_hardunsat_stack[clause] = hardunsat_stack_fill_pointer;
        mypush(clause, hardunsat_stack);
        hard_unsat_nb++;
    }
    else
    {
        index_in_softunsat_stack[clause] = softunsat_stack_fill_pointer;
        mypush(clause, softunsat_stack);
        soft_unsat_weight += org_clause_weight[clause];
    }
}

void Solver::sat(int clause)
{
    int index, last_unsat_clause;

    if (org_clause_weight[clause] == top_clause_weight)
    {
        last_unsat_clause = mypop(hardunsat_stack);
        index = index_in_hardunsat_stack[clause];
        hardunsat_stack[index] = last_unsat_clause;
        index_in_hardunsat_stack[last_unsat_clause] = index;

        hard_unsat_nb--;
    }
    else
    {
        last_unsat_clause = mypop(softunsat_stack);
        index = index_in_softunsat_stack[clause];
        softunsat_stack[index] = last_unsat_clause;
        index_in_softunsat_stack[last_unsat_clause] = index;

        soft_unsat_weight -= org_clause_weight[clause];
    }
}

int Solver::pick_var_BandAll()
{
    int i, v;
    int best_var;

    tabu_step = rand() % 5;

    if (goodvar_stack_fill_pointer > 0)
    {
        if ((rand() % MY_RAND_MAX_INT) * BASIC_SCALE < rdprob){
            v = goodvar_stack[rand() % goodvar_stack_fill_pointer];
            return v;
        }

        if (goodvar_stack_fill_pointer < hd_count_threshold)
        {
            best_var = goodvar_stack[0];
            for (i = 1; i < goodvar_stack_fill_pointer; ++i)
            {
                v = goodvar_stack[i];
                if (score[v] > score[best_var])
                    best_var = v;
                else if (score[v] == score[best_var])
                {
                    if (time_stamp[v] < time_stamp[best_var])
                        best_var = v;
                }
            }
            return best_var;
        }
        else
        {
            best_var = goodvar_stack[rand() % goodvar_stack_fill_pointer];
            for (i = 1; i < hd_count_threshold; ++i)
            {
                v = goodvar_stack[rand() % goodvar_stack_fill_pointer];
                if (score[v] > score[best_var])
                    best_var = v;
                else if (score[v] == score[best_var])
                {
                    if (time_stamp[v] < time_stamp[best_var])
                        best_var = v;
                }
            }
            return best_var;
        }
    }

    update_clause_weights();

    int sel_c;
    Bandlit *p;
    if (hardunsat_stack_fill_pointer > 0)
    {
        while(1){
            sampled_clauses[0] = hardunsat_stack[rand() % hardunsat_stack_fill_pointer];
            if (clause_lit_count[sampled_clauses[0]] != 0)
                break;
        }
        double min = clause_score[sampled_clauses[0]], max = clause_score[sampled_clauses[0]];
        for (int i = 1; i < SC_NUM; i++){
            while(1){
                sampled_clauses[i] = hardunsat_stack[rand() % hardunsat_stack_fill_pointer];
                if (clause_lit_count[sampled_clauses[i]] != 0)
                    break;
            }
            if (clause_score[sampled_clauses[i]] < min)  min = clause_score[sampled_clauses[i]];
            if (clause_score[sampled_clauses[i]] > max)  max = clause_score[sampled_clauses[i]];
        }
        if (max == min){
            sel_c = sampled_clauses[0];
            for (int i = 1; i < SC_NUM; i++){
                if (selected_times[sampled_clauses[i]] < selected_times[sel_c])
                    sel_c = sampled_clauses[i];
                else if (selected_times[sampled_clauses[i]] == selected_times[sel_c]){
                    if (clause_weight[sampled_clauses[i]] > clause_weight[sel_c])
                        sel_c = sampled_clauses[i];
                }
            }
        }
        else{
            double max_value = clause_score[sampled_clauses[0]] + ALPHA * sqrt((log(local_times_hard + 1)) / ((double)(selected_times[sampled_clauses[0]] + 1)));
            sel_c = sampled_clauses[0];
            for (int i = 1; i < SC_NUM; i++){
                double dtemp = clause_score[sampled_clauses[i]] + ALPHA * sqrt((log(local_times_hard + 1)) / ((double)(selected_times[sampled_clauses[i]] + 1)));
                if (dtemp > max_value){
                    max_value = dtemp;
                    sel_c = sampled_clauses[i];
                }
            }
        }
        selected_times[sel_c]++;
        selected_clauses_hard[local_times_hard % BACKWARD_STEP] = sel_c;
        if (local_times_hard > 0){
            long long s = pre_unsat_hard_nb - hard_unsat_nb;
            update_clause_scores3(s);
        }
        pre_unsat_hard_nb = hard_unsat_nb;
        local_times_hard++;

    }
    else
    {
        while(1){
            sampled_clauses[0] = softunsat_stack[rand() % softunsat_stack_fill_pointer];
            if (clause_lit_count[sampled_clauses[0]] != 0)
                break;
        }
        double min = clause_score[sampled_clauses[0]], max = clause_score[sampled_clauses[0]];
        for (int i = 1; i < SC_NUM; i++){
            while(1){
                sampled_clauses[i] = softunsat_stack[rand() % softunsat_stack_fill_pointer];
                if (clause_lit_count[sampled_clauses[i]] != 0)
                    break;
            }
            if (clause_score[sampled_clauses[i]] < min)  min = clause_score[sampled_clauses[i]];
            if (clause_score[sampled_clauses[i]] > max)  max = clause_score[sampled_clauses[i]];
        }
        if (max == min){
            sel_c = sampled_clauses[0];
            for (int i = 1; i < SC_NUM; i++){
                if (selected_times[sampled_clauses[i]] < selected_times[sel_c])
                    sel_c = sampled_clauses[i];
                else if (selected_times[sampled_clauses[i]] == selected_times[sel_c]){
                    if (clause_weight[sampled_clauses[i]] > clause_weight[sel_c])
                        sel_c = sampled_clauses[i];
                }
            }
        }
        else{
            double max_value = clause_score[sampled_clauses[0]] + ALPHA * sqrt((log(local_times + 1)) / ((double)(selected_times[sampled_clauses[0]] + 1)));
            sel_c = sampled_clauses[0];
            for (int i = 1; i < SC_NUM; i++){
                double dtemp = clause_score[sampled_clauses[i]] + ALPHA * sqrt((log(local_times + 1)) / ((double)(selected_times[sampled_clauses[i]] + 1)));
                if (dtemp > max_value){
                    max_value = dtemp;
                    sel_c = sampled_clauses[i];
                }
            }
        }
        selected_times[sel_c]++;
        selected_clauses[local_times % BACKWARD_STEP] = sel_c;
        if (local_times > 0){
            long long s = pre_unsat_weight - soft_unsat_weight;
            update_clause_scores2(s);
        }
        pre_unsat_weight = soft_unsat_weight;
        local_times++;
    }
    if ((rand() % MY_RAND_MAX_INT) * BASIC_SCALE < rwprob){
        v = clause_lit[sel_c][rand() % clause_lit_count[sel_c]].var_num;
        return v;
    }

    best_var = clause_lit[sel_c][0].var_num;
    p = clause_lit[sel_c];

    //for (p++; (v = p->var_num) != 0; p++)
    //{
    for (int j = 0; j < clause_lit_count[sel_c]; j++){
        v = clause_lit[sel_c][j].var_num;
        if (score[v] > score[best_var])
            best_var = v;
        else if (score[v] == score[best_var])
        {
            if (time_stamp[v] < time_stamp[best_var])
                best_var = v;
        }
    }
    return best_var;
}

int Solver::pick_var_FPS()
{
    int i, v;
    int best_var;

    tabu_step = rand() % 5;

    if (goodvar_stack_fill_pointer > 0)
    {
        if ((rand() % MY_RAND_MAX_INT) * BASIC_SCALE < rdprob){
            v = goodvar_stack[rand() % goodvar_stack_fill_pointer];
            return v;
        }

        if (goodvar_stack_fill_pointer < hd_count_threshold)
        {
            best_var = goodvar_stack[0];
            for (i = 1; i < goodvar_stack_fill_pointer; ++i)
            {
                v = goodvar_stack[i];
                if (score[v] > score[best_var])
                    best_var = v;
                else if (score[v] == score[best_var])
                {
                    if (time_stamp[v] < time_stamp[best_var])
                        best_var = v;
                }
            }
            return best_var;
        }
        else
        {
            best_var = goodvar_stack[rand() % goodvar_stack_fill_pointer];
            for (i = 1; i < hd_count_threshold; ++i)
            {
                v = goodvar_stack[rand() % goodvar_stack_fill_pointer];
                if (score[v] > score[best_var])
                    best_var = v;
                else if (score[v] == score[best_var])
                {
                    if (time_stamp[v] < time_stamp[best_var])
                        best_var = v;
                }
            }
            return best_var;
        }
    }

    if ((rand() % MY_RAND_MAX_INT) * BASIC_SCALE < rwprob){
        update_clause_weights();
        int sel_c;

        if (hardunsat_stack_fill_pointer > 0)
        {
            sel_c = hardunsat_stack[rand() % hardunsat_stack_fill_pointer];
        }
        else
        {
            while(1){
                sel_c = softunsat_stack[rand() % softunsat_stack_fill_pointer];
                if (clause_lit_count[sel_c]>0)
                    break;
            }
        }

        best_vars[0] = clause_lit[sel_c][rand() % clause_lit_count[sel_c]].var_num;
        selected_nums = 1;
        return best_vars[0];
    }

    selected_nums = MULTI_NUMS;

    if (hardunsat_stack_fill_pointer > 0){
        for (i = 0; i < MULTI_NUMS; i++){
            sel_cs[i] = hardunsat_stack[rand() % hardunsat_stack_fill_pointer];
        }
    }
    else{
        for (i = 0; i < MULTI_NUMS; i++){
            sel_cs[i] = softunsat_stack[rand() % softunsat_stack_fill_pointer];
        }
    }

    int best_vars_num = 0;

    for (i = 0; i < MULTI_NUMS; i++){
        if (clause_lit_count[sel_cs[i]] == 0){
            selected_nums--;
            continue;
        }
        best_vars[best_vars_num] = clause_lit[sel_cs[i]][rand() % clause_lit_count[sel_cs[i]]].var_num;

        if (selected[best_vars[best_vars_num]]){
            selected_nums--;
        }
        else {
            selected[best_vars[best_vars_num]] = 1;
            best_vars_num++;
        }
    }


    for (i = 0; i < selected_nums; i++)
        selected[best_vars[i]] = 0;

    if (selected_nums == 1){
        update_clause_weights();
        return best_vars[0];
    }

    long long max_score1 = INT64_MIN, max_score2 = INT64_MIN;
    int num1, num2;

    for (i = 0; i < selected_nums; i++)
    {
        //printf("%d\n", score[best_vars[i]]);
        scores[i] = score[best_vars[i]];
        if (score[best_vars[i]] > max_score1){
            max_score1 = score[best_vars[i]]; num1 = i;
        }
        else if (score[best_vars[i]] == max_score1){
            if (time_stamp[best_vars[i]] < time_stamp[best_vars[num1]])
                num1 = i;
        }
    }

    int j;

    for (i = 0; i < selected_nums; i++)
    {
        flip2(best_vars[i]);
        step++;
        if (goodvar_stack2_num > 0){
            if (goodvar_stack2_num < SAMPLE_GOOD_NUMS)
            {
                vars2[i] = goodvar_stack2[0];
                for (j = 1; j < goodvar_stack2_num; ++j)
                {
                    v = goodvar_stack2[j];
                    if (score2[v] > score2[vars2[i]])
                        vars2[i] = v;
                    else if (score2[v] == score2[vars2[i]])
                    {
                        if (time_stamp[v] < time_stamp[vars2[i]])
                            vars2[i] = v;
                    }
                }
            }
            else
            {
                vars2[i] = goodvar_stack2[rand() % goodvar_stack2_num];
                for (j = 1; j < SAMPLE_GOOD_NUMS; ++j)
                {
                    v = goodvar_stack2[rand() % goodvar_stack2_num];
                    if (score2[v] > score2[vars2[i]])
                        vars2[i] = v;
                    else if (score2[v] == score2[vars2[i]])
                    {
                        if (time_stamp[v] < time_stamp[vars2[i]])
                            vars2[i] = v;
                    }
                }
            }
            scores[i] += score2[vars2[i]];
            if (scores[i] > 0){
                flip(best_vars[i]);
                time_stamp[best_vars[i]] = step;
                step++;
                return vars2[i];
            }
        }
        else{
            scores[i] -= 1000;
        }

        if (scores[i] > max_score1){
            if (scores[i] > max_score2){
                max_score2 = scores[i]; num2 = i;
            }
            else if (scores[i] == max_score2){
                if (time_stamp[best_vars[i]] + time_stamp[vars2[i]] < time_stamp[best_vars[num2]] + time_stamp[vars2[num2]])
                    num2 = i;
            }
        }
    }
    update_clause_weights();
    if (max_score1 >= max_score2){
        return best_vars[num1];
    }
    else{
        flip(best_vars[num2]);
        time_stamp[best_vars[num2]] = step;
        step++;
        return vars2[num2];
    }
}
void Solver::update_clause_weights()
{
    if (((rand() % MY_RAND_MAX_INT) * BASIC_SCALE) < smooth_probability && large_weight_clauses_count > large_clause_count_threshold)
    {
        smooth_weights();
    }
    else
    {
        increase_weights();
    }
}

void Solver::increase_weights()
{
    int i, c, v;
    for (i = 0; i < hardunsat_stack_fill_pointer; ++i)
    {
        c = hardunsat_stack[i];
        clause_weight[c] += h_inc;

        if (clause_weight[c] == (h_inc + 1))
            large_weight_clauses[large_weight_clauses_count++] = c;

        //for (Bandlit *p = clause_lit[c]; (v = p->var_num) != 0; p++)
        //{
        for (int j = 0; j < clause_lit_count[c]; j++){
            v = clause_lit[c][j].var_num;
            score[v] += h_inc;
            if (score[v] > 0 && already_in_goodvar_stack[v] == -1)
            {
                already_in_goodvar_stack[v] = goodvar_stack_fill_pointer;
                mypush(v, goodvar_stack);
            }
        }
    }
    for (i = 0; i < softunsat_stack_fill_pointer; ++i)
    {
        c = softunsat_stack[i];
        if (clause_weight[c] > softclause_weight_threshold)
            continue;
        else
            clause_weight[c]++;

        if (clause_weight[c] > 1 && already_in_soft_large_weight_stack[c] == 0)
        {
            already_in_soft_large_weight_stack[c] = 1;
            soft_large_weight_clauses[soft_large_weight_clauses_count++] = c;
        }

        //for (Bandlit *p = clause_lit[c]; (v = p->var_num) != 0; p++)
        //{
        for (int j = 0; j < clause_lit_count[c]; j++){
            v = clause_lit[c][j].var_num;
            score[v]++;
            if (score[v] > 0 && already_in_goodvar_stack[v] == -1)
            {
                already_in_goodvar_stack[v] = goodvar_stack_fill_pointer;
                mypush(v, goodvar_stack);
            }
        }
    }
}

void Solver::smooth_weights()
{
    int i, clause, v;

    for (i = 0; i < large_weight_clauses_count; i++)
    {
        clause = large_weight_clauses[i];
        if (sat_count[clause] > 0)
        {
            clause_weight[clause] -= h_inc;

            if (clause_weight[clause] == 1)
            {
                large_weight_clauses[i] = large_weight_clauses[--large_weight_clauses_count];
                i--;
            }
            if (sat_count[clause] == 1)
            {
                v = sat_var[clause];
                score[v] += h_inc;
                if (score[v] > 0 && already_in_goodvar_stack[v] == -1)
                {
                    already_in_goodvar_stack[v] = goodvar_stack_fill_pointer;
                    mypush(v, goodvar_stack);
                }
            }
        }
    }

    for (i = 0; i < soft_large_weight_clauses_count; i++)
    {
        clause = soft_large_weight_clauses[i];
        if (sat_count[clause] > 0)
        {
            clause_weight[clause]--;
            if (clause_weight[clause] == 1 && already_in_soft_large_weight_stack[clause] == 1)
            {
                already_in_soft_large_weight_stack[clause] = 0;
                soft_large_weight_clauses[i] = soft_large_weight_clauses[--soft_large_weight_clauses_count];
                i--;
            }
            if (sat_count[clause] == 1)
            {
                v = sat_var[clause];
                score[v]++;
                if (score[v] > 0 && already_in_goodvar_stack[v] == -1)
                {
                    already_in_goodvar_stack[v] = goodvar_stack_fill_pointer;
                    mypush(v, goodvar_stack);
                }
            }
        }
    }
}

#define MAXTRIES 1
#define MAXSTEPS 100000000

bool Solver::BandAll(int maxsteps) {

    int i, j;

    num_vars = staticNbVars;
    num_clauses = 0;

    allocate_memory();

    Var var_to_flip, v;
    int nImprovements = 0;
    static int nSolutions=0;
    vec<Var> lastArms;
    int64_t lastLocal, currentLocal=UB;
    unSAT.clear();
    double beginSattime=cpuTime();

    if (!backwardSubsume() || !eliminateEqLits_(prevEquivLitsNb))
        return false;

    clausesLS.clear();
    for(int i = 0; i < staticNbVars; i++){
        neibors[i].clear();
        inClauses[mkLit(i, false)].clear();
        inClauses[mkLit(i, true)].clear();
    }

    attachClausesForSattime(clauses);
    attachClausesForSattime(learnts_core);
    attachClausesForSattime(learnts_tier2);

    //load clauses to BandAll
    //hard clauses
    for (i=0; i<clausesLS.size(); i++) {
        ClauseLS& cls=clausesLS[i];
        Clause& c=ca[cls.cr];
        clause_lit_count[num_clauses] = c.size();
        clause_lit[num_clauses] = new Bandlit[clause_lit_count[num_clauses] + 2];
        for(j=0; j<c.size(); j++) {
            assert(value(c[j]) == l_Undef);
            clause_lit[num_clauses][j].clause_num = num_clauses;
            int lit_num = c[j].x;
            if (lit_num % 2 == 0){
                clause_lit[num_clauses][j].var_num = lit_num / 2;
                clause_lit[num_clauses][j].sense = 1;
            }
            else{
                clause_lit[num_clauses][j].var_num = (lit_num - 1) / 2;
                clause_lit[num_clauses][j].sense = 0;
            }
        }
        org_clause_weight[num_clauses] = hardWeight;
        num_clauses++;
    }
    //soft clauses
    //for (int i = 0; i < staticNbVars; i++){
    for (int i = 0; i < staticNbVars; i++){
        //if (softScore(i) != 0){
        if (auxiVar(i) && value(i)==l_Undef){
            clause_lit_count[num_clauses] = 1;
            clause_lit[num_clauses] = new Bandlit[clause_lit_count[num_clauses] + 2];
            clause_lit[num_clauses][0].clause_num = num_clauses;
            clause_lit[num_clauses][0].var_num = i;
            clause_lit[num_clauses][0].sense = sign(softLits[i]) ? 0 : 1;
            org_clause_weight[num_clauses] = weights[i];
            num_clauses++;
        }
        //}
    }

    build_instance();
    settings();
    init();

    double endSattimePreproc = cpuTime();
    double preprocTime=endSattimePreproc-beginSattime;

    opt_unsat_weight = soft_unsat_weight;

    step = 1;
    while(1){
        if (step >= maxsteps || cpuTime() - endSattimePreproc > 60)
            break;

        if (hard_unsat_nb == 0 && (soft_unsat_weight < opt_unsat_weight || best_soln_feasible == 0))
        {
            if (soft_unsat_weight < opt_unsat_weight)
            {
                maxsteps = step + 250000;
                ++nImprovements;
                printf("c Solution improved by BandAll: %lld in flip %d\n",solutionCost+soft_unsat_weight+fixedCostBySearch+derivedCost, step);
                printf("o %lld\n",solutionCost+soft_unsat_weight+fixedCostBySearch+derivedCost);
                best_soln_feasible = 1;
                opt_unsat_weight = soft_unsat_weight;

                UB = soft_unsat_weight;
                for(int v=0;v<staticNbVars;v++)
                    if (assigns[v]==l_Undef)
                        polarity[v] = !cur_soln[v];

            }
        }
        int flipvar = pick_var_BandAll();
        flip(flipvar);
        time_stamp[flipvar] = step;
        step++;
    }

    free_memory();
    /*
      getNeibors();
      double endSattimePreproc = cpuTime();
      double preprocTime=endSattimePreproc-beginSattime;

      for (i=0;i<MAXTRIES;i++) {
          // compute (and set) the number of satisfied lits, crivar,
          //and collect unsat clauses
          // compute the score of each var and collect decVars
          initialize();
          initNoise();
          assert(unSAT.size()==0);
          assert(UB==cost);
          int tenthSteps = maxsteps/100;
          for (j=0;j<maxsteps;j++) {
              if (j==tenthSteps) {
                  double tenthTime=cpuTime()-endSattimePreproc;
                  if (tenthTime > 5)
                      maxsteps=(int)((500.0/tenthTime)*tenthSteps);
              }
              if (unSAT.size()==0) {
                  ++nSolutions;
                  lastLocal=currentLocal;
                  currentLocal=cost; //countedWeight;
                  if(cost < UB){
                      ++nImprovements;
                      UB=cost;
                      for(v=0;v<staticNbVars;v++)
                        if (assigns[v]==l_Undef)
                          polarity[v] = !assignsLS[v];
                        //	if(level(v)>0)
                      //		assigns[v]=assignsLS[v]?l_True:l_False;
                      printf("c Solution improved by LS: %lld in flip %d\n",UB, j);
                      printf("o %lld\n",solutionCost+UB+fixedCostBySearch+derivedCost);
                      checkSolutionLS();
                  }
                  //All soft literals are true, the solution cannot be further improved
                  if(unsatSV.size()==0){
                    //assert(cost==0);
                      return nImprovements>0;
                  }

                  //Try to improve the solution with multi-armed bandid strategy
                  if(nSolutions>1)
                      updateDelayedReward(lastArms, lastLocal, currentLocal);
                  var_to_flip=choose_arm(nSolutions);
                  if(lastArms.size()<D_WINDOW)
                      lastArms.push(var_to_flip);
                  else //In this case the lastArms has been shifted to left when updating delayed reward
                      lastArms.last()=var_to_flip;
              }
              else
                  var_to_flip=choose_decVar();

              if (var_to_flip==var_Undef) {
                assert(decrVars.size()==0);
                  assert(unSAT.size()>0);
                  var_to_flip=my_choose_var_by_random_walk();
                  assert(var_to_flip!=var_Undef);
              }
              assert(level(var_to_flip)>0);
              assignsLS[var_to_flip]=!assignsLS[var_to_flip];
              check_implied_clauses(var_to_flip);
              flip_time[var_to_flip]=j;
              adaptNoveltyNoise(j);
              score[var_to_flip]=-score[var_to_flip];
              int totalC = inClauses[mkLit(var_to_flip, false)].size() + inClauses[mkLit(var_to_flip, true)].size();
              assert(-totalC<=score[var_to_flip] && score[var_to_flip] <= totalC);
          }
      }
    */
    double totalTime=cpuTime()-beginSattime;
    printf("c BandAll preproc time: %12.2fs, total time: %12.2fs, flips: %d, \n", preprocTime, totalTime, step);
    return true;
}