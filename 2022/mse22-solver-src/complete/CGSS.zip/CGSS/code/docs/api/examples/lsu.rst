LSU algorithm for MaxSAT (:mod:`pysat.examples.lsu`)
====================================================

.. automodule:: examples.lsu
    :no-inherited-members:
    :no-special-members:
    :private-members:
    :exclude-members: parse_options, print_usage

