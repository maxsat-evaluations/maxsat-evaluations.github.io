RC2 MaxSAT solver (:mod:`pysat.examples.rc2`)
=============================================

.. automodule:: examples.rc2
    :no-special-members:
    :private-members:
    :exclude-members: parse_options, usage
