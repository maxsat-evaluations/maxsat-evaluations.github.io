Cardinality encodings (:mod:`pysat.card`)
=========================================

.. automodule:: pysat.card
    :inherited-members:
    :no-special-members:

