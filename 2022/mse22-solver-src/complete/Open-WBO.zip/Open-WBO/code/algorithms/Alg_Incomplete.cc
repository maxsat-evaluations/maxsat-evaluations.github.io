/*!
 * \author Ruben Martins - ruben@cs.cmu.edu
 *
 * @section LICENSE
 *
 * Open-WBO, Copyright (c) 2013-2019, Ruben Martins, Vasco Manquinho, Ines Lynce
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

#include "Alg_Incomplete.h"
#define MAX_CLAUSES 3000000

using namespace openwbo;

StatusCode Incomplete::complete(uint64_t ub, vec<Lit>& pb_function, vec<uint64_t>& pb_coeffs, vec<Lit>& assumptions){
  lbool res = l_True;
  
  Encoder *pb = new Encoder(_INCREMENTAL_NONE_, _CARD_MTOTALIZER_,_AMO_LADDER_, _PB_GTE_);
  int expected_clauses = pb->predictPB(solver, pb_function, pb_coeffs, ub-1);
  printf("c Warn: changing to LSU algorithm.\n"); 
  printf("c GTE auxiliary #clauses = %d\n",expected_clauses);
  if (expected_clauses >= MAX_CLAUSES) {
    printf("c Warn: changing to Adder encoding\n");
    pb->setPBEncoding(_PB_ADDER_);
  }
  pb->encodePB(solver, pb_function, pb_coeffs, ub-1);
  
  while (true) {
    res = searchSATSolver(solver, assumptions);
    if (res == l_True) {
      uint64_t cost = computeCostModel(solver->model);
      printBound(cost);
      saveModel(solver->model);
      savePhase(solver);
      
      if (!pb->hasPBEncoding()){
          pb->encodePB(solver, pb_function, pb_coeffs, cost-1);
        }
        else
          pb->updatePB(solver, cost-1);
    } else {
      if (solver->conflict.size() == 0){
        printAnswer(_OPTIMUM_);
        return _OPTIMUM_;
      } else {
        core.clear();
        for (int i = 0; i < solver->conflict.size(); i++){
          core.insert (~solver->conflict[i]);
        }

        vec<Lit> assumptions_next;
        for (int i = 0; i < assumptions.size(); i++){
            if (core.find(assumptions[i])==core.end())
              assumptions_next.push(assumptions[i]);
          }
        assumptions.clear();
        assumptions_next.copyTo(assumptions);
        assumptions_next.clear();
      }

    }
  }
}


StatusCode Incomplete::weighted() {
  lbool res = l_True;

  solver = buildSolver();
  int currentObj = 0;
  vec<Lit> assumptions;
  vec<Lit> previous_assumptions;
  uint64_t newCost = UINT64_MAX;

  while (true) {

    assumptions.clear();
    for (int i = 0; i < objAssumps.size(); i++){
      	for (int j = 0; j < objAssumps[i].size(); j++)
        	assumptions.push(objAssumps[i][j]);
    }
    res = searchSATSolver(solver, assumptions);

    if (res == l_True) {
      nbSatisfiable++;
      newCost = computeUnweightedCostModel(solver->model, order_weights[currentObj]);
      uint64_t globalCost = computeCostModel(solver->model);
      objAssumps[currentObj].clear();
      bool updated = false;
      if (globalCost < ubCost){
        saveModel(solver->model);
        savePhase(solver);
        ubCost = globalCost;
        updated = true;
      }

      if (updated){
        if (maxsat_formula->getFormat() == _FORMAT_PB_) {
          // optimization problem
          if (maxsat_formula->getObjFunction() != NULL) {
            printBound(globalCost + off_set);
          }
        } else
          printBound(globalCost + off_set);
      }

      if (ubCost == 0) {
        // If there is a model with value 0 then it is an optimal model
          printAnswer(_OPTIMUM_);
          return _OPTIMUM_;

      } else {
            // current value is 0
            if (newCost == 0){
              objAssumps[currentObj].clear();
              for (int i = 0; i < objFunction[currentObj].size(); i++){
                objAssumps[currentObj].push(~objFunction[currentObj][i]);
              }

        		  currentObj++;
              if (currentObj >= order_weights.size()){
                // complete mode preserve assumptions except last one
                assumptions.clear();
                objAssumps[currentObj].clear();
                for (int i = 0; i < objAssumps.size(); i++){
                 for (int j = 0; j < objAssumps[i].size(); j++)
                  assumptions.push(objAssumps[i][j]);
                }

                vec<Lit> pb_function;
                vec<uint64_t> pb_coeffs;
                for (int i = 0; i < objFunction.size(); i++){
                  for(int j = 0; j < objFunction[i].size(); j++){
                    pb_function.push(objFunction[i][j]);
                    pb_coeffs.push(order_weights[i]);
                  }
                }
                return complete(ubCost, pb_function, pb_coeffs, assumptions);
        	    }

            } else if (newCost - 1 == 0){
                objAssumps[currentObj].clear();
                for (int i = 0; i < objFunction[currentObj].size(); i++){
                  objAssumps[currentObj].push(~objFunction[currentObj][i]);
                }
              } else {
                if (!encoder[currentObj]->hasCardEncoding())
                  encoder[currentObj]->buildCardinality(solver, objFunction[currentObj], newCost - 1);

               previous_assumptions.clear();
               objAssumps[currentObj].copyTo(previous_assumptions);
               encoder[currentObj]->incUpdateCardinality(solver, objFunction[currentObj], newCost - 1, objAssumps[currentObj]);
              }
      }

    } else {
      nbCores++;
      if (model.size() == 0) {
        assert(nbSatisfiable == 0);
        // If no model was found then the MaxSAT formula is unsatisfiable
        printAnswer(_UNSATISFIABLE_);
        return _UNSATISFIABLE_;
      } else {
        if (newCost == objFunction[currentObj].size()){
          objAssumps[currentObj].clear();
          for (int i = 0; i < objFunction[currentObj].size(); i++){
            objAssumps[currentObj].push(objFunction[currentObj][i]);
          }
        } else {
          // remove the last assumption 
          objAssumps[currentObj].clear();
          previous_assumptions.copyTo(objAssumps[currentObj]);
          previous_assumptions.clear();
        }
          currentObj++;

          if (currentObj >= order_weights.size()){
            core.clear();
            for (int i = 0; i < solver->conflict.size(); i++){
              core.insert (~solver->conflict[i]);
            }

            // complete mode preserve assumptions except the ones in the core
            assumptions.clear();
            for (int i = 0; i < objAssumps.size(); i++){
              for (int j = 0; j < objAssumps[i].size(); j++){
                  if (core.find(objAssumps[i][j])==core.end())
                    assumptions.push(objAssumps[i][j]);
              }
            }

            vec<Lit> pb_function;
            vec<uint64_t> pb_coeffs;
            for (int i = 0; i < objFunction.size(); i++){
              for(int j = 0; j < objFunction[i].size(); j++){
                pb_function.push(objFunction[i][j]);
                pb_coeffs.push(order_weights[i]);
                }
              }
            return complete(ubCost, pb_function, pb_coeffs, assumptions);
          }

      }
    }
  }

  return _ERROR_;
}

// Public search method
StatusCode Incomplete::search() {

  initRelaxation();
  splitFormula();

  if (maxsat_formula->getProblemType() == _WEIGHTED_) {
    weighted();
  } else
    assert(false);
}

/************************************************************************************************
 //
 // Rebuild MaxSAT solver
 //
 ************************************************************************************************/

Solver *Incomplete::buildSolver() {

  vec<bool> seen;
  seen.growTo(maxsat_formula->nVars(), false);

  Solver *S = newSATSolver();

  reserveSATVariables(S, maxsat_formula->nVars());

  for (int i = 0; i < maxsat_formula->nVars(); i++)
    newSATVariable(S);

  for (int i = 0; i < maxsat_formula->nHard(); i++)
    S->addClause(maxsat_formula->getHardClause(i).clause);

  for (int i = 0; i < maxsat_formula->nPB(); i++) {
    Encoder *enc = new Encoder(_INCREMENTAL_NONE_, _CARD_MTOTALIZER_,
                               _AMO_LADDER_, _PB_GTE_);

    // Make sure the PB is on the form <=
    // if (maxsat_formula->getPBConstraint(i)->_sign)
    //  maxsat_formula->getPBConstraint(i)->changeSign();
    assert(maxsat_formula->getPBConstraint(i)->_sign);

    enc->encodePB(S, maxsat_formula->getPBConstraint(i)->_lits,
                  maxsat_formula->getPBConstraint(i)->_coeffs,
                  maxsat_formula->getPBConstraint(i)->_rhs);

    delete enc;
  }

  for (int i = 0; i < maxsat_formula->nCard(); i++) {
    Encoder *enc = new Encoder(_INCREMENTAL_NONE_, _CARD_MTOTALIZER_,
                               _AMO_LADDER_, _PB_GTE_);

    if (maxsat_formula->getCardinalityConstraint(i)->_rhs == 1) {
      enc->encodeAMO(S, maxsat_formula->getCardinalityConstraint(i)->_lits);
    } else {

      enc->encodeCardinality(S,
                             maxsat_formula->getCardinalityConstraint(i)->_lits,
                             maxsat_formula->getCardinalityConstraint(i)->_rhs);
    }

    delete enc;
  }

  vec<Lit> clause;
  for (int i = 0; i < maxsat_formula->nSoft(); i++) {
    clause.clear();
    maxsat_formula->getSoftClause(i).clause.copyTo(clause);

    for (int j = 0; j < maxsat_formula->getSoftClause(i).relaxation_vars.size();
         j++) {
      clause.push(maxsat_formula->getSoftClause(i).relaxation_vars[j]);
    }

    S->addClause(clause);
  }

  return S;
}

/************************************************************************************************
 //
 // Other protected methods
 //
 ************************************************************************************************/

/*_________________________________________________________________________________________________
  |
  |  initRelaxation : (objective : vec<Lit>&) (weights : vec<int>&)  ->  [void]
  |
  |  Description:
  |
  |    Initializes the relaxation variables by adding a fresh variable to the
  |    'relaxationVars' of each soft clause.
  |
  |  Post-conditions:
  |    * 'objFunction' contains all relaxation variables that were added to soft
  |       clauses.
  |    * 'coeffs' contains the weights of all soft clauses.
  |
  |________________________________________________________________________________________________@*/
void Incomplete::initRelaxation() {
  for (int i = 0; i < maxsat_formula->nSoft(); i++) {
    Lit l = maxsat_formula->newLiteral();
    maxsat_formula->getSoftClause(i).relaxation_vars.push(l);
  }
}

// Print Incomplete configuration.
void Incomplete::print_Incomplete_configuration() {
  printf("c |  Algorithm: %23s                                             "
         "                      |\n",
         "Incomplete-BMO");
}

void Incomplete::splitFormula(){

  for (int i = 0; i < maxsat_formula->nSoft(); i++){
    weights.insert(maxsat_formula->getSoftClause(i).weight);
  }

  for (auto elem : weights){
    order_weights.push_back(elem);
  }

  std::sort (order_weights.begin(), order_weights.end(), greaterThan); 
  int p = 0;
  for (auto elem : order_weights){
    weight2pos[elem] = p++;
  }

  for (int i = 0; i < weights.size(); i++){
    objFunction.push();
    new (&objFunction[i]) vec<Lit>();
    objAssumps.push();
    new (&objAssumps[i]) vec<Lit>();
    Encoder * enc = new Encoder();
    enc->setIncremental(_INCREMENTAL_ITERATIVE_);
    enc->setCardEncoding(_CARD_TOTALIZER_);
    encoder.push_back(enc);
  }

  for (int i = 0; i < maxsat_formula->nSoft(); i++){
    int p = weight2pos[maxsat_formula->getSoftClause(i).weight];
    objFunction[p].push(maxsat_formula->getSoftClause(i).relaxation_vars[0]);
  }

}

uint64_t Incomplete::computeUnweightedCostModel(vec<lbool> &currentModel, uint64_t weight, bool larger) {

  assert(currentModel.size() != 0);
  uint64_t currentCost = 0;

  for (int i = 0; i < maxsat_formula->nSoft(); i++) {
    bool unsatisfied = true;
    for (int j = 0; j < maxsat_formula->getSoftClause(i).clause.size(); j++) {

      if (weight != UINT64_MAX &&
          maxsat_formula->getSoftClause(i).weight != weight && !larger) {
        unsatisfied = false;
        continue;
      }

      if (weight != UINT64_MAX &&
        maxsat_formula->getSoftClause(i).weight > weight && larger) {
        unsatisfied = false;
        continue;
      }

      assert(var(maxsat_formula->getSoftClause(i).clause[j]) <
             currentModel.size());
      if ((sign(maxsat_formula->getSoftClause(i).clause[j]) &&
           currentModel[var(maxsat_formula->getSoftClause(i).clause[j])] ==
               l_False) ||
          (!sign(maxsat_formula->getSoftClause(i).clause[j]) &&
           currentModel[var(maxsat_formula->getSoftClause(i).clause[j])] ==
               l_True)) {
        unsatisfied = false;
        break;
      }
    }

    if (unsatisfied) {
      currentCost += 1;
    }
  }

  return currentCost;
}

 // save polarity from last model 
 void Incomplete::savePhase(Solver * solver) {
  return;
  
  assert (solver->model.size() > 0);
  assert (solver->model.size() >= maxsat_formula->nInitialVars());

  solver->phase_saving = 0;

  // save the polarity of the original variables
  for (int i = 0; i < maxsat_formula->nInitialVars(); i++){
    solver->setPolarity(i, solver->model[i] == l_False);
  }

  // save the polarity of the relaxation variables
  for (int i = 0; i < maxsat_formula->nSoft(); i++){
    assert (maxsat_formula->getSoftClause(i).relaxation_vars.size() == 1);
    maxsat_formula->getSoftClause(i).relaxation_vars[0];
    int v = var(maxsat_formula->getSoftClause(i).relaxation_vars[0]);
    assert (v < solver->model.size());
    solver->setPolarity(v, solver->model[v] == l_False);
  }

 }