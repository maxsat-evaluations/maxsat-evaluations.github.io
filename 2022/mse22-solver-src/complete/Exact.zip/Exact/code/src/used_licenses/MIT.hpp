
#pragma once
namespace licenses {
extern const char* MIT;
}
