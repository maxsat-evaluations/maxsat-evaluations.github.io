### README for the HyWalk MaxSAT Solver

### MaxSAT Evaluation 2022
./hywalk_static <input-file>
