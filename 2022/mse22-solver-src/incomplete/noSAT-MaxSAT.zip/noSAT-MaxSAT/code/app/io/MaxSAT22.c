/**
 * @file MaxSAT22.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "MaxSAT22.h"

#include <ctype.h>
#include <errno.h>
#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/formulas/wcnf.h>
#include <stdlib.h>

#include "common.h"
#include "formulas/wcnf.h"

/**
 * @brief Shallow parsing just to find number of variables and clauses and allocate memory accordingly. Rewinds stream.
 *
 * @param stream
 * @param errLine
 * @return nsms_wcnf_t* NULL in case of error
 */
nsms_wcnf_t* parse0(FILE* stream, nsms_uint_t* errLine);

/**
 * @brief Shallow parsing to find the number of literals of each clause and allocate memory accordingly. Rewinds stream.
 *
 * @param stream
 * @param errLine
 * @param formula
 * @return true In case of error
 * @return false Otherwise
 */
bool parse1(FILE* stream, nsms_uint_t* errLine, nsms_wcnf_t* formula);

nsms_wcnf_t* wcnfFromMaxSAT22(FILE* stream, nsms_uint_t* errLine) {
  nsms_wcnf_t* formula = parse0(stream, errLine);

  if (formula) {
    if (!parse1(stream, errLine, formula)) {
      // indices of variables, clauses, literals being parsed
      nsms_uint_t varIdx = 0;
      nsms_uint_t clauseIdx = 0;
      nsms_uint_t literalIdx = 0;

      // parser state
      enum { ERROR = -1, COMMENT, START, WEIGHT, LITERALS, DONE } state = START;
      int read = EOF;
      nsms_uint_t lineNo = 0;

      while (((read = fgetc(stream)) != EOF) && state != ERROR && state != DONE) {
        const char c = (char)read;

        switch (state) {
          case START:
            lineNo += 1;
            if (c == 'c') {
              state = COMMENT;
            } else if (c != '\n') {
              state = WEIGHT;
              ungetc(c, stream);
            }
            break;

          case COMMENT:
            if (c == '\n') {
              state = START;
            }
            break;

          case WEIGHT:
            if (c == 'h') {
              state = LITERALS;
            } else if (isdigit(c)) {
              addDigit(&formula->clauses[clauseIdx].weight, c);
            } else if (isspace(c)) {
              if (c == '\n') {
                lineNo += 1;
              }
              if (formula->clauses[clauseIdx].weight >= 1) {
                state = LITERALS;
              }
            } else if (c == 0) {
              state = DONE;
            } else {
              state = ERROR;
            }
            break;

          case LITERALS:
            if (isspace(c) && varIdx > 0) {  // finished parsing varIdx
              const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
              nsms_wcnf_literal_t* const literal = clause->literals + literalIdx;
              nsms_wcnf_variable_t* const variable = formula->variables + varIdx - 1;

              literal->variable = variable;
              literal->clause = clause;
              variable->numLiterals += 1;

              literalIdx += 1;
              varIdx = 0;
            } else if (varIdx == 0 && c == '0') {  // end of clause
              clauseIdx += 1;
              literalIdx = 0;

              // expect next weight
              state = WEIGHT;

              const char peek = (char)fgetc(stream);
              ungetc(peek, stream);
              if (peek == '\n') {
                state = START;
              }

            } else if (c == '-') {  // current literal is negated
              formula->clauses[clauseIdx].literals[literalIdx].negated = true;
            } else if (isdigit(c)) {  // add digit to current varIdx
              addDigit(&varIdx, c);
            }
            break;

          case DONE:
          case ERROR:
            break;
        }
      }

      if (!ferror(stream) && state != ERROR) {
        // add pointers from variables to literals
        for (nsms_uint_t c = 0; c < formula->numClauses && state != ERROR; ++c) {
          const nsms_wcnf_clause_t* const clause = formula->clauses + c;
          for (nsms_uint_t l = 0; l < clause->numLiterals && state != ERROR; ++l) {
            const nsms_wcnf_literal_t* const literal = clause->literals + l;
            nsms_wcnf_variable_t* const variable = literal->variable;

            if (!variable->literals) {
              variable->literals = malloc(variable->numLiterals * sizeof(nsms_wcnf_literal_t*));
              variable->numLiterals = 0;  // for later indexing
              if (!variable->literals) {
                state = ERROR;
                lineNo = 0;
                break;
              }
            }
            variable->literals[variable->numLiterals++] = literal;
          }
        }
      }

      if (state == ERROR) {
        if (formula) {
          deleteWCNF(formula);
          formula = NULL;
        }
        if (errLine) {
          *errLine = lineNo;
        }
      }
    }
  }

  return formula;
}

bool wcnfToMaxSAT22(FILE* stream, const nsms_wcnf_t* formula) {
  for (nsms_uint_t c = 0; c < formula->numClauses; ++c) {
    const nsms_wcnf_clause_t* const clause = (formula->clauses + c);
    if (clause->weight == 0) {
      if (fputs("h ", stream) == EOF) {
        return true;
      }
    } else {
      if (fprintf(stream, NSMS_UINT_FORMAT " ", clause->weight) < 0) {
        return true;
      }
    }

    for (nsms_uint_t l = 0; l < clause->numLiterals; ++l) {
      const nsms_wcnf_literal_t* const literal = clause->literals + l;
      if (literal->negated) {
        if (fputc('-', stream) == EOF) {
          return true;
        }
      }
      if (fprintf(stream, "%zu ", literal->variable - formula->variables + 1) < 0) {
        return true;
      }
    }

    if (fputs("0\n", stream) == EOF) {
      return true;
    }
  }

  return false;
}

bool wcnfVariablesToMaxSAT22(FILE* stream, const bool* variables, nsms_uint_t numVariables) {
  if (fputs("v ", stream) == EOF) {
    return true;
  }

  for (nsms_uint_t v = 0; v < numVariables; ++v) {
    const char value = variables[v] ? '1' : '0';
    if (fputc(value, stream) == EOF) {
      return true;
    }
  }

  if (fputc('\n', stream) == EOF) {
    return true;
  }

  return false;
}

nsms_wcnf_t* parse0(FILE* stream, nsms_uint_t* errLine) {
  nsms_uint_t numVariables = 0;
  nsms_uint_t numClauses = 0;

  nsms_uint_t lineNo = 0;
  char* line = NULL;
  size_t numChars;
  errno = 0;
  while (getline(&line, &numChars, stream) != -1) {
    lineNo += 1;

    if (line[0] != 'c') {
      numClauses += 1;

      char* cur = line;
      if (cur[0] == 'h') {  // skip hard clause indicator
        cur += 1;
      } else {  // skip weight
        strtoll(cur, &cur, NSMS_DECIMAL_SYSTEM_BASE);
      }

      {
        nsms_uint_t var;
        do {
          var = llabs(strtoll(cur, &cur, NSMS_DECIMAL_SYSTEM_BASE));
          if (var > numVariables) {
            numVariables = var;
          }
        } while (var != 0);
      }
    }
  }

  rewind(stream);
  free(line);

  if (errno) {
    *errLine = lineNo;
  }

  return newWCNF(numVariables, numClauses);
}

bool parse1(FILE* stream, nsms_uint_t* errLine, nsms_wcnf_t* formula) {
  nsms_uint_t lineNo = 0;
  char* line = NULL;
  size_t numChars;
  errno = 0;
  nsms_uint_t clauseIdx = 0;
  while (getline(&line, &numChars, stream) != -1) {
    lineNo += 1;

    if (line[0] != 'c') {
      char* cur = line;
      if (cur[0] == 'h') {  // skip hard clause indicator
        cur += 1;
      } else {  // skip weight
        strtoll(cur, &cur, NSMS_DECIMAL_SYSTEM_BASE);
      }

      nsms_uint_t numLits = 0;
      while (strtoll(cur, &cur, NSMS_DECIMAL_SYSTEM_BASE) != 0) {
        numLits += 1;
      }

      if (newWCNFLiterals(formula->clauses + clauseIdx++, numLits)) {
        lineNo = 0;
        errno = 1;
        break;
      }
    }
  }

  rewind(stream);
  free(line);

  if (errno) {
    *errLine = lineNo;
    return true;
  }

  return false;
}
