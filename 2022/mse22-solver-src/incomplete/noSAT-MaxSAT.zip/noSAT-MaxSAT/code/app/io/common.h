/**
 * @file common.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief Common IO helper functions
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef IO_COMMON_H
#define IO_COMMON_H

#include <noSAT-MaxSAT/common.h>
#include <stdbool.h>

/**
 * @brief Adds a digit to the given num (in the least-significant position)
 *
 * @param num The number to add a digit to
 * @param digit The character of the digit to add, i.e., '4'
 * @return true When `isdigit()` returns false for `digit`
 * @return false When no error occurred
 */
bool addDigit(nsms_uint_t* num, char digit);

/**
 * @brief Check whether the given character is a whitespace character, but not a newline character ('\n')
 *
 * @param c The character to check
 * @return true When `c` is a non-newline whitespace character
 * @return false Otherwise
 */
bool isNonNewlineSpace(char c);

/**
 * @brief Calculated the number of digits of the given number (iteratively).
 *
 * @param num The number to calculate digits for
 * @return The number of digits of the given number
 */
nsms_uint_t numDigits(nsms_uint_t num);

#endif
