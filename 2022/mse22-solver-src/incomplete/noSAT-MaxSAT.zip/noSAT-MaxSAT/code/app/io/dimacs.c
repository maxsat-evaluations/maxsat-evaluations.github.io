/**
 * @file dimacs.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "dimacs.h"

#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/formulas/cnf.h>
#include <ctype.h>
#include <stdlib.h>

#include "common.h"
#include "formulas/cnf.h"

nsms_cnf_t* cnfFromDIMACS(FILE* stream, nsms_uint_t* errLine) {
  nsms_cnf_t* formula = NULL;

  // number of variables and clauses of the formula
  nsms_uint_t numVariables = 0;
  nsms_uint_t numClauses = 0;

  // indices of variables, clauses, literals being parsed
  nsms_uint_t varIdx = 0;
  nsms_uint_t clauseIdx = 0;
  nsms_uint_t literalIdx = 0;

  // temporary list of literals to copy from when the number of literals in a clause is known
  typedef struct LiteralList {
    nsms_literal_t literal;
    struct LiteralList* next;
  } literalList_t;
  literalList_t literalList = {.next = NULL};
  literalList_t* curLiteralListItem = &literalList;

  // parser state
  enum {
    ERROR = -1,
    COMMENT,
    LINE_START,
    C,
    N,
    F,
    NUM_VARIABLES,
    NUM_CLAUSES,
    PROBLEM_END,
    CLAUSES,
    DONE
  } state = LINE_START;
  int read = EOF;
  nsms_uint_t lineNo = 0;

  while (((read = fgetc(stream)) != EOF) && state != DONE && state != ERROR) {
    const char c = (char)read;

    switch (state) {
      case LINE_START:
        lineNo += 1;
        if (c == 'c') {
          state = COMMENT;
        } else if (c == 'p') {
          state = C;
        } else if (c != '\n') {
          state = ERROR;
        }
        break;

      case COMMENT:
        if (c == '\n') {
          state = LINE_START;
        }
        break;

      // read "cnf"
      case C:
        if (c == 'c') {
          state = N;
        } else if (isNonNewlineSpace(c)) {
          // ignore leading whitespace
        } else {
          state = ERROR;
        }
        break;

      case N:
        if (c == 'n') {
          state = F;
        } else {
          state = ERROR;
        }
        break;

      case F:
        if (c == 'f') {
          state = NUM_VARIABLES;
        } else {
          state = ERROR;
        }
        break;

      case NUM_VARIABLES:
        if (isNonNewlineSpace(c)) {
          if (numVariables > 0) {
            state = NUM_CLAUSES;
          }
        } else if (addDigit(&numVariables, c)) {
          state = ERROR;
        }
        break;

      case NUM_CLAUSES:
        if (isNonNewlineSpace(c)) {
          if (numClauses > 0) {
            state = PROBLEM_END;
          }
        } else if (numClauses > 0 && c == '\n') {
          formula = newCNF(numVariables, numClauses);
          if (formula) {
            state = CLAUSES;
          } else {
            // out of memory
            lineNo = 0;
            state = ERROR;
          }
        } else if (addDigit(&numClauses, c)) {
          state = ERROR;
        }
        break;

      case PROBLEM_END:
        if (isNonNewlineSpace(c)) {
          // ignore trailing whitespace
        } else if (c == '\n') {
          formula = newCNF(numVariables, numClauses);
          if (formula) {
            state = CLAUSES;
          } else {
            // out of memory
            lineNo = 0;
            state = ERROR;
          }
        } else {
          state = ERROR;
        }
        break;

      case CLAUSES:
        if (formula) {  // can only parse clauses if the formula was allocated
          if (clauseIdx < numClauses) {
            if (isspace(c)) {
              if (c == '\n') {
                lineNo += 1;
              }
              if (varIdx > 0) {  // finished parsing varIdx
                if (varIdx <= numVariables) {
                  curLiteralListItem->literal.variable = formula->variables + varIdx - 1;
                  varIdx = 0;

                  literalIdx += 1;
                  if (!curLiteralListItem->next) {
                    // allocate memory for next literal if necessary
                    // use calloc so curLiteralListItem->next->next is initialized with NULL (valgrind complained)
                    curLiteralListItem->next = calloc(1, sizeof(literalList_t));
                  }
                  if (curLiteralListItem->next) {
                    // prepare next literal
                    curLiteralListItem = curLiteralListItem->next;
                    curLiteralListItem->literal.negated = false;
                    curLiteralListItem->literal.variable = NULL;
                  } else {
                    // out of memory
                    lineNo = 0;
                    state = ERROR;
                  }
                } else {
                  state = ERROR;
                }
              }
            } else if (varIdx == 0 && c == '0') {  // end of clause
              if (newCNFLiterals(formula->clauses + clauseIdx, literalIdx)) {
                state = ERROR;
              } else {
                // copy from temporary literal list to literal array of the current clause
                curLiteralListItem = &literalList;
                for (nsms_uint_t i = 0; i < literalIdx; ++i) {
                  formula->clauses[clauseIdx].literals[i] = curLiteralListItem->literal;
                  curLiteralListItem = curLiteralListItem->next;
                }

                // reset literal list to beginning
                curLiteralListItem = &literalList;
                curLiteralListItem->literal.negated = false;
                curLiteralListItem->literal.variable = NULL;

                // reset literalIdx and increase clauseIdx
                literalIdx = 0;
                clauseIdx += 1;
              }
            } else if (c == '-') {
              // current literal is negated
              curLiteralListItem->literal.negated = true;
            } else if (isdigit(c)) {
              // add digit to current varIdx
              addDigit(&varIdx, c);
            }
          } else {
            state = DONE;
          }
        } else {
          // formula not allocated
          lineNo = 0;
          state = ERROR;
        }
        break;

      case DONE:  // unreachable
      case ERROR:
        break;
    }
  }

  // cleanup literal list
  curLiteralListItem = literalList.next;
  while (curLiteralListItem) {
    literalList_t* next = curLiteralListItem->next;
    free(curLiteralListItem);
    curLiteralListItem = next;
  }

  // cleanup formula in case of error
  if (ferror(stream) || state == ERROR) {
    if (errLine) {
      *errLine = lineNo;
    }
    deleteCNF(formula);
    formula = NULL;
  }

  return formula;
}

bool cnfToDIMACS(FILE* stream, const nsms_cnf_t* formula) {
  if (fprintf(stream, "p cnf %zu %zu\n", formula->numVariables, formula->numClauses) < 0) {
    return true;
  }

  for (nsms_uint_t c = 0; c < formula->numClauses; ++c) {
    const nsms_cnf_clause_t* const clause = formula->clauses + c;
    for (nsms_uint_t l = 0; l < clause->numLiterals; ++l) {
      const nsms_literal_t* const literal = clause->literals + l;
      if (literal->negated) {
        if (fputc('-', stream) == EOF) {
          return true;
        }
      }
      if (fprintf(stream, "%zu ", literal->variable - formula->variables + 1) < 0) {
        return true;
      }
    }
    if (fputs("0\n", stream) == EOF) {
      return true;
    }
  }

  return false;
}

bool cnfVariablesToDIMACS(FILE* stream, const nsms_cnf_t* formula) {
  if (fputs("v ", stream) == EOF) {
    return true;
  }

  for (nsms_uint_t v = 0; v < formula->numVariables; ++v) {
    if (!formula->variables[v]) {
      if (fputc('-', stream) == EOF) {
        return true;
      }
    }
    if (fprintf(stream, "%zu ", v + 1) < 0) {
      return true;
    }
  }

  if (fputs("0\n", stream) == EOF) {
    return true;
  }

  return false;
}
