/**
 * @file dimacs.h
 * @author Ole Lübke <ole.luebke@tuhh.de)
 * @brief DIMACS CNF IO functions
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef IO_DIMACS_H
#define IO_DIMACS_H

#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/formulas/cnf.h>
#include <stdbool.h>
#include <stdio.h>

/**
 * @brief Reads a SAT problem in
 * [DIMACS format](https://www.cs.utexas.edu/users/moore/acl2/manuals/current/manual/index-seo.php/SATLINK____DIMACS).
 *
 * @param stream The input stream to read from, e.g., a file or STDIN.
 * @param errLine In case of a parse error, `errLine` is set to the line number
 * on which the error occurred.
 * When an error occurred which was not a parse error, `errLine` is set to 0.
 * `errLine` is an optional argument, i.e., it may be NULL.
 * @return nsms_formula_t* Pointer to the resulting formula, should be freed
 * with `nsms_delete_formula()`.
 */
nsms_cnf_t* cnfFromDIMACS(FILE* stream, nsms_uint_t* errLine);

/**
 * @brief Writes a given formula to a given stream in DIMACS format.
 *
 * @param stream The stream to write to.
 * @param formula The formula to write.
 * @return true In case of error.
 * @return false When no error occurred.
 */
bool cnfToDIMACS(FILE* stream, const nsms_cnf_t* formula);

/**
 * @brief Writes the variables of a formula to the given stream in DIMACS format.
 *
 * @param stream The stream to write to.
 * @param formula The formula holding the variables to write.
 * @return true In case of error.
 * @return false When no error occured.
 */
bool cnfVariablesToDIMACS(FILE* stream, const nsms_cnf_t* formula);

#endif
