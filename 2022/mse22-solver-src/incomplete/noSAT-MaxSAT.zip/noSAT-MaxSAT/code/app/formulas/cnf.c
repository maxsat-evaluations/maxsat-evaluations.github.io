/**
 * @file cnf.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "cnf.h"

#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/formulas/cnf.h>
#include <stdlib.h>

nsms_cnf_t* newCNF(nsms_uint_t numVariables, nsms_uint_t numClauses) {
  nsms_cnf_t* formula = malloc(sizeof(nsms_cnf_t));

  if (formula) {
    formula->numVariables = numVariables;
    formula->variables = malloc(numVariables * sizeof(bool));

    formula->numClauses = numClauses;
    formula->clauses = calloc(numClauses, sizeof(nsms_cnf_clause_t));

    if (!formula->variables || !formula->clauses) {
      deleteCNF(formula);
      formula = NULL;
    }
  }

  return formula;
}

void deleteCNF(nsms_cnf_t* formula) {
  if (formula) {
    if (formula->clauses) {
      for (nsms_uint_t c = 0; c < formula->numClauses; ++c) {
        nsms_cnf_clause_t* clause = formula->clauses + c;
        if (clause->literals) {
          free(clause->literals);
          clause->literals = NULL;
        }
      }

      free(formula->clauses);
      formula->clauses = NULL;
    }

    if (formula->variables) {
      free(formula->variables);
      formula->variables = NULL;
    }

    free(formula);
  }
}

bool newCNFLiterals(nsms_cnf_clause_t* clause, nsms_uint_t numLiterals) {
  bool error = false;
  clause->numLiterals = numLiterals;
  clause->literals = malloc(numLiterals * sizeof(nsms_literal_t));
  if (!clause->literals) {
    error = true;
  }
  return error;
}
