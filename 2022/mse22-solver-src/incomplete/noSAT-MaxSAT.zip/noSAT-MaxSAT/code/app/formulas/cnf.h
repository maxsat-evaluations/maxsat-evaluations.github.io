/**
 * @file cnf.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief Functions for creating and deleting CNF formulas
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef FORMULAS_CNF_H
#define FORMULAS_CNF_H

#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/formulas/cnf.h>
#include <stdbool.h>

/**
 * @brief Allocates memory for a CNF formula.
 *
 * @param numVariables The total number of variables of the formula.
 * @param numClauses The total number of clauses of the formula.
 * @return nsms_formula_t* A pointer to a new formula, or NULL in case of error.
 */
nsms_cnf_t* newCNF(nsms_uint_t numVariables, nsms_uint_t numClauses);

/**
 * @brief Deletes the memory for a CNF formula and its variables, clauses, and literals.
 *
 * @param formula The formula to delete.
 */
void deleteCNF(nsms_cnf_t* formula);

/**
 * @brief Allocates memory for literals of a clause.
 *
 * @param clause The clause to add the literals to.
 * @param numLiterals The number of literals.
 * @return true In case of error.
 * @return false When no error occurred.
 */
bool newCNFLiterals(nsms_cnf_clause_t* clause, nsms_uint_t numLiterals);

#endif
