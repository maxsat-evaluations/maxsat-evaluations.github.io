/**
 * @file main.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <argp.h>
#include <errno.h>
#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/formulas/wcnf.h>
#include <noSAT-MaxSAT/noSAT-MaxSAT.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "common.h"
#include "formulas/wcnf.h"
#include "io/MaxSAT22.h"

#define PERCENTAGE_SCALING_FACTOR ((nsms_uint_t)10000)

typedef struct {
  const char* file;
  nsms_params_t params;
  struct {
    bool usrBMSSize, usrHWeightInc, usrSMaxWeight, usrSmoothProb, usrMaxFlips;
  } flags;
} arguments_t;

static void signalHandler(int signal);

// NOLINTNEXTLINE(readability-non-const-parameter)
static error_t parseOpt(int key, char* arg, struct argp_state* state);

static void parseUIntOpt(nsms_uint_t* val, const char* name, const char* arg, struct argp_state* state);

static void printResult();

static void run(nsms_wcnf_t* formula, const arguments_t* args);

const char* argp_program_version = "noSAT-MaxSAT";
const char* argp_program_bug_address = "<ole.luebke@tuhh.de>";

int main(int argc, char** argv) {
  char doc[] = "Try to solve MaxSAT problem read from FILE using noSAT-MaxSAT";
  char argsDoc[] = "FILE";
  struct argp_option options[] = {{"maxTries", 't', "NUM", 0, NULL, 0},
                                  {"maxFlips", 'f', "NUM", 0, NULL, 0},
                                  {"bmsSize", 'b', "NUM", 0, NULL, 0},
                                  {"hWeightInc", 'h', "NUM", 0, NULL, 0},
                                  {"sMaxWeight", 's', "NUM", 0, NULL, 0},
                                  {"smoothProb", 'p', "%", 0, NULL, 0},
                                  {0}};
  struct argp argp = {options, parseOpt, argsDoc, doc, NULL, NULL, NULL};
  arguments_t args = {.file = NULL,
                      .params = {.maxTries = NSMS_UINT_MAX, .maxFlips = NSMS_UINT_MAX},
                      .flags = {
                          .usrBMSSize = false,
                          .usrHWeightInc = false,
                          .usrSMaxWeight = false,
                          .usrSmoothProb = false,
                      }};

  // NOLINTNEXTLINE(performance-no-int-to-ptr)
  if (signal(SIGTERM, signalHandler) == SIG_ERR) {
    fprintf(stderr, "c Failed to register SIGTERM handler\n");
    exit(EXIT_FAILURE);
  }
  // NOLINTNEXTLINE(performance-no-int-to-ptr)
  if (signal(SIGINT, signalHandler) == SIG_ERR) {
    fprintf(stderr, "c Failed to register SIGINT handler\n");
    exit(EXIT_FAILURE);
  }

  argp_parse(&argp, argc, argv, 0, NULL, &args);

  FILE* inputStream = fopen(args.file, "r");
  if (inputStream) {
    nsms_uint_t errLine = 0;
    nsms_wcnf_t* formula = wcnfFromMaxSAT22(inputStream, &errLine);

    if (formula) {
      if (!(args.flags.usrBMSSize && args.flags.usrHWeightInc && args.flags.usrSMaxWeight && args.flags.usrSmoothProb &&
            args.flags.usrMaxFlips)) {
        nsms_params_t p;
        nsms_params(formula, &p);

        if (!args.flags.usrBMSSize) {
          args.params.bmsSize = p.bmsSize;
        }
        if (!args.flags.usrHWeightInc) {
          args.params.hWeightInc = p.hWeightInc;
        }
        if (!args.flags.usrSMaxWeight) {
          args.params.sMaxWeight = p.sMaxWeight;
        }
        if (!args.flags.usrSmoothProb) {
          args.params.smoothProb = p.smoothProb;
        }

        if (!args.flags.usrMaxFlips) {
          const nsms_uint_t maxFlipsFactor = 10;
          args.params.maxFlips = formula->numVariables < (NSMS_UINT_MAX / maxFlipsFactor)
                                     ? maxFlipsFactor * formula->numVariables
                                     : NSMS_UINT_MAX;
        }
      }

      run(formula, &args);

      deleteWCNF(formula);
      formula = NULL;
    } else {
      if (errLine) {
        fprintf(stderr, "c Syntax error on line " NSMS_UINT_FORMAT ".\n", errLine);
      } else {
        fprintf(stderr, "c Ran out of memory while parsing SAT problem.\n");
      }
    }

    fclose(inputStream);
  } else {
    fprintf(stderr, "c Could not open file \"%s\".\n", args.file);
  }

  return 0;
}

void signalHandler(int signal) {
  switch (signal) {
    case SIGINT:  // fall-through
    case SIGTERM:
      printResult();
      exit(EXIT_SUCCESS);
    default:
      break;
  }
}

static error_t parseOpt(int key, char* arg, struct argp_state* state) {
  arguments_t* const arguments = state->input;

  switch (key) {
    case 't':
      parseUIntOpt(&arguments->params.maxTries, "maxTries", arg, state);
      break;
    case 'f':
      parseUIntOpt(&arguments->params.maxFlips, "maxFlips", arg, state);
      arguments->flags.usrMaxFlips = true;
      break;
    case 'b':
      parseUIntOpt(&arguments->params.bmsSize, "bmsSize", arg, state);
      arguments->flags.usrBMSSize = true;
      break;
    case 'h':
      parseUIntOpt(&arguments->params.hWeightInc, "hWeightInc", arg, state);
      arguments->flags.usrHWeightInc = true;
      break;
    case 's':
      parseUIntOpt(&arguments->params.sMaxWeight, "sMaxWeight", arg, state);
      arguments->flags.usrSMaxWeight = true;
      break;
    case 'p': {
      double p = strtod(arg, NULL);
      if (p == 0.0 || errno == ERANGE) {
        argp_error(state, "Could not parse smoothProb: %s\n", arg);
      }
      arguments->params.smoothProb = (nsms_uint_t)(p * PERCENTAGE_SCALING_FACTOR);
      arguments->flags.usrSmoothProb = true;
    } break;
    case ARGP_KEY_ARG:
      if (state->arg_num >= 1) {
        argp_usage(state);
      }
      arguments->file = arg;
      break;
    case ARGP_KEY_END:
      if (!arguments->file) {
        argp_usage(state);
      }
      break;
    default:
      return ARGP_ERR_UNKNOWN;
  }

  return EXIT_SUCCESS;
}

static void parseUIntOpt(nsms_uint_t* val, const char* name, const char* arg, struct argp_state* state) {
  *val = strtoull(arg, NULL, NSMS_DECIMAL_SYSTEM_BASE);
  if (*val == 0 || errno == ERANGE) {
    argp_error(state, "Could not parse %s: %s\n", name, arg);
  }
}

static nsms_result_t result = {.status = NSMS_INFEASIBLE, .assignment = NULL, .cost = NSMS_UINT_MAX};
static nsms_uint_t numVariables = 0;

void printResult() {
  const bool optFound = result.status == NSMS_OPTIMUM_FOUND;
  const char* const msg = optFound ? "OPTIMUM FOUND" : "UNKNOWN";
  fprintf(stdout, "s %s\n", msg);
  if (result.status != NSMS_INFEASIBLE) {
    printf("o " NSMS_UINT_FORMAT "\n", result.cost);

    if (wcnfVariablesToMaxSAT22(stdout, result.assignment, numVariables)) {
      fputs("c Failed to write result.\n", stderr);
    }
  }
}

void run(nsms_wcnf_t* formula, const arguments_t* args) {
  nsms_init();

  nsms_memoryReq_t detailMemReq;
  const nsms_uint_t memReq = nsms_calcMemoryRequirements(formula, &detailMemReq);
  void* memory = malloc(memReq);

  result.assignment = malloc(formula->numVariables * sizeof(bool));

  if (memory && result.assignment) {
    numVariables = formula->numVariables;

    nsms_solve(formula, &args->params, memory, &detailMemReq, &result);

    printResult();
  } else {
    fputs("c Out of memory\n", stderr);
  }

  if (memory) {
    free(memory);
    memory = NULL;
  }
  if (result.assignment) {
    free(result.assignment);
    result.assignment = NULL;
  }
}
