/**
 * @file io.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief IO module tests
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <check.h>
#include <stdlib.h>

#include "formulas/cnf.h"
#include "formulas/wcnf.h"
#include "io/MaxSAT22.h"
#include "io/dimacs.h"

START_TEST(testDimacsIO) {
  const char* const dimacsStr =
      "p cnf 5 3\n"
      "1 -5 4 0\n"
      "-1 5 3 4 0\n"
      "-3 -4 0\n";

  const nsms_uint_t dimacsBufLen = strlen(dimacsStr) + 1;
  char* dimacsBuf = malloc(dimacsBufLen * sizeof(char));
  ck_assert_ptr_nonnull(dimacsBuf);

  strcpy(dimacsBuf, dimacsStr);
  FILE* stream = fmemopen(dimacsBuf, dimacsBufLen, "r+");
  ck_assert_ptr_nonnull(stream);

  nsms_cnf_t* formula = cnfFromDIMACS(stream, NULL);
  ck_assert_ptr_nonnull(formula);

  ck_assert_int_eq(fseek(stream, 0, SEEK_SET), 0);

  ck_assert(!cnfToDIMACS(stream, formula));

  ck_assert_str_eq(dimacsStr, dimacsBuf);

  deleteCNF(formula);
  formula = NULL;

  fclose(stream);

  free(dimacsBuf);
  dimacsBuf = NULL;
}
END_TEST

START_TEST(testMaxSAT22IO) {
  const char* const maxSAT22Str =
      "h 1 2 3 4 0\n"
      "1 -3 -5 6 7 0\n"
      "6 -1 -2 0\n"
      "4 1 6 -7 0\n";

  const nsms_uint_t maxSAT22BufLen = strlen(maxSAT22Str) + 1;
  char* maxSAT22Buf = malloc(maxSAT22BufLen * sizeof(char));
  ck_assert_ptr_nonnull(maxSAT22Buf);

  strcpy(maxSAT22Buf, maxSAT22Str);
  FILE* stream = fmemopen(maxSAT22Buf, maxSAT22BufLen, "r+");
  ck_assert_ptr_nonnull(stream);

  nsms_wcnf_t* formula = wcnfFromMaxSAT22(stream, NULL);
  ck_assert_ptr_nonnull(formula);

  ck_assert_int_eq(fseek(stream, 0, SEEK_SET), 0);

  ck_assert(!wcnfToMaxSAT22(stream, formula));

  ck_assert_str_eq(maxSAT22Str, maxSAT22Buf);

  deleteWCNF(formula);
  formula = NULL;

  fclose(stream);

  free(maxSAT22Buf);
  maxSAT22Buf = NULL;
}
END_TEST

Suite* ioSuite() {
  Suite* suite = suite_create("io");

  TCase* tcDimacs = tcase_create("DIMACS");
  tcase_add_test(tcDimacs, testDimacsIO);
  suite_add_tcase(suite, tcDimacs);

  TCase* tcMaxSAT22 = tcase_create("MaxSAT22");
  tcase_add_test(tcMaxSAT22, testMaxSAT22IO);
  suite_add_tcase(suite, tcMaxSAT22);

  return suite;
}

int main() {
  Suite* ioS = ioSuite();
  SRunner* ioSRunner = srunner_create(ioS);

  srunner_run_all(ioSRunner, CK_NORMAL);
  const int numFailedTests = srunner_ntests_failed(ioSRunner);
  srunner_free(ioSRunner);

  return (numFailedTests == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
