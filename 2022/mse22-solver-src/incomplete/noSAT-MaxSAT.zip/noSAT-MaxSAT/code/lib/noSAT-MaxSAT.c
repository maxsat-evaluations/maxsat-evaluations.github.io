/**
 * @file noSAT-MaxSAT.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "noSAT-MaxSAT.h"

#include <stddef.h>
#include <stdint.h>

#include "align.h"
#include "bigint.h"
#include "decimation.h"
#include "rng.h"

#ifdef LOGGING
#  include <stdio.h>
#endif

typedef struct {
  nsms_uint_t* weights;                  ///< (updated) weight for each clause
  nsms_uint_t* numSatLiterals;           ///< the number of sat literals for each clause
  bigint_t* scores;                      ///< the score of each variable
  const nsms_wcnf_variable_t** satVars;  ///< for each clause, the (only/first) variable which satisfies it

  nsms_uint_t numDecreasingVars;          ///< the number of decreasing variables
  nsms_wcnf_variable_t** decreasingVars;  ///< decreasing variables (with score > 0)
  nsms_uint_t* decreasingVarsIdx;         ///< for each variable, its index in decrasingVars or NSMS_UINT_MAX

  nsms_uint_t numFalsifiedHardClauses;              ///< the number of falsified hard clauses
  const nsms_wcnf_clause_t** falsifiedHardClauses;  ///< falsified hard clauses
  nsms_uint_t* falsifiedHardClausesIdx;  ///< for each clause, its index in falsifiedHardClauses or NSMS_UINT_MAX

  nsms_uint_t numFalsifiedSoftClauses;              ///< the number of falsified soft clauses
  const nsms_wcnf_clause_t** falsifiedSoftClauses;  ///< falsified soft clauses
  nsms_uint_t* falsifiedSoftClausesIdx;  ///< for each clause, its index in falsifiedSoftClauses or NSMS_UINT_MAX

  void* decimationMem;
} memory_t;

/**
 * @brief Calculates detailed memory requirements
 *
 * @param formula
 * @param out
 */
static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_memoryReq_t* out);

/**
 * @brief Calculates where pointers in out should point to
 *
 * @param mem
 * @param memReq
 * @param cfg
 * @param out
 */
static void initMemory(void* mem, const nsms_memoryReq_t* memReq, memory_t* out);

/**
 * @brief Copies weights from formula to weights
 *
 * @param formula
 * @param mem
 */
static void initWeights(const nsms_wcnf_t* formula, const memory_t* mem);

/**
 * @brief Checks the satisfiability of the formula and updates related fields in mem and cost
 *
 * @param formula
 * @param mem
 */
static void initAlgo(const nsms_wcnf_t* formula, memory_t* mem, nsms_uint_t* cost);

/**
 * @brief Updates the algorithm's output
 *
 * @param result
 * @param variables
 * @param numVariables
 * @param falsifiedHardClauseExists
 * @param cost
 * @param iter may be NULL
 */
static void updateResult(nsms_result_t* result, const nsms_wcnf_variable_t* variables, nsms_uint_t numVariables,
                         bool falsifiedHardClauseExists, nsms_uint_t cost, nsms_uint_t* iter);

/**
 * @brief Selects a variable to flip; also updates weights if no decreasing variable is found
 *
 * @param formula
 * @param cfg
 * @param mem
 * @return nsms_wcnf_variable_t*
 */
static nsms_wcnf_variable_t* selectVariable(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem);

/**
 * @brief Weighting-PMS
 *
 * @param formula
 * @param cfg
 * @param mem
 */
static void updateWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem);

/**
 * @brief Flips the value of the given variable and updates satis/falsified status and cost accordingly
 *
 * @param variable
 * @param formula
 * @param mem
 * @param cost
 */
static void flipVariable(nsms_wcnf_variable_t* variable, const nsms_wcnf_t* formula, memory_t* mem, nsms_uint_t* cost);

/**
 * @brief Check whether there are any unsatisfied clauses left
 *
 * @param mem
 * @return true When there are no unsatisfied clauses
 * @return false Otherwise
 */
static bool done(const memory_t* mem);

/**
 * @brief Adds a variable to the decreasing variables if it is not present in the list
 *
 * @param varIdx
 * @param formula
 * @param mem
 */
static void addDecreasingVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem);

/**
 * @brief Removes a variable from the decreasing variables if it is present in the list
 *
 * @param varIdx
 * @param formula
 * @param mem
 */
static void remDecreasingVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem);

/**
 * @brief Adds a clause to the specified list of clauses
 *
 * @param clauseIdx
 * @param formula
 * @param numFalsifiedClauses
 * @param falsifiedClauses
 * @param falsifiedClausesIdx
 */
static void addFalsifiedClause(nsms_uint_t clauseIdx, const nsms_wcnf_t* formula, nsms_uint_t* numFalsifiedClauses,
                               const nsms_wcnf_clause_t** falsifiedClauses, nsms_uint_t* falsifiedClausesIdx);

/**
 * @brief Removes a list from the specified list of clauses
 *
 * @param clauseIdx
 * @param formula
 * @param numFalsifiedClauses
 * @param falsifiedClauses
 * @param falsifiedClausesIdx
 */
static void remFalsifiedClause(nsms_uint_t clauseIdx, const nsms_wcnf_t* formula, nsms_uint_t* numFalsifiedClauses,
                               const nsms_wcnf_clause_t** falsifiedClauses, nsms_uint_t* falsifiedClausesIdx);

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 * @param memReq
 * @param numHardClauses
 */
void solveHard(nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem, const nsms_memoryReq_t* memReq,
               nsms_uint_t numHardClauses);

/**
 * @brief
 *
 * @param formula
 * @return nsms_uint_t The number of hard clauses in the formula
 */
nsms_uint_t moveHardClausesFirst(const nsms_wcnf_t* formula);

void nsms_init() {
  rngInit();
}

nsms_uint_t nsms_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_memoryReq_t* memReq) {
  calcMemoryReq(formula, memReq);
  return memReq->weightsMemReq + memReq->numSatLiteralsMemReq + memReq->scoresMemReq + memReq->satVarsMemReq +
         memReq->decreasingVarMemReq + memReq->decreasingVarsIdxMemReq + memReq->falsifiedHardClausesMemReq +
         memReq->falsifiedHardClausesIdxMemReq + memReq->falsifiedSoftClausesMemReq +
         memReq->falsifiedSoftClausesIdxMemReq + memReq->decimationMemReq;
}

void nsms_solve(nsms_wcnf_t* formula, const nsms_params_t* cfg, void* memory, const nsms_memoryReq_t* memReq,
                nsms_result_t* result) {
  result->status = NSMS_INFEASIBLE;
  result->cost = NSMS_UINT_MAX;
  for (nsms_uint_t v = 0; v < formula->numVariables; ++v) {  // initial random assignment
    result->assignment[v] = flipCoin();
  }

  memory_t mem;
  initMemory(memory, memReq, &mem);

  const nsms_uint_t numHardClauses = moveHardClausesFirst(formula);
  nsms_params_t solveHardParams = *cfg;
  solveHardParams.maxTries = 2;

#ifdef LOGGING
  printf("c running on a formula with " NSMS_UINT_FORMAT " variables and " NSMS_UINT_FORMAT
         " clauses \n"
         "c parameters: maxTries: " NSMS_UINT_FORMAT ", maxFlips: " NSMS_UINT_FORMAT ", bmsSize: " NSMS_UINT_FORMAT
         ", hWeightInc: " NSMS_UINT_FORMAT ", sMaxWeight: " NSMS_UINT_FORMAT ", smoothProb: " NSMS_UINT_FORMAT "\n",
         formula->numVariables, formula->numClauses, cfg->maxTries, cfg->maxFlips, cfg->bmsSize, cfg->hWeightInc,
         cfg->sMaxWeight, cfg->smoothProb);
#endif

  mem.numFalsifiedHardClauses = NSMS_UINT_MAX;  // so done check below is false on first check
  for (nsms_uint_t t = 0; t < cfg->maxTries && !done(&mem); ++t) {
#ifdef LOGGING
    printf("c try " NSMS_UINT_FORMAT "\n", t);
#endif

    initWeights(formula, &mem);
    for (nsms_uint_t v = 0; v < formula->numVariables; ++v) {  // init vars to best known assignment
      formula->variables[v].value = result->assignment[v];
    }

    nsms_decimation(formula, mem.decimationMem, &memReq->detailedDecimationMemReq, cfg->bmsSize, t > 0);

    solveHard(formula, &solveHardParams, &mem, memReq, numHardClauses);

    nsms_uint_t cost;
    initAlgo(formula, &mem, &cost);

    for (nsms_uint_t f = 0; f < cfg->maxFlips && !done(&mem); ++f) {
      updateResult(result, formula->variables, formula->numVariables, mem.numFalsifiedHardClauses > 0, cost, &f);

      nsms_wcnf_variable_t* variableToFlip = selectVariable(formula, cfg, &mem);
      flipVariable(variableToFlip, formula, &mem, &cost);
    }

    nsms_uint_t f = cfg->maxFlips;
    updateResult(result, formula->variables, formula->numVariables, mem.numFalsifiedHardClauses > 0, cost, &f);
  }
}

void nsms_params(const nsms_wcnf_t* formula, nsms_params_t* params) {
  // Values from Zhendong Lei and Shaowei Cai, Solving (Weighted) Partial MaxSAT by Dynamic Local Search for SAT, 2018

  bool isWeighted = false;
  nsms_uint_t softClauseWeight = 0;
  nsms_uint_t numSoftClauses = 0;

  for (nsms_uint_t i = 0; i < formula->numClauses; ++i) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + i;
    if (!nsms_isWCNFClauseHard(clause)) {
      numSoftClauses += 1;
      softClauseWeight += clause->weight;
      if (clause->weight != 1) {
        isWeighted = true;
      }
    }
  }

  if (!isWeighted) {
    params->bmsSize = 42;      // NOLINT(readability-magic-numbers)
    params->smoothProb = 3;    // NOLINT(readability-magic-numbers)
    params->hWeightInc = 1;    // NOLINT(readability-magic-numbers)
    params->sMaxWeight = 400;  // NOLINT(readability-magic-numbers)
  } else {
    params->bmsSize = 15;                               // NOLINT(readability-magic-numbers)
    params->smoothProb = 100;                           // NOLINT(readability-magic-numbers)
    if ((softClauseWeight / numSoftClauses) > 10000) {  // NOLINT(readability-magic-numbers)
      params->hWeightInc = 300;                         // NOLINT(readability-magic-numbers)
      params->sMaxWeight = 500;                         // NOLINT(readability-magic-numbers)
    } else {
      params->hWeightInc = 3;  // NOLINT(readability-magic-numbers)
      params->sMaxWeight = 1;  // NOLINT(readability-magic-numbers)
    }
  }
}

static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_memoryReq_t* out) {
  out->weightsMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->numSatLiteralsMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->scoresMemReq = align(formula->numVariables * sizeof(bigint_t));
  out->satVarsMemReq = align(formula->numClauses * sizeof(nsms_wcnf_variable_t*));

  out->decreasingVarMemReq = align(formula->numVariables * sizeof(nsms_wcnf_variable_t*));
  out->decreasingVarsIdxMemReq = align(formula->numVariables * sizeof(nsms_uint_t));

  out->falsifiedHardClausesMemReq = align(formula->numClauses * sizeof(nsms_wcnf_clause_t*));
  out->falsifiedHardClausesIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->falsifiedSoftClausesMemReq = align(formula->numClauses * sizeof(nsms_wcnf_clause_t*));
  out->falsifiedSoftClausesIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->decimationMemReq = align(nsms_decimation_calcMemoryRequirements(formula, &out->detailedDecimationMemReq));
}

static void initMemory(void* mem, const nsms_memoryReq_t* memReq, memory_t* out) {
  out->weights = mem;
  out->numSatLiterals = (nsms_uint_t*)((uint8_t*)out->weights + memReq->weightsMemReq);
  out->scores = (bigint_t*)((uint8_t*)out->numSatLiterals + memReq->numSatLiteralsMemReq);
  out->satVars = (const nsms_wcnf_variable_t**)((uint8_t*)out->scores + memReq->scoresMemReq);

  out->numDecreasingVars = 0;
  out->decreasingVars = (nsms_wcnf_variable_t**)((uint8_t*)out->satVars + memReq->satVarsMemReq);
  out->decreasingVarsIdx = (nsms_uint_t*)((uint8_t*)out->decreasingVars + memReq->decreasingVarMemReq);

  out->numFalsifiedHardClauses = 0;
  out->falsifiedHardClauses =
      (const nsms_wcnf_clause_t**)((uint8_t*)out->decreasingVarsIdx + memReq->decreasingVarsIdxMemReq);
  out->falsifiedHardClausesIdx =
      (nsms_uint_t*)((uint8_t*)out->falsifiedHardClauses + memReq->falsifiedHardClausesMemReq);

  out->numFalsifiedSoftClauses = 0;
  out->falsifiedSoftClauses =
      (const nsms_wcnf_clause_t**)((uint8_t*)out->falsifiedHardClausesIdx + memReq->falsifiedHardClausesIdxMemReq);
  out->falsifiedSoftClausesIdx =
      (nsms_uint_t*)((uint8_t*)out->falsifiedSoftClauses + memReq->falsifiedSoftClausesMemReq);

  out->decimationMem = (void*)((uint8_t*)out->falsifiedSoftClausesIdx + memReq->falsifiedSoftClausesIdxMemReq);
}

static void initWeights(const nsms_wcnf_t* formula, const memory_t* mem) {
  static const nsms_uint_t defaultHardClauseWeight = 1;

  for (nsms_uint_t i = 0; i < formula->numClauses; ++i) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + i;
    mem->weights[i] = nsms_isWCNFClauseHard(clause) ? defaultHardClauseWeight : clause->weight;
  }
}

static void initAlgo(const nsms_wcnf_t* formula, memory_t* mem, nsms_uint_t* cost) {
  // zero all memory that we write to (by adding) later
  *cost = 0;
  mem->numDecreasingVars = 0;
  mem->numFalsifiedHardClauses = 0;
  mem->numFalsifiedSoftClauses = 0;

  for (nsms_uint_t v = 0; v < formula->numVariables; ++v) {
    mem->scores[v].negative = false;
    mem->scores[v].value = 0;
    mem->decreasingVarsIdx[v] = NSMS_UINT_MAX;
  }

  for (nsms_uint_t c = 0; c < formula->numClauses; ++c) {
    mem->falsifiedHardClausesIdx[c] = NSMS_UINT_MAX;
    mem->falsifiedSoftClausesIdx[c] = NSMS_UINT_MAX;

    // count satisfied literals per clause
    const nsms_wcnf_clause_t* const clause = formula->clauses + c;
    const nsms_uint_t clauseWeight = mem->weights[c];

    nsms_uint_t* numSatLiterals = mem->numSatLiterals + c;
    *numSatLiterals = 0;

    for (nsms_uint_t l = 0; l < clause->numLiterals; ++l) {
      const nsms_wcnf_literal_t* const literal = clause->literals + l;

      if (nsms_isWCNFLiteralSatisfied(literal)) {
        *numSatLiterals += 1;

        if (*numSatLiterals == 1) {
          mem->satVars[c] = literal->variable;
        }
      }
    }

    if (*numSatLiterals == 1) {
      // penalize score of only satVar b/c if it is flipped, total cost increases
      bigint_sub(mem->scores + (mem->satVars[c] - formula->variables), clauseWeight);
    } else if (*numSatLiterals == 0) {
      // increase scores of all variables of the unsat clause
      for (nsms_uint_t l = 0; l < clause->numLiterals; ++l) {
        bigint_add(mem->scores + (clause->literals[l].variable - formula->variables), clauseWeight);
      }

      // add unsat clause to respective list
      if (nsms_isWCNFClauseHard(clause)) {
        addFalsifiedClause(c, formula, &mem->numFalsifiedHardClauses, mem->falsifiedHardClauses,
                           mem->falsifiedHardClausesIdx);
      } else {
        addFalsifiedClause(c, formula, &mem->numFalsifiedSoftClauses, mem->falsifiedSoftClauses,
                           mem->falsifiedSoftClausesIdx);
        // add weight of unsat clause to total cost
        *cost += clause->weight;
      }
    }
  }

  // now that initial scores for all variables are calculated, filter those that are decreasing
  for (nsms_uint_t v = 0; v < formula->numVariables; ++v) {
    addDecreasingVar(v, formula, mem);
  }
}

static void updateResult(nsms_result_t* result, const nsms_wcnf_variable_t* variables, nsms_uint_t numVariables,
                         bool falsifiedHardClauseExists, nsms_uint_t cost, nsms_uint_t* iter

) {
  if (!falsifiedHardClauseExists && cost < result->cost) {
    for (nsms_uint_t i = 0; i < numVariables; ++i) {
      result->assignment[i] = variables[i].value;  // save currently best assignment
    }

    result->cost = cost;
    result->status = cost == 0 ? NSMS_OPTIMUM_FOUND : NSMS_UNKNOWN;

    if (iter) {
#ifdef LOGGING
      printf("c found better solution with weight " NSMS_UINT_FORMAT " after " NSMS_UINT_FORMAT " iterations\n",
             result->cost, *iter);
#endif
      // just found a better assignment, keep looking
      *iter = 0;
    }
  }
}

static nsms_wcnf_variable_t* selectVariable(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem) {
  if (mem->numDecreasingVars > 0) {
    // if there are decreasing vars, draw some of them randomly (w/ replacement)and select the one with highest score
    nsms_wcnf_variable_t* bestVar = mem->decreasingVars[randIdx(mem->numDecreasingVars)];

    for (nsms_uint_t i = 1; i < cfg->bmsSize; ++i) {
      nsms_wcnf_variable_t* curVar = mem->decreasingVars[randIdx(mem->numDecreasingVars)];
      if (mem->scores[curVar - formula->variables].value > mem->scores[bestVar - formula->variables].value) {
        bestVar = curVar;
      }
    }

    return bestVar;
  }

  // if there are no decreasing vars, update weights
  updateWeights(formula, cfg, mem);

  // select a clause randomly (prefer unsatisfied hard clauses)
  nsms_uint_t numClausesToChooseFrom;
  const nsms_wcnf_clause_t** clausesToChooseFrom;
  if (mem->numFalsifiedHardClauses > 0) {
    numClausesToChooseFrom = mem->numFalsifiedHardClauses;
    clausesToChooseFrom = mem->falsifiedHardClauses;
  } else {
    numClausesToChooseFrom = mem->numFalsifiedSoftClauses;
    clausesToChooseFrom = mem->falsifiedSoftClauses;
  }

  const nsms_wcnf_clause_t* selectedClause = clausesToChooseFrom[randIdx(numClausesToChooseFrom)];

  // select variable with highest score from selected clause
  nsms_wcnf_variable_t* selectedVar = selectedClause->literals[0].variable;
  for (nsms_uint_t l = 1; l < selectedClause->numLiterals; ++l) {
    const nsms_wcnf_literal_t* const literal = selectedClause->literals + l;
    if (bigint_gt(mem->scores + (literal->variable - formula->variables),
                  mem->scores + (selectedVar - formula->variables))) {
      selectedVar = literal->variable;
    }
  }

  return selectedVar;
}

static void updateWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem) {
  if (flipBiasedCoin(cfg->smoothProb)) {
    // smooth weights
    for (nsms_uint_t c = 0; c < formula->numClauses; ++c) {
      // for each clause...
      const nsms_uint_t numSatLiterals = mem->numSatLiterals[c];
      if (numSatLiterals && mem->weights[c] > 1) {
        // ...if it is satisfied and has increased weight...
        nsms_uint_t dec = nsms_isWCNFClauseHard(formula->clauses + c) ? cfg->hWeightInc : 1;
        // ...decrease its weight
        mem->weights[c] -= dec;

        if (numSatLiterals == 1) {
          // if the clause is only satisfied by a single literal...
          const nsms_uint_t varIdx = mem->satVars[c] - formula->variables;
          // ...increase the score of the literal's variable by the decrement
          // reason: the clause has lower weight now; falsifying it by flipping the var is not as bad as before
          bigint_add(mem->scores + varIdx, dec);
          addDecreasingVar(varIdx, formula, mem);
        }
      }
    }
  } else {
    // increase weights
    for (nsms_uint_t c = 0; c < formula->numClauses; ++c) {
      // for each clause...
      const nsms_wcnf_clause_t* const clause = formula->clauses + c;

      if (!mem->numSatLiterals[c]) {
        // ...if it is falsified, select the increment value...
        nsms_uint_t inc = 1;
        if (nsms_isWCNFClauseHard(clause)) {
          inc = cfg->hWeightInc;
        } else if (mem->weights[c] >= cfg->sMaxWeight) {
          inc = 0;
        }

        // ...and increment its weight
        mem->weights[c] += inc;

        for (nsms_uint_t l = 0; inc > 0 && l < clause->numLiterals; ++l) {
          // for all variables of the clause...
          const nsms_wcnf_literal_t* const literal = clause->literals + l;
          const nsms_uint_t varIdx = literal->variable - formula->variables;
          // ...increase the score by the increment
          // reason: the clause has higher weight now; satisfying it by flipping any of the variables is even better now
          bigint_add(mem->scores + varIdx, inc);
          addDecreasingVar(varIdx, formula, mem);
        }
      }
    }
  }
}

static void flipVariable(nsms_wcnf_variable_t* variable, const nsms_wcnf_t* formula, memory_t* mem, nsms_uint_t* cost) {
  // first things first, flip the variable
  variable->value = !variable->value;

  for (nsms_uint_t l = 0; l < variable->numLiterals; ++l) {
    // for each literal (clause) the flipped variable occurs in
    const nsms_wcnf_literal_t* const literal = variable->literals[l];
    const nsms_wcnf_clause_t* const clause = literal->clause;
    const nsms_uint_t clauseIdx = (clause - formula->clauses);

    if (clauseIdx < formula->numClauses) {
      const nsms_uint_t clauseWeight = mem->weights[clauseIdx];

      nsms_uint_t* numSatLiterals = mem->numSatLiterals + clauseIdx;

      // update the number of satisfied literals
      if (nsms_isWCNFLiteralSatisfied(literal)) {
        *numSatLiterals += 1;

        if (*numSatLiterals == 1) {
          // if the clause is satisfied now
          // update the scores of all involved variables
          bigint_sub(mem->scores + (variable - formula->variables), clauseWeight);
          for (nsms_uint_t m = 0; m < clause->numLiterals; ++m) {
            const nsms_uint_t varIdx = clause->literals[m].variable - formula->variables;
            bigint_sub(mem->scores + varIdx, clauseWeight);
            remDecreasingVar(varIdx, formula, mem);
          }

          // save the only satisfying variable
          mem->satVars[clauseIdx] = variable;

          // decrease total cost by the clause's weight
          *cost -= clause->weight;

          // remove the clause from the falsified clauses
          if (nsms_isWCNFClauseHard(clause)) {
            remFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedHardClauses, mem->falsifiedHardClauses,
                               mem->falsifiedHardClausesIdx);
          } else {
            remFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedSoftClauses, mem->falsifiedSoftClauses,
                               mem->falsifiedSoftClausesIdx);
          }
        } else if (*numSatLiterals == 2) {
          // if the clause was satisfied already, but is now satisfied by 2 literals
          // update the score of the previously only satisfying variable
          const nsms_uint_t varIdx = mem->satVars[clauseIdx] - formula->variables;
          bigint_add(mem->scores + varIdx, clauseWeight);
          addDecreasingVar(varIdx, formula, mem);
        }
      } else {
        *numSatLiterals -= 1;

        if (*numSatLiterals == 1) {
          // if the clause is only satisfied by a single variable now
          // find that variable...
          for (nsms_uint_t m = 0; m < clause->numLiterals; ++m) {
            const nsms_wcnf_literal_t* const literal = clause->literals + m;
            if (nsms_isWCNFLiteralSatisfied(literal)) {
              const nsms_uint_t varIdx = literal->variable - formula->variables;
              // ...update its score..
              bigint_sub(mem->scores + varIdx, clauseWeight);
              remDecreasingVar(varIdx, formula, mem);
              // ...and save it
              mem->satVars[clauseIdx] = literal->variable;
              break;
            }
          }
        } else if (*numSatLiterals == 0) {
          // if the clause is falsified now
          // update the scores of all involved variables
          bigint_add(mem->scores + (mem->satVars[clauseIdx] - formula->variables), clauseWeight);
          for (nsms_uint_t m = 0; m < clause->numLiterals; ++m) {
            const nsms_uint_t varIdx = clause->literals[m].variable - formula->variables;
            bigint_add(mem->scores + varIdx, clauseWeight);
            addDecreasingVar(varIdx, formula, mem);
          }

          // unsave the only satisfying variable
          mem->satVars[clauseIdx] = NULL;

          // increase total costs by the clause's weight
          *cost += clause->weight;

          // add the clause to the falsified clauses
          if (nsms_isWCNFClauseHard(clause)) {
            addFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedHardClauses, mem->falsifiedHardClauses,
                               mem->falsifiedHardClausesIdx);
          } else {
            addFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedSoftClauses, mem->falsifiedSoftClauses,
                               mem->falsifiedSoftClausesIdx);
          }
        }
      }
    }
  }
}

static bool done(const memory_t* mem) {
  return mem->numFalsifiedHardClauses == 0 && mem->numFalsifiedSoftClauses == 0;
}

static void addDecreasingVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem) {
  const bigint_t* const score = mem->scores + varIdx;
  if (mem->decreasingVarsIdx[varIdx] == NSMS_UINT_MAX && !score->negative && score->value > 0) {
    // var wasn't decreasing but is now, append it to the end of the list
    mem->decreasingVars[mem->numDecreasingVars] = formula->variables + varIdx;
    mem->decreasingVarsIdx[varIdx] = mem->numDecreasingVars;
    mem->numDecreasingVars += 1;
  }
}

static void remDecreasingVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem) {
  const bigint_t* const score = mem->scores + varIdx;
  if (mem->decreasingVarsIdx[varIdx] < NSMS_UINT_MAX && (score->negative || score->value == 0)) {
    // var was decreasing but isn't anymore
    const nsms_uint_t replaceIdx = mem->decreasingVarsIdx[varIdx];

    // remove it from the list
    mem->numDecreasingVars -= 1;
    mem->decreasingVarsIdx[varIdx] = NSMS_UINT_MAX;

    // if it wasn't the last list element, move the last element to fill the gap
    if (mem->numDecreasingVars > 0 && replaceIdx < mem->numDecreasingVars) {
      nsms_wcnf_variable_t* const moveVar = mem->decreasingVars[mem->numDecreasingVars];
      mem->decreasingVars[replaceIdx] = moveVar;
      mem->decreasingVarsIdx[moveVar - formula->variables] = replaceIdx;
    }
  }
}

static void addFalsifiedClause(nsms_uint_t clauseIdx, const nsms_wcnf_t* formula, nsms_uint_t* numFalsifiedClauses,
                               const nsms_wcnf_clause_t** falsifiedClauses, nsms_uint_t* falsifiedClausesIdx) {
  // append to the end of the list
  falsifiedClauses[*numFalsifiedClauses] = formula->clauses + clauseIdx;
  falsifiedClausesIdx[clauseIdx] = *numFalsifiedClauses;
  *numFalsifiedClauses += 1;
}

static void remFalsifiedClause(nsms_uint_t clauseIdx, const nsms_wcnf_t* formula, nsms_uint_t* numFalsifiedClauses,
                               const nsms_wcnf_clause_t** falsifiedClauses, nsms_uint_t* falsifiedClausesIdx) {
  const nsms_uint_t replaceIdx = falsifiedClausesIdx[clauseIdx];

  // remove from the list
  *numFalsifiedClauses -= 1;
  falsifiedClausesIdx[clauseIdx] = NSMS_UINT_MAX;

  // if it wasn't the last element, move the last element to fill the gap
  if (*numFalsifiedClauses > 0 && replaceIdx < *numFalsifiedClauses) {
    const nsms_wcnf_clause_t* moveClause = falsifiedClauses[*numFalsifiedClauses];
    falsifiedClauses[replaceIdx] = moveClause;
    falsifiedClausesIdx[moveClause - formula->clauses] = replaceIdx;
  }
}

void solveHard(nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem, const nsms_memoryReq_t* memReq,
               nsms_uint_t numHardClauses) {
  if (numHardClauses > 0) {
    const nsms_uint_t oldNumClauses = formula->numClauses;
    formula->numClauses = numHardClauses;

    // basically nsms_solve
    for (nsms_uint_t t = 0; t < cfg->maxTries && !done(mem); ++t) {
      initWeights(formula, mem);

      nsms_decimation(formula, mem->decimationMem, &memReq->detailedDecimationMemReq, cfg->bmsSize, t > 0);

      nsms_uint_t cost;
      initAlgo(formula, mem, &cost);

      for (nsms_uint_t f = 0; f < cfg->maxFlips && !done(mem); ++f) {
        nsms_wcnf_variable_t* variableToFlip = selectVariable(formula, cfg, mem);
        flipVariable(variableToFlip, formula, mem, &cost);
      }
    }

    formula->numClauses = oldNumClauses;

#ifdef LOGGING
    if (done(mem)) {
      printf("c successfully solved hard clauses\n");
    }
#endif
  }
}

nsms_uint_t moveHardClausesFirst(const nsms_wcnf_t* formula) {
  // in-place sorting hard clauses to beginning of array
  nsms_uint_t numHardClauses = 0;
  nsms_uint_t lastHardClauseIdx = 0;

  for (nsms_uint_t c = 0; c < formula->numClauses; ++c) {
    nsms_wcnf_clause_t* const clause = formula->clauses + c;

    if (nsms_isWCNFClauseHard(clause)) {
      numHardClauses += 1;
    } else {
      // search next hard clause
      nsms_wcnf_clause_t* nextHardClause = NULL;
      for (nsms_uint_t d = (c > lastHardClauseIdx ? c : lastHardClauseIdx) + 1; d < formula->numClauses; ++d) {
        nsms_wcnf_clause_t* candidate = formula->clauses + d;
        if (nsms_isWCNFClauseHard(candidate)) {
          lastHardClauseIdx = d;
          nextHardClause = candidate;
          break;
        }
      }

      if (nextHardClause) {
        // swap places
        const nsms_wcnf_clause_t tmp = *clause;
        *clause = *nextHardClause;
        *nextHardClause = tmp;

        // update back pointers
        for (nsms_uint_t l = 0; l < clause->numLiterals; ++l) {
          clause->literals[l].clause = clause;
        }
        for (nsms_uint_t l = 0; l < nextHardClause->numLiterals; ++l) {
          nextHardClause->literals[l].clause = nextHardClause;
        }

        numHardClauses += 1;
      } else {
        break;  // all hard clauses found
      }
    }
  }

  return numHardClauses;
}
