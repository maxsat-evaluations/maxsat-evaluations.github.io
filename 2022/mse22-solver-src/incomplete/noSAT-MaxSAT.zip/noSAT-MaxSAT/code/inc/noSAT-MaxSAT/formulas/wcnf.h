/**
 * @file wcnf.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief Structs for representing a SAT formula in WCNF and associated functions
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_FORMULAS_WCNF_H
#define NSMS_FORMULAS_WCNF_H

#include <stdbool.h>

#include "common.h"

struct nsms_wcnf_literal_s;
struct nsms_wcnf_clause_s;

/**
 * @brief Type for variables
 *
 */
typedef struct {
  bool value;                                   ///> The truth value of the variable
  nsms_uint_t numLiterals;                      ///> The number of literals the variable occurs in
  const struct nsms_wcnf_literal_s** literals;  ///> Pointers to the literal the variable occurs in
} nsms_wcnf_variable_t;

/**
 * @brief A literal, i.e., a possibly negated variable
 *
 */
typedef struct nsms_wcnf_literal_s {
  bool negated;                    ///< Whether the variable of the clause is negated
  nsms_wcnf_variable_t* variable;  ///< Pointer to the variable (into the variable array of the associated formula)
  const struct nsms_wcnf_clause_s* clause;  ///> Pointer to the clause the literal is part of
} nsms_wcnf_literal_t;

/**
 * @brief A weighted CNF clause
 *
 */
typedef struct nsms_wcnf_clause_s {
  nsms_uint_t weight;             ///< The weight of the clause, 0 for hard clauses, >= 1 for soft clauses
  nsms_uint_t numLiterals;        ///< The number of literals in the clause
  nsms_wcnf_literal_t* literals;  ///< Array which hold the literals
} nsms_wcnf_clause_t;

/**
 * @brief A formula in WCNF, i.e., a conjunction of weighted clauses
 *
 */
typedef struct {
  nsms_uint_t numVariables;         ///< The total number of variables of the formula
  nsms_uint_t numClauses;           ///< The total number of clauses of the formula
  nsms_wcnf_variable_t* variables;  ///< Array which hold the variables
  nsms_wcnf_clause_t* clauses;      ///< Array which holds the clauses
} nsms_wcnf_t;
/**
 * @brief Checks whether a literal is satisfied
 *
 * @param literal The literal to check
 * @return true When the literal is satisfied
 * @return false Otherwise
 */
static inline bool nsms_isWCNFLiteralSatisfied(const nsms_wcnf_literal_t* literal) {
  return literal->variable->value != literal->negated;
}

/**
 * @brief Checks whether a clause is hard
 *
 * @param clause The clause to check
 * @return true When the clause is hard
 * @return false Otherwise
 */
static inline bool nsms_isWCNFClauseHard(const nsms_wcnf_clause_t* clause) {
  return clause->weight == 0;
}

/**
 * @brief Count the number of satisfied literals in a clause
 *
 * @param clause The clause to check
 * @return nsms_uint_t The number of satisfied literals in the clause
 */
static inline nsms_uint_t nsms_countSatLiterals(const nsms_wcnf_clause_t* clause) {
  nsms_uint_t count = 0;
  for (nsms_uint_t l = 0; l < clause->numLiterals; ++l) {
    const nsms_wcnf_literal_t* const literal = clause->literals + l;
    if (nsms_isWCNFLiteralSatisfied(literal)) {
      count += 1;
    }
  }
  return count;
}

#endif
