/**
 * @file common.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief Common definitions used across other files of the project.
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_COMMON_H
#define NSMS_COMMON_H

#include <inttypes.h>
#include <limits.h>
#include <stdint.h>

#define NSMS_UINT_FORMAT "%" PRIu64
#define NSMS_UINT_MAX UINT64_MAX
typedef uint64_t nsms_uint_t;

#endif
