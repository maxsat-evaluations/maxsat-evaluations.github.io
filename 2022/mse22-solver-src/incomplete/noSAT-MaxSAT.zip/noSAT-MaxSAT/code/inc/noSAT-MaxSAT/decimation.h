/**
 * @file decimation.h
 * @author Ole Lübke
 * @brief Unit clause propagation-based decimation (preprocessing)
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_PRIVATE_DECIMATION_H
#define NSMS_PRIVATE_DECIMATION_H

#include <stdbool.h>

#include "common.h"
#include "formulas/wcnf.h"

typedef struct {
  nsms_uint_t unassignedVarsMemReq, unassignedVarsIdxMemReq, hardUnitClausesMemReq, hardUnitClausesIdxMemReq,
      softUnitClausesMemReq, softUnitClausesIdxMemReq, prevDeciStepMemReq, clauseRemovedMemReq, numLiteralsMemReq;
} nsms_decimation_memoryReq_t;

nsms_uint_t nsms_decimation_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_decimation_memoryReq_t* memReq);

void nsms_decimation(const nsms_wcnf_t* formula, void* memory, const nsms_decimation_memoryReq_t* memReq,
                     nsms_uint_t bmsSize, bool reusePrevious);

#endif
