/**
 * @file cnf.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief Structs for representing a SAT formula in CNF and associated functions
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_FORMULAS_CNF_H
#define NSMS_FORMULAS_CNF_H

#include <stdbool.h>
#include <stddef.h>

#include "common.h"

/**
 * @brief A literal, i.e., a possibly negated variable
 *
 */
typedef struct {
  bool negated;    ///< Whether the variable of the clause is negated
  bool* variable;  ///< Pointer to the variable (into the variable array of the associated formula)
} nsms_literal_t;

/**
 * @brief A clause, i.e., a disjunction of literals
 *
 */
typedef struct {
  nsms_uint_t numLiterals;   ///< The number of literals in the clause
  nsms_literal_t* literals;  ///< Array which hold the literals
} nsms_cnf_clause_t;

/**
 * @brief A formula in CNF, i.e., a conjuction of clauses
 *
 */
typedef struct {
  nsms_uint_t numVariables;    ///< The total number of variables of the formula
  nsms_uint_t numClauses;      ///< The total number of clauses of the formula
  bool* variables;             ///< Array which hold the variables
  nsms_cnf_clause_t* clauses;  ///< Array which holds the clauses
} nsms_cnf_t;

#endif
