
#pragma once
namespace licenses {
extern const char* zib_academic;
}
