library(viridis)
options(digits=5, scipen=100)
fs <- 1.4

time_min <- 0.01
time_max <- 7200

data <- read.csv("results.csv", sep=",")
data <- data[order(data$app, data$instance, data$solver),]
data[is.na(data$result),]$cputime <- 7200

n_solvers <- length(unique(data$solver))
colors <- viridis(n_solvers)

apps <- unique(data$app)
solvers <- unique(data$solver)

for (app in apps) {
    data_ <- data[data$app == app,]
    data_ <- data_[order(data_$cputime),]
    pdf(paste("cactus_ipamir", app, ".pdf", sep = ""))
    par(pty="s", lwd=2)
    i = 0
    xlim_max <- 0
    for (solver in solvers) {
        xlim_max <- max(xlim_max, length(data_[data_$solver == solver & data_$cputime != 7200,]$cputime))
    }
    for (solver in solvers) {
        if (i == 0) {
            xlim <- c(0, xlim_max)
            plot(data_[data_$solver == solver & data_$cputime != 7200,]$cputime, type="b", lwd=2, lty=i+1, pch=i+1, col=colors[i+1], xlab="instances solved", ylab="CPU time (s)", cex.axis=fs, cex.lab=fs, xlim=xlim, ylim=c(time_min, time_max), yaxt="n", main=app)
        } else {
            lines(data_[data_$solver == solver & data_$cputime != 7200,]$cputime, type="b", lwd=2, lty=i+1, pch=i+1, col=colors[i+1])
        }
        i <- i+1
    }
    abline(h=time_max, lwd=2)
    axis(2, gap.axis=-100, cex.axis=fs)
    legend("topleft", legend=solvers, col=colors, lwd=rep(2, n_solvers), lty=seq(1, n_solvers), pch=seq(1, n_solvers), cex=fs, bg="white")
    dev.off()
}