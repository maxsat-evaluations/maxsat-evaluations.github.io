import glob
from pathlib import Path

apps = ["adaboost", "extenf", "ic3ref", "bioptsat", "mlicseesaw"]
dirs = ["mse22-ipamir" + app for app in apps]

csv = open("results.csv", "w")
header = ["app", "instance", "solver", "wctime", "cputime", "usertime", "systemtime", "cpuusage", "maxvm", "maxmm", "maxrss", "timeout", "memout", "exitstatus", "result"]
csv.write(",".join(header) + "\n")
csv_lines = []

for directory in dirs:
    for file in Path("./" + directory).rglob("*.log"):
        app = directory.replace("mse22-ipamir", "")
        instance = ".".join(str(file).split("/")[-1].split(".")[:-2])
        solver = str(file).split("/")[-1].split(".")[-2]
        contents = open(file).read().split("\n")[:-1]
        stats = [line for line in contents[-22:] if not line.startswith("#")]
        stats = [line for line in stats if not "# WCTIME" in line]
        stats = [stat.split("=")[1] for stat in stats]
        row = [app, instance, solver] + stats

        result = "NA"
        if app == "adaboost":
            result_line = [line for line in contents if line.startswith("c Final training accuracy = ")]
            if len(result_line) > 0:
                assert(len(result_line) == 1)
                result = result_line[0].split(" = ")[-1]
        elif app == "extenf":
            result_line = [line for line in contents if line.startswith("o ")]
            if len(result_line) > 0:
                assert(len(result_line) == 1)
                result = result_line[0].replace("o ", "")
        elif app == "ic3ref":
            result_line = [line for line in contents if line == "0" or line == "1"]
            if len(result_line) > 0:
                assert(len(result_line) == 1)
                result = result_line[0]
        elif app == "bioptsat":
            result_lines = [line for line in contents if line.startswith("c SOLUTION: ")]
            finished = [line for line in contents if line.startswith("c INFO: there are no more pareto-optimal solutions")]
            if len(finished) > 0:
                result_lines = [[word.split("=")[1].replace(",", "") for word in line.split() if word.startswith("inc=") or word.startswith("dec=")] for line in result_lines]
                result = ";".join([";".join(line) for line in result_lines])
        elif app == "mlicseesaw":
            result_lines = [line for line in contents if line.startswith("c SOLUTION: ")]
            finished = [line for line in contents if line.startswith("c Terminating algorithm due to ")]
            if len(finished) > 0:
                result_lines = [[word.split("=")[1].replace(",", "") for word in line.split() if word.startswith("inc=") or word.startswith("dec=")] for line in result_lines]
                result = ";".join([";".join(line) for line in result_lines])
        row += [result]
        csv_lines += [",".join(row) + "\n"]

csv_lines.sort()
for line in csv_lines:
    csv.write(line)

csv.close()