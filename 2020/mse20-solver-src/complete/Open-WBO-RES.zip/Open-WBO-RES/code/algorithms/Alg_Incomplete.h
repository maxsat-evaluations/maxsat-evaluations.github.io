/*!
 * \author Ruben Martins - ruben@cs.cmu.edu
 *
 * @section LICENSE
 *
 * Open-WBO, Copyright (c) 2013-2019, Ruben Martins, Vasco Manquinho, Ines Lynce
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

#ifndef Alg_Incomplete_h
#define Alg_Incomplete_h

#ifdef SIMP
#include "simp/SimpSolver.h"
#else
#include "core/Solver.h"
#endif

#include "../Encoder.h"
#include "../MaxSAT.h"
#include <map>
#include <set>
#include <vector>
#include <iostream>


using NSPACE::vec;
using NSPACE::Lit;

namespace openwbo {

//=================================================================================================
class Incomplete : public MaxSAT {

public:
  Incomplete(int verb = _VERBOSITY_MINIMAL_)
      : solver(NULL) {
    verbosity = verb;
  }

  ~Incomplete() {
    if (solver != NULL)
      delete solver;
  }

  StatusCode search(); // Linear search.

  // Print solver configuration.
  void printConfiguration(bool bmo, int ptype) {

    if(!print) return;

    printf("c ==========================================[ Solver Settings "
           "]============================================\n");
    printf("c |                                                                "
           "                                       |\n");
    print_Incomplete_configuration();
    printf("c |                                                                "
           "                                       |\n");
  }

protected:
  Solver *buildSolver();
  StatusCode weighted();
  
  // Greater than comparator.
  bool static greaterThan(uint64_t i, uint64_t j) { return (i > j); }

  // Other
  void initRelaxation(); // Relaxes soft clauses.

  void print_Incomplete_configuration();

  // savePhase
  void savePhase(Solver * solver);
  uint64_t computeUnweightedCostModel(vec<lbool> &currentModel,
                            uint64_t weight = UINT64_MAX,
                            bool larger = false);
  void splitFormula();
  StatusCode backwards_weighted(vec<uint64_t>& opts);
  StatusCode complete(uint64_t ub, vec<Lit>& pb_function, vec<uint64_t>& pb_coeffs, vec<Lit>& assumptions);

  std::set<uint64_t> weights;
  std::vector<uint64_t> order_weights;
  vec<vec<Lit>> objFunction;
  vec<vec<Lit>> objAssumps;
  std::set<Lit> core;
  std::map<uint64_t,int> weight2pos;

  Solver *solver;  // SAT Solver used as a black box.
  std::vector<Encoder*> encoder; // Interface for the encoder of constraints to CNF.
  int encoding;    // Encoding for cardinality constraints.
  int pb_encoding;

};
} // namespace openwbo

#endif
