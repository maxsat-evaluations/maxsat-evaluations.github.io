/*
 *  Copyright (C) 2018  Mario Alviano (mario@alviano.net)
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

#include "Autarkies.h"

namespace zuccherino {

AutarkiesPropagator::AutarkiesPropagator(GlucoseWrapper& solver) : Propagator(solver), nextToPropagate(0), toSatisfy(0) {}

AutarkiesPropagator::AutarkiesPropagator(GlucoseWrapper& solver, const AutarkiesPropagator& init) : Propagator(solver, init), nextToPropagate(init.nextToPropagate), conflictLit(init.conflictLit), data(init.data), clauseData(init.clauseData), toSatisfy(init.toSatisfy) {
}

bool AutarkiesPropagator::activate() {
    assert(solver.decisionLevel() == 0);
    return true;
}
    
void AutarkiesPropagator::onCancel() {
    while(nextToPropagate > solver.nAssigns()) {
        Lit lit = solver.assigned(--nextToPropagate);
        
        if(data.has(lit)) {
            vec<unsigned>& c = clauses(lit);
            for(int i = 0; i < c.size(); i++) {
                ClauseData& cd = clauseData[c[i]];
                cd.satisfied--;
                if(cd.satisfied == 0 && cd.touched > 0) toSatisfy++;
            }
        }
        
        if(data.has(~lit)) {
            vec<unsigned>& c = clauses(~lit);
            for(int i = 0; i < c.size(); i++) {
                ClauseData& cd = clauseData[c[i]];
                cd.touched--;
                if(cd.satisfied == 0 && cd.touched == 0) toSatisfy--;
            }
        }
        
    }
}

bool AutarkiesPropagator::simplify() {
    return propagate();
}

bool AutarkiesPropagator::propagate() {
    while(nextToPropagate < solver.nAssigns()) {
        Lit lit = solver.assigned(nextToPropagate);

        if(data.has(lit)) {
            vec<unsigned>& c = clauses(lit);
            for(int i = 0; i < c.size(); i++) {
                ClauseData& cd = clauseData[c[i]];
                if(cd.satisfied == 0 && cd.touched > 0) toSatisfy--;
                cd.satisfied++;
            }
        }
        
        if(data.has(~lit)) {
            vec<unsigned>& c = clauses(~lit);
            for(int i = 0; i < c.size(); i++) {
                ClauseData& cd = clauseData[c[i]];
                if(cd.satisfied == 0 && cd.touched == 0) toSatisfy++;
                cd.touched++;
            }
        }
        
        nextToPropagate++;
    }
    
    cout << nextToPropagate << "  " << toSatisfy << endl;
    return true;
}

void AutarkiesPropagator::getConflict(vec<Lit>& ret) {
    
}

void AutarkiesPropagator::getReason(Lit lit, vec<Lit>& ret) {
    
}

void AutarkiesPropagator::add(const Clause& clause) {
    for(int i = 0; i < clause.size(); i++) {
        Lit lit = clause[i];
        if(!data.has(lit)) data.push(solver, lit);
        clauses(lit).push(clauseData.size());
    }
    clauseData.push();
}

} // zuccherino
