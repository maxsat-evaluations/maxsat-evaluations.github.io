This is going to be the Pacose MaxSAT solver.

To generate a makefile follow the steps indicated below.

But at first git clone the solver-proxy repository directly from the pacose folder:
git clone https://<username>@projects.informatik.uni-freiburg.de/git/solver-proxy.git

Then follow the readme.txt steps in that folder, after this, continue with the following steps

mkdir build
cd build
cmake ..
make		// generates a bin directory and a binary ../bin/Pacose is produced (if working)


