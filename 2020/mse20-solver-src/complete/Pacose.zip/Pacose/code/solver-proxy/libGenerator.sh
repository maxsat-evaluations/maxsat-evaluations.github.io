#!/bin/bash

#mkdir -p libs
for d in ../*/ ; do
#	echo $d
  if [[ "$d" != "../libs/" &&  "$d" != "../build/" ]]; then
    cp $d*.a .
  fi
done
rm libSATSolverProxy.a
for f in *.a; do
  echo $f
  ar -x $f
done

ar -qc libSATSolverProxy.a  *.o
ar -qc libSATSolverProxy.a  *.or
shopt -s extglob
rm !("libSATSolverProxy.a"|"libGenerator.sh")
shopt -u extglob
