/*
 *  Copyright (C) 2018  Mario Alviano (mario@alviano.net)
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
 
#ifndef zuccherino_autarkies_propagator_h
#define zuccherino_autarkies_propagator_h

#include "Data.h"
#include "Propagator.h"

namespace zuccherino {

class AutarkiesPropagator : public Propagator {
public:
    AutarkiesPropagator(GlucoseWrapper& solver);
    AutarkiesPropagator(GlucoseWrapper& solver, const AutarkiesPropagator& init);

    virtual bool activate();
    
    virtual void onCancel();
    virtual bool simplify();
    virtual bool propagate();
    
    virtual void getConflict(vec<Lit>& ret);
    virtual void getReason(Lit lit, vec<Lit>& ret);

    void add(const Clause& clause);
    
private:
    int nextToPropagate;
    Lit conflictLit;
    
    struct LitData : LitDataBase {
        vec<unsigned> clauses;
    };

    Data<VarDataBase, LitData> data;
    
    inline vec<unsigned>& clauses(Lit l) { return data(l).clauses; }

    struct ClauseData {
        inline ClauseData() : touched(0), satisfied(0) {}
        unsigned touched;
        unsigned satisfied;
    };
    
    vec<ClauseData> clauseData;
    
    int toSatisfy;

};
    
} // zuccherino

#endif
