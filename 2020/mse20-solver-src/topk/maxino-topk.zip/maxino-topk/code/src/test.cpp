/*
 *  Copyright (C) 2017  Mario Alviano (mario@alviano.net)
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

#include "utils/main.h"

#include "2QBF.h"
#include "MaxSAT.h"
#include "Autarkies.h"

#include <vector>

void SIGINT_interrupt(int) {
}

//static zuccherino::MaxSATExchange* solver = NULL;
//void SIGINT_interrupt(int) { 
//    solver->interrupt();
//    sleep(1);
//    exit(1);
//}
//
//class MyListener : public zuccherino::MaxSATExchange::Listener {
//    virtual void onNewLowerBound(int64_t value) { cout << "lb " << value << endl; }
//    virtual void onNewUpperBound(int64_t value) { cout << "ub " << value << endl; }
//    virtual void onNewClause(const std::vector<int>& clause) { cout << "add"; for(unsigned i = 0; i < clause.size(); i++) cout << " " << clause[i]; cout << endl; }
//    virtual void onNewEqual(const std::vector<int>& lits, int64_t bound) { cout << "add"; for(unsigned i = 0; i < lits.size(); i++) cout << " " << lits[i]; cout << " = " << bound << endl; }
//};

int main(int argc, char** argv) {
    premain();
    
    Glucose::setUsageHelp(
        "usage: %s [flags] [input-file]\n");

    Glucose::parseOptions(argc, argv, true);

    if(argc > 2) {
        cerr << "Extra argument: " << argv[2] << endl;
        exit(-1);
    }
    
    zuccherino::Autarkies solver;
//    solver.newVar();
//    solver.newVar();
//    
//    Glucose::vec<Lit> v;
//    v.push(mkLit(0));
//    v.push(mkLit(1));
//        
//    solver.addClause(v);
//    
//    solver.solve();
    
    /*
    std::vector<std::vector<int> > clauses;
    std::vector<int64_t> weights;

    clauses.push_back(std::vector<int>());
    clauses.back().push_back(1);
    clauses.back().push_back(2);
    clauses.back().push_back(3);
    weights.push_back(1000);

    clauses.push_back(std::vector<int>());
    clauses.back().push_back(1);
    clauses.back().push_back(2);
    clauses.back().push_back(4);
    weights.push_back(1000);

    clauses.push_back(std::vector<int>());
    clauses.back().push_back(1);
    clauses.back().push_back(3);
    clauses.back().push_back(4);
    weights.push_back(1000);

    clauses.push_back(std::vector<int>());
    clauses.back().push_back(2);
    clauses.back().push_back(3);
    clauses.back().push_back(4);
    weights.push_back(1000);
    
    for(int i = 1; i <= 4; i++) {
        clauses.push_back(std::vector<int>());
        clauses.back().push_back(-i);
        weights.push_back(1);
    }
    //*/
    
    /*
    clauses.push_back(std::vector<int>());
    clauses.back().push_back(1);
    clauses.back().push_back(2);
    clauses.back().push_back(3);
    weights.push_back(1000);
    
    clauses.push_back(std::vector<int>());
    clauses.back().push_back(4);
    clauses.back().push_back(5);
    weights.push_back(1000);

    for(int i = 1; i <= 4; i++) {
        clauses.push_back(std::vector<int>());
        clauses.back().push_back(-i);
        weights.push_back(1);
    }
    clauses.push_back(std::vector<int>());
    clauses.back().push_back(-5);
    weights.push_back(2);
    //*/
    
//    zuccherino::MaxSATExchange solver(clauses, weights, 1000);
//    ::solver = &solver;
//    
//    MyListener listener;
//    solver.setListener(&listener);
//    
//    std::vector<int> unsat_core;
//    unsat_core.push_back(-1);
//    unsat_core.push_back(-2);
//    unsat_core.push_back(-3);
//    solver.start(unsat_core, INT64_MAX);
    
    gzFile in = argc == 1 ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
    solver.parse(in);
    gzclose(in);
    
    solver.eliminate(true);
    if(!solver.okay()) {
        cout << "UNSATISFIABLE" << endl;
        exit(20);
    }
    
    lbool ret = solver.solve();
    
#ifndef NDEBUG
    exit(ret == l_True ? 10 : ret == l_False ? 20 : 0);     // (faster than "return", which will invoke the destructor for 'Solver')
#endif
    return (ret == l_True ? 10 : ret == l_False ? 20 : 0);
}
