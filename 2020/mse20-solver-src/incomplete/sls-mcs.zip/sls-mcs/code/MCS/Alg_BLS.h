#ifndef BLS_h
#define BLS_h

#ifdef SIMP
#include "simp/SimpSolver.h"
#else
#include "core/Solver.h"
#endif

// #include "../MaxSAT.h"
#include "MaxSAT.h"
#include "utils/System.h"
#include <utility>
#include <map>
#include <vector>

namespace openwbo {
  
  class BLS : public MaxSAT {
    
  public:
    BLS(int verb = _VERBOSITY_MINIMAL_, int weight = _WEIGHT_NONE_, int strategy = _WEIGHT_NONE_, int limit = INT32_MAX){
      solver = NULL;
      verbosity = verb;
      
      nbCores = 0;
      nbSatisfiable = 0;
      nbSatCalls = 0;
      sumSizeCores = 0;
      
      nbMCS = 0;
      _smallestMCS = UINT64_MAX;
      _lbWeight = 0;
      _maxMCS = 30;
      _maxSAT = false;
      _useCores = false;
      _useAllVars = false;
      conflict_limit = 100000;
      strat_lwr = 15.0;     // MTN - stratification: 15.0 is what we used for MOCO; decrease if too few or too big partitions
      part_confl_limit = 20000; // MTN - stratification: conflicts allowed before merging with next partition
    }
    
    ~BLS(){
      if (solver != NULL)
        delete solver;
    }
    
    void search();                                      // BLS search.
    void printAnswer(int type);                         // Print the answer.
    
    void setUseCores(bool c) { _useCores = c; }
    void setMaxSAT(bool m) { _maxSAT = m; }
    void setMaxMCS(int n) { _maxMCS = n; }
    void setAllVarUsage(bool all_bones) { 
      _useAllVars = all_bones; // false: only use soft vars in quasibones. true: use all vars
    }
    void setConflictLimit(int64_t limit) { conflict_limit = limit; }
    
    // return the quasi-bones 
    vec<Lit>& getQuasiBones(){
      return _quasibones;
    }
    
    vec<float>& getVariablesScore() {
      return _varScore;
    }
    
    uint64_t getCost(){ // Unweighted. TODO: Save weighted solution!
      return _smallestMCS;
    }

    Solver* getSolver(){
      return solver;
    }
    
    void printSmallestModel();                          // Print the best satisfying model.
    std::vector<int> getSmallestModel();

    
    void my_search(vec<Lit>& assumpt);                                      // BLS search. - AG
    Solver * my_getSolver(); //AG - estava como protected
  protected:
    
    void my_basicSearch(vec<Lit>& assumpt, int maxMCS, bool maxsat); //AG
    bool my_findNextMCS(vec<Lit>& assumpt);
    bool my_findNextStratifiedMCS(vec<Lit>& assumpt);
    
    // Rebuild MaxSAT solver
    //
    Solver * buildSolver();
    
    lbool solve();                                      // SAT solver call
    
    // Utils for model management
    //
    void saveModel(vec<lbool> &currentModel);             // Saves a Model.
    void saveSmallestModel(vec<lbool> &currentModel);     // Saves the smallest model found until now.
    
    // init methods
    void init();
    
    void initUndefClauses(vec<int>& undefClauses);
    void initStratifiedUndefClauses(vec<int>& undef, int part_i);
    
    // Core Management
    void identifyDisjointCores();
    uint64_t coreMinCost(int c);
    
    // BLS search
    //
    void basicSearch(int maxMCS, bool maxsat);
    void basicCoreBasedSearch(int maxMCS, bool maxsat);
    
    bool findNextMCS();
    bool findNextStratifiedMCS();
    bool findNextCoreBasedMCS();
    void addMCSClause(vec<int>& unsatClauses);
    void addBackboneLiterals(int softIndex);
    
    // Utils for printing
    //
    void printModel();                                  // Print the last model.
//     void printSmallestModel();                          // Print the best satisfying model.
    void printStats();                                  // Print search statistics.
    
    // Other utils
    bool satisfiedSoft(int i);
    uint64_t computeModelCost();
    inline int64_t getPartConflBudget() {
        int64_t remaining = confl_top - solver->conflicts;
        return (remaining < part_confl_limit) ? remaining : part_confl_limit;
    }
    inline int64_t getRemainingConflBudget() {
        return confl_top - solver->conflicts;
    }

    
  protected:
    //Data Structures
    
    // SAT solver and MaxSAT database
    //
    Solver* solver;                                     // SAT solver used as a black box.
    int verbosity;                                      // Controls the verbosity of the solver.
    
    // Options
    int _maxMCS;
    bool _maxSAT;
    bool _useCores;
    bool _useAllVars;
    int64_t conflict_limit;
    
    // Core extraction 
    //
    std::map<Lit,int> coreMapping;                      // Maps the assumption literal to the number of the soft clause.
    vec<Lit> assumptions;                               // Stores the assumptions to be used in the extraction of the core.
    vec<int> _prevAssumptions;
    
    vec< vec<int> > _cores;
    vec< vec<int> > _coreSatClauses;
    vec< vec<int> > _coreUnsatClauses;
    vec<int> _satClauses;
    
    // Symmetry breaking
    //
    vec<int> indexSoftCore;                             // Indexes of soft clauses that appear in the current core.
    vec< vec<int> > softMapping;                        // Maps the soft clause with the cores where they appears.
    
    // Statistics
    //
    int nbCores;                                        // Number of cores.
    uint64_t sumSizeCores;                              // Sum of the sizes of cores.
    int nbSatisfiable;                                  // Number of satisfiable calls.
    int nbSatCalls;                                     // Number of SAT solver calls.
    int nbMCS;
    
    //MCS Management
    uint64_t _maxWeight;
    uint64_t _smallestMCS;
    uint64_t _lbWeight;
    vec<lbool> _smallestModel;
    int _nMCS;
    
    // Quasi-Bones
    vec<int> _soft_variables;
    vec<int> _assigned_true;
    vec<Lit> _quasibones;
    vec<float> _varScore;

    // Stratification
    double strat_lwr;
    int64_t part_confl_limit;
    uint64_t confl_top = UINT64_MAX;
    vec<uint64_t> weight_order;
  };
}

#endif
 
