#include "basis_pms.h"
#include "pms.h"

int main(int argc, char* argv[])
{
	start_timing();
#if VARIANT == 1
    printf("c this is sls-mcs solver\n");
#elif VARIANT == 2
    printf("c this is sls-lsu solver\n");
#endif
	Satlike s;
	vector<int> init_solution;
	s.build_instance(argv[1]);
	s.local_search_with_decimation(init_solution,argv[1]);
	//s.simple_print();
	s.free_memory();
	
    return 0;
}
