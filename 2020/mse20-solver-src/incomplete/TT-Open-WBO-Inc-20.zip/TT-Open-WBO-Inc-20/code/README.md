### README for the TT-Open-WBO-Inc MaxSAT Solver
### Version 1.0 -- 24 May 2020

TT-Open-WBO-Inc is an anytime MaxSAT solver. It's a spin-off of Open-WBO-Inc. It won both the weighted, incomplete categories at MaxSAT Evaluation 2019. It has been submissted to both weighted and unweighted incomplete categories to MaxSAT Evaluation 2020.

### MaxSAT Evaluation 2020
./tt-open-wbo-inc <input-file>

Author: Alexander Nadel
Authors and Contributors of Open-WBO-Inc: Ruben Martins, Vasco Manquinho, Ines Lynce, Miguel Neves, Saurabh Joshi, Mikolas Janota
To contact the author please send an email to:  alexander.nadel@cs.tau.ac.il
