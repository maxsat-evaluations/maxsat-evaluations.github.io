#include "Alg_BLS.h"
#include <vector>


using namespace openwbo;
//using namespace NSPACE;




/************************************************************************************************
 //
 // Utils for model management
 //
 ************************************************************************************************/ 

/*_________________________________________________________________________________________________
  |
  |  saveModel : (currentModel : vec<lbool>&)  ->  [void]
  |  
  |  Description:
  |		 
  |    Saves the current model found by the SAT solver.
  |
  |  Pre-conditions:
  |    * Assumes that 'nbInitialVariables' has been initialized.
  |    * Assumes that 'currentModel' is not empty.
  |
  |  Post-conditions:
  |    * 'model' is updated to the current model.
  |    * 'nbSatisfiable' is increased by 1.
  |
  |________________________________________________________________________________________________@*/
void BLS::saveModel(vec<lbool> &currentModel){
  //assert (n_initial_vars != 0);
  assert (currentModel.size() != 0);
  
  model.clear();
  // Only store the value of the variables that belong to the original MaxSAT formula.
  for (int i = 0; i < maxsat_formula->nVars(); i++){
    model.push(currentModel[i]);
  }
  
  nbSatisfiable++;
}


void BLS::saveSmallestModel(vec<lbool> &currentModel){
  //assert (n_initial_vars != 0);
  assert (currentModel.size() != 0);
  
  _smallestModel.clear();
  // Only store the value of the variables that belong to the original MaxSAT formula.
  for (int i = 0; i < maxsat_formula->nVars(); i++){
    _smallestModel.push(currentModel[i]);
  }
}


/************************************************************************************************
 //
 // BLS search
 //
 ************************************************************************************************/ 

// Disjoint cores

void BLS::identifyDisjointCores() {
  lbool res = l_True;
  std::map<Lit,int> assumptionMapping;
  uint64_t w = 0;
  
  assumptions.clear();
  _cores.clear();
  _coreSatClauses.clear();
  _coreUnsatClauses.clear();
  _satClauses.clear();
  _prevAssumptions.clear();
  
  for (int i = 0; i < maxsat_formula->nSoft(); i++) {
    assumptions.push(~(maxsat_formula->getSoftClause(i).assumption_var));
    assumptionMapping[maxsat_formula->getSoftClause(i).assumption_var] = i;
  }
  
  do {
    res = solve();
    if (res == l_False) {
      printf("c Core #%d found.\n", _cores.size());
      // Core found!
      // If core is empty, then hard clause set is unsat!
      if (solver->conflict.size() == 0) {
	if (nbMCS == 0) {
	  printAnswer(_UNSATISFIABLE_);
	  exit(_UNSATISFIABLE_);
	}
	else {
	  // It is not the first MCS. Hence, all MCS were found.
	  printAnswer(_OPTIMUM_);
// 	  exit(_OPTIMUM_);
      return; 
	}
      }
      
      _cores.push();
      _prevAssumptions.push();
      _coreSatClauses.push();
      _coreUnsatClauses.push();
      
      for (int i = 0; i < solver->conflict.size(); i++) {
	int indexSoft = coreMapping[solver->conflict[i]];
	int assumptionPos = assumptionMapping[solver->conflict[i]];
	
	//Add to core
	_cores[_cores.size()-1].push(indexSoft);
	
	//remove from assumptions
	assumptions[assumptionPos] = assumptions.last();
	assumptionMapping[~(assumptions.last())] = assumptionPos;
	assumptions.pop();
      }
      
      w += coreMinCost(_cores.size()-1);
    }
    else if (res == l_True) {
      for (int i = 0; i < assumptions.size(); i++) {
	_satClauses.push(coreMapping[~(assumptions[i])]);
      }
    }
  } while (res == l_False);
  printf("c # Disjoint Cores: %d\n", _cores.size());
  if (w > _lbWeight) _lbWeight = w;
}




uint64_t BLS::coreMinCost(int c) {
  unsigned int w = UINT_MAX;
  for (int i = 0; i < _cores[c].size(); i++)
    if (maxsat_formula->getSoftClause(_cores[c][i]).weight < w)
      w = maxsat_formula->getSoftClause(_cores[c][i]).weight;
  return w;
}


// Checks if a soft clause is satisfied by saved model

bool BLS::satisfiedSoft(int i) {
  for (int j = 0; j < maxsat_formula->getSoftClause(i).clause.size(); j++){
    assert (var(maxsat_formula->getSoftClause(i).clause[j]) < model.size());
    if ((sign(maxsat_formula->getSoftClause(i).clause[j]) && model[var(maxsat_formula->getSoftClause(i).clause[j])] == l_False) || 
	(!sign(maxsat_formula->getSoftClause(i).clause[j]) && model[var(maxsat_formula->getSoftClause(i).clause[j])] == l_True)) {
      return true;
    }
  }
  return false;
}

uint64_t BLS::computeModelCost() {
    uint64_t cost = 0;
    for (int i = 0; i < maxsat_formula->nSoft(); ++i) {
        if (!satisfiedSoft(i)) {
            cost += maxsat_formula->getSoftClause(i).weight;
        }
    }
    return cost;
}

// Call to the SAT solver...

lbool BLS::solve() {
  nbSatCalls++;  
#ifdef SIMP
  return ((SimpSolver*)solver)->solveLimited(assumptions);
#else
  return solver->solveLimited(assumptions);
#endif
}


void BLS::addMCSClause(vec<int>& unsatClauses) {
  vec<Lit> lits;
  for (int i = 0; i < unsatClauses.size(); i++) {
    //printf("%d ", unsatClauses[i]);
    lits.push(~maxsat_formula->getSoftClause(unsatClauses[i]).assumption_var);
  }
  //printf("\n");
  
  //addHardClause(lits);
  maxsat_formula->addHardClause(lits);
  
  solver->addClause(maxsat_formula->getHardClause(maxsat_formula->nHard()-1).clause);
  //solver->addClause(lits);
  
}


void BLS::initUndefClauses(vec<int>& undefClauses) {
  for (int i = 0; i < maxsat_formula->nSoft(); i++) 
    undefClauses.push(i);
}


void BLS::basicCoreBasedSearch(int maxMCS = 10, bool maxSAT = false) {
  // Init Structures
  init();
  
  //Build solver
  solver = buildSolver();
  
  identifyDisjointCores();
  
  while (_nMCS < maxMCS) {
    bool foundMCS = findNextCoreBasedMCS();
    
    if (foundMCS) _nMCS++;
    // if (!foundMCS || (maxSAT && _nMCS % 100 == 0))
    //   identifyDisjointCores();
    if (!foundMCS) identifyDisjointCores();
    if (maxSAT && _smallestMCS <= _lbWeight) {
      printAnswer(_OPTIMUM_);
//       exit(_OPTIMUM_);      
      return; 
    }
  }
  printf("c All requested MCSs found\n");
}



void BLS::addBackboneLiterals(int index) {
  assumptions.push(maxsat_formula->getSoftClause(index).assumption_var);
  for (int j = 0; j < maxsat_formula->getSoftClause(index).clause.size(); j++){
    assumptions.push(~(maxsat_formula->getSoftClause(index).clause[j]));
  }
}



// Find next MCS.

bool BLS::findNextCoreBasedMCS() {
  vec<int> undefClauses;
  uint64_t costModel = 0;
  lbool res = l_True;
  int initCore = 0;
  
  // Initialize CostModel. This could be done incrementally!!!
  while (initCore < _cores.size() && _coreUnsatClauses[initCore].size() > 0) {
    for (int i = 0; i < _coreUnsatClauses[initCore].size(); i++) 
      costModel += maxsat_formula->getSoftClause(_coreUnsatClauses[initCore][i]).weight;
    initCore++;
  }
  
  do {
    res = solve();
    if (res == l_False) {
      // All MCS with these disjoint cores were enumerated. Must get new set of disjoint cores.
      if (initCore == 0) return false;
      
      initCore--;
      while (assumptions.size() > _prevAssumptions[initCore])
	assumptions.pop();
      
      _coreSatClauses[initCore].clear();
      
      for (int i = 0; i < _coreUnsatClauses[initCore].size(); i++)
	costModel -= maxsat_formula->getSoftClause(_coreUnsatClauses[initCore][i]).weight;
      
      _coreUnsatClauses[initCore].clear();
    }
  } while (res == l_False);

  for (int c = initCore; c < _cores.size(); c++) {
    for (int i = 0; i < _cores[c].size(); i++) 
      costModel += maxsat_formula->getSoftClause(_cores[c][i]).weight;
  }
  
  // Iterate all cores to find next MCS
  for (int c = initCore; c < _cores.size(); c++) {
    undefClauses.clear();
    
    for (int i = 0; i < _cores[c].size(); i++) undefClauses.push(_cores[c][i]);
    
    _prevAssumptions[c] = assumptions.size();
    
    while (undefClauses.size()) {
      int i = undefClauses.last();
      undefClauses.pop();
      _coreSatClauses[c].push(i);
      assumptions.push(~(maxsat_formula->getSoftClause(i).assumption_var));
      
      res = solve();
      
      if (res == l_False) {
	_coreUnsatClauses[c].push(_coreSatClauses[c].last());
	_coreSatClauses[c].pop();
	assumptions.pop();
	addBackboneLiterals(i);
      }
      else if (res == l_True) {
	costModel -= maxsat_formula->getSoftClause(_coreSatClauses[c].last()).weight;
	saveModel(solver->model);
	
	i = 0;
	//Remove satisfied soft clauses from undefClauses
	while (i < undefClauses.size()) {
	  if (satisfiedSoft(undefClauses[i])) {
	    //Add soft clause as Hard!
	    _coreSatClauses[c].push(undefClauses[i]);
	    assumptions.push(~(maxsat_formula->getSoftClause(undefClauses[i]).assumption_var));
	    costModel -= maxsat_formula->getSoftClause(undefClauses[i]).weight;
	    undefClauses[i] = undefClauses.last();
	    undefClauses.pop();
	  }
	  else i++;
	}
	if (costModel < _smallestMCS) {
	  saveSmallestModel(solver->model);
	  printf("o %ld\n", costModel);
	  fflush(stdout);
	}
      }
      else {
	printf("c SAT Solver unable to solve formula?!?!?\n");
      }
    }
  }
  
  if (costModel < _smallestMCS) {
    _smallestMCS = costModel;
    //Last saved model is smallest MCS...
  }
  nbMCS++;
  printf("c MCS #%d Weight: %ld\n", nbMCS, costModel);
  
  vec<int> unsatClauses;
  for (int c = 0; c < _cores.size(); c++) {
    for (int i = 0; i < _coreUnsatClauses[c].size(); i++)
      unsatClauses.push(_coreUnsatClauses[c][i]);
  }
  addMCSClause(unsatClauses);
  
  return true;
}



Solver * BLS::my_getSolver(){
    init();
    solver = buildSolver();
    return solver;
}



// Always consider all clauses by adding assumption var to each soft clause.

void BLS::my_basicSearch(vec<Lit>& assumpt, int maxMCS = 50, bool maxSAT = false) {
  // Init Structures
//   init();
  
  //Build solver
//   solver = buildSolver();
  confl_top = solver->conflicts + conflict_limit;
  
  while (maxMCS && getRemainingConflBudget() > 0) {
    //if (!findNextMCS()) break;
//       printf("remaining budget -> %d\n", getRemainingConflBudget());
    if (!my_findNextStratifiedMCS(assumpt)) break;
    
    maxMCS--;
    if (maxSAT && _smallestMCS <= _lbWeight) {
      //printAnswer(_OPTIMUM_);
//       exit(_OPTIMUM_);      
      return; 
    }
    
    
  }
  if (maxMCS == 0) 
    printf("c All requested MCSs found\n");
}



// Always consider all clauses by adding assumption var to each soft clause.

void BLS::basicSearch(int maxMCS = 50, bool maxSAT = false) {
  // Init Structures
  init();
  
  //Build solver
  solver = buildSolver();
  confl_top = solver->conflicts + conflict_limit;
  
  while (maxMCS && getRemainingConflBudget() > 0) {
    //if (!findNextMCS()) break;
//       printf("remaining budget -> %d\n", getRemainingConflBudget());
    if (!findNextStratifiedMCS()) break;
    
    maxMCS--;
    if (maxSAT && _smallestMCS <= _lbWeight) {
      //printAnswer(_OPTIMUM_);
//       exit(_OPTIMUM_);      
      return; 
    }
    
    
  }
  if (maxMCS == 0) 
    printf("c All requested MCSs found\n");
}


// Find next MCS.
// Returns false if the SAT solver was not able to finish. Otherwise, returns true.

void BLS::initStratifiedUndefClauses(vec<int>& undef, int part_i) {
    uint64_t lb = weight_order[part_i], ub = part_i > 0 ? weight_order[part_i-1] : _maxWeight+1;
    for (int i = 0; i < maxsat_formula->nSoft(); i++) {
        uint64_t weight = maxsat_formula->getSoftClause(i).weight;
        if (weight >= lb && weight < ub) {
            undef.push(i);
        }
    }
}
// MTN - stratification: separate method for now; should be refactored to re-use findNextMCS()
bool BLS::my_findNextStratifiedMCS(vec<Lit>& assumpt) {
    uint64_t costModel = UINT64_MAX;
    vec<int> undef_cls, mcs;
    solver->setConfBudget(getRemainingConflBudget());
    
    printf("c nvars, nassumpts: %d %d\n", solver->nVars(), assumpt.size());
    assumptions.clear();
    for(int i = 0; i < assumpt.size(); i++)
        assumptions.push(assumpt[i]);

    
    // check satisfiability of hard formula
//     printf("(solve start) budget: %lld\n", getRemainingConflBudget());
    lbool res = solve();
//     printf("(solve end) budget left: %lld\n", getRemainingConflBudget());
//     printf("res: %d\n", res);
    if (res == l_False) {
        return false;
    }
    else if (res == l_True) {
        saveModel(solver->model);
        costModel = computeModelCost();
        if(costModel < _smallestMCS){
            _smallestMCS = costModel;
            saveSmallestModel(solver->model);
//             printf("c o1\n");
            printf("o %ld\n", costModel);
            fflush(stdout);
        }
    }
    else {
        printf("c Warn: SAT Solver exit due to conflict budget.\n");
        return false;
    }
    // find MCS
#if VARIANT == 3
    assumptions.clear();
#endif
//     for(int i = 0; i < assumpt.size(); i++)
//         assumptions.push(assumpt[i]);

    Lit r_l = maxsat_formula->newLiteral();
    newSATVariable(solver);
    assumptions.push(~r_l);
    int part_i = 0;
    for (; part_i < weight_order.size(); ++part_i) {
        initStratifiedUndefClauses(undef_cls, part_i);
        // run CLD
        do {
            int i = 0;
            while (i < undef_cls.size()) {
                if (satisfiedSoft(undef_cls[i])) {
                    assumptions.push(~(maxsat_formula->getSoftClause(undef_cls[i]).assumption_var));
                    undef_cls[i] = undef_cls.last();
                    undef_cls.pop();
                }
                else i++;
            }
            if (undef_cls.size() == 0) { break; }
            // build clause D
            vec<Lit> d_cl;
            d_cl.push(r_l);
            for (i = 0; i < undef_cls.size(); ++i) {
                d_cl.push(~(maxsat_formula->getSoftClause(undef_cls[i]).assumption_var));
            }
            solver->addClause(d_cl);
            // check satisfiability
            if (part_i < weight_order.size()-1) {
                solver->setConfBudget(getPartConflBudget());
            }
            else {
                solver->setConfBudget(getRemainingConflBudget());
            }
            res = solve();
            if (res == l_True) {
                saveModel(solver->model);
                costModel = computeModelCost();
                if(costModel < _smallestMCS){
                    _smallestMCS = costModel;
                    saveSmallestModel(solver->model);
//                     printf("c o2\n");
//                     printf("o %ld\n", costModel);
                    fflush(stdout);
                }
            }
            else if (res == l_Undef) {
                printf("c Warn: SAT Solver exit due to conflict budget.\n");
                return false; 
            }
        }
        while (res == l_True);
        // if undef, next partition will be merged to current one
        if (res == l_False) {   // add check for 'undef_cls.size() == 0' for robustness? it should work as is for now
            for (int i = 0; i < undef_cls.size(); ++i) {
                mcs.push(undef_cls[i]);
                assumptions.push(maxsat_formula->getSoftClause(undef_cls[i]).assumption_var);
            }
            undef_cls.clear();
            r_l = maxsat_formula->newLiteral();
            newSATVariable(solver);
            assumptions[0] = ~r_l;
        }
    }
    if (part_i == weight_order.size() && (res == l_False || undef_cls.size() == 0)) {
        nbMCS++;
        printf("c MCS #%d Weight: %ld\n", nbMCS, costModel);
        addMCSClause(mcs);
        return true;
    }
    return false;
}


// MTN - stratification: separate method for now; should be refactored to re-use findNextMCS()
bool BLS::findNextStratifiedMCS() {
    uint64_t costModel = UINT64_MAX;
    vec<int> undef_cls, mcs;
    solver->setConfBudget(getRemainingConflBudget());
    
    
    // check satisfiability of hard formula
    lbool res = solve();
    if (res == l_False) {
        return false;
    }
    else if (res == l_True) {
        saveModel(solver->model);
        costModel = computeModelCost();
        if(costModel < _smallestMCS){
            _smallestMCS = costModel;
            saveSmallestModel(solver->model);
//             printf("c o1\n");
//             printf("o %ld\n", costModel);
            fflush(stdout);
        }
    }
    else {
        printf("c Warn: SAT Solver exit due to conflict budget.\n");
        return false;
    }
    // find MCS
    assumptions.clear();

    Lit r_l = maxsat_formula->newLiteral();
    newSATVariable(solver);
    assumptions.push(~r_l);
    int part_i = 0;
    for (; part_i < weight_order.size(); ++part_i) {
        initStratifiedUndefClauses(undef_cls, part_i);
        // run CLD
        do {
            int i = 0;
            while (i < undef_cls.size()) {
                if (satisfiedSoft(undef_cls[i])) {
                    assumptions.push(~(maxsat_formula->getSoftClause(undef_cls[i]).assumption_var));
                    undef_cls[i] = undef_cls.last();
                    undef_cls.pop();
                }
                else i++;
            }
            if (undef_cls.size() == 0) { break; }
            // build clause D
            vec<Lit> d_cl;
            d_cl.push(r_l);
            for (i = 0; i < undef_cls.size(); ++i) {
                d_cl.push(~(maxsat_formula->getSoftClause(undef_cls[i]).assumption_var));
            }
            solver->addClause(d_cl);
            // check satisfiability
            if (part_i < weight_order.size()-1) {
                solver->setConfBudget(getPartConflBudget());
            }
            else {
                solver->setConfBudget(getRemainingConflBudget());
            }
            res = solve();
            if (res == l_True) {
                saveModel(solver->model);
                costModel = computeModelCost();
                if(costModel < _smallestMCS){
                    _smallestMCS = costModel;
                    saveSmallestModel(solver->model);
//                     printf("c o2\n");
//                     printf("o %ld\n", costModel);
                    fflush(stdout);
                }
            }
            else if (res == l_Undef) {
                printf("c Warn: SAT Solver exit due to conflict budget.\n");
            }
        }
        while (res == l_True);
        // if undef, next partition will be merged to current one
        if (res == l_False) {   // add check for 'undef_cls.size() == 0' for robustness? it should work as is for now
            for (int i = 0; i < undef_cls.size(); ++i) {
                mcs.push(undef_cls[i]);
                assumptions.push(maxsat_formula->getSoftClause(undef_cls[i]).assumption_var);
            }
            undef_cls.clear();
            r_l = maxsat_formula->newLiteral();
            newSATVariable(solver);
            assumptions[0] = ~r_l;
        }
    }
    if (part_i == weight_order.size() && (res == l_False || undef_cls.size() == 0)) {
        nbMCS++;
        printf("c MCS #%d Weight: %ld\n", nbMCS, costModel);
        addMCSClause(mcs);
        return true;
    }
    return false;
}

/*bool BLS::findNextMCS() {
  vec<int> undefClauses;
  vec<int> satClauses;
  vec<int> unsatClauses;
  uint64_t costModel = _maxWeight;
  lbool res = l_True;
  int conflict_limit = 100000;
  
  initUndefClauses(undefClauses);
  assumptions.clear();
  
  solver->setConfBudget(conflict_limit);
  
  // make first call.
  res = solve();
  
  // Check outcome of first call
  if (res == l_False) {
    // Hard clause set in unsat!
    if (nbMCS == 0) {
      printAnswer(_UNSATISFIABLE_);
      exit(_UNSATISFIABLE_);
    }
    else {
      // It is not the first MCS. Hence, all MCS were found.
      printAnswer(_OPTIMUM_);
      exit(_OPTIMUM_);
    }
  }
  else if (res == l_True) saveModel(solver->model);
  else {
    printf("c Warn: SAT Solver exit due to conflict budget.\n");
    return false;
  }
  
  // Iterate to find next MCS
  while (undefClauses.size()) {
    int i = 0;
    if (res == l_True) {
      //Remove satisfied soft clauses from undefClauses
      
      while (i < undefClauses.size()) {
      	if (satisfiedSoft(undefClauses[i])) {
      	  //Add soft clause as Hard!
      	  satClauses.push(undefClauses[i]);
	  assumptions.push(~(maxsat_formula->getSoftClause(undefClauses[i]).assumption_var));
      	  costModel -= maxsat_formula->getSoftClause(undefClauses[i]).weight;
      	  undefClauses[i] = undefClauses.last();
      	  undefClauses.pop();
      	}
      	else i++;
      }
      
      if (costModel < _smallestMCS) {
	saveSmallestModel(solver->model);
	printf("o %ld\n", costModel);
	fflush(stdout);
      }
    }
    
    if (undefClauses.size() == 0) {
      break;
    }
    
    i = undefClauses.last();
    undefClauses.pop();
    satClauses.push(i);
    assumptions.push(~(maxsat_formula->getSoftClause(i).assumption_var));

    res = solve();
    
    
    if (res == l_False) {
      unsatClauses.push(satClauses.last());
      satClauses.pop();
      assumptions.pop();
    }
    else if (res == l_True) {
      saveModel(solver->model);
      costModel -= maxsat_formula->getSoftClause(satClauses.last()).weight;
      if (undefClauses.size() == 0 && costModel < _smallestMCS) {
        printf("o %ld\n", costModel);
        fflush(stdout);
      }
    }
    else {
      printf("c Warn: SAT Solver exit due to conflict budget.\n");
      return false;
    }
  }
  
  if (costModel < _smallestMCS) {
    _smallestMCS = costModel;
    //Last saved model is smallest MCS...
  }
  nbMCS++;
  printf("c MCS #%d Weight: %ld\n", nbMCS, costModel);
  
  // collect some information to compute hamming distance
  for (int i = 0; i < _assigned_true.size(); i++){
    if (solver->model[i] == l_True){
      _assigned_true[i]++;
    }
  }
  
  addMCSClause(unsatClauses);
  return true;
}*/
// TODO: hacked implementation of CLD; if it works, make it an option and re-name class
bool BLS::findNextMCS() {
  vec<int> undefClauses;
  vec<int> satClauses;
  uint64_t costModel = _maxWeight;
  lbool res = l_True;

  initUndefClauses(undefClauses);
  assumptions.clear();

  solver->setConfBudget(conflict_limit);

  // make first call.
  res = solve();

  // Check outcome of first call
  if (res == l_False) {
    return false;
    // Hard clause set in unsat!
    
  }
  else if (res == l_True) {
    saveModel(solver->model);
  }
  else {
    printf("c Warn: SAT Solver exit due to conflict budget.\n");
    return false;
  }

  // Iterate to find next MCS
  Lit r_l = maxsat_formula->newLiteral();
  newSATVariable(solver);
  assumptions.push(~r_l);
  do {
    int i = 0;
    while (i < undefClauses.size()) {
      if (satisfiedSoft(undefClauses[i])) {
        satClauses.push(undefClauses[i]);
        assumptions.push(~(maxsat_formula->getSoftClause(undefClauses[i]).assumption_var));
        costModel -= maxsat_formula->getSoftClause(undefClauses[i]).weight;
        undefClauses[i] = undefClauses.last();
        undefClauses.pop();
      }
      else i++;
    }
    if (costModel < _smallestMCS) {
      saveSmallestModel(solver->model);
      printf("o %ld\n", costModel);
      fflush(stdout);
    }
    if (!undefClauses.size()) break;
    vec<Lit> d_cl;
    d_cl.push(r_l);
    for (i = 0; i < undefClauses.size(); ++i) {
      d_cl.push(~(maxsat_formula->getSoftClause(undefClauses[i]).assumption_var));
    }
    solver->addClause(d_cl);
    res = solve();
    if (res == l_True) {
        saveModel(solver->model);
    }
    else if (res == l_Undef) {
        
    if(costModel < _smallestMCS){ 
//             saveModel(solver->model);
        
        _smallestMCS = costModel;
//           saveSmallestModel(solver->model);
      }
      printf("c Warn: SAT Solver exit due to conflict budget.\n");
      return false;
    }
  }
  while (res == l_True);

  if (costModel < _smallestMCS) {
    _smallestMCS = costModel;
    //Last saved model is smallest MCS...
  }
  nbMCS++;
  printf("c MCS #%d Weight: %ld\n", nbMCS, costModel);

  // collect some information to compute hamming distance
  for (int i = 0; i < _assigned_true.size(); i++){
    if (solver->model[i] == l_True){
      _assigned_true[i]++;
    }
  }

  addMCSClause(undefClauses);
  return true;
}



void  BLS::my_search(vec<Lit>& assumpt) {
  
  //if (_useCores == false)
  my_basicSearch(assumpt, _maxMCS, _maxSAT);
  // else 
  //   basicCoreBasedSearch(_maxMCS, _maxSAT);
  
  printStats();

  // Make sure the conflict budget is turned off.
  solver->budgetOff();  
  
}

void  BLS::search() {
  
  //if (_useCores == false)
  basicSearch(_maxMCS, _maxSAT);
  // else 
  //   basicCoreBasedSearch(_maxMCS, _maxSAT);
  
  printStats();

  // Make sure the conflict budget is turned off.
  solver->budgetOff();  
  
}



/************************************************************************************************
 //
 // Utils for printing
 //
 ************************************************************************************************/ 

// Prints the best satisfying model. Assumes that 'model' is not empty.
void BLS::printModel(){
  
  assert (model.size() != 0);
  
  printf("v ");
  for (int i = 0; i < model.size(); i++){
    if (model[i] == l_True) printf("%d ",i+1);
    else printf("%d ",-(i+1));
  }
  printf("\n");
}


// Prints the best satisfying model. Assumes that '_smalledtModel' is not empty.
void BLS::printSmallestModel(){
  assert (_smallestModel.size() != 0);
  /*
  printf("v ");
  for (int i = 0; i < _smallestModel.size(); i++){
    if (_smallestModel[i] == l_True) printf("%d ",i+1);
    else printf("%d ",-(i+1));
  }
  printf("\n");*/ 
}



std::vector<int> BLS::getSmallestModel(){
    std::vector<int> mymodel;
    printf("smallest size: %d\n", _smallestModel.size());
//     if(_smallestMCS < _maxWeight){
    if(nbMCS > 0 || _smallestModel.size() > 0){
        for (int i = 0; i < maxsat_formula->nVars(); i++){
            if (_smallestModel[i] == l_True) mymodel.push_back(i+1);
            else mymodel.push_back(-(i+1));
        }
    }
    return mymodel;
}


// Prints search statistics.
void BLS::printStats(){
  //double totalTime = cpuTime();
  
  printf("c\n");
  //printf("c  Best solution:          %12"PRIu64"\n", ubCost);
  //printf("c  Total time:             %12.2f s\n",totalTime - initialTime);
  printf("c  Nb SAT solver calls:    %12d\n", nbSatCalls);
  printf("c  Nb SAT calls:           %12d\n", nbSatisfiable);
  printf("c  Nb UNSAT calls:         %12d\n", nbSatCalls-nbSatisfiable);
  printf("c  Nb MCS:                 %12d\n", nbMCS);
  printf("c  Smallest MCS:           %12ld\n", _smallestMCS);
  printf("c  Lower Bound:            %12ld\n", _lbWeight);
  //printf("c  Average core size:      %12.2f\n", (float)sumSizeCores/nbCores);
  printf("c\n"); 
}


// Prints the corresponding answer.
void BLS::printAnswer(int type){

  if (verbosity > 0)
    printStats();

  if (type == _UNKNOWN_ && model.size() > 0)
    type = _SATISFIABLE_;
  
  switch(type){
  case _SATISFIABLE_:
//     printf("s SATISFIABLE\n");
    printf("c mcs-sat\n");
    printSmallestModel();
    break;
  case _OPTIMUM_:
    printf("c All requested MCSs found\n");
    printf("c mcs-optf\n");
    //     printf("s OPTIMUM FOUND\n");
    printSmallestModel();
    break;
  case _UNSATISFIABLE_:
    printf("c mcs-unsat\n");
//     printf("s UNSATISFIABLE\n");
    break;  
  case _UNKNOWN_:
    printf("c mcs-unkn\n");
//     printf("s UNKNOWN\n");
    break;
  default:
    printf("c Error: Unknown answer type.\n");
  }
}

/************************************************************************************************
 //
 // Other protected methods
 //
 ************************************************************************************************/ 

Solver *BLS::buildSolver() {

  vec<bool> seen;
  seen.growTo(maxsat_formula->nVars(), false);

  Solver *S = newSATSolver();
  
  for (int i = 0; i < maxsat_formula->nVars(); i++)
    newSATVariable(S);
  
  for (int i = 0; i < maxsat_formula->nHard(); i++)
    S->addClause(maxsat_formula->getHardClause(i).clause);

  vec<Lit> clause;
  for (int i = 0; i < maxsat_formula->nSoft(); i++) {
    
    clause.clear();
    maxsat_formula->getSoftClause(i).clause.copyTo(clause);
    
    for (int j = 0; j < maxsat_formula->getSoftClause(i).relaxation_vars.size();
	 j++) {
      clause.push(maxsat_formula->getSoftClause(i).relaxation_vars[j]);
    }
    
    S->addClause(clause);
  }

  return S;
}



void BLS::init() {
  vec<int> vars;
  vars.growTo(maxsat_formula->nVars(), 0);
  
  if (!_useAllVars) {
    for (int i = 0; i < maxsat_formula->nSoft(); i++) {
      for (int j = 0; j < maxsat_formula->getSoftClause(i).clause.size(); j++) {
        int v = var(maxsat_formula->getSoftClause(i).clause[j]);
        assert (v < vars.size());
        if (vars[v] == 0){
          _soft_variables.push(v);
          vars[v] = 1;
        }
      }
    }
  }
  else {
    for (int i = 0; i < maxsat_formula->nVars(); i++) {
      _soft_variables.push(i);
    }
  }
  _assigned_true.growTo(maxsat_formula->nInitialVars(),0);
  _varScore.growTo(maxsat_formula->nInitialVars(),0);
  
  _maxWeight = 0;
  std::map<uint64_t, int> weight_count;
  for (int i = 0; i < maxsat_formula->nSoft(); i++) {
    Lit l = maxsat_formula->newLiteral();
    maxsat_formula->getSoftClause(i).relaxation_vars.push(l);
    maxsat_formula->getSoftClause(i).assumption_var = maxsat_formula->getSoftClause(i).relaxation_vars[0]; // Assumption Var is relaxation var
    
    _maxWeight += maxsat_formula->getSoftClause(i).weight;

    // MTN - stratification: count clauses for each weight
    std::pair<std::map<uint64_t, int>::iterator, bool> ret;
    ret = weight_count.emplace(maxsat_formula->getSoftClause(i).weight, 1);
    if (!ret.second) {      // weight already in map
      ret.first->second = ret.first->second + 1;
    }
  }
  printf("c Max. Weight: %ld\n", _maxWeight);
  // MTN - stratification: build partitioning using clause counts per weight
  weight_order.clear();
  int nclauses = 0, nweights = 0;
  for (std::map<uint64_t, int>::reverse_iterator it = weight_count.rbegin(); it != weight_count.rend(); it++) {
    nclauses += it->second;
    ++nweights;
    if ((double)nclauses/(double)nweights >= strat_lwr || std::next(it) == weight_count.rend()) {
        my_npartitions++;
      printf("c Stratification: partition %d, nclauses = %d, nweights = %d\n",
             weight_order.size(), nclauses, nweights);
      weight_order.push(it->first);
      nclauses = nweights = 0;
    }
  }
}

