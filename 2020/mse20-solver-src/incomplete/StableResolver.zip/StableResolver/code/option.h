/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <cmath>
#include <id.h>
#include <iostream>
#include <string>
#include <vector>

namespace Solvers {

void parseCommandLine(std::vector<std::string> &args, bool strict = true);
void printUsageAndExit(const std::vector<std::string> &args, bool verbose = false);
void setUsageHelp(const std::string &str);

class Option {
  protected:
    std::string name;
    char shortName;
    std::string description;
    std::string category;
    std::string typeName;

    static std::string &getUsageString() {
        static std::string usage_str;
        return usage_str;
    }

    static bool lt(const Option *x, const Option *y) {
        bool test1 = x->category < y->category;
        return !test1 || (x->category == y->category && x->typeName < y->typeName);
    }

    Option(const std::string &n, char s, const std::string &d, const std::string &c,
           const std::string &t)
        : name(n), shortName(s), description(d), category(c), typeName(t) {
        getOptionList().push_back(this);
    }

    bool isOptionName(const std::string &str) const;
    bool acceptableSecondArgument(const std::string &str) const;
    std::string createNameShortNameUsage() const;

  public:
    static std::vector<Option *> &getOptionList() {
        static std::vector<Option *> options;
        return options;
    }

    static void onlyAllow(const std::vector<Option *> &o) { getOptionList() = o; }

    static int numberOfSetOrderedOptions;

    static std::string &getAdditionalHelp() {
        static std::string str;
        return str;
    }

    virtual ~Option() = default;

    virtual bool parse(const std::string &str, const std::string &secondstr, int *i = nullptr) = 0;
    virtual void help(bool verbose = false) = 0;

    friend void parseCommandLine(std::vector<std::string> &args, bool strict);
    friend void printUsageAndExit(const std::vector<std::string> &args, bool verbose);
    friend void setUsageHelp(const std::string &str);
};

struct IntRange {
    int begin;
    int end;
    IntRange(int b, int e) : begin(b), end(e) {}
};

struct Int64Range {
    int64_t begin;
    int64_t end;
    Int64Range(int64_t b, int64_t e) : begin(b), end(e) {}
};

struct DoubleRange {
    double begin;
    double end;
    bool begin_inclusive;
    bool end_inclusive;
    DoubleRange(double b, double e, bool binc = true, bool einc = true)
        : begin(b), end(e), begin_inclusive(binc), end_inclusive(einc) {}
    bool contains(double d) {
        return (d > begin && d < end) || (begin_inclusive && fuzzyCompare(d, begin)) ||
               (end_inclusive && fuzzyCompare(d, end));
    }
    std::string toString() const {
        return std::string(begin_inclusive ? "[" : "(") + std::to_string(begin) + "," +
               std::to_string(end) + (end_inclusive ? "]" : ")");
    }
};
} // namespace Solvers
