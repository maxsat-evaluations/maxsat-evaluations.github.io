/*
 * Copyright (C) Synoptics GmbH
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains the property of Synoptics GmbH and its
 * suppliers, if any. The intellectual and technical concepts contained herein are proprietary to
 * Synoptics GmbH and its suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly forbidden unless
 * prior written permission is obtained from Synoptics GmbH.
 *
 */

#include "doubleoption.h"

namespace Solvers {

bool DoubleOption::parse(const std::string &str, const std::string &secondstr, int *i) {
    if (isOptionName(str) && !secondstr.empty()) {
        if (i) {
            (*i)++;
        }
        if (acceptableSecondArgument(secondstr)) {
            double val;
            try {
                val = std::stod(secondstr);
            } catch (...) {
                std::cout << "ERROR value " << str << " for option " << name << " is not a double"
                          << std::endl;
                return false;
            }
            if (!range.contains(val)) {
                std::cout << val << std::endl;
                std::cout << "ERROR value " << str << " for option " << name << " is not in range "
                          << range.toString() << ". Use -h for help." << std::endl;
                return false;
            }
            value = val;
            return true;
        }
    }
    return false;
}

void DoubleOption::help(bool verbose) {
    std::cout << "  ";
    std::cout << createNameShortNameUsage();
    std::cout << " = ";
    std::cout << typeName << " " << range.toString();
    std::cout << "(default: " << value << ")" << std::endl;
    if (verbose) {
        std::cout << "\n        " << description << std::endl;
        std::cout << std::endl;
    }
}
} // namespace Solvers
