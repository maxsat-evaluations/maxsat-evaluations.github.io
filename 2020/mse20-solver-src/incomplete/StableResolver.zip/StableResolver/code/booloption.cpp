/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "booloption.h"

namespace Solvers {

bool BoolOption::parse(const std::string &str, const std::string &secondstr, int *i) {
    (void)secondstr;
    (void)i;
    if (str.rfind('-', 0) == 0) {
        if (str == std::string("-") + shortName || str == std::string("-") + name) {
            value = true;
            return true;
        } else if (str == std::string("-n") + shortName || str == std::string("-no") + name) {
            value = false;
            return true;
        }
    }
    return false;
}

void BoolOption::help(bool verbose) {
    if (shortName != 0) {
        std::cout << std::string("  -") << name << " -" << shortName << ", -no" << name << " -n"
                  << shortName;
    } else {
        std::cout << std::string("  -") << name << ", -no" << name;
    }

    std::cout << " ";
    std::cout << std::string("(default: ") << (value ? "true" : "false") << ")" << std::endl;
    if (verbose) {
        std::cout << std::string("\n        ") << description << "\n";
        std::cout << std::endl;
    }
}
} // namespace Solvers
