/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <algorithm>
#include <string>
#include <vector>

namespace Solvers {

class Interval {
  public:
    int lower;
    int upper;

    /**
     * Default constructor, which creates the Interval with
     * lower = 0 and upper = 0.
     */
    inline Interval();

    /**
     * Creates a new interval.
     */
    inline Interval(int l, int u);

    explicit Interval(const std::string &s);

    /**
     * Copy constructor.
     * @param other the copy.
     */
    inline Interval(const Interval &other);

    bool contains(int i) const { return i >= lower && i <= upper; }
    bool contains(Interval i) const { return i.lower >= lower && i.upper <= upper; }
    bool intersects(Interval i) const {
        return (i.lower <= upper && i.lower >= lower) || (i.upper >= lower && i.upper <= upper) ||
               (i.lower <= lower && i.upper >= upper);
    }
    inline Interval intersected(Interval i) const;

    /**
     * Destructor.
     */
    inline ~Interval();

    /**
     * Assignment operator.
     * @param other the copy.
     * @return a reference to this instance.
     */
    inline Interval &operator=(const Interval &other);

    inline std::string toString() const;

    inline Interval inv() const;

    inline bool operator==(const Interval &other) const {
        return lower == other.lower && upper == other.upper;
    }
    inline bool operator!=(const Interval &other) const { return !(*this == other); }
    inline Interval operator+(const Interval &o) const {
        return Interval(lower + o.lower, upper + o.upper);
    }
    inline Interval operator+(int i) const { return Interval(lower + i, upper + i); }

    bool isEmpty() const { return lower > upper; }

    std::vector<Interval>
    intervalMinus(const std::vector<Interval> &l, int extension, int min,
                  int max) const; // l must be a disjoint list of sorted intervals
    bool hasIntersection(Interval i) const {
        return (lower <= i.upper && upper >= i.lower) || (i.lower >= upper && i.upper <= lower);
    } // for integer intervals only
};

Interval::Interval() : lower(0), upper(0) {}

Interval::Interval(int l, int u) : lower(l), upper(u) {}

Interval::Interval(const Interval &other) : lower(other.lower), upper(other.upper) {}

Interval Interval::intersected(Interval i) const {
    Interval res(0, -1);
    res.lower = i.lower > lower ? i.lower : lower;
    res.upper = i.upper < upper ? i.upper : upper;
    return res;
}

Interval::~Interval() {}

Interval &Interval::operator=(const Interval &other) {
    if (this != &other) {
        lower = other.lower;
        upper = other.upper;
    }
    return *this;
}

std::string Interval::toString() const {
    return std::string("[") + std::to_string(lower) + "," + std::to_string(upper) + "]";
}

/**
 * for int intervals only
 */
std::vector<Interval> expandOccupiedTime(const std::vector<Interval> &l, int k);

/**
 * for int intervals only
 */
Interval Interval::inv() const { return Interval(-upper, -lower); }
std::vector<Interval> uniteIntervals(
    const std::vector<Interval> &l,
    const Interval
        &i); // l must be a disjoint list of sorted intervals; works only with int intervals for now

} // namespace Solvers
