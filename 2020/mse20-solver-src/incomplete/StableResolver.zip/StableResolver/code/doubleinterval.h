/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <string>
#include <vector>

namespace Solvers {

class DoubleInterval {
  public:
    double lower;
    double upper;

    DoubleInterval() : lower(0.), upper(0.) {}
    DoubleInterval(double l, double u) : lower(l), upper(u) {}
    explicit DoubleInterval(const std::string &s);

    bool contains(double d) const { return d >= lower && d <= upper; }
    bool contains(DoubleInterval i) const { return i.lower >= lower && i.upper <= upper; }
    bool intersects(DoubleInterval i) const {
        return (i.lower <= upper && i.lower >= lower) || (i.upper >= lower && i.upper <= upper) ||
               (i.lower <= lower && i.upper >= upper);
    }
    DoubleInterval intersected(DoubleInterval i) const {
        DoubleInterval res;
        res.lower = i.lower > lower ? i.lower : lower;
        res.upper = i.upper < upper ? i.upper : upper;
        return res;
    }
    DoubleInterval inv() const { return DoubleInterval(-upper, -lower); }

    std::string toString() const {
        return std::string("[") + std::to_string(lower) + "," + std::to_string(upper) + "]";
    }

    inline bool operator==(const DoubleInterval &other) const {
        return lower == other.lower && upper == other.upper;
    }
    bool operator!=(const DoubleInterval &other) const { return !(*this == other); }
    DoubleInterval operator+(const DoubleInterval &o) const {
        return DoubleInterval(lower + o.lower, upper + o.upper);
    }
    DoubleInterval operator+(double i) const { return DoubleInterval(lower + i, upper + i); }

    bool isEmpty() const { return lower > upper; }
};
} // namespace Solvers
