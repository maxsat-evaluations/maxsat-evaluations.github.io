/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <option.h>

namespace Solvers {

class BoolOption : public Option {
    bool value;

  public:
    BoolOption(const std::string &c, const std::string &n, char s, const std::string &d, bool v)
        : Option(n, s, d, c, "<bool>"), value(v) {}

    operator bool(void) const { return value; }
    operator bool &(void) { return value; }
    BoolOption &operator=(bool b) {
        value = b;
        return *this;
    }

    virtual bool parse(const std::string &str, const std::string &secondstr,
                       int *i = nullptr) override;

    virtual void help(bool verbose = false) override;
};
} // namespace Solvers
