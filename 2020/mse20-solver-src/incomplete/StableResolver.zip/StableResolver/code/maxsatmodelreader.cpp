/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "maxsatmodelreader.h"
#include <cassert>
#include <fstream>
#include <iostream>
#include <list>
#include <numeric>
#include <options.h>
#include <sstream>
#include <stream.h>
#include <utils/ParseUtils.h>
#include <zlib.h>

namespace Solvers::MaxSat {

template <class B> static uint64_t parseUll(B &in) {
    uint64_t val = 0;
    skipWhitespace(in);
    if (*in < '0' || *in > '9') {
        fprintf(stderr, "PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
    }

    while (*in >= '0' && *in <= '9') {
        val = val * 10 + (*in - '0'), ++in;
    }
    return val;
}

bool MaxSATModelReader::readFromWcnfFile(const std::string &fileName, MaxsatModel &model,
                                         int timeout) {
    Timer t2;
    std::vector<int> sol;

    gzFile ingz = gzopen(fileName.data(), "rb");
    Glucose::StreamBuffer in(ingz);

    MaxsatModel curModel;
    std::vector<int> litOnlyPol; // 0=both, 1=only true, -1=only false, 2=unknown
    size_t numClauses = 0;
    bool weighted = false;
    bool firstSoft = true;
    uint64_t firstWeight;

    // for labeling of soft clauses
    std::vector<int> posSignUnitSoft;
    std::vector<int> negSignUnitSoft;
    std::vector<int> posSignSoft;
    std::vector<int> negSignSoft;
    std::vector<int> posSignHard;
    std::vector<int> negSignHard;
    std::vector<uint32_t> posLabel;
    std::vector<uint32_t> negLabel;

    std::vector<int> remLits; // -1 --> fulfilled (could be propagated)
    bool skip = false;
    for (;;) {
        skipWhitespace(in);
        if (*in == EOF) {
            break;
        }
        if (!skip && numClauses % 1000 == 0 && programTimer.elapsed() > (timeout - 1) * 1000) {
            // timeout almost reached so return current sol
            model.setnClauses(curModel.getnClauses());
            model.setnLiterals(curModel.getnLiterals());

            model.init();
            skip = true;
        }
        if (*in == 'c') {
            skipLine(in);
            continue;
        }
        if (*in == 'p') {
            if (eagerMatch(in, "p wcnf")) {
                int vars = Glucose::parseInt(in);
                curModel.setnLiterals(vars);
                litOnlyPol.reserve(vars);
                sol = std::vector<int>(curModel.getnLiterals(), 0);

                int clauses = Glucose::parseInt(in);
                curModel.setnClauses(clauses);
                remLits.reserve(clauses);

                posSignUnitSoft.resize(curModel.getnLiterals());
                negSignUnitSoft.resize(curModel.getnLiterals());
                posSignSoft.resize(curModel.getnLiterals());
                negSignSoft.resize(curModel.getnLiterals());
                posSignHard.resize(curModel.getnLiterals());
                negSignHard.resize(curModel.getnLiterals());
                posLabel.resize(curModel.getnLiterals());
                negLabel.resize(curModel.getnLiterals());

                uint64_t w = parseUll(in);
                model.setMaxWeight(w);
                curModel.setMaxWeight(w);
                curModel.init();
            } else {
                ERROR_EXIT("wrong p line")
            }
        } else {
            Clause curClause;

            curClause.weight = parseUll(in);
            curModel.addToUpperBound(curClause.weight);

            if (!weighted && curClause.weight != curModel.getMaxWeight()) {
                if (firstSoft) {
                    firstWeight = curClause.weight;
                    firstSoft = false;
                } else {
                    if (firstWeight != curClause.weight) {
                        weighted = true;
                    }
                }
            }

            if (!skip) {
                bool lastSign;
                Literal lastLit;
                bool existsPos = false;
                Literal lit;
                for (;;) {

                    int number = parseInt(in);
                    if (number == 0) {
                        break;
                    }

                    lit = mkLit(number);
                    auto idx = index(lit);
                    if (litOnlyPol.size() < idx + 1) {
                        litOnlyPol.resize(idx + 1, 2);
                    }
                    if (litOnlyPol[idx] != 0) {
                        bool sign = isSigned(lit);
                        lastSign = sign;

                        if (sign) {
                            existsPos = true;
                        }

                        if (litOnlyPol[idx] == 2) {
                            litOnlyPol[idx] = sign ? 1 : -1;
                        } else {
                            if (!sign && litOnlyPol[idx] == 1) {
                                litOnlyPol[idx] = 0;
                            } else if (sign && litOnlyPol[idx] == -1) {
                                litOnlyPol[idx] = 0;
                            }
                        }
                    }

                    curClause.literals.push_back(lit);

                    if (lit.sign) {
                        if (curClause.weight == curModel.getMaxWeight()) {
                            posSignHard[index(lit)]++;
                        } else {
                            posSignSoft[index(lit)]++;
                        }
                    }

                    lastLit = lit;
                }

                if (curClause.literals.size() == 1 && curClause.weight != curModel.getMaxWeight()) {
                    if (lastSign) {
                        posSignUnitSoft[index(lastLit)]++;
                        posLabel[index(lastLit)] = numClauses;
                    } else {
                        negSignUnitSoft[index(lastLit)]++;
                        negLabel[index(lastLit)] = numClauses;
                    }
                }

                if (!curClause.literals.empty() && !existsPos) {
                    sol[index(lit)] = 0;
                }

                if (curClause.weight == 0) {
                    continue;
                }

                if (curClause.weight == curModel.getMaxWeight()) {
                    curModel.feature.numhardclauses++;
                    curModel.feature.avglenhardlength += curClause.literals.size();
                    curModel.feature.numminhardclauselength = std::min(
                        int(curClause.literals.size()), curModel.feature.numminhardclauselength);
                    curModel.feature.nummaxhardclauselength = std::max(
                        int(curClause.literals.size()), curModel.feature.numminhardclauselength);
                } else {
                    curModel.feature.numsoftclauses++;
                    curModel.feature.avglensoftlength += curClause.literals.size();
                    curModel.feature.numminsoftclauselength = std::min(
                        int(curClause.literals.size()), curModel.feature.numminsoftclauselength);
                    curModel.feature.nummaxsoftclauselength = std::max(
                        int(curClause.literals.size()), curModel.feature.numminsoftclauselength);
                }

                remLits.push_back(curClause.literals.size());

                curModel.addClause(std::move(curClause));
                numClauses++;
            }
        }
    }
    gzclose(ingz);
    if (skip) {
        LOG("skipped")
        model.setUpperBound(curModel.getUpperBound());
        return false;
    }
    curModel.feature.weighted = weighted;
    curModel.feature.numclauses = numClauses;
    curModel.feature.numliterals = litOnlyPol.size();

    if (curModel.feature.numhardclauses > 0) {
        curModel.feature.avglenhardlength =
            curModel.feature.avglenhardlength / curModel.feature.numhardclauses;
    } else {
        curModel.feature.avglenhardlength = 0;
    }
    if (curModel.feature.numsoftclauses > 0) {
        curModel.feature.avglensoftlength =
            curModel.feature.avglensoftlength / curModel.feature.numsoftclauses;
    } else {
        curModel.feature.avglensoftlength = 0;
    }
    if (curModel.feature.numsoftclauses > 0) {
        curModel.feature.avgSoftWeight =
            (curModel.getUpperBound() - curModel.feature.numhardclauses * curModel.getMaxWeight()) /
            curModel.feature.numsoftclauses;
    } else {
        curModel.feature.avgSoftWeight = 1;
    }

    curModel.setnClauses(numClauses);
    curModel.setnLiterals(litOnlyPol.size());

    LOG(std::string("time file read = ") + std::to_string(t2.restart() / 1000.) + "s");

    if (programTimer.elapsed() < timeout * 1000 / 6 &&
        (curModel.feature.numhardclauses > 0 ||
         (!curModel.feature.weighted && curModel.feature.numsoftclauses > 9690))) {
        // label soft clauses: 1. identify labels
        std::unordered_set<uint32_t> alreadyLabeled;

        int found = 0;

        // check if either pos of neg lit is a label, i.e. is contained in a single unit soft
        // clause and else only in hard clauses

        for (uint32_t litIndex = 0; litIndex < curModel.getnLiterals(); litIndex++) {

            if (posSignUnitSoft[litIndex] == 1 && posSignSoft[litIndex] == 1 &&
                negSignSoft[litIndex] == 0 && posSignHard[litIndex] == 0) {
                alreadyLabeled.insert(posLabel[litIndex]);
                found++;
            } else if (negSignUnitSoft[litIndex] == 1 && negSignSoft[litIndex] == 1 &&
                       posSignSoft[litIndex] == 0 && negSignHard[litIndex] == 0) {
                alreadyLabeled.insert(negLabel[litIndex]);
                found++;
            }
        }
        LOG(std::string("identified labels = ") + std::to_string(found));

        // 2. label remanining (unlabeled) soft clauses
        curModel.numAux = 0;
        uint32_t originalnClauses = curModel.getnClauses();
        uint32_t originalnLits = curModel.getnLiterals();
        for (uint32_t i = 0; i < originalnClauses; i++) {
            auto &cl = curModel.getClause(i);
            if (cl.weight == curModel.getMaxWeight()) {
                continue;
            }
            if (alreadyLabeled.contains(i)) {
                continue;
            }

            // create label literal
            curModel.numAux++;
            Literal lit;
            lit.idx = originalnLits + curModel.numAux - 1;
            curModel.setnLiterals(originalnLits + curModel.numAux);

            // add new unit clause consitsing of the label literal with neg sign
            Clause labelClause;
            labelClause.weight = cl.weight;
            lit.sign = false;
            labelClause.literals.push_back(lit);
            curModel.extendVarMapping();
            curModel.addClause(std::move(labelClause));
            numClauses++;

            // add label literal to old soft clause with pos sign and make it a hard clause
            auto &clNew = curModel.getClause(i);
            lit.sign = true;
            lit.idx = curModel.getOrigToMappedVar(
                index(lit)); // in add clause the literal's index has changed
            clNew.literals.push_back(lit);
            clNew.weight = curModel.getMaxWeight();

            // append label literal to litinclause of old soft clause
            LitInClause litInCause;
            litInCause.clauseIdx = i;
            litInCause.sign = true;
            curModel.litInClauses[index(lit)].push_back(litInCause);

            // add weight of clause + (maxweight-weight of clause) to upperbound
            curModel.addToUpperBound(curModel.getMaxWeight());

            // append sol
            sol.push_back(0);
        }
        LOG(std::string("added labels = ") + std::to_string(curModel.numAux));
    }

    // skip preprocessing if either parameter not set or it reading the model took too long
    bool doPreproc = preproc && programTimer.elapsed() < timeout * 1000 / 3;
    if (doPreproc) {
        sol = preprocess(curModel, litOnlyPol, remLits);
        // TODO return if timeout is over
        LOG(std::string("time preprocessing = ") + std::to_string(t2.restart() / 1000.) + "s");
    }
    finalize(curModel, model, sol, remLits, doPreproc);

    LOG(std::string("time model init = ") + std::to_string(t2.restart() / 1000.) + "s");

    return true;
}

// cppcheck-suppress constParameter
std::vector<int> MaxSATModelReader::preprocess(MaxsatModel &curModel,
                                               const std::vector<int> &litOnlyPol,
                                               std::vector<int> &remLits) {

    std::vector<int> solution(curModel.getnLiterals(), 0); // 0 = unset, 1 = true, -1 = false

    auto propagate = [&](Literal l) -> bool {
        bool sign = isSigned(l);
        auto idx = index(l);
        assert(solution[idx] == 0);
        solution[idx] = sign ? 1 : -1;
        bool moreUnits = false;
        for (LitInClause lc : curModel.getClausesOfLit(index(l))) {

            // check if has already been propagated
            if (remLits[lc.clauseIdx] == -1) {
                continue;
            }

            // check if remove literal or clause is fulfilled
            if (lc.sign != sign) {
                remLits[lc.clauseIdx]--;
                moreUnits |= remLits[lc.clauseIdx] == 1;
            } else {
                remLits[lc.clauseIdx] = -1;
            }
        }
        return moreUnits;
    };

    size_t pureProps = 0;
    for (uint32_t idx = 0; idx < litOnlyPol.size(); ++idx) {
        int pol = litOnlyPol[idx];
        if (pol == 0 || pol == 2) {
            continue;
        }
        propagate(Literal{idx, pol == 1});
        pureProps++;
    }
    LOG("num_pure_propagations = " + std::to_string(pureProps));

    size_t unitpropsdone = 0;
    bool hasUnitProps = true;
    while (hasUnitProps) {
        hasUnitProps = false;
        for (size_t i = 0; i < curModel.getnClauses(); ++i) {
            if (remLits[i] != 1) {
                continue;
            }
            const Clause &c = curModel.getClause(i);
            if (c.weight == curModel.getMaxWeight()) {
                for (Literal l : c.literals) {
                    // cppcheck-suppress useStlAlgorithm
                    if (solution[index(l)] == 0) {
                        hasUnitProps |= propagate(l);
                        unitpropsdone++;
                        break;
                    }
                }
            }
        }
    }
    LOG("num_unit_propagations = " + std::to_string(unitpropsdone));

    return solution;
}

void MaxSATModelReader::applyFinalize(
    MaxsatModel &curModel, MaxsatModel &model, std::vector<bool> &initsol,
    const std::unordered_map<uint32_t, bool> &propagatedLits, Glucose::Solver *solver,
    std::vector<bool> &origInitsol, const std::unordered_set<uint32_t> &eliminatedVars,
    std::unordered_map<uint32_t, std::vector<Clause>> &eliminatedClauses) {

    this->solver = solver;
    origInitsol.clear();
    origInitsol.resize(curModel.getNumOrigVars(), false);

    model.numAux = curModel.numAux;

    std::vector<int> sol;
    sol.reserve(curModel.getnLiterals());
    for (uint32_t v = 0; v < curModel.getnLiterals(); v++) {
        auto it = propagatedLits.find(v);
        if (it != propagatedLits.end()) {
            bool val = it->second;
            sol.push_back(val ? 1 : -1);
            auto origv = curModel.getMappedToOrigVar(v);
            origInitsol[origv] = val;
        } else {
            sol.push_back(0);
        }
    }

    std::vector<int> remLits;
    remLits.reserve(curModel.getnClauses());
    for (size_t i = 0; i < curModel.getnClauses(); i++) {
        auto &c = curModel.getClause(i);
        remLits.push_back(0);
        if (c.weight >= curModel.getMaxWeight()) {
            continue;
        }
        for (auto l : c.literals) {
            if (sol[index(l)] == 0) {
                remLits.back()++;
            } else {
                bool b = sol[index(l)] == 1;
                if (b == isSigned(l)) {
                    remLits.back() = -1;
                    break;
                }
            }
        }
    }
    finalize(curModel, model, sol, remLits, true);
    this->solver = nullptr;

    std::vector<bool> initsolCur = std::move(initsol);
    for (uint32_t v = 0; v < initsolCur.size(); v++) {
        auto vOrig = curModel.getMappedToOrigVar(v);
        origInitsol[vOrig] = initsolCur[v];
    }

    // store eliminiated clauses now, before they are lost
    std::unordered_set<uint32_t> alreadyRemovedClauses;
    for (auto eVar : eliminatedVars) {
        auto &litinClauses = curModel.getClausesOfLit(eVar);
        std::vector<Clause> clauses;
        clauses.reserve(litinClauses.size());
        for (auto lic : litinClauses) {
            if (alreadyRemovedClauses.contains(lic.clauseIdx)) {
                continue;
            } else {
                alreadyRemovedClauses.insert(lic.clauseIdx);
            }
            const Clause &clause = curModel.getClause(lic.clauseIdx);
            assert(clause.weight == curModel.getMaxWeight());
            Clause cNew;
            cNew.literals.reserve(clause.literals.size());
            cNew.weight = clause.weight;
            for (auto l : clause.literals) {
                Literal litOrig{static_cast<uint32_t>(curModel.getMappedToOrigVar(index(l))),
                                isSigned(l)};
                cNew.literals.push_back(litOrig);
            }
            clauses.emplace_back(std::move(cNew));
        }
        eliminatedClauses.emplace(curModel.getMappedToOrigVar(eVar), std::move(clauses));
    }

    initsol.clear();
    initsol.reserve(model.getnLiterals());

    for (uint32_t v = 0; v < model.getnLiterals(); v++) {
        initsol.push_back(origInitsol[model.getMappedToOrigVar(v)]);
    }
}

// cppcheck-suppress constParameter
void MaxSATModelReader::finalize(MaxsatModel &curModel, MaxsatModel &model, std::vector<int> &sol,
                                 const std::vector<int> &remLits, bool doPreproc) {

    if (doPreproc) {
        size_t numClauses = 0;

        for (size_t i = 0; i < remLits.size(); ++i) {
            int r = remLits[i];
            if (r > 0) {
                numClauses++;
            }
        }
        if (solver) {
            numClauses += solver->nClauses();
        }

        model.setnClauses(numClauses);
        model.setnLiterals(curModel.getnLiterals());
        model.setMaxWeight(curModel.getMaxWeight());
        model.init();

        model.feature = curModel.feature;

        size_t curI = 0;

        auto addclause = [&](Clause &c, int64_t originI) {
            int r = c.literals.size();
            if (originI >= 0) {
                r = remLits[originI];
            }
            if (r >= 0) {
                model.addToUpperBound(c.weight);
            }
            if (r <= 0) {
                return;
            }
            if (r < c.literals.size()) {
                Clause cur = std::move(c);
                c = Clause{};
                c.literals.reserve(r);
                c.weight = cur.weight;
                for (auto l : cur.literals) {
                    if (sol[index(l)] == 0) {
                        c.literals.push_back(l);
                    }
                }
            }
            model.addClause(std::move(c));
            curI++;
        };

        std::vector<bool> added(curModel.getnClauses(), false);

        if (!solver) {
            for (size_t i = 0; i < curModel.getnClauses(); i++) {
                auto &c = curModel.getClause(i);
                if (c.weight == curModel.getMaxWeight()) {
                    added[i] = true;
                    addclause(c, i);
                }
            }
        } else {
            for (int i = 0; i < solver->nClauses(); i++) {
                auto &c = solver->getClause(i);
                Clause clause;
                clause.literals.reserve(c.size());
                clause.weight = curModel.getMaxWeight();
                for (int j = 0; j < c.size(); j++) {
                    auto l = c[j];
                    clause.literals.push_back(Literal{static_cast<uint32_t>(var(l)), !sign(l)});
                }
                addclause(clause, -1);
            }
        }

        // add soft clauses now
        for (size_t i = 0; i < curModel.getnClauses(); i++) {
            if (added[i]) {
                continue;
            }
            auto &c = curModel.getClause(i);
            if (solver && c.weight == curModel.getMaxWeight()) {
                continue;
            }
            addclause(c, i);
        }
    } else {
        model = std::move(curModel);
    }

    model.finalize();

    std::vector<int> solNew;
    solNew.reserve(model.getnLiterals());
    for (uint32_t vNew = 0; vNew < model.getnLiterals(); vNew++) {
        int v = model.getMappedToOrigVar(vNew);
        int val = sol[v];
        solNew.push_back(val);
    }

    if (doPreproc) {
        model.mergeVarMapping(curModel);
    }

    model.setInitialInterpretation(std::move(solNew));
}

std::vector<bool> MaxSATModelReader::readSolutionFromFile(const std::string &fileName) {
    gzFile ingz = gzopen(fileName.data(), "rb");
    Glucose::StreamBuffer in(ingz);

    std::vector<bool> sol;
    for (;;) {
        skipWhitespace(in);
        if (*in == EOF) {
            break;
        }
        if (*in == 'c' || *in == 'o' || *in == 's') {
            skipLine(in);
            continue;
        }

        if (*in != 'v') {
            continue;
        }
        if (eagerMatch(in, "v")) {
            for (;;) {
                skipWhitespace(in);
                if (*in == EOF) {
                    break;
                }
                int number = Glucose::parseInt(in);
                if (number == 0) {
                    continue;
                }

                Literal lit = mkLit(number);
                auto i = index(lit);
                if (i >= sol.size()) {
                    sol.resize(i + 1, false);
                }
                sol[i] = isSigned(lit);
            }
        }
    }
    return sol;
}

} // namespace Solvers::MaxSat
