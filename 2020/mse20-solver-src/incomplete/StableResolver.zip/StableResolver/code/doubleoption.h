/*
 * Copyright (C) Synoptics GmbH
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains the property of Synoptics GmbH and its
 * suppliers, if any. The intellectual and technical concepts contained herein are proprietary to
 * Synoptics GmbH and its suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly forbidden unless
 * prior written permission is obtained from Synoptics GmbH.
 *
 */
#pragma once

#include <option.h>

namespace Solvers {
class DoubleOption : public Option {
    double value;
    DoubleRange range;

  public:
    DoubleOption(const std::string &c, const std::string &n, char s, const std::string &d,
                 const DoubleRange &r, double def)
        : Option(n, s, d, c, "<double>"), value(def), range(r) {}

    operator double() const { return value; }
    operator double &() { return value; }
    double val() const { return value; }
    DoubleOption &operator=(double s) {
        if (range.contains(s))
            value = s;
        return *this;
    }

    virtual bool parse(const std::string &str, const std::string &secondstr,
                       int *i = NULL) override;

    virtual void help(bool verbose = false) override;
};
} // namespace Solvers
