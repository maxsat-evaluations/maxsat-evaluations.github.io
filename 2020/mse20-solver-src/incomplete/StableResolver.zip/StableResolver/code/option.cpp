/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "option.h"

#include "options.h"
#include "orderedoption.h"
#include <algorithm>
#include <unordered_set>

namespace Solvers {

int Option::numberOfSetOrderedOptions(0);

void parseCommandLine(std::vector<std::string> &args, bool strict) {
    std::string &usage = Option::getUsageString();
    usage = "Usage: ";
    usage += args[0];
    for (int k = 0; k < Option::getOptionList().size(); k++) {
        Option *o = Option::getOptionList()[k];
        OrderedOption *oo = dynamic_cast<OrderedOption *>(o);
        if (oo) {
            std::string u = std::string("<") + oo->name + ">";
            if (oo->isOptional()) {
                u = std::string("[<") + oo->name + ">]";
            }
            usage += " " + u;
        }
    }
    usage += " [OPTIONS]";

    int i;
    for (i = 1; i < args.size(); i++) {
        const std::string &str = args[i];
        std::string secondstr = std::string();
        if (i < args.size() - 1) {
            secondstr = args[i + 1];
        }
        if (str == std::string("-h") || str == std::string("-help")) {
            printUsageAndExit(args, false);
        } else if (str == std::string("-H") || str == "-help-verb") {
            printUsageAndExit(args, true);
        } else {
            bool parsed_ok = false;

            for (int k = 0; !parsed_ok && k < Option::getOptionList().size(); k++) {
                parsed_ok = Option::getOptionList()[k]->parse(str, secondstr, &i);
            }

            if (!parsed_ok) {
                if (strict && str.rfind('-', 0) == 0) {
                    std::cout << "ERROR: unknown flag " << str << ", use -h for help" << std::endl;
                    exit(EXIT_FAILURE);
                } else {
                    args.erase(args.begin() + i);
                    i--;
                }
            }
        }
    }

    // analyze options
    bool optionalorderedset = false;
    std::unordered_set<std::string> foundnames;
    std::unordered_set<char> foundshortnames;

    Option::numberOfSetOrderedOptions = 0;
    for (int k = 0; k < Option::getOptionList().size(); k++) {
        Option *o = Option::getOptionList()[k];
        OrderedOption *oo = dynamic_cast<OrderedOption *>(o);
        if (oo) {
            if (oo->isSet()) {
                Option::numberOfSetOrderedOptions++;
            }
            if (!oo->isOptional() && !oo->isSet()) {
                std::cout << "ERROR: non-optional argument <" << o->name
                          << "> is not set, use -h for help" << std::endl;
                if (!usage.empty()) {
                    std::cout << usage << std::endl;
                }
                exit(EXIT_FAILURE);
            }
            if (optionalorderedset && !oo->isOptional()) {
                std::cout << "ERROR: non-optional argument <" << o->name
                          << "> after optional argument" << std::endl;
                if (!usage.empty()) {
                    std::cout << usage << std::endl;
                }
                exit(EXIT_FAILURE);
            }
            if (oo->isOptional()) {
                optionalorderedset = true;
            }
        }
        if (o->shortName != 0 && foundshortnames.find(o->shortName) != foundshortnames.end()) {
            std::cerr << "ERROR: duplicated shortname -" << o->shortName << std::endl;
            exit(EXIT_FAILURE);
        }
        foundshortnames.insert(o->shortName);
        if (!o->name.empty() && foundnames.find(o->name) != foundnames.end()) {
            std::cerr << "ERROR: duplicated name -" << o->name << std::endl;
            exit(EXIT_FAILURE);
        }
        foundnames.insert(o->name);
    }

    if (vvvverbose) {
        vvverbose = true;
    }

    if (vvverbose) {
        vverbose = true;
    }

    if (vverbose) {
        verbose = true;
    }
}

void printUsageAndExit(const std::vector<std::string> &args, bool verbose) {
    (void)args;
    const std::string &usage = Option::getUsageString();
    if (!usage.empty()) {
        std::cout << usage << std::endl;
    }

    std::sort(Option::getOptionList().begin(), Option::getOptionList().end(), Option::lt);

    std::string prev_cat;
    std::string prev_type;

    for (int i = 0; i < Option::getOptionList().size(); i++) {
        const std::string &cat = Option::getOptionList()[i]->category;
        const std::string &type = Option::getOptionList()[i]->typeName;

        if (cat != prev_cat) {
            std::cout << std::endl << cat << " OPTIONS:" << std::endl << std::endl;
        } else if (type != prev_type) {
            std::cout << std::endl;
        }

        Option::getOptionList()[i]->help(verbose);

        prev_cat = Option::getOptionList()[i]->category;
        prev_type = Option::getOptionList()[i]->typeName;
    }

    if (verbose && !Option::getAdditionalHelp().empty()) {
        std::cout << std::endl;
        std::cout << Option::getAdditionalHelp() << std::endl;
    }

    std::cout << std::endl << "HELP OPTIONS:" << std::endl << std::endl;
    std::cout << "  -help -h         Print help message." << std::endl;
    std::cout << "  -help-verb -H    Print verbose help message." << std::endl;
    std::cout << std::endl;
    std::cout << std::endl;
    // TODO save / load options
    exit(0);
}

bool Option::isOptionName(const std::string &str) const {
    return str.rfind('-', 0) == 0 && (str.rfind(name, 1) == 1 || str.rfind(shortName, 1) == 1);
}

bool Option::acceptableSecondArgument(const std::string &str) const {
    return !str.empty() && str.rfind('-', 0) != 0;
}

std::string Option::createNameShortNameUsage() const {
    std::string res;
    if (!name.empty()) {
        res += "-" + name;
        if (shortName != 0) {
            res += " ";
        }
    }
    if (shortName != 0) {
        res += std::string("-") + shortName;
    }
    return res;
}

void setUsageHelp(const std::string &str) { Option::getUsageString() = str; }
} // namespace Solvers
