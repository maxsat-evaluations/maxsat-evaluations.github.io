/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software:
 * you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You
 * should have received a copy of the GNU Lesser General Public License along with this program.
 *
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "intinterval.h"
#include <cassert>
#include <intinterval.h>
#include <stream.h>

namespace Solvers {

std::vector<Interval> uniteIntervals(
    const std::vector<Interval> &l,
    const Interval &i) { // l must be a disjoint list of sorted intervals (disjoint means > epsilon
    // distance between double intervals and > 1 distance between int intervals)
    std::vector<Interval> res;
    int state = 0;
    Interval newinterval;
    bool intervalintegrated = false;
    for (const auto &cur : l) {
        if (state == 0) {
            if (i.lower <= cur.lower && i.upper >= cur.lower - 1) {
                newinterval.lower = i.lower;
                state = 1;
            } else if (i.lower >= cur.lower - 1 && i.lower <= cur.upper + 1) {
                state = 1;
                newinterval.lower = cur.lower < i.lower ? cur.lower : i.lower;
            } else if (i.upper < cur.lower) {
                state = 5; // finished
                res.push_back(i);
                intervalintegrated = true;
            }

            if (state == 1) {
                if (!res.empty()) {
                    auto last = res.back();
                    if (last.upper == newinterval.lower - 1) {
                        newinterval.lower = last.lower;
                        res.pop_back();
                    }
                }
            }
        }

        if (state == 1) {
            if (i.upper <= cur.upper && i.upper >= cur.lower - 1) {
                newinterval.upper = cur.upper;
                state = 2;
            } else if (i.upper < cur.lower - 1) {
                newinterval.upper = i.upper;
                state = 3;
            }
        }

        if (state == 5 || state == 0) {
            res.push_back(cur);
        }

        if (state == 2 || state == 3) {
            res.push_back(newinterval);
            if (state == 3) {
                res.push_back(cur);
            }
            state = 5;
            intervalintegrated = true;
        }
    }
    if (!intervalintegrated) {
        if (state == 1) {
            newinterval.upper = i.upper;
            res.push_back(newinterval);
        } else {
            res.push_back(i);
        }
    }
    return res;
}

std::vector<Interval> Interval::intervalMinus(const std::vector<Interval> &l, int extension,
                                              int min, int max) const {

    // compute: ( interval setminus ( union of intervals in l ) ) intersected with interval
    // (min,max)
    // allow also extension but no res interval can consist of extension part only
    std::vector<Interval> res;
    Interval interval(std::max(lower, min), std::min(upper, max));

    // return immediately if nothing is to be cut away
    if (l.empty()) {
        interval.upper += extension;
        res.emplace_back(interval);
        return res;
    }
    // I scan my interval from left to tight and curr says at which value I am currently
    int curr = interval.lower;
    for (const Interval &i : l) {
        if (i.lower > interval.upper + extension) {
            // intervals have passed my interval, so return the rest of my interval
            res.emplace_back(Interval(curr, interval.upper + extension));
            return res;
        }
        if (i.upper >= curr) {
            // i cuts something away from my interval
            if (i.lower > curr) {
                // either there there is something left on the left, then add it to res
                // if it is not only in extension
                if (curr <= interval.upper) {
                    res.emplace_back(Interval(curr, i.lower - 1));
                    curr = i.upper + 1;
                }

            } else {
                // or there is nothing left on the left
                curr = i.upper + 1;
            }
        }
    }

    // add remaining interval if something is left on the right (and not only in extension)
    if (curr <= interval.upper) {
        res.emplace_back(Interval(curr, interval.upper));
    }

    return res;
}

std::vector<Interval> expandOccupiedTime(const std::vector<Interval> &l, int k) {
    // make each interval k numbers larger to its left and unite if necessary
    // only works with integer intervals
    if (l.empty()) {
        return l;
    }
    int lastUpper = -std::numeric_limits<int>::max();
    int lastLower = l[0].lower;
    std::vector<Interval> res;
    for (const Interval &i : l) {
        if (i.lower - k <= lastUpper) {
            // unite with future intervals
            lastUpper = i.upper;
        } else {
            // add last streched interval and update lower
            if (lastUpper > -std::numeric_limits<int>::max()) {
                res.emplace_back(Interval(lastLower - k, lastUpper));
            }
            lastUpper = i.upper;
            lastLower = i.lower;
        }
    }
    res.emplace_back(Interval(lastLower - k, lastUpper));

    return res;
}
} // namespace Solvers
