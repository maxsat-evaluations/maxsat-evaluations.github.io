/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "intoption.h"

namespace Solvers {

bool IntOption::parse(const std::string &str, const std::string &secondstr, int *i) {
    if (isOptionName(str) && !secondstr.empty()) {
        if (i) {
            (*i)++;
        }
        if (acceptableSecondArgument(secondstr)) {
            int val;
            try {
                val = std::stoi(secondstr);
            } catch (...) {
                std::cout << "ERROR value " << secondstr << " for option " << name
                          << " is not an integer" << std::endl;
                return false;
            }
            if (!range.contains(val)) {
                std::cout << "ERROR value " << secondstr << " for option " << name
                          << " is not in range. Use -h for help." << std::endl;
                return false;
            }
            value = val;
            return true;
        }
    }
    return false;
}

void IntOption::help(bool verbose) {
    std::cout << "  ";
    std::cout << createNameShortNameUsage();
    std::cout << " = ";
    std::cout << typeName << " " << range.toString();
    std::cout << "(default: " << value << ")" << std::endl;
    if (verbose) {
        std::cout << "\n        " << description << std::endl;
        std::cout << std::endl;
    }
}
} // namespace Solvers
