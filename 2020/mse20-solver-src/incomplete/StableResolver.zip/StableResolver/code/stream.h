/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <cstring>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <optional>
#include <sstream>
#include <string>
#include <timer.h>
#include <vector>

namespace Solvers {

#define __FILENAME__ (strrchr(__FILE__, '/') ? strrchr(__FILE__, '/') + 1 : __FILE__)

extern bool programTimerStarted;
extern Timer programTimer;
extern std::mutex timeMutex;
static inline std::string std_evalCurTime() {
    if (!programTimerStarted) {
        programTimerStarted = true;
        programTimer.start();
    }
    time_t e = programTimer.elapsed() / 1000;
    std::stringstream buffer;
    timeMutex.lock();
    buffer << std::put_time(std::gmtime(&e), "%H:%M:%S");
    timeMutex.unlock();
    return buffer.str();
}

extern std::mutex logMutex;
extern int globalTimeout;

#ifndef COMP_MODE
#define WRITE_LOG(msg, type)                                                                       \
    logMutex.lock();                                                                               \
    std::cout << std_evalCurTime() << type << __func__ << " " << __FILENAME__ << ":" << __LINE__   \
              << ": " << (msg) << std::endl;                                                       \
    logMutex.unlock();
#else
#define WRITE_LOG(msg, type)                                                                       \
    logMutex.lock();                                                                               \
    std::cout << type << std_evalCurTime() << " " << (msg) << std::endl;                           \
    logMutex.unlock();
#endif

#ifndef COMP_MODE

#define ERROR(msg) WRITE_LOG(msg, " E ")
#define WARNING(msg) WRITE_LOG(msg, " W ")
#define LOG(msg) WRITE_LOG(msg, " I ")

#else

#define ERROR(msg) WRITE_LOG(msg, "c ERROR ")
#define WARNING(msg) WRITE_LOG(msg, "c WARNING ")
#define LOG(msg) WRITE_LOG(msg, "c ")
#define LOGobj(msg)                                                                                \
    logMutex.lock();                                                                               \
    std::cout << "o " << (msg) << std::endl;                                                       \
    logMutex.unlock();

#endif

#define LOGs(msg)                                                                                  \
    if (!silent) {                                                                                 \
        LOG(msg);                                                                                  \
    }

#define LOGvv(msg)                                                                                 \
    if (vverbose) {                                                                                \
        LOG(msg);                                                                                  \
    }

#define LOGvvv(msg)                                                                                \
    if (vvverbose) {                                                                               \
        LOG(msg)                                                                                   \
    }

#define LOGv(msg)                                                                                  \
    if (verbose) {                                                                                 \
        LOG(msg);                                                                                  \
    }

#define LOGMINI(msg)                                                                               \
    logMutex.lock();                                                                               \
    std::cout << std_evalCurTime() << " " << (msg) << std::endl;                                   \
    logMutex.unlock();

#define STRVARVALUE(var) (QString("%1 = %2").arg(#var).arg(var))
#define ERROR_EXIT(msg)                                                                            \
    ERROR(msg);                                                                                    \
    ::exit(EXIT_FAILURE);
} // namespace Solvers

template <class T> std::ostream &operator<<(std::ostream &out, const std::vector<T> &vec) {
    bool first = true;
    for (const T &val : vec) {
        if (!first) {
            out << ", ";
        } else {
            first = false;
        }
        out << val;
    }
    return out;
}
