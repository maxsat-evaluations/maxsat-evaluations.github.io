/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */
#pragma once

#include <cmath>
#include <unordered_map>

namespace Solvers {

static bool fuzzyCompare(double a, double b, double eps = .000001f) {
    return std::fabs(a - b) < eps;
}

template <class Tag, class T = int, T defaultValue = -1> class Id {
  public:
    using Type = T;
    static Id invalidId() { return Id(); }
    Id() : m_id(defaultValue) {}
    explicit Id(T id) : m_id(id) {}
    operator T &() { return m_id; }
    operator T() const { return m_id; }
    bool isValid() const { return m_id != invalidId(); }

    friend bool operator==(Id a, Id b) { return a.m_id == b.m_id; }
    friend bool operator!=(Id a, Id b) { return a.m_id != b.m_id; }

  private:
    T m_id;
};

} // namespace Solvers

namespace std {
template <class Tag, class T> struct hash<Solvers::Id<Tag, T>> {
    size_t operator()(const Solvers::Id<Tag, T> &k) const { return hash<T>()(k); }
};
} // namespace std
