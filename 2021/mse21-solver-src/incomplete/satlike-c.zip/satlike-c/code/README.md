### README for the SATLike MaxSAT Solver

### MaxSAT Evaluation 2021
./satlike-c_static <input-file>
