/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once

#include <option.h>

namespace Solvers {

class StringOption : public Option, public std::string {
  public:
    StringOption(const std::string &c, const std::string &n, char s, const std::string &d,
                 const std::string &defaultstr)
        : Option(n, s, d, c, "<string>"), std::string(defaultstr) {}
    StringOption &operator=(const std::string &s) {
        std::string::operator=(s);
        return *this;
    }

    virtual bool parse(const std::string &str, const std::string &secondstr,
                       int *i = nullptr) override;

    virtual void help(bool verbose = false) override;
};
} // namespace Solvers
