/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#pragma once
#include <booloption.h>
#include <climits>
#include <functional>
#include <list>
#include <maxsatmodel.h>
#include <random>
#include <simp/SimpSolver.h>
#include <timer.h>
#include <unordered_set>

namespace Solvers::MaxSat {

/**
 * @brief Interface for independent set solver.
 */

struct StablePara {
    double geom = 0.5;
    int maxStepsWorse = 1;
    int maxrandomclauses = 1;
    int innerMaxIt = 1;
    int initcandids = 1;
    int perturbtoweights = 0;
    bool autoparam = false;
    double plateau = 0.01;
    int maxstepsperturbtosat = 10;
    int iterLimitGlucose = 1000;
    int approxtime = 1;
};

class StableResolver {

  public:
    explicit StableResolver(MaxsatModel &model, int maxit = INT_MAX, int timeout = INT_MAX,
                            const StablePara &para = {}, Glucose::Solver *satSolver = nullptr,
                            MaxsatModel *initialModel = nullptr);
    void run(std::vector<bool> &&initsol = {});
    uint32_t getNumberOfViolatedHardClauses();
    uint64_t getBestObjectiveValue() { return bestObjectiveValue; };
    void writeSolution(const std::string &fileName,
                       const std::vector<bool> &origInitSol = {}) const;
    void writeSolution(std::ostream &f, const std::vector<bool> &origInitSol = {}) const;
    void setInterpretation(const std::vector<bool> &i) { interpretation = i; };
    void setStabilities(const std::vector<int> &s) { stabilities = s; };
    void setIntermediate(const std::vector<bool> &i) { intermediate = i; };
    void setObjectiveValue(uint64_t o) { objectiveValue = o; };
    void improve(uint32_t curClauseIndex);
    void saveBest();
    void dostop() { stop = true; }

    std::vector<bool> &getInterpretationRef() { return interpretation; }
    const std::vector<bool> &getInterpretation() const { return interpretation; }

    std::vector<bool> prevInterpretation;

  private:
    using CandidateClause = uint32_t;
    static constexpr CandidateClause NoClause = std::numeric_limits<CandidateClause>::max();

    bool perturb();
    bool perturbRandomClause();
    bool perturbSatSolver();
    void stableImprove();
    void checkSolution();
    int64_t flipSign(uint32_t literalIndex,
                     std::vector<uint32_t> *unsatisfiedClauseIndices = nullptr,
                     std::vector<uint32_t> *clauseIndicesOfstabilityOneToTwo = nullptr,
                     bool addToUnsatCandidatesForPerturb = false);
    int64_t flipIfNoHarm(uint32_t literalIndex);
    std::pair<bool, int64_t> flipIfNoNextHarm(uint32_t literalIndex, bool onlyImprove);

    void restoreBest();
    void saveIntermediate();
    void restoreIntermediate();
    double getDecreasingProb();
    void validateSolutionValue();
    void setParams(int it);
    void plateau();

    void initCandidateClauses();
    void addToCandidateClauses(CandidateClause c);
    void addToCandidateClauses(const std::list<CandidateClause> &l);
    void addToCandidateClauses(const std::vector<CandidateClause> &l);
    CandidateClause popFromCandidateClauses();
    CandidateClause getRandomZeroStabilityClause();
    bool hasCandidateClauses();

    MaxsatModel model;
    int maxit;
    int notImproved = 0;

    int timeout;
    std::vector<uint64_t> weights;
    double probReach = 0;
    double prob = 0;
    int it = 0;
    int numStepsWorse = 0;
    uint64_t sumHardWeights = 0;
    int num_breaks = 0;
    int Successflipifnonextharmwithoutimprove = 0;
    int Successflipifnonextharmwithimprove = 0;

    StablePara para;

    std::vector<bool> alreadyFlippedInImprove;
    std::vector<uint32_t> alreadyFlippedIndexInImprove;
    std::unordered_set<uint32_t> alreadyTriedLitForNextHarm;
    std::unordered_set<uint32_t> alreadyFlippedInPerturb;

    std::default_random_engine generator;

    int notimproved = 0;
    int improved = 0;
    int bestimproved = 0;

    size_t innerCalls = 0;
    double approxTime() const; // in ms

    std::vector<bool> intermediate;
    std::unordered_set<uint32_t> intermediateSet;
    std::vector<bool> best;
    std::unordered_set<uint32_t> bestSet;

    // solution ingridiences
    std::vector<bool> interpretation;
    std::vector<int> stabilities;
    uint64_t objectiveValue = 0;
    std::list<CandidateClause> candidateClauses;
    std::vector<bool> isCandidateClauses;

    uint64_t prevObjectiveValue = 0;

    // intermedia solution in simulated annealing with reset
    std::vector<bool> intermediateInterpretation;
    uint64_t intermediateObjectiveValue = 0;
    std::vector<int> intermediateStabilities;
    std::list<uint32_t> intermediateCandidateClauses;

    // best solution in total
    uint64_t bestObjectiveValue = 0;

    std::vector<CandidateClause> randomCandidates;
    std::unordered_set<CandidateClause> unsatCandidatesForPerturb;
    std::unordered_set<CandidateClause> newUnsatCandidatesForPerturb;
    std::vector<CandidateClause> unsatisfiedClauseIndices;
    std::vector<CandidateClause> innerUnsatisfiedClauseIndices;
    std::vector<CandidateClause> increasedStabilityIndices;
    bool stop = false;

    double curSatSolverSeed = 1.0;
    Glucose::Solver *satSolver;
    MaxsatModel *initialModel;
    std::vector<bool> lastSatSolverInterpretation;
    bool solveViaSatSolver(const std::vector<uint32_t> &softClauses);
    // bool solveViaSatSolverSatisfiedSoftclauses();
    bool solveViaSatSolverUnsatisfiedSoftclauses();
};
} // namespace Solvers::MaxSat
