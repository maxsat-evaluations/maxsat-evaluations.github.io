/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "core/Solver.h"
#include <csignal>
#include <doubleoption.h>
#include <fstream>
#include <maxsatmodel.h>
#include <maxsatmodelreader.h>
#include <options.h>
#include <satsolvergenerator.h>
#include <simp/SimpSolver.h>
#include <stableresolver.h>
#include <stream.h>
#include <valgrind/callgrind.h>

using namespace Solvers;
using namespace Solvers::MaxSat;

StringOption outsol("solver", "outsol", 'o', "", "");
StringOption initsolpath("solver", "initsol", 0, "Path to iniital solution if should be used", "");
IntOption maxit("solver", "maxit", 0, "Maximum number of Iterations.", Interval(0, INT_MAX),
                INT_MAX);
IntOption timeout("solver", "timeout", 'z', "Maximum seconds.", Interval(0, INT_MAX), INT_MAX);
DoubleOption geomPerturb("solver", "geom", 0, "Geom para.", DoubleRange(0., 1., false, false),
                         0.75);
IntOption innerMaxIt("solver", "innermaxit", 0, "Maximal Number of Iterations in each Improve Step",
                     Interval(0, INT_MAX), 100);
IntOption calcinitsol("solver", "calcinitsol", 0,
                      "0=all lits false, 1=all lits true, 2=greedy init, 3=glucose.",
                      Interval(0, 3), 3);
IntOption maxstepsworse("solver", "maxstepsworse", 0,
                        "Max steps worse while solving. -1 means auto calc.", Interval(0, INT_MAX),
                        1000);
IntOption maxrandomclauses("solver", "maxrandomclauses", 0,
                           "Max number of random guesses of unsat clauses", Interval(0, INT_MAX),
                           1000);
IntOption perturbtoweights("solver", "perturbtoweights", 0,
                           "number of clauses from which the one with max weight is chosen ",
                           Interval(0, INT_MAX), 1);
BoolOption autoparam("solver", "autoparam", 0,
                     "Do not automatical set params according to features and decision tree model.",
                     false);
BoolOption elim("solver", "elim", 0,
                "Do elminiate all variables and clauses that the sat solver has found.", true);
DoubleOption plateau("solver", "plateau", 0,
                     "Para for geom distr for how many plateau search steps are performed",
                     DoubleRange(0., 1., false, false), 0.01);
IntOption approxtime("solver", "approxtime", 0, "factor of 10 000 for approxtime ",
                     Interval(0, INT_MAX), 6);

IntOption maxstepsperturbtosat(
    "solver", "maxstepsperturbtosat", 0,
    "after how many iterations without improvements should perturb to sat be called",
    Interval(0, INT_MAX), 500);
IntOption iterLimitGlucose("solver", "iterLimitGlucose", 0,
                           "iteration limit for glucose when called from perturb to sat",
                           Interval(0, INT_MAX), 500);

std::vector<bool> initGreedy(const MaxsatModel &model);
std::vector<bool> initExact(MaxsatModel &model, std::vector<bool> &origInitsol,
                            std::unordered_map<uint32_t, std::vector<Clause>> &eliminatedClauses,
                            MaxsatModel *oldModel);

static StableResolver *srsolver = nullptr;
static Glucose::Solver *satsolver = nullptr;
static Glucose::Solver *solver;
static Glucose::SimpSolver *simpSolver;
static Glucose::Solver *usedsolver = nullptr;
static bool useSimp = false;
static std::unordered_map<uint32_t, bool> propagatedLits;
static std::unordered_set<uint32_t> eliminatedVars;

void solve(const std::string &fName) {
    srand(int(seed));

    LOG("start maxsat solver");

    MaxsatModel model;

    StablePara para;
    para.geom = geomPerturb;
    para.innerMaxIt = innerMaxIt;
    para.maxStepsWorse = maxstepsworse;
    para.maxrandomclauses = maxrandomclauses;
    para.perturbtoweights = perturbtoweights;
    para.autoparam = autoparam;
    para.maxstepsperturbtosat = maxstepsperturbtosat;
    para.iterLimitGlucose = iterLimitGlucose;
    para.approxtime = approxtime;

    // greedy assign initsol
    std::vector<bool> initsol;
    std::vector<bool> origInitsol;

    if (calcinitsol == 3) {
        preproc = false;
    }

    std::unordered_map<uint32_t, std::vector<Clause>> eliminatedClauses;

    MaxsatModel oldModel;

    if (MaxSATModelReader().readFromWcnfFile(fName, model, timeout)) {
        LOG("model has nClauses: " + std::to_string(model.getnClauses()) +
            " nVars: " + std::to_string(model.getnLiterals()))
        if (calcinitsol == 0) {
            // assign all to false
            initsol = std::vector<bool>(model.getnLiterals(), false);

        } else if (calcinitsol == 1) {
            // assign all to true
            initsol = std::vector<bool>(model.getnLiterals(), true);

        } else if (calcinitsol == 2) {
            // apply greedy
            initsol = initGreedy(model);

        } else if (calcinitsol == 3) {
            // apply exact via sat solver
            initsol = initExact(model, origInitsol, eliminatedClauses, &oldModel);
        }
    }

    if (!initsolpath.empty()) {
        MaxSATModelReader r;
        auto inputinitsol = r.readSolutionFromFile(initsolpath);
        for (uint32_t v = 0; v < inputinitsol.size(); v++) {
            auto vMapped = model.getOrigToMappedVar(v);
            if (vMapped >= 0) {
                initsol[vMapped] = inputinitsol[v];
            }
        }
    }

    if (origInitsol.empty()) {
        origInitsol.reserve(model.getNumOrigVars());
        for (uint32_t v = 0; v < model.getNumOrigVars(); v++) {
            auto vMapped = model.getOrigToMappedVar(v);
            if (vMapped >= 0) {
                origInitsol.push_back(initsol[vMapped]);
            } else {
                origInitsol.push_back(false);
            }
        }
    }

    if (verbose) {
        model.writeModel("tmp.wcnf");
    }

    auto srOldModel = oldModel.getNumOrigVars() > 0 ? &oldModel : &model;
    StableResolver sr{model, maxit, timeout, para, usedsolver, srOldModel};
    srsolver = &sr;
    CALLGRIND_START_INSTRUMENTATION;
    sr.run(std::move(initsol));
    CALLGRIND_STOP_INSTRUMENTATION;

    auto &interpretation = sr.getInterpretationRef();

    if (verbose) {
        LOG("check solution")
        size_t numUnsat = 0;
        for (const Clause &c : model.getClauses()) {
            if (c.weight < model.getMaxWeight()) {
                continue;
            }
            bool clauseSatisfied = false;
            for (auto lit : c.literals) {
                if (interpretation[index(lit)] == isSigned(lit)) {
                    clauseSatisfied = true;
                    break;
                }
            }
            if (!clauseSatisfied) {
                ERROR(model.toString(c, interpretation));
                numUnsat++;
            }
        }
        LOG("num_unsat = " + std::to_string(numUnsat));
    }

    // flip for eliminated clauses
    if (elim && !eliminatedVars.empty()) {
        Glucose::vec<Glucose::Lit> assumps;
        for (uint32_t v = 0; v < interpretation.size(); v++) {
            if (model.getClausesOfLit(v).empty()) {
                continue;
            }
            uint32_t vMapped = oldModel.getOrigToMappedVar(model.getMappedToOrigVar(v));
            Glucose::Lit gLit = Glucose::mkLit(vMapped, !interpretation[v]);
            assumps.push(gLit);
        }
        LOG("find eliminated vars solution, fixed=" + std::to_string(assumps.size()))
        simpSolver->ignoreTimeout = true;
        Glucose::lbool satM = simpSolver->solveLimited(assumps);

        bool sat;
        {
            using namespace Glucose;
            sat = satM == l_True;
        }
        Glucose::Solver *ressolver = simpSolver;
        bool extraSolver = false;
        if (!sat) {
            extraSolver = true;

            auto *elimsolver = SatSolverGenerator(oldModel).generateSolver();
            elimsolver->ignoreTimeout = false;
            globalTimeout += 2;

            WARNING("Could not restore eliminated clauses! Restore via "
                    "extra Satsolver with clauses: " +
                    std::to_string(elimsolver->nClauses()) +
                    " nvars: " + std::to_string(elimsolver->nVars()))
            WARNING("OldModel has nClauses: " + std::to_string(oldModel.getnClauses()) +
                    " nVars: " + std::to_string(oldModel.getnLiterals()))

            for (uint32_t v = 0; v < interpretation.size(); v++) {
                elimsolver->setPolarity(oldModel.getOrigToMappedVar(model.getMappedToOrigVar(v)),
                                        !interpretation[v]);
            }

            Glucose::vec<Glucose::Lit> dummy;
            satM = elimsolver->solveLimited(dummy);
            ressolver = elimsolver;

            {
                using namespace Glucose;
                sat = satM == l_True;
            }
            if (sat) {
                LOG("Could restore via polarities in SatSolver")
                for (size_t v = 0; v < oldModel.getnLiterals(); ++v) {
                    using namespace Glucose;
                    auto val = elimsolver->model[v];
                    if (val != l_Undef) {
                        origInitsol[oldModel.getMappedToOrigVar(v)] = val == l_True;
                        auto vMapped = model.getOrigToMappedVar(oldModel.getMappedToOrigVar(v));
                        if (vMapped >= 0) {
                            interpretation[vMapped] = val == l_True;
                        }
                    }
                }
            } else {
                ERROR("Could NOT restore via polarities, use init sol as fallback")
                for (uint32_t v = 0; v < interpretation.size(); v++) {
                    interpretation[v] = origInitsol[model.getMappedToOrigVar(v)];
                }
            }
            for (uint32_t vAux = oldModel.getnLiterals() - model.numAux;
                 vAux < oldModel.getnLiterals(); vAux++) {
                LitInClause soft;
                LitInClause hard;
                for (auto c : oldModel.getClausesOfLit(vAux)) {
                    const Clause &cl = oldModel.getClause(c.clauseIdx);
                    (cl.weight < oldModel.getMaxWeight() ? soft : hard) = c;
                }
                const Clause &softC = oldModel.getClause(soft.clauseIdx);
                assert(softC.literals.size() == 1);
                bool valAux = origInitsol[oldModel.getMappedToOrigVar(vAux)];
                if (valAux != soft.sign) {
                    const Clause &hardC = oldModel.getClause(hard.clauseIdx);
                    int stability = 0;
                    for (auto lit : oldModel.getClause(hard.clauseIdx).literals) {
                        bool val = origInitsol[oldModel.getMappedToOrigVar(index(lit))];
                        stability += isSigned(lit) == val;
                    }
                    if (stability > 1) {
                        origInitsol[oldModel.getMappedToOrigVar(vAux)] = !valAux;
                        interpretation[model.getOrigToMappedVar(
                            oldModel.getMappedToOrigVar(vAux))] = !valAux;
                    }
                }
            }
        }
        if (!sat) {
            ERROR("Could not restore eliminated clauses, the solution might be wrong! Has been "
                  "resetted to initsol")
        } else {
            for (auto vElim : eliminatedVars) {
                uint32_t v = oldModel.getOrigToMappedVar(
                    oldModel.getMappedToOrigVar(vElim)); // TODO why the mapping back and forth?
                using namespace Glucose;
                auto val = ressolver->model[v];
                origInitsol[oldModel.getMappedToOrigVar(v)] = val == l_True;
            }
        }
        if (extraSolver) {
            delete ressolver;
        }
    }

    // update origInitsol to new solution
    for (uint32_t v = 0; v < origInitsol.size(); v++) {
        auto vMapped = model.getOrigToMappedVar(v);
        if (vMapped >= 0) {
            origInitsol[v] = interpretation[vMapped];
        }
    }

    // use srOldModel from here on since we may not have been eliminated stuff

    if (verbose) {
        LOG("check solution original model")
        size_t numUnsat = 0;
        for (const Clause &c : srOldModel->getClauses()) {
            if (c.weight < srOldModel->getMaxWeight()) {
                continue;
            }
            bool clauseSatisfied = false;
            for (auto lit : c.literals) {
                bool val = origInitsol[srOldModel->getMappedToOrigVar(index(lit))];
                if (val == isSigned(lit)) {
                    clauseSatisfied = true;
                    break;
                }
            }
            if (!clauseSatisfied) {
                ERROR(srOldModel->toString(c, origInitsol, false));
                numUnsat++;
            }
        }
        LOG("num_unsat = " + std::to_string(numUnsat));
    }

    // calc final gap
    bool isSat = true;
    uint64_t solutionObj = 0;
    for (uint32_t cIdx = 0; cIdx < srOldModel->getnClauses(); cIdx++) {
        const Clause &cl = srOldModel->getClause(cIdx);
        if (srOldModel->isSatisfied(cIdx, origInitsol, false)) {
            // cppcheck-suppress useStlAlgorithm
            solutionObj += cl.weight;
        } else if (cl.weight == srOldModel->getMaxWeight()) {
            isSat = false;
        }
    }

    auto writeSolution = [&](std::ostream &f) {
        f << "v";
        if (!origInitsol.empty()) {
            for (uint32_t i = 0; i < origInitsol.size() - model.numAux; i++) {
                f << " ";
                bool val = origInitsol[i];
                Literal l{i, val};
                f << outputLit(l);
            }
        }
        f << std::endl;
    };

    if (isSat) {
        LOG("final_clique_gap = " + std::to_string(srOldModel->getUpperBound() - solutionObj));
#ifdef COMP_MODE
        LOGobj(srOldModel->getUpperBound() - solutionObj)
#endif

            LOG("finished solver")
#ifdef COMP_MODE
                writeSolution(std::cout);
#endif
    } else {
        LOG("finished solver, Model is UNSAT")
    }
    if (!outsol.empty()) {
        std::ofstream f(outsol);
        if (!f.is_open()) {
            ERROR_EXIT(std::string("could not open file ") + outsol);
        }
        writeSolution(f);
    }
#ifdef COMP_MODE
    _exit(0);
#endif
    srsolver = nullptr;
    delete usedsolver;
}

static void termexit(int n) {
    if (srsolver) {
        LOG("plan exit srsolver")
        srsolver->dostop();
    } else if (satsolver) {
        LOG("plan exit satsolver")
        _exit(0);
    } else {
        _exit(0);
    }
}

int main(int argc, char *argv[]) {
    signal(SIGTERM, termexit);
    std::vector<std::string> sl(argv, argv + argc);
    preproc = true;

    OrderedOption instancename("solver", "INSTANCEFILE", 0, "", "");
    Option::onlyAllow({&seed,
                       &preproc,
                       &maxit,
                       &timeout,
                       &instancename,
                       &verbose,
                       &vverbose,
                       &tempdelete,
                       &vvverbose,
                       &outsol,
                       &geomPerturb,
                       &innerMaxIt,
                       &maxstepsworse,
                       &maxrandomclauses,
                       &perturbtoweights,
                       &calcinitsol,
                       &autoparam,
                       &plateau,
                       &elim,
                       &maxstepsperturbtosat,
                       &iterLimitGlucose,
                       &initsolpath,
                       &approxtime});
    parseCommandLine(sl);
    globalTimeout = timeout;

    solve(instancename);
    return 0;
}

std::vector<bool> initGreedy(const MaxsatModel &model) {
    std::vector<bool> initsol(model.getnLiterals(), false);
    std::vector<bool> initsolDef(model.getnLiterals(), false);
    auto findAssign = [&](const auto &literals) {
        bool foundPossible = false;
        Literal possibleLit;
        for (Literal lit : literals) {
            int idx = index(lit);
            if (!foundPossible && !initsolDef[idx]) {
                possibleLit = lit;
                foundPossible = true;
            } else if (initsolDef[idx] && initsol[idx] == isSigned(lit)) {
                foundPossible = false;
                break;
            }
        }
        if (foundPossible) {
            int idx = index(possibleLit);
            initsol[idx] = isSigned(possibleLit);
            initsolDef[idx] = true;
        }
    };
    for (const Clause &c : model.getClauses()) {
        if (c.weight == model.getMaxWeight()) {
            findAssign(c.literals);
        }
    }
    for (const Clause &c : model.getClauses()) {
        if (c.weight < model.getMaxWeight()) {
            findAssign(c.literals);
        }
    }
    return initsol;
}

std::vector<bool> initExact(MaxsatModel &model, std::vector<bool> &origInitsol,
                            std::unordered_map<uint32_t, std::vector<Clause>> &eliminatedClauses,
                            MaxsatModel *oldModel) {

    // initialize
    std::vector<bool> initsol(model.getnLiterals(), false);
    // TODO continue when ignoreTimeout is set
    useSimp = programTimer.elapsed() / 1000 < globalTimeout / 6;

    Glucose::vec<Glucose::Lit> assumps;
    SatSolverGenerator gen(model, initsolpath, &assumps);
    if (!useSimp) {
        LOGv("use normal solver");
        solver = gen.generateSolver(true);
        usedsolver = solver;
    } else {
        LOGv("use simp solver");
        simpSolver = gen.generateSimpSolver(true);
        usedsolver = simpSolver;
    }

    satsolver = usedsolver;

    // solve and read solution
    if (useSimp) {
        simpSolver->simplify();
        simpSolver->eliminate(false);
    }

    Glucose::lbool satM;

    if (useSimp) {
        satM = simpSolver->solveLimited(assumps, true, false);
        simpSolver->use_simplification = false; // for furhter calls of the same model
    } else {
        satM = solver->solveLimited(assumps);
    }

    bool sat;
    {
        using namespace Glucose;
        sat = satM == l_True;
    }
    if (sat) {
        LOG("glucose found start solution")
        for (size_t v = 0; v < model.getnLiterals(); ++v) {
            using namespace Glucose;
            auto val = usedsolver->model[v];
            if (val != l_Undef) {
                initsol[v] = val == l_True;
            }
        }

        if (elim && useSimp) {
            for (uint32_t v = 0; v < model.getnLiterals(); ++v) {
                using namespace Glucose;
                if (simpSolver->isEliminated(v)) {
                    eliminatedVars.insert(v);
                }
            }
            LOG("eliminated: " + std::to_string(eliminatedVars.size()))
            propagatedLits.reserve(simpSolver->getTrail().size());
            for (int i = 0; i < simpSolver->getTrail().size(); i++) {
                auto glucoseLit = simpSolver->getTrail()[i];
                using namespace Glucose;
                propagatedLits.insert({static_cast<uint32_t>(var(glucoseLit)), !sign(glucoseLit)});
            }
            LOG("propagated: " + std::to_string(propagatedLits.size()))
        }

        // check solution if needed and satisfied
        if (verbose) {
            LOG("check solution")
            size_t numUnsat = 0;
            for (const Clause &c : model.getClauses()) {
                if (c.weight < model.getMaxWeight()) {
                    continue;
                }
                bool clauseSatisfied = false;
                for (auto lit : c.literals) {
                    if (initsol[index(lit)] == isSigned(lit)) {
                        clauseSatisfied = true;
                    }
                }
                if (!clauseSatisfied) {
                    LOG(model.toString(c, initsol));
                    numUnsat++;
                }
            }
            LOG("num_unsat = " + std::to_string(numUnsat));
            LOG("initsol_size = " + std::to_string(initsol.size()));

            satsolver->toDimacs("tmp_simpl.cnf");
        }

        if (elim && (!eliminatedVars.empty() || !propagatedLits.empty())) {
            MaxsatModel newModel;
            MaxSATModelReader r;
            r.applyFinalize(model, newModel, initsol, propagatedLits, usedsolver, origInitsol,
                            eliminatedVars, eliminatedClauses);
            LOG("remaining variables: " + std::to_string(newModel.getnLiterals()));
            LOG("remaining clauses: " + std::to_string(newModel.getnClauses()));

            if (oldModel) {
                *oldModel = std::move(model);
            }
            model = std::move(newModel);
        }
    } else {
        eliminatedVars.clear();
        propagatedLits.clear();
        LOG("glucose did not find start solution")
    }

    satsolver = nullptr;
    return initsol;
}
