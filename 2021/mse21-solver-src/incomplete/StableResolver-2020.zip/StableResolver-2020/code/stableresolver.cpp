/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "stableresolver.h"
#include <algorithm>
#include <cassert>
#include <fstream>
#include <numeric>
#include <options.h>
#include <stream.h>
#include <valgrind/callgrind.h>

namespace Solvers::MaxSat {

static unsigned int fastSeed = 1;
static void sFastRand(int seed) { fastSeed = seed; }
static unsigned int fastRand() {
    fastSeed = (214013 * fastSeed + 2531011);
    return (fastSeed >> 16) & 0x7FFF;
}

StableResolver::StableResolver(MaxsatModel &model, int maxit, int timeout, const StablePara &para,
                               Glucose::Solver *satSolver, MaxsatModel *initialModel)
    : model(model), maxit(maxit), timeout(timeout), para(para), generator(int(seed)),
      interpretation(model.getnLiterals(), false), objectiveValue(model.getInitialObjectiveValue()),
      intermediateObjectiveValue(model.getInitialObjectiveValue()),
      isCandidateClauses(model.getnClauses(), false),
      prevObjectiveValue(model.getInitialObjectiveValue()),
      bestObjectiveValue(model.getInitialObjectiveValue()), satSolver(satSolver),
      initialModel(initialModel) {}

void StableResolver::run(std::vector<bool> &&initsol) {

    sFastRand(seed + 1);

    stop = false;

    stabilities.clear();
    stabilities.resize(model.getnClauses(), 0);
    intermediate.clear();
    intermediate.resize(model.getnLiterals(), false);
    best.clear();
    best.resize(model.getnLiterals(), false);
    bestObjectiveValue = intermediateObjectiveValue;

    if (!initsol.empty()) {
        assert(initsol.size() == model.getnLiterals());
        interpretation = std::move(initsol);
    }
    for (size_t v = 0; v < interpretation.size(); ++v) {
        int s = model.getInitialInterpretation()[v];
        if (s == 1) {
            interpretation[v] = true;
        } else if (s == -1) {
            interpretation[v] = false;
        }
    }

    if (interpretation.empty()) {

        LOG(std::string("sr_clique_gap = ") +
            std::to_string(model.getUpperBound() - bestObjectiveValue));
        return;
    }
    assert(interpretation.size() == model.getnLiterals());

    for (size_t i = 0; i < model.getnClauses(); ++i) {
        const Clause &c = model.getClause(i);
        if (c.weight == model.getMaxWeight()) {
            sumHardWeights += c.weight;
        }
        int stability = 0;
        bool clauseSatisfied = false;
        for (auto lit : c.literals) {
            if (interpretation[index(lit)] == isSigned(lit)) {
                stability++;
                clauseSatisfied = true;
            }
        }
        if (clauseSatisfied) {
            objectiveValue += c.weight;
        }
        stabilities[i] = stability;
    }

    saveBest();
    LOG("start with objective value: " + std::to_string(objectiveValue) +
        " initial_gap: " + std::to_string(model.getUpperBound() - objectiveValue));

    // repeat until stopping criterion is met

    initCandidateClauses();
    model.feature.numunsatclauses = candidateClauses.size();
    if (hasCandidateClauses()) {
        bool first = true;
        while (!stop && it < maxit && objectiveValue != model.getUpperBound() &&
               programTimer.elapsed() / 1000 < timeout) {
            if (!para.autoparam) {
                setParams(it);
            }

            plateau();

            if (!first) {
                if (!perturb()) {
                    break;
                }

            } else {
                first = false;
            }

            stableImprove();
            checkSolution();
            it++;
        }
        restoreBest();

        auto numOrig = model.getNumOrigVars();
        for (uint32_t vOrig = numOrig - model.numAux; vOrig < numOrig; vOrig++) {
            auto vMapped = model.getOrigToMappedVar(vOrig);
            if (vMapped >= 0) {
                flipIfNoHarm(vMapped);
            }
        }
        saveBest();
    }

    LOG(std::string("Improvements nextharm only improve: ") +
        std::to_string(Successflipifnonextharmwithimprove))
    LOG(std::string("Improvements nextharm also without improve: ") +
        std::to_string(Successflipifnonextharmwithoutimprove))
    LOG(std::string("num of breaks: ") + std::to_string(num_breaks))

    LOG(std::string("improved: ") + std::to_string(improved) + std::string(" vs not improved: ") +
        std::to_string(notimproved));
    LOG(std::string("Number of Best Interpretation Updates:: ") + std::to_string(bestimproved));

    LOG("num_iterations: " + std::to_string(it) +
        " ~t: " + std::to_string(int(approxTime() / 1000)));

    LOG("final objective value: " + std::to_string(bestObjectiveValue));

    LOG("further_features = " + std::to_string(model.feature.numunsatclauses) + " " +
        std::to_string(model.feature.improved200) + " " +
        std::to_string(model.feature.bestimproved200) + " " +
        std::to_string(model.feature.notimproved200) + " " +
        std::to_string(model.feature.successflipifnonextharmwithoutimprove200) + " " +
        std::to_string(model.feature.successflipifnonextharmwithimprove200) + " " +
        std::to_string(model.feature.improved1000) + " " +
        std::to_string(model.feature.bestimproved1000) + " " +
        std::to_string(model.feature.notimproved1000) + " " +
        std::to_string(model.feature.successflipifnonextharmwithoutimprove1000) + " " +
        std::to_string(model.feature.successflipifnonextharmwithimprove1000) + " " +
        std::to_string(model.feature.improved10000) + " " +
        std::to_string(model.feature.bestimproved10000) + " " +
        std::to_string(model.feature.notimproved10000) + " " +
        std::to_string(model.feature.successflipifnonextharmwithoutimprove10000) + " " +
        std::to_string(model.feature.successflipifnonextharmwithimprove10000) + " " +
        std::to_string(int(model.feature.avgSoftWeight)))

    LOG(std::string("sr_clique_gap = ") +
        std::to_string(model.getUpperBound() - bestObjectiveValue));
    LOG(std::string("number_unsatisfied_hard_clauses = ") +
        std::to_string(getNumberOfViolatedHardClauses()));

    validateSolutionValue();
}

void StableResolver::plateau() {
    std::geometric_distribution<int> distribution(para.plateau);
    int i = distribution(generator) + 1;
    while (--i > 0) {
        uint32_t curLitIdx = generator() % interpretation.size();
        flipIfNoHarm(curLitIdx);
    }
}

void StableResolver::setParams(int it) {

    if (it == 0) {

        if (model.feature.weighted) {

            // set geom
            para.geom = .75;

            // set maxstepsperturbtosat
            para.maxstepsperturbtosat = 500;

            // set iterLimitGlucose
            para.iterLimitGlucose = 20;

            // set perturb to weights
            para.perturbtoweights =
                std::min(10, std::max(int(model.feature.numsoftclauses / 10), 1));

            // set approxtime
            para.approxtime = 10;

            // set innermaxit
            if (model.feature.numsoftclauses >= 5000) {
                para.innerMaxIt = 10;
            }

        } else {
            // set perturb to weights
            para.perturbtoweights = 1;

            // set maxstepsperturbtosat
            para.maxstepsperturbtosat = 100;

            // set iterLimitGlucose
            para.iterLimitGlucose = 20;

            // set geom
            para.geom = 1;
        }
    }

    if (it == 200) {
        model.feature.improved200 = improved;
        model.feature.bestimproved200 = bestimproved;
        model.feature.notimproved200 = notimproved;
        model.feature.successflipifnonextharmwithoutimprove200 =
            Successflipifnonextharmwithoutimprove;
        model.feature.successflipifnonextharmwithimprove200 = Successflipifnonextharmwithimprove;

        if (model.feature.weighted && model.feature.improved200 >= 1000) {
            para.innerMaxIt = 10;
        }
    }
    if (it == 1000) {
        model.feature.improved1000 = improved;
        model.feature.bestimproved1000 = bestimproved;
        model.feature.notimproved1000 = notimproved;
        model.feature.successflipifnonextharmwithoutimprove1000 =
            Successflipifnonextharmwithoutimprove;
        model.feature.successflipifnonextharmwithimprove1000 = Successflipifnonextharmwithimprove;

        if (model.feature.weighted) {
            if (model.feature.bestimproved1000 >= 60) {
                para.maxStepsWorse = 10000;
            } else {
                para.maxStepsWorse = 1000;
            }
        }
    }

    if (it == 10000) {
        model.feature.improved10000 = improved;
        model.feature.bestimproved10000 = bestimproved;
        model.feature.notimproved10000 = notimproved;
        model.feature.successflipifnonextharmwithoutimprove10000 =
            Successflipifnonextharmwithoutimprove;
        model.feature.successflipifnonextharmwithimprove10000 = Successflipifnonextharmwithimprove;
    }
}

uint32_t StableResolver::getNumberOfViolatedHardClauses() {
    uint32_t res = 0;
    for (int i = 0; i < model.getnClauses(); i++) {
        const Clause &cl = model.getClause(i);
        if (cl.weight == model.getMaxWeight()) {
            if (!std::any_of(cl.literals.begin(), cl.literals.end(), [&](Literal lit) -> bool {
                    return isSigned(lit) == interpretation[index(lit)];
                })) {
                res++;
            }
        }
    }
    return res;
}

void StableResolver::validateSolutionValue() {
    uint64_t solutionValidated = 0;
    for (uint32_t cIdx = 0; cIdx < model.getnClauses(); cIdx++) {
        const Clause &cl = model.getClause(cIdx);
        if (model.isSatisfied(cIdx, interpretation)) {
            // cppcheck-suppress useStlAlgorithm
            solutionValidated += cl.weight;
        } else {
            if (cl.weight == model.getMaxWeight()) {
                ERROR("hard clause unsat: " + model.toString(cl, interpretation))
            }
        }
    }
    if (solutionValidated != bestObjectiveValue) {
        ERROR_EXIT("solution_value=" + std::to_string(solutionValidated) +
                   " != bestobjective=" + std::to_string(bestObjectiveValue));
    }
}

void StableResolver::initCandidateClauses() {
    // get non satisfied clauses as candidates
    for (size_t i = 0; i < stabilities.size(); i++) {
        if (!model.getClause(i).literals.empty() && stabilities[i] == 0) {
            addToCandidateClauses(i);
            unsatCandidatesForPerturb.insert(i);
        }
    }
}

void StableResolver::addToCandidateClauses(CandidateClause c) {
    if (!isCandidateClauses[c]) {
        isCandidateClauses[c] = true;
        candidateClauses.push_back(c);
    }
}

void StableResolver::addToCandidateClauses(const std::list<CandidateClause> &l) {
    for (auto c : l) {
        addToCandidateClauses(c);
    }
}

void StableResolver::addToCandidateClauses(const std::vector<CandidateClause> &l) {
    for (auto c : l) {
        addToCandidateClauses(c);
    }
}

StableResolver::CandidateClause StableResolver::popFromCandidateClauses() {
    auto c = candidateClauses.front();
    isCandidateClauses[c] = false;
    candidateClauses.pop_front();
    return c;
}

StableResolver::CandidateClause StableResolver::getRandomZeroStabilityClause() {

    // First try to get an unsat clause by chance
    size_t it = 0;
    int i = 0;
    uint32_t weightIdx = 0;
    uint32_t idx;
    while (++it <= para.maxrandomclauses) {
        uint32_t curIdx = generator() % stabilities.size();
        if (stabilities[curIdx] == 0) {
            i++;
            if (model.getClause(curIdx).weight > weightIdx) {
                idx = curIdx;
                weightIdx = model.getClause(curIdx).weight;
            }
            if (i == para.perturbtoweights) {
                return idx;
            }
        }
    }
    if (i > 0) {
        return idx;
    }

    // if this was not successfull, get all unsat clauses
    randomCandidates.clear();
    newUnsatCandidatesForPerturb.clear();
    for (uint32_t clIdx : unsatCandidatesForPerturb) {
        if (stabilities[clIdx] == 0 && !model.getClause(clIdx).literals.empty()) {
            randomCandidates.push_back(clIdx);
            newUnsatCandidatesForPerturb.insert(clIdx);
        }
    }

    if (randomCandidates.empty()) {
        return NoClause;
    }
    unsatCandidatesForPerturb = newUnsatCandidatesForPerturb;

    // apply ranking function
    uint32_t bestWeight = 0;
    uint32_t bestIdx = -1;
    for (int j = 0; j <= para.maxrandomclauses; j++) {
        uint32_t randIdx;
        if (randomCandidates.size() == 1) {
            randIdx = 0;
        } else {
            randIdx = generator() % randomCandidates.size();
        }
        if (model.getClause(randomCandidates[randIdx]).weight > bestWeight) {
            bestIdx = randIdx;
            bestWeight = model.getClause(randomCandidates[randIdx]).weight;
        }
    }
    // return random clause maximizing ranking function
    if (bestIdx == -1) {
        return NoClause;
    }
    return randomCandidates[bestIdx];
}

bool StableResolver::hasCandidateClauses() { return !candidateClauses.empty(); }

bool StableResolver::perturbRandomClause() {
    // Calc random number k where P(X=k)=1/(2^k), k>=1
    int number;
    if (para.geom == 1) {
        number = 1;
    } else {
        std::geometric_distribution<int> distribution(para.geom);
        number = distribution(generator) + 1;
    }

    // Get random unsatisfied clause
    auto randomClauseIdx = getRandomZeroStabilityClause();

    if (randomClauseIdx == NoClause) {
        return false;
    }
    unsatisfiedClauseIndices.clear();
    alreadyFlippedInPerturb.clear();
    uint32_t clauseIdx = 0;

    while (number > 0) {
        number--;
        bool foundNextLit = false;
        // Get random literal in this clause
        auto literals = model.getClause(randomClauseIdx).literals;
        Literal randomLiteral;
        for (int i = literals.size() - 1; i >= 0; i--) {
            if (i != 0) {
                int randomNumber = fastRand() % (i + 1);
                auto temp = literals[i];
                literals[i] = literals[randomNumber];
                literals[randomNumber] = temp;
            }
            randomLiteral = literals[i];

            if (alreadyFlippedInPerturb.find(index(randomLiteral)) ==
                alreadyFlippedInPerturb.end()) {
                foundNextLit = true;
                break;
            }
        }

        if (foundNextLit) {
            alreadyFlippedInPerturb.insert(index(randomLiteral));

            // Flip sign of this literal
            flipSign(index(randomLiteral), &unsatisfiedClauseIndices);
        }

        // Get next random clause in neighborhood
        if (number == 0) {
            break;
        }
        if (unsatisfiedClauseIndices.empty()) {
            bool foundNextClause = false;
            for (auto litIdx : alreadyFlippedInPerturb) {
                auto clauses = model.getClausesOfLit(litIdx);
                for (int i = clauses.size() - 1; i >= 0; i--) {
                    if (i != 0) {
                        int randomNumber = fastRand() % (i + 1);
                        auto temp = clauses[i];
                        clauses[i] = clauses[randomNumber];
                        clauses[randomNumber] = temp;
                    }
                    auto clause = clauses[i];
                    if (randomClauseIdx != clause.clauseIdx) {
                        randomClauseIdx = clause.clauseIdx;
                        foundNextClause = true;
                        break;
                    }
                }
            }

            if (!foundNextClause) {
                break;
            }

        } else {
            if (unsatisfiedClauseIndices.size() == 1) {
                clauseIdx = 0;
            } else {
                clauseIdx = generator() % unsatisfiedClauseIndices.size();
            }
            randomClauseIdx = unsatisfiedClauseIndices[clauseIdx];
            unsatisfiedClauseIndices.erase(unsatisfiedClauseIndices.begin() + clauseIdx);
        }
    }
    for (int i = 0; i < unsatisfiedClauseIndices.size(); i++) {
        addToCandidateClauses(unsatisfiedClauseIndices[i]);
        unsatCandidatesForPerturb.insert(unsatisfiedClauseIndices[i]);
    }
    return true;
}
bool StableResolver::perturbSatSolver() {
    // bool b = solveViaSatSolverSatisfiedSoftclauses();
    bool b = solveViaSatSolverUnsatisfiedSoftclauses();
    LOGv("satsolver perturb solved=" + std::to_string(b));

    if (b) {
        for (int i = 0; i < lastSatSolverInterpretation.size(); i++) {
            if (lastSatSolverInterpretation[i] != interpretation[i]) {
                flipSign(i, nullptr, nullptr, true);
            }
        }
    }

    return true;
}

bool StableResolver::perturb() {
    if (notImproved > para.maxstepsperturbtosat) {

        notImproved = 0;
        return perturbSatSolver();
    } else {
        return perturbRandomClause();
    }
}

void StableResolver::stableImprove() {
    // improve as long as it is possible
    size_t it = 0;
    while (hasCandidateClauses()) {
        it++;
        // give enough time (1s) for checksolution
        if (it % 10 == 0 && programTimer.elapsed() / 1000 > timeout - 1) {
            stop = true;
            break;
        }
        if (stop) {
            // this is extra, because stop can be set from outside
            break;
        }

        // Try to improve first clause of candidates
        CandidateClause curClauseIndex = popFromCandidateClauses();
        if (stabilities[curClauseIndex] > 0) {
            continue;
        }
        improve(curClauseIndex);
    }
}

void StableResolver::improve(uint32_t curClauseIndex) {
    CALLGRIND_START_INSTRUMENTATION;
    if (vverbose) {
        prevInterpretation = interpretation;
    }

    // init
    prevObjectiveValue = objectiveValue;

    const Clause &cl = model.getClause(curClauseIndex);
    assert(stabilities[curClauseIndex] == 0);
    CALLGRIND_STOP_INSTRUMENTATION;

    alreadyFlippedInImprove.clear();
    alreadyFlippedInImprove.resize(model.getnLiterals(), false);
    alreadyFlippedIndexInImprove.clear();

    alreadyTriedLitForNextHarm.clear();
    CALLGRIND_START_INSTRUMENTATION;

    unsatisfiedClauseIndices.clear();

    auto randomLitIndex = fastRand() % cl.literals.size();
    Literal lit = cl.literals[randomLitIndex];

    assert(index(lit) < model.getnLiterals());

    alreadyFlippedInImprove[index(lit)] = true;
    alreadyFlippedIndexInImprove.push_back(index(lit));

    int64_t curWeight = flipSign(index(lit), &unsatisfiedClauseIndices);

    bool foundNextLit = true;
    int it_num = 0;
    bool onlyImprove = true;

    int curSuccessflipifnonextharmwithoutimprove = 0;
    int curSuccessflipifnonextharmwithimprove = 0;

    while (foundNextLit && it_num < para.innerMaxIt && !stop) {
        if (unsatisfiedClauseIndices.empty()) {
            break;
        }
        it_num++;

        foundNextLit = false;
        Literal randomLit;
        for (int i = unsatisfiedClauseIndices.size() - 1; i >= 0; i--) {
            if (i != 0) {
                int randomNumber = fastRand() % (i + 1);
                uint32_t temp = unsatisfiedClauseIndices[i];
                unsatisfiedClauseIndices[i] = unsatisfiedClauseIndices[randomNumber];
                unsatisfiedClauseIndices[randomNumber] = temp;
            }

            if (stabilities[unsatisfiedClauseIndices[i]] > 0) {
                continue;
            }
            auto randomClause = model.getClause(unsatisfiedClauseIndices[i]);

            for (int j = randomClause.literals.size() - 1; j >= 0; j--) {

                if (j != 0) {
                    int randomNumber = fastRand() % (j + 1);
                    auto temp = randomClause.literals[j];
                    randomClause.literals[j] = randomClause.literals[randomNumber];
                    randomClause.literals[randomNumber] = temp;
                }

                randomLit = randomClause.literals[j];
                if (!alreadyFlippedInImprove[index(randomLit)] &&
                    alreadyTriedLitForNextHarm.find(index(randomLit)) ==
                        alreadyTriedLitForNextHarm.end()) {

                    foundNextLit = true;
                    break;
                }
            }

            if (foundNextLit) {
                break;
            }
        }

        if (foundNextLit) {
            auto res = flipIfNoNextHarm(index(randomLit), onlyImprove);
            if (res.first) {
                if (!onlyImprove) {
                    curWeight += res.second;
                    curSuccessflipifnonextharmwithoutimprove++;
                    if (curWeight > 0) {
                        break;
                    }
                } else {
                    curWeight += res.second;
                    curSuccessflipifnonextharmwithimprove++;
                }
            }

        } else {
            if (!onlyImprove) {
                num_breaks++;

            } else if (curWeight < 0) {
                // no lits with improvements found so allow now worsening
                foundNextLit = true;
                onlyImprove = false;
                alreadyTriedLitForNextHarm.clear();
            }
        }
    }

    // clauses that we could not satisfy shall be added to the candidate list in case we
    // have improved the solution
    if (objectiveValue > prevObjectiveValue) {
        improved++;
        for (int i = 0; i < unsatisfiedClauseIndices.size(); i++) {
            addToCandidateClauses(unsatisfiedClauseIndices[i]);
            unsatCandidatesForPerturb.insert(unsatisfiedClauseIndices[i]);
        }

        Successflipifnonextharmwithoutimprove += curSuccessflipifnonextharmwithoutimprove;
        Successflipifnonextharmwithimprove += curSuccessflipifnonextharmwithimprove;
    }
    if (objectiveValue == prevObjectiveValue) {
        for (int i = 0; i < unsatisfiedClauseIndices.size(); i++) {
            unsatCandidatesForPerturb.insert(unsatisfiedClauseIndices[i]);
        }
    }

    // check if we have worsend the objective value and if so, flip back
    // remark: if obj value is the same, do not flip back but also do not add unsatisfied
    // clauses as new candidates in order to avoid infinite loops
    if (objectiveValue < prevObjectiveValue) {
        if (vverbose) {
            LOG("flipped lits:")
            for (size_t v = 0; v < interpretation.size(); ++v) {
                if (interpretation[v] != prevInterpretation[v]) {

                    LOG(v)
                }
            }
            LOG("flip back")
        }

        for (auto i : alreadyFlippedIndexInImprove) {
            flipSign(i);
            LOGvv(i);
        }
        assert(objectiveValue == prevObjectiveValue);
    }
}

void StableResolver::checkSolution() {
    notImproved++;

    // If new solution is the best, save it as new best solution
    if (objectiveValue > bestObjectiveValue) {
        bestimproved++;
        saveBest();
        saveIntermediate();
        numStepsWorse = 0;
        auto printObj = bestObjectiveValue;
        if (printObj > sumHardWeights) {
            printObj -= sumHardWeights;
        }
        LOG("new best (it=" + std::to_string(it) + " ~t=" +
            std::to_string(int(approxTime() / 1000)) + ") of value:" + std::to_string(printObj) +
            +" gap=" + std::to_string(model.getUpperBound() - bestObjectiveValue));
    } else if (objectiveValue == bestObjectiveValue) {
        saveBest();
    }

    else {
        // if not, maybe we still save it as intermediate solution
        if (objectiveValue < intermediateObjectiveValue) {

            if (numStepsWorse > para.maxStepsWorse) {
                // if for too long, no best solution has been found, restore best solution
                restoreBest();
                saveIntermediate();
                numStepsWorse = 0;
            } else {
                // else, toss a coin and with decreasing probability, accept a worse
                // intermediate solution

                double decreasedProb = getDecreasingProb();

                probReach = std::exp(-10 * decreasedProb);

                prob = static_cast<double>(generator()) / RAND_MAX;

                if (prob > probReach) { // Toss a coin whether or not we should worsen the solution
                    restoreIntermediate();
                } else {
                    saveIntermediate();
                }
                numStepsWorse++;
            }
        } else {

            saveIntermediate();
        }
    }
}

void StableResolver::saveBest() {
    notImproved = 0;
    bestObjectiveValue = objectiveValue;
    best.clear();
    best.resize(model.getnLiterals(), false);
    bestSet.clear();
}

void StableResolver::restoreBest() {
    for (uint32_t litIdx : bestSet) {
        if (best[litIdx]) {
            flipSign(litIdx, nullptr, nullptr, true);
        }
    }
    best.clear();
    best.resize(model.getnLiterals(), false);
    bestSet.clear();
}

void StableResolver::saveIntermediate() {
    intermediateObjectiveValue = objectiveValue;
    intermediate.clear();
    intermediate.resize(model.getnLiterals(), false);
    intermediateSet.clear();
}

void StableResolver::restoreIntermediate() {
    for (uint32_t litIdx : intermediateSet) {
        if (intermediate[litIdx]) {
            flipSign(litIdx, nullptr, nullptr, true);
        }
    }
    intermediate.clear();
    intermediate.resize(model.getnLiterals(), false);
    intermediateSet.clear();
}

double StableResolver::approxTime() const { // in ms
    return innerCalls / (para.approxtime * 10000.);
}

double StableResolver::getDecreasingProb() {
    if (maxit != INT_MAX) {
        return static_cast<double>(it) / maxit;
    } else {
        return static_cast<double>(approxTime()) / (1000 * static_cast<double>(timeout));
    }
}

std::pair<bool, int64_t> StableResolver::flipIfNoNextHarm(uint32_t literalIndex, bool onlyImprove) {
    std::pair<bool, int64_t> res;
    if (alreadyFlippedInImprove[literalIndex]) {
        res.first = false;
        return res;
    }
    int64_t addObjValue = 0;

    // collect unsatisifed clauses if flipped
    innerUnsatisfiedClauseIndices.clear();
    increasedStabilityIndices.clear();
    addObjValue =
        flipSign(literalIndex, &innerUnsatisfiedClauseIndices, &increasedStabilityIndices);

    // find all to be flipped literals that help to improve the objective
    size_t literalIndicesFlipped = alreadyFlippedIndexInImprove.size();

    alreadyFlippedInImprove[literalIndex] = true;
    alreadyFlippedIndexInImprove.push_back(literalIndex);

    for (int i = increasedStabilityIndices.size() - 1; i >= 0; i--) {
        if (i != 0) {
            int randomNumber = fastRand() % (i + 1);
            uint32_t temp = increasedStabilityIndices[i];
            increasedStabilityIndices[i] = increasedStabilityIndices[randomNumber];
            increasedStabilityIndices[randomNumber] = temp;
        }
        auto cidx = increasedStabilityIndices[i];
        Clause &c = model.getClause(cidx);

        if (stabilities[cidx] < 2) {
            continue;
        }

        for (int j = c.literals.size() - 1; j >= 0; j--) {
            if (j != 0) {
                int randomNumber = fastRand() % (j + 1);
                auto temp = c.literals[j];
                c.literals[j] = c.literals[randomNumber];
                c.literals[randomNumber] = temp;
            }
            Literal lit = c.literals[j];
            if (!alreadyFlippedInImprove[index(lit)] && index(lit) != literalIndex &&
                isSigned(lit) == interpretation[index(lit)]) {

                // find neighbouring clauses that can be satisfied again
                int64_t addWeight = flipIfNoHarm(index(lit));

                if (addWeight != -1) {
                    alreadyFlippedInImprove[index(lit)] = true;
                    alreadyFlippedIndexInImprove.push_back(index(lit));
                    // add weights if all other clauses that became satisfied due to this
                    // flip
                    addObjValue += addWeight;
                }
                // we found the 2nd true literal, so we can break here
                break;
            }
        }
    }

    if (addObjValue >= 0 || !onlyImprove) {

        for (auto cidx : innerUnsatisfiedClauseIndices) {
            if (stabilities[cidx] == 0) {
                // cppcheck-suppress useStlAlgorithm
                unsatisfiedClauseIndices.push_back(cidx);
            }
        }
        res.first = true;
        res.second = addObjValue;
        return res;
    } else {
        for (size_t i = literalIndicesFlipped; i < alreadyFlippedIndexInImprove.size(); i++) {
            auto vidx = alreadyFlippedIndexInImprove[i];
            alreadyFlippedInImprove[vidx] = false;
            flipSign(vidx);
        }
        alreadyFlippedIndexInImprove.resize(literalIndicesFlipped);
        alreadyTriedLitForNextHarm.insert(literalIndex);
        res.first = false;
        return res;
    }
}

int64_t StableResolver::flipIfNoHarm(uint32_t literalIndex) {
    // check that all clauses being satisfied by this literal are satisfied by at least one
    // other literal as well
    uint64_t addWeights = 0;
    if (model.getClausesOfLit(literalIndex).empty()) {
        return -1;
    }
    for (auto litInClause : model.getClausesOfLit(literalIndex)) {
        innerCalls++;
        uint32_t clauseIdx = litInClause.clauseIdx;
        if (stabilities[clauseIdx] == 1) {
            const Clause &clause = model.getClause(clauseIdx);
            bool sign = litInClause.sign;

            // Is clause satisfied by this literal? (if not, even better: a flip would improve
            // stability of this clause)
            if (sign == interpretation[literalIndex]) {
                assert(stabilities[clauseIdx] > 0);

                // Is clause satisfied by this one literal alone?

                // then a flip would do harm, so do not flip!
                return -1;
            }
        } else if (stabilities[clauseIdx] == 0) {

            addWeights += model.getClause(clauseIdx).weight;
        }
    }

    // no harm was detected, so flip
    flipSign(literalIndex);
    return addWeights;
}

int64_t StableResolver::flipSign(uint32_t literalIndex,
                                 std::vector<uint32_t> *unsatisfiedClauseIndices,
                                 std::vector<uint32_t> *clauseIndicesOfstabilityOneToTwo,
                                 bool addToUnsatCandidatesForPerturb) {

    assert(!model.getClausesOfLit(literalIndex).empty());
    int64_t addValue = 0;
    // flip sign of literal
    bool stabilityZero = false;
    intermediate[literalIndex] = !intermediate[literalIndex];
    intermediateSet.insert(literalIndex);
    best[literalIndex] = !best[literalIndex];
    bestSet.insert(literalIndex);

    interpretation[literalIndex] = !interpretation[literalIndex];

    // update all clauses the literals belongs to
    for (auto litInClause : model.getClausesOfLit(literalIndex)) {
        innerCalls++;
        // if new sign of the literal satisfies the clause...
        uint32_t clauseIdx = litInClause.clauseIdx;
        const Clause &clause = model.getClause(clauseIdx);
        bool sign = litInClause.sign;

        if (sign == interpretation[literalIndex]) {

            // and it is the first literal to do so, then add weight of this clause to
            // objectiveValue
            if (stabilities[clauseIdx] == 0) {
                objectiveValue += clause.weight;
                addValue += clause.weight;

            } else if (clauseIndicesOfstabilityOneToTwo && stabilities[clauseIdx] == 1) {
                clauseIndicesOfstabilityOneToTwo->push_back(clauseIdx);
            }

            // update stability
            stabilities[clauseIdx]++;

        } else {

            // vice versa if new sign does not satisfy the clause...
            // ...update stability...
            stabilities[clauseIdx]--;
            assert(stabilities[clauseIdx] >= 0);

            // ... and decrease objectiveValue if ths was the only literal satisfying this
            // clause
            if (stabilities[clauseIdx] == 0) {
                objectiveValue -= clause.weight;
                addValue -= clause.weight;
                if (addToUnsatCandidatesForPerturb) {
                    unsatCandidatesForPerturb.insert(clauseIdx);
                }

                // Also: Return all unsatisfied clauses (because in stable resolving, we
                // need them to try to repair them)
                if (unsatisfiedClauseIndices) {
                    unsatisfiedClauseIndices->push_back(clauseIdx);
                }
            }
        }
    }

    return addValue;
}

void StableResolver::writeSolution(std::ostream &f, const std::vector<bool> &origInitSol) const {
    f << "v";
    if (!origInitSol.empty()) {
        for (uint32_t i = 0; i < origInitSol.size() - model.numAux; i++) {
            f << " ";
            auto mappedVar = model.getOrigToMappedVar(i);
            bool val;
            if (mappedVar >= 0) {
                val = interpretation[mappedVar];
            } else {
                val = origInitSol[i];
            }
            Literal l{i, val};
            f << outputLit(l);
        }
    } else {
        for (uint32_t i = 0; i < interpretation.size(); i++) {
            f << " ";
            Literal l{i, interpretation[i]};
            f << outputLit(l);
        }
    }
    f << std::endl;
}

void StableResolver::writeSolution(const std::string &fileName,
                                   const std::vector<bool> &origInitSol) const {
    LOG("write solution to " + fileName);
    std::ofstream f(fileName);
    if (!f.is_open()) {
        ERROR_EXIT(std::string("could not open file ") + fileName);
    }
    writeSolution(f, origInitSol);
}

bool StableResolver::solveViaSatSolver(const std::vector<uint32_t> &softClauses) {
    assert(satSolver);

    satSolver->stopGlucoseInPerturb = para.iterLimitGlucose;

    Glucose::vec<Glucose::Lit> solverClause;
    std::vector<Glucose::CRef> addedClauses;
    size_t numClauses = satSolver->nClauses();
    Glucose::vec<Glucose::Lit> assumps;
    for (auto cIdx : softClauses) {
        const Clause &c = model.getClause(cIdx);
        if (c.literals.size() == 1) {
            auto lit = c.literals.front();
            uint32_t vSolver =
                initialModel->getOrigToMappedVar(model.getMappedToOrigVar(index(lit)));
            assumps.push(Glucose::mkLit(vSolver, !isSigned(lit)));
            continue;
        }
        for (Literal lit : c.literals) {
            uint32_t vSolver =
                initialModel->getOrigToMappedVar(model.getMappedToOrigVar(index(lit)));
            Glucose::Lit gLit = Glucose::mkLit(vSolver, !isSigned(lit));
            solverClause.push(gLit);
        }
        size_t prevSize = satSolver->nClauses();
        bool ok = satSolver->addClause_(solverClause);
        if (ok) {
            if (satSolver->nClauses() == prevSize + 1) {
                addedClauses.push_back(satSolver->getClauses()[prevSize]);
            }
        } else {
            if (c.literals.size() > 1) {
                WARNING(
                    "this clause cannot be removed any more, because it is shrinked to 1 literal "
                    "and has been propagated in glucose :-(") // for debugging only currently

                // TODO in glucose bei addClause_ wenn er da shrink macht und nur noch 1 literal
                // uebrig bleibt, dann propagiert er das. anstelle von propagieren wollen wir hier
                // das als unit clause zurueck bekommen und als assumption hinzufuegen, damit das
                // sich glucose nicht merkt!
            }
        }
        solverClause.clear();
    }
    LOGv("added clauses: " + std::to_string(addedClauses.size()));
    // set initial solution
    for (uint32_t v = 0; v < interpretation.size(); v++) {
        uint32_t vSolver = initialModel->getOrigToMappedVar(model.getMappedToOrigVar(v));
        satSolver->setPolarity(vSolver, !interpretation[v]);
    }
    satSolver->ignoreTimeout = false;
    // satSolver->timeLimit = programTimer.elapsed() / 1000 + 5; // stop glucose after x seconds
    satSolver->silent = true;
    satSolver->setSeed(curSatSolverSeed);
    curSatSolverSeed += 1.0;
    Glucose::lbool satM = satSolver->solveLimited(assumps);
    satSolver->silent = false;

    for (auto &c : addedClauses) {
        satSolver->removeClause(c);
    }

    lastSatSolverInterpretation.clear();
    bool sat;
    {
        using namespace Glucose;
        sat = satM == l_True;
    }
    if (sat) {
        for (int v = 0; v < interpretation.size(); v++) {
            uint32_t vSolver = initialModel->getOrigToMappedVar(model.getMappedToOrigVar(v));
            using namespace Glucose;
            auto val = satSolver->model[vSolver];
            lastSatSolverInterpretation.push_back(val == l_True);
        }
    }

    satSolver->stopGlucoseInPerturb = 0;

    return sat;
}

// bool StableResolver::solveViaSatSolverSatisfiedSoftclauses() {
//    std::vector<uint32_t> softClauses;
//    for (size_t i = 0; i < model.getnClauses(); i++) {
//        auto &c = model.getClause(i);
//        if (c.weight < model.getMaxWeight() && stabilities[i] > 0) {
//            softClauses.push_back(i);
//        }
//    }
//    bool res = solveViaSatSolver(softClauses);
//    assert(res);
//    return res;
//}

bool StableResolver::solveViaSatSolverUnsatisfiedSoftclauses() {

    std::vector<uint32_t> unsatClauses;

    // Calc random number k where P(X=k)=1/(2^k), k>=1
    std::geometric_distribution<int> distribution(para.geom);
    int number = distribution(generator) + 1;

    // Get random unsatisfied clauses
    while (number > 0) {
        auto clauseIdx = getRandomZeroStabilityClause();
        auto &c = model.getClause(clauseIdx);
        if (c.weight < model.getMaxWeight() &&
            std::find(unsatClauses.begin(), unsatClauses.end(), clauseIdx) == unsatClauses.end()) {
            unsatClauses.push_back(clauseIdx);
        }
        number--;
    }

    // call SAT solver
    LOGv(unsatClauses.size());
    if (unsatClauses.empty()) {
        return false;
    }
    bool res = solveViaSatSolver(unsatClauses);

    return res;
}

} // namespace Solvers::MaxSat
