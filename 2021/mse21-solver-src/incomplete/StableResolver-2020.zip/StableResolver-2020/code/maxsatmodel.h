/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */
#pragma once

#include <stream.h>
#include <unordered_set>
#include <vector>

namespace Solvers::MaxSat {

struct Literal {
    uint32_t idx : 31;
    bool sign : 1;
};

static inline Literal mkLit(int lit) {
    return Literal{static_cast<uint32_t>(std::abs(lit) - 1), lit > 0};
}
static inline int outputLit(Literal lit) { return lit.sign ? lit.idx + 1 : -(lit.idx + 1); }
static inline Literal complLit(Literal lit) { return Literal{lit.idx, !lit.sign}; }
static inline bool isSigned(Literal lit) { return lit.sign; }
static inline uint32_t index(Literal lit) { return lit.idx; }

struct LitInClause {
    uint32_t clauseIdx : 31;
    bool sign : 1;
};

using LitInClauses = std::vector<LitInClause>;

struct Clause {
    std::vector<Literal> literals;
    uint64_t weight;
};

struct Features {
    bool weighted = true;
    uint32_t numclauses = 0;
    uint32_t numliterals = 0;
    uint32_t numsoftclauses = 0;
    uint32_t numhardclauses = 0;
    int numminhardclauselength = 99999;
    int nummaxhardclauselength = 0;
    int numminsoftclauselength = 99999;
    int nummaxsoftclauselength = 0;
    double avglensoftlength = 0;
    double avglenhardlength = 0;
    double avgSoftWeight = 0;
    uint32_t numunsatclauses = 0;
    uint32_t improved200 = 0;
    uint32_t bestimproved200 = 0;
    uint32_t notimproved200 = 0;
    uint32_t successflipifnonextharmwithoutimprove200 = 0;
    uint32_t successflipifnonextharmwithimprove200 = 0;
    uint32_t improved1000 = 0;
    uint32_t bestimproved1000 = 0;
    uint32_t notimproved1000 = 0;
    uint32_t successflipifnonextharmwithoutimprove1000 = 0;
    uint32_t successflipifnonextharmwithimprove1000 = 0;
    uint32_t improved10000 = 0;
    uint32_t bestimproved10000 = 0;
    uint32_t notimproved10000 = 0;
    uint32_t successflipifnonextharmwithoutimprove10000 = 0;
    uint32_t successflipifnonextharmwithimprove10000 = 0;
};

class MaxsatModel {
  public:
    MaxsatModel() = default;
    void setnLiterals(int n);
    void setnClauses(int n) { nClauses = n; };
    void setMaxWeight(uint64_t newMaxWeight) { maxWeight = newMaxWeight; }
    int getnClauses() const { return nClauses; }
    int getnLiterals() const { return nLiterals; }

    //-1 = false, 1 = true, 0 = unset
    const std::vector<int> &getInitialInterpretation() { return initialSol; }
    void setInitialInterpretation(std::vector<int> &&s) { initialSol = s; }

    void init();
    void finalize();
    void addClause(Clause &&clause);

    /**
     * @brief The literals of the clause will be transformed to an at-most-one clause set witht he
     * weight of the given clause.
     */
    int addAtMostOne(const Clause &clause, std::optional<Literal> implLit = std::nullopt);

    std::string toString(const Clause &c, const std::vector<bool> &sol = {},
                         bool isMappedSol = true) const;
    void addToInitialObjective(uint64_t summand) { initialObjectiveValue += summand; }
    void addToUpperBound(uint64_t summand) { upperBound += summand; }
    void setUpperBound(uint64_t ub) { upperBound = ub; }
    uint64_t getUpperBound() const { return upperBound; }
    uint64_t getInitialObjectiveValue() const { return initialObjectiveValue; }
    const Clause &getClause(uint32_t i) const { return clauses[i]; }
    Clause &getClause(uint32_t i) { return clauses[i]; }
    const std::vector<Clause> &getClauses() const { return clauses; }
    std::vector<Clause> &getClausesRef() { return clauses; }
    const LitInClauses &getClausesOfLit(uint32_t i) const { return litInClauses.at(i); }
    const uint64_t &getMaxWeight() const { return maxWeight; }
    void writeModel(const std::string &fileName) const;
    void writeHardModel(const std::string &fileName) const;

    int getOrigToMappedVar(uint32_t v) const { return doMapping ? varMapping[v] : v; }
    int getMappedToOrigVar(uint32_t v) const { return doMapping ? varMappedToOrigMapping[v] : v; }

    size_t getNumOrigVars() const { return doMapping ? varMapping.size() : nLiterals; }

    /**
     * @param mapping maps old original variables to the old new variables (which is this models'
     * original variables)
     */
    void mergeVarMapping(const MaxsatModel &merge);
    void extendVarMapping() { varMapping.push_back(-1); };

    bool isSatisfied(uint32_t clauseIndex, const std::vector<bool> &sol,
                     bool isMappedSol = true) const;

    Features feature;
    std::vector<LitInClauses> litInClauses;
    int numAux = 0;
    bool doMapping = true;

  private:
    uint32_t getOrCreateVar(uint32_t idxOuter);
    Literal getOrCreateLiteral(Literal litOuter);
    int nLiterals = 0;
    int nClauses = 0;
    uint64_t initialObjectiveValue = 0;
    uint64_t upperBound = 0;
    uint64_t maxWeight = 0;
    std::vector<Clause> clauses;
    std::vector<int> initialSol;
    int nVars = 0;
    std::vector<int> varMapping; // orig to new
    std::vector<int> varMappedToOrigMapping;
};
} // namespace Solvers::MaxSat
