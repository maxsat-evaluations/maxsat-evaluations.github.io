/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "stringoption.h"

namespace Solvers {

bool StringOption::parse(const std::string &str, const std::string &secondstr, int *i) {
    if (isOptionName(str) && !secondstr.empty()) {
        if (i) {
            (*i)++;
        }
        if (acceptableSecondArgument(secondstr)) {
            *this = secondstr;
            return true;
        }
    }
    return false;
}

void StringOption::help(bool verbose) {
    std::cout << "  " << createNameShortNameUsage() << " = " << typeName << " ("
              << (empty() ? "default is empty" : std::string("default=") + *this) << ")"
              << std::endl;
    if (verbose) {
        std::cout << "\n        " << description << std::endl;
        std::cout << std::endl;
    }
}
} // namespace Solvers
