/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "options.h"

#include <climits>

namespace Solvers {

BoolOption silent(GLOBALCAT, "silent", 0, "Tries to run the application as silent as possible.",
                  false);
BoolOption verbose(GLOBALCAT, "verbose", 'v', "Print extended output.", false);
BoolOption vverbose(GLOBALCAT, "vv", 0, "Very verbose.", false);
BoolOption vvverbose(GLOBALCAT, "vvv", 0, "Very very verbose.", false);
BoolOption vvvverbose(GLOBALCAT, "vvvv", 0, "Very very extreme verbose.", false);
BoolOption printoutput(GLOBALCAT, "printoutput", 0, "Print output to console for further parsing.",
                       false);
BoolOption tempdelete(GLOBALCAT, "tempdelete", 0, "Delete temporary files.", true);
BoolOption tempdeleteall(GLOBALCAT, "tempdeletall", 0, "Delete ALL temporary files.", true);
BoolOption externalcall(GLOBALCAT, "externalcall", 0,
                        "Should be set, if the program is called from inside another "
                        "program.",
                        false);
IntOption threads(GLOBALCAT, "threads", 't',
                  "On parallel blocks, the amount of threads is limited by this option.",
                  Interval(1, 200), 1);
IntOption servername(GLOBALCAT, "servername", 0, "Internal parameter for synchronization.",
                     Interval(-1, INT_MAX), -1);
IntOption seed("solver", "seed", 2, "Random seed initialization (srand()).", Interval(0, INT_MAX),
               0);
BoolOption preproc(GLOBALCAT, "preproc", 'p', "Should the Cliquemodel be preprocessed?", false);

void setVerboseLevel(const BoolOption &l) {
    bool found = false;
    if (l == vvvverbose) {
        vvvverbose = true;
        found = true;
    }
    if (l == vvverbose || found) {
        vvverbose = true;
        found = true;
    }
    if (l == vverbose || found) {
        vverbose = true;
        found = true;
    }
    if (l == verbose || found) {
        verbose = true;
    }
}
} // namespace Solvers
