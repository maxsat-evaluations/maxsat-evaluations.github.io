/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "satsolvergenerator.h"
#include "maxsatmodel.h"
#include "simp/SimpSolver.h"
#include <fstream>
#include <maxsatmodelreader.h>
#include <options.h>
#include <stream.h>

namespace Solvers::MaxSat {

SatSolverGenerator::SatSolverGenerator(const MaxsatModel &model, const std::string &initsolpath,
                                       Glucose::vec<Glucose::Lit> *toBeStoredAssumps)
    : model(model), initsolpath(initsolpath), toBeStoredAssumps(toBeStoredAssumps) {}

Glucose::SimpSolver *SatSolverGenerator::generateSimpSolver(bool incremental) {
    auto solver = new Glucose::SimpSolver;
    toBeFilled = solver;
    useSimp = true;

    solver->parsing = true;
    fill(incremental);
    solver->parsing = false;

    return solver;
}

Glucose::Solver *SatSolverGenerator::generateSolver(bool incremental) {
    auto solver = new Glucose::Solver;
    toBeFilled = solver;
    useSimp = false;

    fill(incremental);

    return solver;
}

void SatSolverGenerator::fill(bool incremental) {
    if (incremental) {
        toBeFilled->setIncrementalMode();
    }
    genVars();
    setInitSol();
    fillClauses();
}

void SatSolverGenerator::genVars() {
    for (size_t i = 0; i < model.getnLiterals(); ++i) {
        toBeFilled->newVar();
    }
}

void SatSolverGenerator::setInitSol() {
    // set polarities if input init sol exists for fast solution
    std::vector<bool> inputinitsol;
    if (!initsolpath.empty()) {
        MaxSATModelReader r;
        inputinitsol = r.readSolutionFromFile(initsolpath);
        for (uint32_t v = 0; v < inputinitsol.size(); v++) {
            auto vMapped = model.getOrigToMappedVar(v);
            if (vMapped >= 0) {
                toBeFilled->setPolarity(vMapped, !inputinitsol[v]);
                if (toBeStoredAssumps) {
                    Glucose::Lit gLit = Glucose::mkLit(vMapped, !inputinitsol[v]);
                    toBeStoredAssumps->push(gLit);
                }
            }
        }
    }
}

void SatSolverGenerator::fillClauses() {
    Glucose::vec<Glucose::Lit> solverClause;
    size_t numHardClauses = 0;
    std::unordered_set<uint32_t> alreadyFrozen;
    for (const Clause &c : model.getClauses()) {

        // skip soft clauses and freeze soft variables
        if (c.weight < model.getMaxWeight()) {
            if (useSimp) {
                for (Literal lit : c.literals) {
                    auto var = index(lit);
                    if (!alreadyFrozen.contains(var)) {
                        static_cast<Glucose::SimpSolver *>(toBeFilled)->setFrozen(var, true);
                        alreadyFrozen.insert(var);
                    }
                }
            }

            continue;
        }

        numHardClauses++;
        for (Literal lit : c.literals) {
            Glucose::Lit gLit = Glucose::mkLit(index(lit), !isSigned(lit));
            solverClause.push(gLit);
        }

        toBeFilled->addClause_(solverClause);

        solverClause.clear();
    }
    LOGv(toBeFilled->nVars());
    LOGv(toBeFilled->nClauses());

    if (verbose) {
        std::ofstream f("tmp.cnf");
        LOG("write tmp file start")
        if (!f.is_open()) {
            ERROR_EXIT(std::string("could not open file ") + "tmp.cnf");
        }
        f << "p cnf " << model.getnLiterals() << " " << numHardClauses << std::endl;
        for (const Clause &c : model.getClauses()) {
            if (c.weight < model.getMaxWeight()) {
                continue;
            }
            for (auto lit : c.literals) {
                f << outputLit(lit) << " ";
            }
            f << "0" << std::endl;
        }
        LOG("write tmp file done")
    }
}

} // namespace Solvers::MaxSat
