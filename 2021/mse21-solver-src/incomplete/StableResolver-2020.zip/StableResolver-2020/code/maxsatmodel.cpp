/*
 * Optimization Solvers
 * Copyright (C) 2019 Synoptics GmbH
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "maxsatmodel.h"
#include <cassert>
#include <fstream>
#include <options.h>

namespace Solvers::MaxSat {

void MaxsatModel::init() {

    // start with all literals set to false
    LOGv("init literals");
    LOGv(nLiterals);
    LOGv(nClauses);
    clauses.reserve(nClauses);
    if (doMapping) {
        varMapping.resize(nLiterals, -1);
        varMappedToOrigMapping.reserve(nLiterals);
        litInClauses.reserve(nLiterals);
    } else {
        litInClauses.resize(nLiterals);
    }
}

void MaxsatModel::setnLiterals(int n) {
    if (!doMapping && litInClauses.size() <= n) {
        litInClauses.resize(n);
    }
    nLiterals = n;
}

void MaxsatModel::finalize() {
    if (doMapping) {
        nLiterals = nVars;
    }
}

int MaxsatModel::addAtMostOne(const Clause &clause, std::optional<Literal> implLit) {
    auto &c = clause.literals;
    int numberOfClauses = 0;

    if (c.size() < 2) {
        return 0;
    }

    if (c.size() <= 5) {
        // naive encoding
        for (int i = 0; i < c.size(); i++) {
            for (int j = i + 1; j < c.size(); j++) {
                if (implLit) {
                    addClause(Clause{{*implLit, complLit(c[i]), complLit(c[j])}, clause.weight});
                } else {
                    addClause(Clause{{complLit(c[i]), complLit(c[j])}, clause.weight});
                }
                numberOfClauses++;
            }
        }
    } else {
        // binary encoding
        double jmaxdbl = std::log2(c.size());
        int jmax = static_cast<int>(jmaxdbl);
        double dummy;
        if (std::modf(jmaxdbl, &dummy) > 0) {
            jmax++;
        }
        uint32_t auxlitstart = nLiterals;
        nLiterals += jmax;
        // TODO fix it (mapping)
        litInClauses.resize(nLiterals);
        for (size_t i = 0; i < c.size(); i++) {
            for (int j = 0; j < jmax; j++) {
                Literal auxlit{auxlitstart + j, true};
                if (((1U << j) & i) == 0) {
                    auxlit.sign = false;
                }
                if (implLit) {
                    addClause(Clause{{*implLit, complLit(c[i]), auxlit}, clause.weight});
                } else {
                    addClause(Clause{{complLit(c[i]), auxlit}, clause.weight});
                }
                numberOfClauses++;
            }
        }
    }
    return numberOfClauses;
}

void MaxsatModel::mergeVarMapping(const MaxsatModel &merge) {
    const std::vector<int> &oldMappedToOldOrig = merge.varMappedToOrigMapping;
    const std::vector<int> &oldOrigToOldMapped = merge.varMapping;

    // map already mapped values to old orig
    for (uint32_t vOrig = 0; vOrig < varMapping.size(); vOrig++) {
        assert(oldMappedToOldOrig.size() > vOrig);
        auto vMapped = varMapping[vOrig];
        if (vMapped >= 0) {
            assert(varMappedToOrigMapping.size() > vMapped);
            auto vOldOrig = oldMappedToOldOrig[vOrig];
            varMappedToOrigMapping[vMapped] = vOldOrig;
        }
    }

    // varMapping = oldOrigToOldMapped;
    varMapping.clear();
    varMapping.resize(oldOrigToOldMapped.size(), -1);

    for (uint32_t vMapped = 0; vMapped < varMappedToOrigMapping.size(); vMapped++) {
        auto vOrig = varMappedToOrigMapping[vMapped];
        varMapping[vOrig] = vMapped;
    }
}

uint32_t MaxsatModel::getOrCreateVar(uint32_t idxOuter) {
    auto &mappedVar = varMapping[idxOuter];
    if (mappedVar < 0) {
        mappedVar = nVars;
        varMappedToOrigMapping.push_back(idxOuter);
        ++nVars;
        assert(litInClauses.size() == mappedVar);
        litInClauses.resize(litInClauses.size() + 1);
    }
    return mappedVar;
}

Literal MaxsatModel::getOrCreateLiteral(Literal litOuter) {
    return Literal{getOrCreateVar(index(litOuter)), isSigned(litOuter)};
}

void MaxsatModel::addClause(Clause &&clauseOuter) {
    uint32_t clauseIndex = clauses.size();
    Clause clause;
    clause.literals.reserve(clauseOuter.literals.size());
    clause.weight = clauseOuter.weight;
    for (Literal litOuter : clauseOuter.literals) {
        Literal lit = litOuter;
        if (doMapping) {
            lit = getOrCreateLiteral(litOuter);
        }
        LitInClause litInClause;
        litInClause.clauseIdx = clauseIndex;
        litInClause.sign = lit.sign;
        litInClauses[index(lit)].push_back(litInClause);
        clause.literals.push_back(lit);
    }
    clauses.emplace_back(std::move(clause));
    if (nClauses < clauses.size()) {
        nClauses++;
    }
}

std::string MaxsatModel::toString(const Clause &c, const std::vector<bool> &sol,
                                  bool isMappedSol) const {
    std::string res;
    for (Literal lit : c.literals) {
        Literal litOut{static_cast<uint32_t>(getMappedToOrigVar(index(lit))), isSigned(lit)};
        res += std::to_string(outputLit(litOut));
        if (!sol.empty()) {
            uint32_t idx = isMappedSol ? index(lit) : getMappedToOrigVar(index(lit));
            res += "(" + std::to_string(sol[idx]) + ")";
        }
        res += " ";
    }
    res += "w=" + std::to_string(c.weight);
    return res;
}

void MaxsatModel::writeModel(const std::string &fileName) const {
    std::ofstream f(fileName);
    if (!f.is_open()) {
        ERROR_EXIT(std::string("could not open file ") + fileName);
    }
    f << "c file generatejd by Synoptics Maxsat Model" << std::endl;
    uint64_t numVars = doMapping ? varMapping.size() : nLiterals;
    f << "p wcnf " << numVars << " " << nClauses << " " << maxWeight << std::endl;
    for (const Clause &c : clauses) {
        bool clauseSatisfied = false;
        f << c.weight << " ";
        for (auto litI : c.literals) {
            Literal lit;
            if (doMapping) {
                lit = Literal{static_cast<uint32_t>(varMappedToOrigMapping[index(litI)]),
                              isSigned(litI)};
            } else {
                lit = Literal{static_cast<uint32_t>(index(litI)), isSigned(litI)};
            }
            f << outputLit(lit) << " ";
        }
        f << "0" << std::endl;
    }
}

void MaxsatModel::writeHardModel(const std::string &fileName) const {
    std::ofstream f(fileName);
    if (!f.is_open()) {
        ERROR_EXIT(std::string("could not open file ") + fileName);
    }
    f << "c file generatejd by Synoptics Maxsat Model" << std::endl;
    uint64_t numVars = doMapping ? varMapping.size() : nLiterals;
    f << "p cnf " << numVars << " " << nClauses << std::endl;
    for (const Clause &c : clauses) {
        if (c.weight < maxWeight) {
            continue;
        }
        bool clauseSatisfied = false;
        for (auto litI : c.literals) {
            Literal lit;
            if (doMapping) {
                lit = Literal{static_cast<uint32_t>(varMappedToOrigMapping[index(litI)]),
                              isSigned(litI)};
            } else {
                lit = Literal{static_cast<uint32_t>(index(litI)), isSigned(litI)};
            }
            f << outputLit(lit) << " ";
        }
        f << "0" << std::endl;
    }
}

bool MaxsatModel::isSatisfied(uint32_t clauseIndex, const std::vector<bool> &sol,
                              bool isMappedSol) const {
    const Clause &cl = getClause(clauseIndex);
    for (auto lit : cl.literals) {
        uint32_t idx = isMappedSol ? index(lit) : getMappedToOrigVar(index(lit));
        bool val = sol[idx];
        if (val == isSigned(lit)) {
            return true;
        }
    }
    return false;
}

} // namespace Solvers::MaxSat
