#pragma once

#ifdef SIMP
#include "simp/SimpSolver.h"
#else
#include "core/Solver.h"
#endif
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "MaxSATFormula.h"
using NSPACE::lbool;
using NSPACE::Lit;
using NSPACE::sign;
using NSPACE::Solver;
using NSPACE::vec;
class Kissat {
 public:
  static Kissat *Instance();
  void SetWcnfFileName(char *s) { cnfFileName = s; }
  void CvtWcnf2Cnf(openwbo::MaxSATFormula *F) const {
    std::ofstream out(GetCnfFileName(), std::ios::out);
    if (!out.is_open() || !out.good()) {
      printf("c Kissat Error: cnf file open failed.\n");
      printf("s UNKNOWN\n");
      exit(_ERROR_);
    }
    out << "p cnf " << F->nVars() << " " << F->nHard() << std::endl;
    for (int i = 0; i < F->nHard(); i++) {
      auto &C = F->getHardClause(i).clause;
      for (int j = 0; j < C.size(); j++) {
        out << (sign(C[j]) ? "-" : "") << var(C[j]) + 1 << " ";// index > 0
      }
      out << "0\n";
    }
    out.close();
  }
  lbool saveModelFromResFile(Solver *S, std::string tmpFile) const {
    std::ifstream in(tmpFile, std::ios::in);
    if (!in.is_open() || !in.good()) {
      printf("c Kissat Error: cannot open kissat res file.\n");
      printf("s UNKNOWN\n");
      exit(_ERROR_);
    }
    char chr;
    std::string tmpStr;
    bool flag = false;
    in >> chr >> tmpStr;
    if (tmpStr != "SATISFIABLE") {
      printf("s UNKNOWN\n");
      exit(_ERROR_);
    }
    S->model.clear();
    while (std::getline(in, tmpStr)) {
      std::istringstream ss(tmpStr);
      ss >> chr;
      int idx = 0;
      while (ss >> idx) {
        if (idx == 0) {
          flag = true;
          break;
        }
        S->model.push((idx > 0) ? l_True : l_False);
      }
      if (flag) {
        break;
      }
    }
    in.close();
    return l_True;
  }
  std::string GetCnfFileName() const {
    std::string tmpStr(cnfFileName);
    int pos = tmpStr.rfind("/");
    tmpStr = tmpStr.substr(pos + 1);
    return tmpStr + ".cnf";
    // return tmpStr.erase(tmpStr.length() - 4, 1);
    // return "kissat_tmp.cnf";
  }
  std::string GetKissatResFileName() const {
    std::string tmpStr(cnfFileName);
    int pos = tmpStr.rfind("/");
    tmpStr = tmpStr.substr(pos + 1);
    return tmpStr + ".res";
    // return GetCnfFileName() + ".res";
  }
  void SetRunKissat(bool isRun) {runKissat = isRun;}
  bool GetRunKissat() {return runKissat;}
 private:
  Kissat() : cnfFileName(NULL), runKissat(false){};
  static Kissat *m_pInstance;
  char *cnfFileName;
  bool runKissat;
};
