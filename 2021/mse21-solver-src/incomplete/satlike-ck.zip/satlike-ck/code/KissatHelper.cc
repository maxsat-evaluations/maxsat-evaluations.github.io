#include <stddef.h>  // defines NULL
#include <cstdlib>

#include "KissatHelper.h"
 
// Global static pointer used to ensure a single instance of the class.
Kissat* Kissat::m_pInstance = NULL; 
Kissat* Kissat::Instance()
{
   if (!m_pInstance)   // Only allow one instance of class to be generated.
      m_pInstance = new Kissat;
   return m_pInstance;
}