### README for the SATLike MaxSAT Solver

### MaxSAT Evaluation 2021
./satlike-ck_static <input-file>
