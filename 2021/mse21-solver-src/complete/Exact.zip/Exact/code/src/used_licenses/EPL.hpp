
#pragma once
namespace licenses {
extern const char* EPL;
}
