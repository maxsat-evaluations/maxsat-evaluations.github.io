
#include "virtualsat.h"

VirtualSAT::~VirtualSAT() {

}

