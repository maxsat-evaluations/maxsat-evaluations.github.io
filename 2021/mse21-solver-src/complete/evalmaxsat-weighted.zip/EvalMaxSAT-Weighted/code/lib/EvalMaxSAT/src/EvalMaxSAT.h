﻿#ifndef EVALMAXSAT_SLK178903R_H
#define EVALMAXSAT_SLK178903R_H

#include <iostream>
#include <vector>
#include <algorithm>
#include <random>

#include "communicationlist.h"
#include "Chrono.h"
#include "coutUtil.h"
#include "virtualmaxsat.h"
#include "virtualsat.h"
#include "monglucose41.h"
#include "mcqd.h"
#include "coutUtil.h"

using namespace MaLib;



class MonSAT {
    MonGlucose41 solver;
    MaLib::Chrono C;

public:

    MonSAT(bool fullMinimizeActivated=true) : solver(fullMinimizeActivated) {

    }

    long getLastSolveTime() {
        return C.tacSec();
    }

    template <class T>
    bool solve(const T & assum) {
        C.tic();
        std::vector<int> clause;
        for(auto l: assum) {
            clause.push_back(l);
        }
        auto result = solver.solve(clause);
        C.pause(true);
        return result;
    }

    template <class T>
    int solveLimited(const T & assum, int budget, int litToExclude=0) {
        C.tic();
        std::vector<int> clause;
        for(auto l: assum) {
            assert(l != 0);
            if(l != litToExclude) {
                clause.push_back(l);
            }
        }

        auto result = solver.solveLimited(clause, budget);
        C.pause(true);
        return result;
    }

    bool propagate(const std::vector<int> &assum, std::vector<int> &prop) {
        return solver.propagate(assum, prop);
    }

    int newVar(bool decisionVar = true) {
        return solver.newVar(decisionVar);
    }
    
    template <class T>
    T getCore() {
        T result;

        for(auto lit: solver.getConflictInv()) {
            result.insert(lit);
        }

        return result;
    }

    template <class T>
    void getCore(T & result) {
        result.clear();
        for(auto lit: solver.getConflictInv()) {
            result.insert(lit);
        }
    }

    std::vector<int> getConflict() {
        std::vector<int> conflict;

        for(auto lit: solver.getConflictInv()) {
            conflict.push_back(lit);
        }

        return conflict;
    }

    void addClause(const std::vector<int> & vclause) {
        solver.addClause(vclause);
    }

    unsigned int sizeConflict() {
        return solver.sizeConflict();
    }

    bool getValue(unsigned int var) {
        return solver.getValue(var);
    }
};



class EvalMaxSAT : public VirtualMAXSAT {


    Chrono C_total;

    bool fullMinimizeActivated;

    MonSAT solver;

    std::vector<t_weight> _weight;
    std::vector<bool> model;
    std::vector<int> mapAssum2card;
    std::vector< std::tuple<std::shared_ptr<CardIncremental_Lazy>, int, t_weight> > save_card; // { {1, -2, 4}, 1 } <==> a + !b + d <= 1


    std::map<t_weight, std::set<int>> mapWeight2Assum;  // TODO: désactiver cela lorsque non weighted

    t_weight cost = 0;
    bool _isWeighted = false;
    unsigned int nbSoft = 0;


    struct compareLitByNum {
      bool operator() (const int& a, const int& b) const {
          if(abs(a) < abs(b))
              return true;

          if(abs(a) == abs(b))
              return /*a>b;*/ (a>0) && (b<0);

          return false;
      }
    };


public:


    EvalMaxSAT(bool fullMinimizeActivated = true) : fullMinimizeActivated(fullMinimizeActivated), solver(fullMinimizeActivated)
    {
        _weight.push_back(0);           //
        model.push_back(false);         // Fake lit with id=0
        mapAssum2card.push_back(-1);    //
    }

    virtual bool isSoft(unsigned int var) {
        return _weight[var] > 0;
    }

    bool getDefaultValue(unsigned int var) {
        return model[var];
    }

    virtual t_weight getCost() {
        return cost;
    }

    unsigned int nInputVars=0;  // Number of initial variables
    virtual void setNInputVars(unsigned int nInputVars) {
        this->nInputVars=nInputVars;
    }

    bool getValue(unsigned int var) {
        return solver.getValue(var);
    }

    virtual int newSoftVar(bool value, bool decisionVar, t_weight weight) {
        assert(weight > 0);
        _weight.push_back(weight);
        mapAssum2card.push_back(-1);
        model.push_back(value);
        nbSoft++;

        int var = solver.newVar(decisionVar);
        assert(var == _weight.size()-1);
        mapWeight2Assum[weight].insert(value?var:-var);

        if(weight > (t_weight)1) {
            _isWeighted = true;
        }

        assert(var == _weight.size()-1);

        return var;
    }

    virtual int newVar(bool decisionVar=true) {
        _weight.push_back(0);
        mapAssum2card.push_back(-1);
        model.push_back(false);

        int var = solver.newVar(decisionVar);

        assert(var == _weight.size()-1);

        return var;
    }

    virtual void setVarSoft(unsigned int var, bool value, t_weight weight) {

        while(var >= _weight.size()) {
            newVar();
        }

        if(weight > (t_weight)1) {
            _isWeighted = true;
        }
        assert(weight>0);
        int lit = value?var:-var;
        
        if( _weight[var] == 0 ) {
            _weight[var] = weight;
            mapWeight2Assum[weight].insert(lit);
            model[var] = value;
            nbSoft++;

        } else {
            if(model[var] == value) {
                assert(mapWeight2Assum[_weight[var]].count(lit) == 1);
                mapWeight2Assum[_weight[var]].erase(lit);

                _weight[var] += weight;
                mapWeight2Assum[_weight[var]].insert(lit);
            } else {
                assert(mapWeight2Assum[_weight[var]].count(-lit) == 1);
                mapWeight2Assum[_weight[var]].erase(-lit);

                if( _weight[var] > weight ) {
                    _weight[var] -= weight;
                    cost += weight;
                    mapWeight2Assum[_weight[var]].insert(-lit);
                } else if( _weight[var] < weight ) {
                    cost += std::min(weight, _weight[var]);
                    _weight[var] = weight - _weight[var];
                    model[var] = !model[var];
                    mapWeight2Assum[_weight[var]].insert(lit);
                } else { assert( _weight[var] == weight );
                    cost += _weight[var];
                    _weight[var] = 0;
                    nbSoft--;
                }
            }
        }
    }

    virtual void addClause(const std::vector<int> &vclause) {
        if(vclause.size() == 1) {
            int lit = vclause[0];
            unsigned int var1 = abs(lit);
            if( _weight[var1] > 0 ) {
                if(model[var1] == (lit < 0)) {                                        
                    cost += _weight[var1];
                    MonPrint("addClause: cost = ", cost);
                    assert(mapWeight2Assum[_weight[var1]].count(-lit));
                    mapWeight2Assum[_weight[var1]].erase(-lit);
                    _weight[var1] = 0;
                    nbSoft--;
                    removeLitFromAssum(-lit);
                } else {
                    assert(mapWeight2Assum[_weight[var1]].count(vclause[0]));
                    mapWeight2Assum[_weight[var1]].erase(vclause[0]);
                    _weight[var1] = 0;
                    nbSoft--;
                    _assumptions.erase(lit);
                }
            }
        }

        solver.addClause(vclause);

    }

    static const bool CONF_EXHAUST = true;
        unsigned int CONF_BOUND_FOR_EXHAUST = 10000;

    static const bool CONF_EXTRACT_AM1 = true;

    static const bool CONF_FAST_MINIMIZE = true;

    static const long CONF_MAXTIMEOUT_FOR_MINIMIZE = 60;                        // Timeout maximal pour la full minimization
    static const unsigned int CONF_SOLVER_BOUND_FOR_MINIMIZE = 1000;            // Bound a utilisé pour minimize
    static const unsigned int CONF_MAX_MULTIMINIMIZE = 10000;

    static const unsigned int CONF_NBMAX_ASSUM_FOR_MINIMIZE = 100000;

    static const unsigned int CONF_SOLVER_BOUND = 10000;                        // Bound a utiliser lorsque l'on utilise solverLimited

    static const bool CONF_MULTISOLVE = true;
        static const unsigned int CONF_TIMEOUT_MULTISOLVE = 60;                     // Arreter de maniere prematuré apres le timeout
        static const unsigned int CONF_MAX_MULTISOLVE = 10000;                      // Arreter de maniere prématuré apres le nombre max de multisolve
        static const unsigned int CONF_NB_ASSUM_FOR_REDUCE_MULTISOLVE = 100000;     // Nombre d'assumption impliquence une reduction du nombre minimal de multisolve
        static const unsigned int CONF_MIN_MULTISOLVE_REDUCED = 3;                  // Nombre minimal de multisolve en cas de reduction
        static const unsigned int CONF_MIN_MULTISOLVE = 20;                         // Nombre minimal de multisolve


    static const bool CONF_HARDEN_ASSUM = true;

    MaLib::Chrono chronoLastSolve;

    bool getValueImpliesByAssign(unsigned int var) {
        if( mapAssum2card[var] == -1 ) {
            if(mapSoft2clause.count(var) == 0) { 
                return getValue(var);
            } else {
                for(auto lit: mapSoft2clause[var]) {
                    if( solver.getValue( abs(lit) ) == (lit>0)  ) {
                        return true;
                    }
                }
                return false;
            }
        }

        auto [card, k, w] = save_card[ mapAssum2card[var] ];

        unsigned int k2=1;
        for(;k2<=k;k2++) {
            if( std::abs( card->atMost(k2) ) == var ) {
                break;
            }
        }
        assert( k2 <= k );

        unsigned int sum=0;
        for(auto lit: card->getClauses()) {
            if( getValueImpliesByAssign( abs(lit) ) == (lit>0) ) {
                sum++;
            }
        }

        return !(sum <= k2);
    }

    t_weight coutAssumInPartialSolution(unsigned int var) {
        t_weight result = 0;

        int lit = model[var]?var:-(int)var;

        if( (_weight[var] > 0) && (getValueImpliesByAssign(var) != model[var]) ) {     // un poid non null qui n'est pas satisfait

            result += _weight[var];

            if( mapAssum2card[var] != -1 ) {
                auto [card, k, w] = save_card[ mapAssum2card[var] ];

                unsigned int sum=0;
                for(auto lit: card->getClauses()) {
                    if( getValueImpliesByAssign( abs(lit) ) == (lit>0) ) {
                        sum++;
                    }
                }
                assert(sum > k); // car la card n'est pas satisfaite

                result += ((t_weight)(sum-k-1)) * w;
            }
        }

        return result;
    }

    t_weight coutPartialSolution() {
        t_weight result = cost;

        for(unsigned int var=1; var<_weight.size(); var++) {
            result += coutAssumInPartialSolution(var);
        }

        for(const auto &[clause, maxCost, exhaust]: _cardsToAdd) {
            unsigned int nb=0;
            for(auto lit: clause) {
                unsigned int var = abs(lit);
                assert( model[var] == (lit<0) );
                if( getValueImpliesByAssign( var ) == (lit>0) ) {
                    nb++;
                }
            }
            result += ((t_weight)nb - 1) * maxCost;
        }

        return result;
    }


    unsigned int harden() {
        unsigned int nbHarden=0;
        if(_isWeighted && CONF_HARDEN_ASSUM) {

            auto costRemovedAssumLOCAL = coutPartialSolution() - cost;

            
            for(auto it = _assumptions.begin(); it != _assumptions.end(); ) {
                int lit = *it;
                ++it;
                if( _weight[ abs(lit) ] >= costRemovedAssumLOCAL ) {
                    nbHarden++;
                    addClause({lit});
                }
            }
            MonPrintForce("\t", nbHarden, " harden.");

        }

        return nbHarden;
    }

    double strategy = 0.0;
    unsigned int lvlRestant = 0;
    t_weight chooseNextMinWeight(t_weight previousMinWeight = std::numeric_limits<t_weight>::max()) {  // TODO: ajouter la strategie

        // clear empty mapWeight2Assum
        for(auto it = mapWeight2Assum.begin(); it != mapWeight2Assum.end(); ) {
            if(it->second.size() == 0) {
                it = mapWeight2Assum.erase(it);
            } else {
                ++it;
            }
        }

        unsigned int nbNewConsidered = 0;
        unsigned int nbAlreadyConsidered = 0;
        lvlRestant = mapWeight2Assum.size();
        for(auto it = mapWeight2Assum.rbegin() ; it != mapWeight2Assum.rend(); ++it, --lvlRestant) {
            if( it->first >= previousMinWeight ) {
                nbAlreadyConsidered += it->second.size();
                continue; 
            }

            nbNewConsidered += it->second.size();
            assert( nbSoft > nbAlreadyConsidered );
            if( ((double)nbNewConsidered / (double)(nbSoft - nbAlreadyConsidered)) >= strategy ) {
                return it->first;
            }
        }

        return 1;
    }

    bool solve() {
        C_total.tic();

        if(CONF_EXTRACT_AM1) {
            extractAM();
        }

        MonPrintForce("First solve");
        _assumptions.clear();
        auto res = solver.solveLimited(_assumptions, 1000);    // TODO: HYPER PARAMETRE
        if(res == 0) {
            return false;
        }


        t_weight minWeightToConsider = std::numeric_limits<t_weight>::max();
        if(res != 1) {
            MonPrintForce("No stratification!");
            minWeightToConsider = 1;
        } else {
            MonPrintForce("Stratification!");
            auto nbHarden = harden();
            if(nbHarden > 0) {
                if(CONF_EXTRACT_AM1) {
                    adapt_am1_FastHeuristicV7();
                }
            }
        }

        

        //initializeAssumptions();
        initializeCardToAdd();
        for(;;) {
            assert(minWeightToConsider > 0);

            /// INITIALISATION ///
            if(minWeightToConsider > 1) { // Statification active
                minWeightToConsider = chooseNextMinWeight(minWeightToConsider);
            }
            initializeAssumptions(minWeightToConsider);

            unsigned int nbSecondSolveMin = CONF_MIN_MULTISOLVE;
            if(_assumptions.size() > CONF_NB_ASSUM_FOR_REDUCE_MULTISOLVE) {
                nbSecondSolveMin = CONF_MIN_MULTISOLVE_REDUCED;
            }
            /// END INITIALISATION ///

            unsigned int nbHarden = 0;
            MaLib::Chrono C_BOUCLE;
            bool storeCardStrat = true;
            for(;;) {
                //print_chrono();

        
                if( (minWeightToConsider > 1) && (C_BOUCLE.tacSec() > 120) ) {  // TODO: hyperparametre
                    strategy += 0.1;
                    applyAllCards();
                    break;
                }


                chronoLastSolve.tic();
                int solverResult;
                if(_cardsToAdd.size() == 0) {
                    solverResult = solver.solve(_assumptions);
                } else {
                    solverResult = solver.solveLimited(_assumptions, CONF_SOLVER_BOUND);
                }
                chronoLastSolve.pause(true);

                if(solverResult != 0) {

                    MonPrint("Solve(): solve(assumptions) didn't find any conflict!");

                    if(solverResult == 1) {
                        nbHarden += harden();
                        if(nbHarden > 0) {
                            if(CONF_EXTRACT_AM1) {
                                adapt_am1_FastHeuristicV7();
                            }
                        }
                    }

                    if( _cardsToAdd.size() == 0 ) {
                        if( minWeightToConsider == 1 ) {
                            assert(solverResult == 1);
                            return true;
                        }
                        break;  // strat fini
                    }


                    bool newAssum = applyAllCards();

                    if( solverResult == 2 ) {
                        if(minWeightToConsider == 1) {
                            storeCardStrat = false;
                            continue;
                        }
                        strategy += 0.1;
                        break;
                    }

                    if( nbSoft == 0 ) {
                        return true;
                    }


                    if(minWeightToConsider > 1) { 

                        if( C_BOUCLE.tacSec() * lvlRestant  >= 1200 ) { // TODO : HYPERPARAMETRE
                            strategy += 0.1;
                        } else {
                            if( strategy > 0.05 ) {
                                strategy -= 0.1;
                                if(strategy < 0.05)
                                    strategy = 0;
                                if(strategy > 0.5) {
                                    strategy = 0.5;
                                }
                            }
                        }


                        minWeightToConsider++; // Trick pour permetre de considérer encore le meme lvl

                        break;
                    }


                } else {
                    MonPrint("\t\t\tSolve(): solve(assumtion) is false!");

                    std::vector<int> conflict = solver.getConflict();

                    if(conflict.size() == 0) {
                        cost = -1;
                        assert(false);
                        return false; // No solution
                    }

                    /// SecondSolve
                    if(CONF_MULTISOLVE) {
                        MonPrint("\t\t\tMain Thread: Second solve...");
                        MaLib::Chrono chronoForBreak;
                        unsigned int nbSecondSolve = 0;
                        std::vector<int> forSecondSolve(_assumptions.begin(), _assumptions.end());
                        while((nbSecondSolve < nbSecondSolveMin) || (chronoLastSolve.tac() >= chronoForBreak.tac())) { 

                            if(conflict.size() == 1)
                                break;
                            nbSecondSolve++;
                            if(chronoForBreak.tacSec() > CONF_TIMEOUT_MULTISOLVE)
                                break;
                            if(nbSecondSolve > CONF_MAX_MULTISOLVE)
                                break;

                            std::random_shuffle(forSecondSolve.begin(), forSecondSolve.end());
                            bool res = solver.solve(forSecondSolve);
                            assert(!res);

                            if( conflict.size() > solver.sizeConflict() ) {
                                conflict = solver.getConflict();
                            }
                        }
                        MonPrint("\t\t\tMain Thread: ", nbSecondSolve, " solves done in ", chronoForBreak.tacSec(), "sec");
                    }

                    bool isMinimal = false;
                    
                    if(fullMinimizeActivated) {
                        if(_isWeighted) {
                            fastMinimizeSmallestLit(conflict);
                        }

                        /// FastMinimize
                        bool doFullMinimize = true;
                        if(C_total.tacSec() < 2000)
                        if(CONF_FAST_MINIMIZE) {
                            doFullMinimize = fastMinimize(conflict, chronoLastSolve.tac());  // hyperparametre
                        }

                        if(conflict.size() == 1) {
                            MonPrint("\t\t\tMain Thread: Optimal found, no need to fullMinimize");
                            doFullMinimize = false;
                        }

                        /// FullMinimize
                        if(C_total.tacSec() < 3000)
                        if(doFullMinimize) {
                            MonPrint("\t\t\tMain Thread: call CL_ConflictToMinimize.push");
                            if(C_total.tacSec() < 2000) {
                                isMinimal = fullMinimize(conflict, chronoLastSolve.tac());
                            } else {
                                
                                isMinimal = fullMinimizeOneIT(conflict, chronoLastSolve.tac());
                                
                            }
                        }
                    } else {
                        isMinimal = fullMinimizeOneIT(conflict, chronoLastSolve.tac());
                    }
                    

                    considerConflict(conflict, !isMinimal);

                    if(!storeCardStrat) {
                        applyAllCards();
                    }
                }

            }
        }
        
        assert(cost == coutPartialSolution());
        return true;

    }

private:

    void sortByWight(std::vector<int> &conflict, bool ascending=true) {

        if(ascending) {
            std::sort( conflict.begin(), conflict.end(), [&](int litA, int litB) {

                assert( _weight[std::abs(litA)] <= std::numeric_limits<t_weight_signed>::max() );
                assert( _weight[std::abs(litB)] <= std::numeric_limits<t_weight_signed>::max() );

                t_weight_signed wA = _weight[std::abs(litA)];
                if( model[abs(litA)] != (litA>0) ) {
                    wA = -wA;
                }
                t_weight_signed wB = _weight[std::abs(litB)];
                if( model[abs(litB)] != (litB>0) ) {
                    wB = -wB;
                }

                if(wA < wB) {
                    return true;
                }

                if(wA == wB) {
                    return compareLitByNum()(litA, litB);
                    //return a<b;
                }

                return false;
            } );
        } else {
            std::sort( conflict.begin(), conflict.end(), [&](int litA, int litB) {

                assert( _weight[std::abs(litA)] <= std::numeric_limits<t_weight_signed>::max() );
                assert( _weight[std::abs(litB)] <= std::numeric_limits<t_weight_signed>::max() );

                t_weight_signed wA = _weight[std::abs(litA)];
                if( model[abs(litA)] != (litA>0) ) {
                    wA = -wA;
                }
                t_weight_signed wB = _weight[std::abs(litB)];
                if( model[abs(litB)] != (litB>0) ) {
                    wB = -wB;
                }

                if(wA > wB) {
                    return true;
                }

                if(wA == wB) {
                    return compareLitByNum()(litA, litB);
                    //return a<b;
                }

                return false;
            } );
        }
    }


    void sortByWight(std::list<int> &conflict, bool ascending=true) {
        if(ascending) {
            conflict.sort( [&](int litA, int litB) {

                assert( _weight[std::abs(litA)] <= std::numeric_limits<t_weight_signed>::max() );
                assert( _weight[std::abs(litB)] <= std::numeric_limits<t_weight_signed>::max() );

                t_weight_signed wA = _weight[std::abs(litA)];
                if( model[abs(litA)] != (litA>0) ) {
                    wA = -wA;
                }
                t_weight_signed wB = _weight[std::abs(litB)];
                if( model[abs(litB)] != (litB>0) ) {
                    wB = -wB;
                }

                if(wA < wB) {
                    return true;
                }

                if(wA == wB) {
                    return compareLitByNum()(litA, litB);
                    //return a<b;
                }

                return false;
            } );
        } else {
            conflict.sort( [&](int litA, int litB) {

                assert( _weight[std::abs(litA)] <= std::numeric_limits<t_weight_signed>::max() );
                assert( _weight[std::abs(litB)] <= std::numeric_limits<t_weight_signed>::max() );

                t_weight_signed wA = _weight[std::abs(litA)];
                if( model[abs(litA)] != (litA>0) ) {
                    wA = -wA;
                }
                t_weight_signed wB = _weight[std::abs(litB)];
                if( model[abs(litB)] != (litB>0) ) {
                    wB = -wB;
                }

                if(wA > wB) {
                    return true;
                }

                if(wA == wB) {
                    return compareLitByNum()(litA, litB);
                    //return a<b;
                }

                return false;
            } );
        }
    }

    ///////////////////////////
    ///// For Minimize ////////
    ///////////////////////////

    t_weight fastMinimizeSmallestLit(std::vector<int> &conflict) {
        MonPrint("fastMinimizeSmallestLit ", conflict.size());

        if( nbSoft >= CONF_NBMAX_ASSUM_FOR_MINIMIZE) {
            MonPrint("Skip");
            return _weight[ abs(conflict[0]) ];
        }

        int B = 10000;  // Hyperparametre // TODO: mettre un B plus grand ?

        sortByWight(conflict, false);

        for(int i=conflict.size()-1; i>=0; i--) {

            switch(solver.solveLimited(conflict, B, conflict[i])) {
            case 2:
                [[fallthrough]];
            case 1:
                return _weight[ abs(conflict[i]) ];

            case 0:
                conflict[i] = conflict.back();
                conflict.pop_back();
                continue;

            default:
                assert(false);
            }
        }
        assert(false);
        return -1;
    }

    bool fastMinimize(std::vector<int> &conflict, long timeout) {
        MonPrint("fastMinimize ", conflict.size(), " conflict with timeout = ", timeout);

        if( nbSoft >= CONF_NBMAX_ASSUM_FOR_MINIMIZE) {
            MonPrint("Skip");
            return _weight[ abs(conflict[0]) ];
        }

        int B = 1;

        sortByWight(conflict, false);

        Chrono chrono;

        for(int i=conflict.size()-1; i>=0; i--) {
            MonPrintR("\t", conflict.size()-i, "/", conflict.size());

            if(chrono.tacSec() > 60) {                    // TODO : hyper parametre
                MonPrint("TIMEOUT fastMinimize!");
                return false;
            }

            switch(solver.solveLimited(conflict, B, conflict[i])) {
            case 2:
                [[fallthrough]];
            case 1:
                break;

            case 0:
                conflict[i] = conflict.back();
                conflict.pop_back();
                break;

            default:
                assert(false);
            }
        }

        MonPrint("\tFin fastMinimize avec ", conflict.size(), " lits");
        return true;
    }



    bool fullMinimizeOneIT(std::vector<int> &conflict, long timeout) {
        MonPrint("fullMinimizeOneIT ", conflict.size(), " conflict with timeout = ", timeout);

        if( nbSoft >= CONF_NBMAX_ASSUM_FOR_MINIMIZE) {
            MonPrint("Skip");
            return _weight[ abs(conflict[0]) ];
        }
        bool minimum = true;
        
        sortByWight(conflict, false);


        int B = CONF_SOLVER_BOUND_FOR_MINIMIZE;


        for(int i=conflict.size()-1; i>=0; i--) {
            MonPrintR("\t", conflict.size()-i, "/", conflict.size());

            switch(solver.solveLimited(conflict, B, conflict[i])) {
            case 2:
                minimum=false;
                [[fallthrough]];
            case 1:
                break;

            case 0:
                conflict[i] = conflict.back();
                conflict.pop_back();
                break;

            default:
                assert(false);
            }
        }

        return true;
    }


    bool fullMinimize(std::vector<int> & conflict, long timeout) {
        MonPrint("fullMinimize ", conflict.size(), " conflict with timeout = ", timeout);

        if( nbSoft >= CONF_NBMAX_ASSUM_FOR_MINIMIZE) {
            MonPrint("Skip");
            return _weight[ abs(conflict[0]) ];
        }

        MaLib::Chrono chrono;
        bool minimum = true;
        bool minimumForRemovable = true;

        int B = CONF_SOLVER_BOUND_FOR_MINIMIZE;

        if(timeout > CONF_MAXTIMEOUT_FOR_MINIMIZE*1000000) {
            timeout = CONF_MAXTIMEOUT_FOR_MINIMIZE*1000000;
        }

        unsigned int nbLoopMin = 5;             
        if( C_total.tacSec() > 1000 ) {         
            nbLoopMin = 3;                      
        }                                       


        std::vector<int> removable;
        MonPrint("\tCalculer Removable...");
        
        for(int i=conflict.size()-1; i>=0; i--) {
            MonPrintR("\t", conflict.size()-i, "/", conflict.size());
            auto lit = conflict[i];
            switch(solver.solveLimited(conflict, B, lit)) {
            case 2:
                minimumForRemovable = false;
                minimum = false;
                [[fallthrough]];
            case 1:
                break;

            case 0:
                removable.push_back( lit );
                break;

            default:
                assert(false);
            }
        }
        MonPrint("\tremovable = ", removable.size(), "/", conflict.size());

        //sortByWight(removable, true); 

        std::vector<int> uselessLit;
        auto bestConflict = conflict;

        if(removable.size() <= 1) {
            uselessLit = removable;
        } else {

            int maxLoop = CONF_MAX_MULTIMINIMIZE;           // Hyperparameter
            if(removable.size() < 8) {                      // Hyperparameter
                maxLoop = 2*std::tgamma(removable.size());  // TODO: si pas beaucoups d'élement, faire une recherche exaustive ?
            }

            chrono.tic();
            for(int i=0; i<maxLoop; i++) {
                auto wConflict = conflict;   // TODO: amélioration possible avec une list chainé ou set (vérifier si ca vaut le coups)
                std::vector<int> tmp_uselessLit;
                bool minimumForI = true;
                
                //for(auto [w, lit]: removable) {
                for(unsigned int j=0; j<removable.size(); j++) {
                    auto lit = removable[j];
                    MonPrintR("\tMinimize (loop ", i+1, "): ", j+1, "/", removable.size(), "     ", tmp_uselessLit.size(), " removed.");
                    switch(solver.solveLimited(wConflict, B, lit)) {
                        case 2:
                            minimum=false;
                            minimumForI = minimumForRemovable;
                            [[fallthrough]];
                        case 1:
                            break;

                        case 0:
                            for(unsigned int i=0; i<wConflict.size(); i++) {
                                if(wConflict[i] == lit) {
                                    wConflict[i] = wConflict.back();
                                    wConflict.pop_back();
                                    break;
                                }
                            }

                            tmp_uselessLit.push_back(lit);
                            break;

                        default:
                            assert(false);
                    }
                }


                if(tmp_uselessLit.size() > uselessLit.size()) {
                    MonPrint("\tnewBest: ", tmp_uselessLit.size(), " removes.");
                    uselessLit = tmp_uselessLit;
                    minimum = minimumForI;
                    bestConflict = wConflict;
                }

                if(uselessLit.size() >= removable.size()-1) {
                    MonPrint("\tOptimal trouvé !");
                    break;
                }

                if(
                        (i>nbLoopMin) // nombre minimal de bouche a faire
                        &&
                        (timeout <= chrono.tac()) ) {
                    MonPrint("\tTimeOut after ", (i+1), " loops !");
                    break;
                }

                std::random_shuffle(removable.begin(), removable.end());
            }
        }

        conflict = bestConflict;

        MonPrint("\tFin fullminimize avec ", conflict.size(), " lits.");
        return minimum;
    }




    ///////////////////////
    ///// For Card ////////
    ///////////////////////

    std::vector< std::tuple<std::vector<int>, t_weight, bool> > _cardsToAdd;

    void initializeCardToAdd() {
        _cardsToAdd.clear();
    }

    /**
     * @brief enleve lit de assumption et générer les cards qui été couvert par lit
     */
    void removeLitFromAssum(int lit) {
        unsigned int var = abs(lit);
        assert( ((lit>0) != model[var]) || _weight[var] == 0 ); // lit peut effectivment étre supprimé

        _assumptions.erase(lit);

        if(mapAssum2card[var] != -1) {
            int idCard = mapAssum2card[var];
            assert(idCard >= 0);

            if(lit == (*std::get<0>(save_card[idCard]) <= std::get<1>(save_card[idCard]))) {
                // Si on est au bout de card, il faut générer la nouvelle assumption qui été couverte

                std::get<1>(save_card[idCard])++;
                assert( std::get<1>(save_card[idCard]) <= std::get<0>(save_card[idCard])->size() );
                int litForCard = (*std::get<0>(save_card[idCard]) <= std::get<1>(save_card[idCard]));

                if(std::get<1>(save_card[idCard]) == std::get<0>(save_card[idCard])->size()) {
                    assert(litForCard == 0);
                }

                if(litForCard != 0) {
                    _assumptions.insert( litForCard );
                    assert(_weight[ abs(litForCard) ] == 0);
                    mapWeight2Assum[ std::get<2>(save_card[idCard]) ].insert( litForCard );
                    _weight[ abs(litForCard) ] = std::get<2>(save_card[idCard]);
                    assert( _weight[ abs(litForCard) ] != 0 );
                    nbSoft++;
                    model[abs(litForCard)] = (litForCard>0);
                    mapAssum2card[ abs(litForCard) ] = idCard;
                }
            } else {
                // Rien a faire
            }
        }
    }

    void addLitToAssum(int lit) {
        unsigned int var = abs(lit);

        assert( _assumptions.count(lit) == 0 );
        assert( _assumptions.count(-lit) == 0 );

        assert( _weight[var] > 0 );         // lit peut effectivment étre ajouté
        assert( ((lit>0) == model[var]) );  // lit peut effectivment étre ajouté

        _assumptions.insert( lit );

    }
    
    void relaxeLit(int lit, t_weight w) {
        assert( abs(lit) < mapAssum2card.size() );

        assert( w > 0 );                        // les lit sont forcement des assumptions
        assert( _assumptions.count(lit) );      // les lit sont forcement des assumptions
        assert( (lit>0) == model[abs(lit)] );   // les lit sont forcement des assumptions

        unsigned int var = abs(lit);

        assert(var < _weight.size());
        assert( _weight[var] >= w );

        assert( mapWeight2Assum[ _weight[var] ].count(lit) );
        mapWeight2Assum[ _weight[var] ].erase( lit );
        _weight[var] -= w;
        if(_weight[var] == 0) {
            nbSoft--;
            removeLitFromAssum(lit);
        } else {
            mapWeight2Assum[ _weight[var] ].insert( lit );
        }
    }


    bool isCardAtMostLit(int lit) {
        unsigned int var = abs(lit);
        if(mapAssum2card[var] == -1) {
            return false;
        }

        return lit < 0; // TRICK : les lit des cards sont négatif par defaut.
    }


    ///
    /// Function called when a conflict is found in the assumptions set
    ///
    void considerConflict(const std::vector<int> & clause, bool exhaust, bool applyNow=false) {

        assert( [&](){
            for(auto lit: clause) {
                assert(_assumptions.count(lit));
            }
            return true;
        }());
        assert( solver.solve( std::vector<int>({clause}) ) == false ); // assert: clause is a conflict

        t_weight maxCostInitial = std::numeric_limits<t_weight>::max();
        for(auto lit: clause) {
            unsigned int var = std::abs(lit);
            assert(_weight[var] > 0);                                   // assert: clause is formed by assumtion literals
            assert( model[var] == (lit>0) );

            if( _weight[var] < maxCostInitial ) {
                maxCostInitial = _weight[var];
            }
        }

        t_weight maxCost = maxCostInitial;
        assert(maxCost > 0);

        MonPrint("\t\t\tMain Thread: cost = ", cost, " + ", maxCost);
        cost += maxCost;

        for(auto lit: clause) {
            relaxeLit(lit, maxCost);
        }

        std::vector<int> forCard;
        for(auto lit: clause) {
            forCard.push_back(-lit);
        }

        if(forCard.size() > 1) {
            if(applyNow) {
                applyCard(forCard, maxCost, exhaust);
            } else {
                _cardsToAdd.push_back( {forCard, maxCost, exhaust} );  // Pour ajouter la card plus tard
            }
        }

    }

    int applyCard(std::vector<int>& clause, t_weight maxCost, bool exhaust) {

        auto card = newCard(clause);

        unsigned int k = 1;
        auto newAssumForCard = ((*card) <= k);

        assert(newAssumForCard != 0);

        if(CONF_EXHAUST) {
            if(exhaust) {
                MonPrint("solveLimited for Exhaust...");
                while(solver.solveLimited(std::vector<int>({newAssumForCard}), CONF_BOUND_FOR_EXHAUST) == 0) {
                    k++;
                    MonPrint("Exhaust: cost = ", cost, " + ", maxCost);
                    cost += maxCost;
                    newAssumForCard = ((*card) <= k);

                    // TODO: on peut potentielement faire mieux que += maxCost   (générer de nouveaux conflicts)

                    if(newAssumForCard==0) {
                        break;
                    }
                }
            }
            MonPrint("Exhaust fini!");
        }

        if(newAssumForCard != 0) {
            assert(k <= card->getClauses().size());
            assert(clause.size() == card->getClauses().size());

            save_card.push_back( {card, k, maxCost} );

            assert(abs(newAssumForCard) < _weight.size());
            assert( _weight[abs(newAssumForCard)] == 0);
            assert(maxCost > 0);
            _weight[abs(newAssumForCard)] = maxCost;    // TODO: possiblement plus que maxCost en créant une seconde card (ou encore plus si k > 1)
            nbSoft++;
            
            mapWeight2Assum[ _weight[abs(newAssumForCard)] ].insert( newAssumForCard );
            model[abs(newAssumForCard)] = (newAssumForCard>0);
            _assumptions.insert( newAssumForCard );
            mapAssum2card[ abs(newAssumForCard) ] = save_card.size()-1;
        }

        return newAssumForCard;
    }


    bool applyAllCards( ) {
        bool newAssums = false;
        while(_cardsToAdd.size()) {
            auto [clause, maxCost, exhaust] = _cardsToAdd.back();
            _cardsToAdd.pop_back();
            if(applyCard(clause, maxCost, exhaust)) {
                newAssums = true;
            }
        }
        return newAssums;
    }



    //////////////////////////////
    ///// For Assumptions ////////
    //////////////////////////////
    std::set<int/*, compareLitByNum*/> _assumptions;

    void initializeAssumptions(t_weight minWeightToConsider = 1) {
        _assumptions.clear();

        for(unsigned int i=1; i<_weight.size(); i++) {
            if(_weight[i] >= minWeightToConsider) {
                if(model[i]) {
                    _assumptions.insert(static_cast<int>(i));
                } else {
                    _assumptions.insert(-static_cast<int>(i));
                }
            }
        }
    }

    bool isInAssum(int lit) {
        unsigned int var = static_cast<unsigned int>(abs(lit));
        if( _weight[var] > 0 ) {
            if( model[var] == (lit>0) )
                return true;
        }
        return false;
    }


    //////////////////////////////
    ////// For extractAM ////////
    ////////////////////////////
    void extractAM(t_weight minWeight = 1) {

        MonPrint("\tExtractAM1...");

        if(nbSoft < 30000) {
            std::vector<int> assumption;
            for(unsigned int i=1; i<_weight.size(); i++) {
                if(_weight[i] > 0) {
                    if(model[i]) {
                        assumption.push_back(static_cast<int>(i));
                    } else {
                        assumption.push_back(-static_cast<int>(i));
                    }
                }
            }
            adapt_am1_exact(assumption);
            adapt_am1_FastHeuristicV7();

        } else if(minWeight > 1) {
            std::vector<int> assumption;
            for(unsigned int i=1; i<_weight.size(); i++) {
                if(_weight[i] >= minWeight) {
                    if(model[i]) {
                        assumption.push_back(static_cast<int>(i));
                    } else {
                        assumption.push_back(-static_cast<int>(i));
                    }
                }
            }

            if(assumption.size() < 30000) {
                adapt_am1_exact(assumption);
                adapt_am1_FastHeuristicV7(minWeight);
            } else {
                adapt_am1_FastHeuristicV7();
            }
        } else {
            adapt_am1_FastHeuristicV7();
        }

        MonPrint("Cost after AM1: ", cost);
    }

    void reduceCliqueV2(std::list<int> & clique) {

        sortByWight(clique, false);  

        for(auto posImpliquant = clique.begin() ; posImpliquant != clique.end() ; ++posImpliquant) {
            auto posImpliquant2 = posImpliquant;
            for(++posImpliquant2 ; posImpliquant2 != clique.end() ; ) {
                if(solver.solveLimited(std::vector<int>({-(*posImpliquant), -(*posImpliquant2)}), 10000) != 0) {
                    posImpliquant2 = clique.erase(posImpliquant2);
                } else {
                    ++posImpliquant2;
                }
            }
        }
    }

    bool adapt_am1_FastHeuristicV7(t_weight minWeight = 1) {


        MonPrint("adapt_am1_FastHeuristic : (_weight.size() = ", _weight.size(), " )");
        Chrono chrono;
        std::vector<int> prop;
        unsigned int nbCliqueFound=0;

        for(unsigned int VAR = 1; VAR<_weight.size(); VAR++) {
            if(_weight[VAR] < minWeight)
                continue;

            assert(_weight[VAR] > 0);
            int LIT = model[VAR]?static_cast<int>(VAR):-static_cast<int>(VAR);
            prop.clear();
            if(solver.propagate({LIT}, prop)) {
                if(prop.size() == 0)
                    continue;
                assert(*prop.begin() == LIT);
                if(prop.size() == 1)
                    continue;

                std::list<int> clique;
                for(auto litProp: prop) {
                    if( _weight[ abs(litProp) ] < minWeight )
                        continue;
                    if(isInAssum(-litProp)) {
                        clique.push_back(litProp);
                        assert(solver.solve(std::vector<int>({-litProp, LIT})) == false);
                    }
                }

                if(clique.size() == 0)
                    continue;

                reduceCliqueV2(clique); // retirer des elements pour que clique soit une clique

                clique.push_back(-LIT);

                if(clique.size() >= 2) {
                    nbCliqueFound++;

                    std::vector<int> clause;
                    for(auto lit: clique)
                        clause.push_back(-lit);

                    processAtMostOne(clause);
                }
            } else {
                addClause({-LIT});
            }
        }

        MonPrint("FastHeuristicV7:", nbCliqueFound, " cliques found in ", chrono.tac() / 1000, "ms.");

        return true;
    }

    bool adapt_am1_exact(std::vector<int> &assumption) {


        Chrono chrono;
        unsigned int nbCliqueFound=0;

        MonPrint("Create graph for searching clique...");
        unsigned int size = assumption.size();
        bool **conn = new bool*[size];
        for(unsigned int i=0; i<size; i++) {
            conn[i] = new bool[size];
            for(unsigned int x=0; x<size; x++)
                conn[i][x] = false;
        }

        MonPrint("Create link in graph...");
        for(unsigned int i=0; i<size; ) {
            int lit1 = assumption[i];

            std::vector<int> prop;
            if(solver.propagate({lit1}, prop)) {
                for(int lit2: prop) {
                    for(unsigned int j=0; j<size; j++) {
                        if(j==i)
                            continue;
                        if(assumption[j] == -lit2) {
                            conn[i][j] = true;
                            conn[j][i] = true;
                        }
                    }
                }
                i++;
            } else {
                assert( solver.solve( std::vector<int>({lit1}) ) == false );
                addClause({-lit1});

                assumption[i] = assumption.back();
                assumption.pop_back();

                for(unsigned int x=0; x<size; x++) {
                    conn[i][x] = false;
                    conn[x][i] = false;
                }

                size--;
            }
        }


        if(size == 0) {
            for(unsigned int i=0; i<size; i++) {
                delete conn[i];
            }
            delete [] conn;
            return true;
        }

        std::vector<bool> active(size, true);
        for(;;) {
            int *qmax;
            int qsize=0;
            Maxclique md(conn, size, 0.025);
            md.mcqdyn(qmax, qsize, 100000);

            if(qsize <= 2) { // Hyperparametre: Taille minimal a laquelle arreter la methode exact
                for(unsigned int i=0; i<size; i++) {
                    delete conn[i];
                }
                delete [] conn;
                delete qmax;

                MonPrint("adapt_am1_exact: ", nbCliqueFound, " cliques found in ", (chrono.tac() / 1000), "ms.");

                return true;
            }
            nbCliqueFound++;

            {
                std::vector<int> clause;

                for (unsigned int i = 0; i < qsize; i++) {
                    int lit = assumption[qmax[i]];
                    active[qmax[i]] = false;
                    clause.push_back(lit);

                    for(unsigned int x=0; x<size; x++) {
                        conn[qmax[i]][x] = false;
                        conn[x][qmax[i]] = false;
                    }
                }

                auto newAssum = processAtMostOne(clause);
                assert(qsize >= newAssum.size());

                for(unsigned int j=0; j<newAssum.size() ; j++) {
                    assumption[ qmax[j] ] = newAssum[j];

                    std::vector<int> prop;
                    if(solver.propagate({newAssum[j]}, prop)) {
                        for(int lit2: prop) {
                            for(unsigned int k=0; k<size; k++) {
                                assert(active[qmax[j]] == false);
                                if(active[k]) {
                                    assert(k != qmax[j]);
                                    if(assumption[k] == -lit2) {
                                        conn[qmax[j]][k] = true;
                                        conn[k][qmax[j]] = true;
                                    }
                                }
                            }
                        }
                    } else {
                        assert( solver.solve( std::vector<int>({newAssum[j]}) ) == false );
                        addClause({-newAssum[j]});
                    }

                    active[ qmax[j] ] = true;
                }
            }

            delete qmax;
        }

        assert(false);
    }

    std::vector<int> processAtMostOne(std::vector<int> clause) {
        std::vector<int> newAssum;

        while(clause.size() > 1) {

            assert([&](){
                for(unsigned int i=0; i<clause.size(); i++) {
                    for(unsigned int j=i+1; j<clause.size(); j++) {
                        assert(solver.solve(std::vector<int>({clause[i], clause[j]})) == false );
                    }
                }
                return true;
            }());

            auto saveClause = clause;
            t_weight w = _weight[ abs(clause[0]) ];

            for(unsigned int i=1; i<clause.size(); i++) {
                if( w > _weight[ abs(clause[i]) ] ) {
                    w = _weight[ abs(clause[i]) ];
                }
            }

            assert(w > 0);

            for(unsigned int i=0; i<clause.size(); ) {
                assert( model[ abs(clause[i]) ] == (clause[i]>0) );
                assert( mapWeight2Assum[ _weight[ abs(clause[i]) ] ].count(clause[i]) );
                mapWeight2Assum[ _weight[ abs(clause[i]) ] ].erase( clause[i] );
                _weight[ abs(clause[i]) ] -= w;

                if( _weight[ abs(clause[i]) ] == 0 ) {
                    nbSoft--;
                    removeLitFromAssum(clause[i]);
                    clause[i] = clause.back();
                    clause.pop_back();
                } else {
                    mapWeight2Assum[ _weight[ abs(clause[i]) ] ].insert(clause[i]);
                    i++;
                }
            }
            MonPrint("AM1: cost = ", cost, " + ", w * (t_weight)(saveClause.size()-1));
            cost += w * (t_weight)(saveClause.size()-1);

            assert(saveClause.size() > 1);
            newAssum.push_back( addWeightedClause(saveClause, w) );
            assert( _weight[ abs(newAssum.back()) ] > 0 );
            assert( model[ abs(newAssum.back()) ]  == (newAssum.back() > 0) );
        }

        if( clause.size() ) {
            newAssum.push_back(clause[0]);
        }
        return newAssum;

    }

};


#endif // EVALMAXSAT_SLK178903R_H
