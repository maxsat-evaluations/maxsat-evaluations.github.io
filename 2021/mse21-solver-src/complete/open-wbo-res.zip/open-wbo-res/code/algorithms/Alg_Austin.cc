/*!
 * \author Ruben Martins - ruben@sat.inesc-id.pt
 *
 * @section LICENSE
 *
 * Open-WBO, Copyright (c) 2013-2017, Ruben Martins, Vasco Manquinho, Ines Lynce
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

#include "Alg_Austin.h"
#define CONFLICT_LIMIT 1000
#define CLAUSE_LIMIT 100000

using namespace openwbo;

void Austin::minimizeModel(){
  vec<Lit> assumptions;
  for (int i = 0; i < objFunction.size(); i++){
    assumptions.clear();
    if (softStatus[i] != 0){
      // try to remove it
      for (int j = 0; j < softStatus.size(); j++){
        if (j == i) 
          assumptions.push(~objFunction[j]);
        else {
          if (softStatus[j] == 0) 
            assumptions.push(~objFunction[j]);
          else
            assumptions.push(objFunction[j]);
        }
      }

        solver->setConfBudget(CONFLICT_LIMIT);
        lbool res = searchSATSolver(solver, assumptions);
        solver->budgetOff();
        if (res == l_True){
          // this relation variable can be flipped
          softStatus[i] = 0;
          nb_inactive++;
          nb_active--;
        }
    }
  }
}


StatusCode Austin::normalSearch() {

  lbool res = l_True;
  ubCost = UINT64_MAX;

  initRelaxation();
  solver = rebuildSolver();
  vec<Lit> encodingAssumptions;
  vec<Lit> assumptions;
  vec<Lit> join;
  vec<Lit> obj;

  while (true) {

    res = searchSATSolver(solver, assumptions);

    if (res == l_True) {
      nbSatisfiable++;
      join.clear();

      uint64_t newCost = computeLocalCostModel(solver->model, join);
      if (newCost < ubCost){
        saveModel(solver->model);
        savePhase(solver);
        ubCost = newCost;
        printBound(newCost);
      }

      printf("c I = %d, D = %d, A = %d\n",nb_inactive, nb_disable, nb_active);
      if (nbSatisfiable == 1){
        // if there are not too many soft clauses in the model try to minimize it
        if (newCost < CLAUSE_LIMIT)
          minimizeModel();

        assumptions.clear();
        for (int i = 0; i < softStatus.size(); i++){
          if (softStatus[i] == 0) assumptions.push(~objFunction[i]);
        }
      }

      printf("c I = %d, D = %d, A = %d\n",nb_inactive, nb_disable, nb_active);

      if (newCost == 0) {
        // If there is a model with value 0 then it is an optimal model
        ubCost = newCost;

        if (maxsat_formula->getFormat() == _FORMAT_PB_ &&
            maxsat_formula->getObjFunction() == NULL) {
          printAnswer(_SATISFIABLE_);
          return _SATISFIABLE_;
        } else {
          printAnswer(_OPTIMUM_);
          return _OPTIMUM_;
        }

      } else {
          // Unweighted.
          if (!encoder.hasCardEncoding()){
            obj.clear();
            join.copyTo(obj);
            encoder.buildCardinality(solver, obj, ubCost - 1);
          } else {
            if (join.size() > 0){
              encoder.joinEncoding(solver, join, ubCost - 1);
              for (int i = 0; i < join.size(); i++){
                obj.push(join[i]);
              }
            }
            encodingAssumptions.clear();
            encoder.incUpdateCardinality(solver, obj, ubCost-1, encodingAssumptions);
            for (int i = 0; i < encodingAssumptions.size(); i++){
              assumptions.push(encodingAssumptions[i]);
            }
          }
        }

        ubCost = newCost;
    
    } else {
      nbCores++;
      if (solver->conflict.size() == 0 && model.size() == 0){
        assert(nbSatisfiable == 0);
        // If no model was found then the MaxSAT formula is unsatisfiable
        printAnswer(_UNSATISFIABLE_);
        return _UNSATISFIABLE_;
      } else {
        if (solver->conflict.size() == 0){
          printAnswer(_OPTIMUM_);
          return _OPTIMUM_;  
        } else {
          // inactive -> disable
          for (int i = 0; i < solver->conflict.size(); i++){
            if (core2soft.find(solver->conflict[i])!=core2soft.end()){
              assert (softStatus[core2soft[solver->conflict[i]]] == 0);
              softStatus[core2soft[solver->conflict[i]]] = 1;
              nb_inactive--;
              nb_disable++;
            }
          }

          assumptions.clear();
          for (int i = 0; i < softStatus.size(); i++){
            if (softStatus[i] == 0) assumptions.push(~objFunction[i]);
          }

          printf("c I = %d, D = %d, A = %d\n",nb_inactive, nb_disable, nb_active);          
        }
      }
    }
  }

  return _ERROR_;
}

// Public search method
StatusCode Austin::search() {

  assert (maxsat_formula->getProblemType() == _UNWEIGHTED_);
  return normalSearch();
}

/************************************************************************************************
 //
 // Rebuild MaxSAT solver
 //
 ************************************************************************************************/

/*_________________________________________________________________________________________________
  |
  |  rebuildSolver : (minWeight : int)  ->  [Solver *]
  |
  |  Description:
  |
  |    Rebuilds a SAT solver with the current MaxSAT formula.
  |    If a weight is specified, then it only considers soft clauses with weight
  |    smaller than the specified weight.
  |    NOTE: a weight is specified in the 'bmo' approach.
  |
  |________________________________________________________________________________________________@*/
Solver *Austin::rebuildSolver(uint64_t min_weight) {

  vec<bool> seen;
  seen.growTo(maxsat_formula->nVars(), false);

  Solver *S = newSATSolver();

  reserveSATVariables(S, maxsat_formula->nVars());

  for (int i = 0; i < maxsat_formula->nVars(); i++)
    newSATVariable(S);

  for (int i = 0; i < maxsat_formula->nHard(); i++)
    S->addClause(maxsat_formula->getHardClause(i).clause);

  for (int i = 0; i < maxsat_formula->nPB(); i++) {
    Encoder *enc = new Encoder(_INCREMENTAL_NONE_, _CARD_MTOTALIZER_,
                               _AMO_LADDER_, _PB_GTE_);

    // Make sure the PB is on the form <=
    // if (maxsat_formula->getPBConstraint(i)->_sign)
    //  maxsat_formula->getPBConstraint(i)->changeSign();
    assert(maxsat_formula->getPBConstraint(i)->_sign);

    enc->encodePB(S, maxsat_formula->getPBConstraint(i)->_lits,
                  maxsat_formula->getPBConstraint(i)->_coeffs,
                  maxsat_formula->getPBConstraint(i)->_rhs);

    delete enc;
  }

  for (int i = 0; i < maxsat_formula->nCard(); i++) {
    Encoder *enc = new Encoder(_INCREMENTAL_NONE_, _CARD_MTOTALIZER_,
                               _AMO_LADDER_, _PB_GTE_);

    if (maxsat_formula->getCardinalityConstraint(i)->_rhs == 1) {
      enc->encodeAMO(S, maxsat_formula->getCardinalityConstraint(i)->_lits);
    } else {

      enc->encodeCardinality(S,
                             maxsat_formula->getCardinalityConstraint(i)->_lits,
                             maxsat_formula->getCardinalityConstraint(i)->_rhs);
    }

    delete enc;
  }

  vec<Lit> clause;
  for (int i = 0; i < maxsat_formula->nSoft(); i++) {
    if (maxsat_formula->getSoftClause(i).weight < min_weight)
      continue;

    clause.clear();
    maxsat_formula->getSoftClause(i).clause.copyTo(clause);

    for (int j = 0; j < maxsat_formula->getSoftClause(i).relaxation_vars.size();
         j++) {
      clause.push(maxsat_formula->getSoftClause(i).relaxation_vars[j]);
    }

    S->addClause(clause);
  }

  return S;
}

/************************************************************************************************
 //
 // Other protected methods
 //
 ************************************************************************************************/

/*_________________________________________________________________________________________________
  |
  |  initRelaxation : (objective : vec<Lit>&) (weights : vec<int>&)  ->  [void]
  |
  |  Description:
  |
  |    Initializes the relaxation variables by adding a fresh variable to the
  |    'relaxationVars' of each soft clause.
  |
  |  Post-conditions:
  |    * 'objFunction' contains all relaxation variables that were added to soft
  |       clauses.
  |    * 'coeffs' contains the weights of all soft clauses.
  |
  |________________________________________________________________________________________________@*/
void Austin::initRelaxation() {
  softStatus.growTo(maxsat_formula->nSoft(), 0);
  for (int i = 0; i < maxsat_formula->nSoft(); i++) {
    Lit l = maxsat_formula->newLiteral();
    maxsat_formula->getSoftClause(i).relaxation_vars.push(l);
    objFunction.push(l);
    core2soft[l] = i;
  }
}

 // save polarity from last model 
 void Austin::savePhase(Solver * solver) {
  
  assert (solver->model.size() > 0);
  assert (solver->model.size() >= maxsat_formula->nInitialVars());

  // save the polarity of the original variables
  for (int i = 0; i < maxsat_formula->nInitialVars(); i++){
    solver->setPolarity(i, solver->model[i] == l_False);
  }

  // save the polarity of the relaxation variables
  for (int i = 0; i < maxsat_formula->nSoft(); i++){
    assert (maxsat_formula->getSoftClause(i).relaxation_vars.size() == 1);
    maxsat_formula->getSoftClause(i).relaxation_vars[0];
    int v = var(maxsat_formula->getSoftClause(i).relaxation_vars[0]);
    assert (v < solver->model.size());
    solver->setPolarity(v, solver->model[v] == l_False);
  }

 }

uint64_t Austin::computeLocalCostModel(vec<lbool> &currentModel, vec<Lit>& join) {

  assert(currentModel.size() != 0);
  uint64_t currentCost = 0;

  for (int i = 0; i < maxsat_formula->nSoft(); i++) {
    bool unsatisfied = true;
    for (int j = 0; j < maxsat_formula->getSoftClause(i).clause.size(); j++) {

      assert(var(maxsat_formula->getSoftClause(i).clause[j]) <
             currentModel.size());
      if ((sign(maxsat_formula->getSoftClause(i).clause[j]) &&
           currentModel[var(maxsat_formula->getSoftClause(i).clause[j])] ==
               l_False) ||
          (!sign(maxsat_formula->getSoftClause(i).clause[j]) &&
           currentModel[var(maxsat_formula->getSoftClause(i).clause[j])] ==
               l_True)) {
        unsatisfied = false;
        break;
      }
    }

    if (unsatisfied) {
      if (softStatus[i] == 1 || nbSatisfiable == 1){
        softStatus[i] = 2;
        if (nbSatisfiable > 1) nb_disable--;
        nb_active++;
        join.push(objFunction[i]);
      }
      currentCost += 1;
    } else {
      if (nbSatisfiable == 1) {
        softStatus[i] = 0;
        nb_inactive++;
      }
    }
  }

  return currentCost;
}