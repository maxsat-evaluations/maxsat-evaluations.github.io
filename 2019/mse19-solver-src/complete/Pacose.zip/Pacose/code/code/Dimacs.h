/****************************************************************************************[Dimacs.h]
Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
/* koshi 20140124
#ifndef Minisat_Dimacs_h
#define Minisat_Dimacs_h
*/
#ifndef Glucose_Dimacs_h
#define Glucose_Dimacs_h

#include <stdio.h>
#include <vector>

/* koshi 20140210
#include "utils/ParseUtils.h"
*/
/* koshi 20170630
#include "maxsat0.2f-glucose3.0/ParseUtils.h"
*/
#include "ParseUtils.h"
#include "core/SolverTypes.h"
#include "solver/antom.h"

#include <iostream>
/* koshi 20140124
namespace Minisat {
*/
namespace Glucose {

//=================================================================================================
// DIMACS Parser:

// koshi 20140106
template<class B, class Solver>
static bool readClause(B& in, Solver& S, vec<Lit>& lits,
                       long long int& weight, long long int top) {
    long long int     parsed_lit; // koshi 20140106
    int var;
    bool soft = false;
    lits.clear();
    if (top == 0) { // koshi 20140106 (ms: all clauses are 1-weighted soft)
        soft = true;
        weight = 1;
    } else {// koshi 20140106
        parsed_lit = parseInt(in);
        if ((1 <= parsed_lit && parsed_lit < top) || top == -1) { // soft clause
            // top == -1 indicates all clauses are weighted
            soft = true;
            weight = parsed_lit;
        } else if (parsed_lit != top) { // weight of hard clause must be top
            printf("Unexpected weight %c\n", *in), exit(3);
        }
    }

    for (;;){
        parsed_lit = parseInt(in);
        if (parsed_lit == 0) break;
        var = abs(parsed_lit)-1;
        //while (var >= S.nVars()) S.newVar();
        lits.push( (parsed_lit > 0) ? mkLit(var) : ~mkLit(var) );
    }

    return soft;
}
// koshi 20140106
template<class B, class Solver>
static void parse_DIMACS_main(B& in, Solver& S,
                              // koshi 20140106
                              int& out_nbvar,
                              long long int& out_top, int& out_nbsoft,
                              vec<long long int>& weights,
                              vec<Lit>& blockings,
                              std::vector<std::vector<u_int32_t>>& literals,
                              antom::Antom& antom) {
    vec<Lit> lits;
    std::vector<u_int32_t> antLits;
    int vars    = 0;
    int clauses = 0;
    int cnt     = 0;

    // koshi 20140106
    int uscnt = 0;
    long long int sWeight=0; // sum of weights of soft clauses
    long long int usWeight=0; // sum of weights of unit soft clauses
    weights.clear(); blockings.clear();
    long long int top=0;

    bool moreThanTwoWeights(false);
    uint64_t minWeight((uint64_t) - 1);
    uint64_t maxWeight(0);

    for (;;){
        skipWhitespace(in);
        if (*in == EOF) break;
        else if (*in == 'p') {
            if (eagerMatch(in, "p cnf")){ // koshi 20140106 (Unweighted MaxSAT)
                vars    = parseInt(in);
                clauses = parseInt(in);
                // SATRACE'06 hack
                // if (clauses > 4000000)
                //     S.eliminate(true);
                top = 0; // all clauses are 1-weighted soft
            } else if (eagerMatch(in, "wcnf")) {
                vars    = parseInt(in);
                clauses = parseInt(in);
                while((*in == 9 ||*in == 32)) ++in; // koshi 20140117 skip space and tab
                //	skipWhitespace(in);
                if (*in >= '0' && *in <= '9') {
                    top = parseInt(in);
                    printf("c top = %lld\n",top);
                }
                else {
                    top = -1; // weighted Max-SAT (no hard clause)
                    printf("c weighted Max-SAT (wms)\n");
                }
            } else {
                printf("PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
            }
            out_nbvar   = vars;
            out_top     = top;
            while (vars > S.nVars()) S.newVar();

            printf("c |  Number of variables:    %-12d                                     |\n", vars);
            printf("c |  Number of clauses:      %-12d                                     |\n", clauses);
            if (top == -1)
                printf("c |  all clauses are weithed soft                                             |\n");
            else if (top == 0)
                printf("c |  all clauses are 1-weithed soft                                           |\n");
            else
                printf("c |  Weight of hard clauses: %-12lld                                     |\n", top);
        } else if (*in == 'c' || *in == 'p')
            skipLine(in);
        else { // soft or hard clause
            long long int weight = 0;
            cnt++;
            if (readClause(in, S, lits, weight, out_top)) {// soft clause
                out_nbsoft++;
                weights.push(weight);

                if (weight < minWeight)
                {
                    minWeight = weight;
                }
                if (weight > maxWeight)
                {
                    maxWeight = weight;
                }
                if (!moreThanTwoWeights && minWeight != maxWeight && weight != minWeight && weight != maxWeight)
                {
                    moreThanTwoWeights = true;
                    //        std::cout << "hasmoreThanTwoWeights" << std::endl;
                }

                sWeight += weight;
                //    printf("weight: %d, sum: %d\n", weight, sWeight);
                antLits.clear();
                if (lits.size() == 1) {// unit clause
                    uscnt++;
                    usWeight += weight;
                    blockings.push(~lits[0]);

                    antLits.push_back(static_cast<u_int32_t>(toInt(lits[0]) + 2));
                    literals.push_back(antLits);

                    continue;
                } else {
                    Lit lit = mkLit(S.newVar());

                    for(int i = 0; i < lits.size(); i++)
                    {
                        antLits.push_back(static_cast<u_int32_t>(toInt(lits[i]) + 2));
                    }
                    literals.push_back(antLits);

                    blockings.push(lit);
                    lits.push(lit);
                }
            }
            S.addClause_(lits);
        }
    }

    antom.SetMoreThanTwoWeights(moreThanTwoWeights);
    antom.SetTopWeight(static_cast<uint64_t>(top));
    antom.SetMinWeight(minWeight);
    antom.SetMaxWeight(maxWeight);
    antom.SetHasHardClauses(out_nbsoft < S.nClauses());

    // koshi 20140107
    printf("c |  Number of soft clauses: %-12d                                     |\n", out_nbsoft);
    printf("c |  Number of unit soft clauses: %-12d                                |\n", uscnt);
    // koshi 2013.05.21
    printf("c |  Maximum Cardinality (by unit): %-12lld (%-12lld)               |\n", sWeight, usWeight);

    /* koshi 20140107
  if (vars != S.nVars())
    fprintf(stderr, "WARNING! DIMACS header mismatch: wrong number of variables.\n");
  */
    if (cnt  != clauses)
        fprintf(stderr, "WARNING! DIMACS header mismatch: wrong number of clauses.\n");
}

// Inserts problem into solver.
//
template<class Solver>
static void parse_DIMACS(gzFile input_stream, Solver& S,
                         // koshi 20140107
                         int& out_nbvar,
                         long long int& out_top,
                         int& out_nbsoft,
                         vec<long long int>& weights,
                         vec<Lit>& blockings,
                         std::vector<std::vector<u_int32_t>>& literals,
                         antom::Antom& antom) {
    StreamBuffer in(input_stream);
    //  parse_DIMACS_main(in, S, out_nbvar, out_top, out_nbsoft); }
    parse_DIMACS_main(in, S, out_nbvar, out_top, out_nbsoft,
                      weights, blockings, literals, antom); }

//=================================================================================================
}

#endif
