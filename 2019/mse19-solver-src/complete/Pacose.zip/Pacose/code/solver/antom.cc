
/********************************************************************************************
antom.cpp -- Copyright (c) 2014-2016, Sven Reimer

dPermission is hereby granted, free of charge, to any person obtaining a copy of this 
software and associated documentation files (the "Software"), to deal in the Software 
without restriction, including without limitation the rights to use, copy, modify, merge, 
publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons 
to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING 
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
********************************************************************************************/

#include <cmath>
#include <iomanip>

// Include antom related headers.
#include "antom.h"
#include "sorter.h"
#include "cascade.h"
#include "timemeasurement.h"
#include "timevariables.h"

namespace antom
{
  Antom::Antom(Glucose::Solver* glucose) :
    _softClauses(),
    _sorterTree(),
    _glucose(glucose),
    _antomSetting(new Settings),
    _maxSorterDepth(0),
    _maxsatResult(ANTOM_UNKNOWN),
    _optimum(nullptr),
    _timeVariables(nullptr),
    _mainCascade(nullptr),
    _greatestCommonDivisor(1),
    _formulaStructure(),
    _currentBucketForTare(0),
    _satWeight(0),
    _moreThanTwoWeights(false),
    _topWeight(0),
    _minWeight(1),
    _maxWeight(0),
    _sumOfSoftWeights(0),
    _resultUnknown(false),
    _clausesBefore(0),
    _binaryClausesBefore(0),
    _ternaryClausesBefore(0),
    _addedClauses(0),
    _addedBinaryClauses(0),
    _addedTernaryClauses(0),
    _binaryTopClauses(0),
    _ternaryTopClauses(0),
    _binaryBottomClauses(0),
    _ternaryBottomClauses(0),
    _satSolverCalls(0),
    _highestBucketMultiplicator(0),
    _currentBucketMultiplicator(0),
    _estimatedSatWeight(0),
    _diffToSatWeight(0),
    _collectedAssumptions(),
    _totalTime(nullptr)
  {
    _sorterTree.resize(1);
  }

  Antom::~Antom(void)
  {
    for (uint32_t i = 0; i != _sorterTree.size(); ++i)
      {
        for (uint32_t j = 0; j != _sorterTree[i].size(); ++j)
	  {
            delete _sorterTree[i][j];
	  }
      }
    for (uint32_t i = 0; i != _softClauses.size(); ++i)
      {
        delete _softClauses[i];
      }
    delete _antomSetting;
    delete _timeVariables;
  }

  /********** Interface to Glucose and reimplemented functions from AntomBase **********/

  // Creates and returns a fresh variable index not used so far.
  uint32_t Antom::NewVariable(void)
  {
    Glucose::Var newVar = _glucose->newVar(true, true);
    return static_cast<uint32_t>(newVar) + 1;
  }

  // TODO: optimize -> change interface to Glucose data structures
  bool Antom::AddClause(std::vector<uint32_t>& clause, uint32_t lbd)
  {
    _addedClauses++;
    Glucose::vec<Glucose::Lit> newClause;
    for (uint32_t lit : clause )
      {
        assert(lit > 1);
        Glucose::Lit newLit = Glucose::toLit(static_cast<int>(lit - 2));
        newClause.push(newLit);
      }
    return _glucose->addClause_(newClause);
  }
  
  bool Antom::AddClause(Glucose::vec<Glucose::Lit>& clause)
  {
    _addedClauses++;
    return _glucose->addClause_(clause);
  }

  bool Antom::AddUnit(uint32_t lit)
  {
    std::vector<uint32_t > unitclause;
    unitclause.push_back(lit);
    return AddClause(unitclause);
  }

  uint32_t Antom::Solve(void)
  {
    std::vector<uint32_t> assumptions; 
    return Solve(assumptions); 
  }

  uint32_t Antom::Solve(const std::vector<uint32_t>& assumptions)
  {
    Glucose::vec<Glucose::Lit> dummy;
    for(uint32_t lit: assumptions)
    {
        assert(lit>1);
        dummy.push(Glucose::toLit(static_cast<int>(lit-2)));
    }
    Glucose::lbool result = _glucose->solveLimited(dummy);
    if (result == Glucose::l_True)
      {
    return ANTOM_SAT;
      }
    else if (result == Glucose::l_False)
      {
    return ANTOM_UNSAT;
      }
    else
      {
    return ANTOM_UNKNOWN;
      }
  }

  // TODO: optimize!
  // copies whole model vector
  std::vector<uint32_t> Antom::Model(void) const
  {
    std::vector<uint32_t> antomModel(_glucose->model.size()+1, 0);

    for(int32_t i = 0; i != _glucose->model.size(); ++i)
      {
        uint32_t antomValue = 0;
        if (_glucose->model[i] == Glucose::l_True)
          {
            antomValue = (i+1)<<1;
          }
        else if (_glucose->model[i] == Glucose::l_False)
          {
            antomValue = ((i+1)<<1)^1;
          }
        antomModel[i+1] = antomValue;
      }
    return antomModel;
  }
  
  // TODO: Check this for correctness!
  // TODO: Try to use this interface whenever possible
  uint32_t Antom::Model(uint32_t var) const
  {
    assert(var>0);
    if (_glucose->model[var-1] == Glucose::l_True)
      {
        return (var)<<1;
      }
    else if (_glucose->model[var-1] == Glucose::l_False)
      {
        return ((var)<<1)^1;
      }
    else return var;
  }
  
  uint32_t Antom::Variables() const
  {
    return static_cast<uint32_t>(_glucose->nVars());
  }

  uint32_t Antom::Clauses() const
  {
    return static_cast<uint32_t>(_glucose->nClauses() + _glucose->nLearnts());
  }

  uint32_t Antom::StaticClauses() const
  {
    return static_cast<uint32_t>(_glucose->nClauses());
  }

  uint32_t Antom::CurrentBinaryClauses() const
  {
    // TODO: implement me!
    return 0;
  }
  uint32_t Antom::CurrentTernaryClauses() const
  {
    // TODO: implement me!
    return 0;
  }


  // Add SoftClause from glucose to antom database
  void Antom::AddSCfromGlucose( uint64_t weight, const std::vector<u_int32_t>& sclause, uint32_t antBlock)
  {

      uint32_t triggerLit(0);
      std::vector < uint32_t > clause;
//      Glucose::vec<Glucose::Lit>& clause;
//      Glucose::Lit newLit = Glucose::toLit(static_cast<int>(lit - 2));
//      newClause.push(newLit);

	  // for unit soft clauses: ignore blocking lit and create new one
	  // also, we have to add the clause to the database, since this is not done so far
      if(sclause.size() == 1)
      {
        triggerLit = NewVariable()<<1;
//        triggerLit = antBlock;
		clause.push_back(sclause[0]);
        clause.push_back(triggerLit);
        AddClause(clause);
      }
	  else // for all other soft clauses: just set the triggerlit correctly
      {
          triggerLit = antBlock;
      }

      SoftClause* sclaus = new SoftClause (triggerLit, sclause, weight);
      _softClauses.push_back( sclaus );

      _sumOfSoftWeights += weight;
      return;
  }

  Settings* Antom::GetSetting()
  {
      return _antomSetting;
  }

  /********** End: Interface to Glucose and reimplemented functions from AntomBase **********/
  
  bool Antom::AddWeightedSoftClause(std::vector<uint32_t>& clause, uint64_t weight)
  {
    SoftClause* sclaus = new SoftClause (0, clause, weight);
    _softClauses.push_back( sclaus );

    return true;
  }

  // If sorter == nullptr, we want to count for all soft clauses
  uint64_t Antom::CountSatisfiedSoftClauses(Sorter* sorter)
  {

    std::vector< SoftClause* > softclauses;
    if( sorter == nullptr )
      {
        softclauses = _softClauses;
      }
    else
      {
        softclauses = sorter->GetSoftClauses();
      }

    uint64_t result = CountSatisfiedSoftClauses(softclauses);

    if( sorter != nullptr )
      {
        sorter->SetMinSatisfied(result);
      }
    return result;
  }

  uint64_t Antom::CountSatisfiedSoftClauses(std::vector< SoftClause* > softclauses)
  {
    if (_antomSetting->verbosity > 4)
    {
        std::cout << __PRETTY_FUNCTION__ << std::endl;
        std::cout << "SC.size: " << softclauses.size() << std::endl;
        std::cout << "Clauses.size: " << Clauses() << std::endl;
    }
    uint64_t result(0);
    // Proceed all soft clauses
    for( uint32_t i = 0; i != softclauses.size(); ++i )
      {
	uint32_t relaxlit = softclauses[i]->relaxationLit;


    if( Model(relaxlit>>1) == relaxlit )
	  {
	    std::vector< uint32_t> clause( softclauses[i]->clause );
	    uint32_t pos = 0;
	    for(; pos != clause.size(); ++pos )
	      {
		// clause satisfied without trigger?
        if( Model(clause[pos]>>1) == clause[pos] )
		  {
		    result += softclauses[i]->weight;
		    softclauses[i]->lastassignment = relaxlit^1;
//            std::cout << "++" << result;
		    break;
		  }
	      }
	    if ( pos == clause.size() )
	      {
		softclauses[i]->lastassignment = relaxlit;
	      }
	  }
    else if ( Model(relaxlit>>1) != 0 )
	  {
        assert( Model(relaxlit>>1) == (relaxlit^1));
	    softclauses[i]->lastassignment = relaxlit^1;
	    result += softclauses[i]->weight;
//        std::cout << " ++relax sat " << result;
	  }
    }
    return result;

  }

  // Weigthed maxsat
  // ____________________________________________________________________________________________________________________
  uint32_t Antom::MaxSolveWeightedPartial(int64_t& optimum)
  {
    std::vector<uint32_t> externalAssumptions;
    uint32_t result = MaxSolveWeightedPartial(externalAssumptions, optimum);
    _timeVariables->DumpVariables();
    return result;

  }

  // ____________________________________________________________________________________________________________________
  uint32_t Antom::MaxSolveWeightedPartial(const std::vector<uint32_t>& externalAssumptions, int64_t& optimum)
  {
//      _antomSetting->verbosity = 10;
//    std::cout << __PRETTY_FUNCTION__ << std::endl;

    // to change optimum value with another function called from cascade and bucket
    _optimum = &optimum;
    _antomSetting->application = WEIGHTEDMAXSAT;

    _timeVariables = new TimeVariables();
    TimeMeasurement totalTime(&_timeVariables->total, true);
    _totalTime = &totalTime;
//    struct rusage resources;
//    getrusage(RUSAGE_SELF, &resources);
//    double timeS = static_cast<double>(resources.ru_utime.tv_sec + 1.e-6 ) * static_cast<double>( resources.ru_utime.tv_usec );
//    double timeC = timeS;
//    _control->SetStartTime(timeS);
//    _control->SetSumTime(true);
    uint32_t currentresult(ANTOM_UNKNOWN);

    //uint32_t averageBucketEntries(0);


#ifndef NDEBUG
    uint64_t softWeights = 0;
    std::for_each(_softClauses.begin(), _softClauses.end(), [&](SoftClause* SC) { softWeights += SC->weight; });
//	std::cout << "soft weights: " << softWeights << " sumofweights: " << _sumOfSoftWeights << std::endl;
    assert(softWeights == _sumOfSoftWeights);
#endif

    _clausesBefore = StaticClauses();
    _variablesBefore = Variables();

    _antomSetting->Print();

//    std::cout << "c clauses before.........: " << _clausesBefore << std::endl;
    std::cout << "c #softclauses...........: " << _softClauses.size() << std::endl;
    std::cout << "c #sum of SoftWeights....: " << _sumOfSoftWeights << std::endl;
    if (!_antomSetting->solveAtFirst)


    if (_antomSetting->onlyByTares || _antomSetting->mcDivideStrategy != SOLVEINNORMALCASCADEMODE)
      {
        _antomSetting->encodeStrategy = ENCODEONLYIFNEEDED;
      }

    if (_antomSetting->solveAtFirst)
      {
        TimeMeasurement timeSolvedFirst(&_timeVariables->solvedFirst, true);
        currentresult = Solve();
      if (currentresult == ANTOM_UNSAT)
	  {
            return ANTOM_UNSAT;
	  }
        else if (currentresult == ANTOM_UNKNOWN)
	  {
            return ANTOM_UNKNOWN;
	  }


        CalculateOverallOptimum(_satWeight, true);

        if (_softClauses.size() == 1 && _satWeight == 0 && _sumOfSoftWeights == _softClauses[0]->weight) {
            // try to solve the only remaining softclause!
            std::vector<uint32_t> assumptions;
            assumptions.push_back(_softClauses[0]->relaxationLit ^ 1);
            currentresult = Solve(assumptions);
            if (currentresult == ANTOM_UNSAT) {
                std::cout << "c The only SC is NOT satisfiable!" << std::endl;
                Solve();
                return ANTOM_SAT;
            } else if (currentresult == ANTOM_SAT) {
                std::cout << "c The only SC is SATISFIABLE!" << std::endl;
                CalculateOverallOptimum(_satWeight, true);
            }
        }
//        std::cout << "c #sum of SoftWeights....: " << _sumOfSoftWeights << std::endl;
        std::cout << "c SATWeight solved first.: " << _satWeight << std::endl;
        std::cout << "c first o value..........: " << *_optimum * _greatestCommonDivisor << std::endl;
      }
    if (_satWeight == _sumOfSoftWeights)
      return ANTOM_SAT;

    // calc and set all trivially conflicting softclauses
    // TOASK: maybe better seperately for each bucket - to know boundaries of bucket!
    // together with mode of solving bucket parts to get max
    //CheckAllWeightedConflictingSoftclauses();

        _antomSetting->cascadeDivider = 0;

    // no else if, because if _cascadeDivider returns only one cascade then _cascadeDivider == 0
    if (_antomSetting->cascadeDivider == 0)
      {
        _clausesBefore = StaticClauses();

        _mainCascade = new Cascade(this, nullptr, _antomSetting->onlyByTares);

        _mainCascade->Fill(&_softClauses, _antomSetting->partitionStrategy, _antomSetting->encodeStrategy);

	//if (_antomSetting->verbosity > 2 && _antomSetting->base > 2)
	//{
        //std::cout << "How often is Softclause in Bucket, because of base " << _baseMode << std::endl;
        //DumpBucketStructure();
	//}

	if (_antomSetting->cascadeDivider == 0)
	  {
	    if (_antomSetting->encodeStrategy == ENCODEALL)
	      {
        _clausesBefore = StaticClauses();
	      }
	    if (! _mainCascade->Encode())
	      {
		return ANTOM_UNKNOWN;
	      }
//	    if (_antomSetting->encodeStrategy == ENCODEALL)
//	      {
////            std::cout << "c #clauses of coding.....: " << StaticClauses() - _clausesBefore > 0 ? StaticClauses() - _clausesBefore : 0 << std::endl;
////            std::cout << "c #variables of coding...: " << Variables() - _variablesBefore << std::endl;
//	      }
	  }

	// TOBI: SetDecisionStrategiesForCascadeModel!!!!
	//SetDecisionStrategiesForMaxSAT();
        currentresult = _mainCascade->Solve();
      }


//    if (_antomSetting->encodeStrategy != ENCODEALL && _antomSetting->onlyByTares)
//    {
//        std::cout << "c #clauses of coding.....: " << _addedClauses << std::endl;
//        std::cout << "c #variables of coding...: " << Variables() - _variablesBefore << std::endl;
//    }

    if ( currentresult == ANTOM_UNKNOWN )
      {
	return ANTOM_UNKNOWN;
      }

    // if there is more than one cascade, we have to calculate
    // the OverallOptimum again to sum up the weights.
    //CalculateOverallOptimum(_satWeight, true);
    optimum = optimum * _greatestCommonDivisor;
//    std::cout << "s OPTIMUM FOUND" << std::endl;
//    std::cout << "o " << optimum << std::endl;
    return currentresult;
  }

  StructureInfo Antom::AnalyzeandConvertStructure()
  {
	std::cout << __FUNCTION__ << std::endl;
    StructureInfo structure = AnalyzeStructure();
    switch ( structure )
      {
      case ISWEIGHTEDMAXSAT:
        break;
      case ISSAT:
        return ISSAT;
      case ISMAXSAT:
        if (_minWeight > 1)
		  {
            DivideAllSoftClausesByFactor(_minWeight);
            std::cout << "DivideByDivisormW: " << _minWeight << std::endl;
		  }
        break;
      case CONVERTTOMAXSAT:
        ConvertFormulaToMaxSAT(_maxWeight);
        // TOASK: better - TOTELL
        // This line makes it faster with a high factor!!
        // But the value of _minWeight has to be multiplied to optimum!
        if (_minWeight > 1)
		  {
            DivideAllSoftClausesByFactor(_minWeight);
            std::cout << "DivideByDivisormW: " << _minWeight << std::endl;
		  }
		
        structure = ISMAXSAT;
        break;
      case antom::DIVIDEWEIGHTSBYDIVISOR:
        DivideAllSoftClausesByFactor(_greatestCommonDivisor);
        structure = ISWEIGHTEDMAXSAT;
        break;
      }
    // Add information to SoftClauses
    //AddSoftClauseVector();
    return structure;
  }

  StructureInfo Antom::AnalyzeStructure()
  {
    //assert(_sumOfSoftWeights > _topWeight);
    bool maxIsMin = (_maxWeight == _minWeight);
    bool withHC = Clauses() != 0;
    bool minIsSet = _minWeight != ((uint64_t) - 1);
    bool maxIsSet = _maxWeight != 0;
    // is SAT formula
    bool onlyHC = !minIsSet && !maxIsSet && withHC;
    // is MaxSAT formula -- NOT PARTIAL
    bool onlySCwithOneWeight = !_moreThanTwoWeights && maxIsMin && !withHC;
    // is partial MaxSAT formula - Set _minWeight to one
    bool oneHCWeightAndSCWeight = maxIsMin && withHC;
    // if sum (_minWeight) < _maxWeight --> is partial MaxSAT formula
    bool onlySCwithTwoWeights = !_moreThanTwoWeights && !maxIsMin && minIsSet && maxIsSet && !withHC;
    // Calculate the greatest common divisor of all softclauseweights.
    uint64_t greatestCommonDivisor = _minWeight;

    for (uint32_t ind = 0; ind < _softClauses.size(); ++ind)
      {
        if (greatestCommonDivisor == 1)
	  break;
        greatestCommonDivisor = GreatestCommonDivisor(greatestCommonDivisor, _softClauses[ind]->weight);
      }
    _greatestCommonDivisor = greatestCommonDivisor;


    if (_antomSetting->verbosity > 2)
      {
        std::cout << std::setw(30) << "_topWeight " << _topWeight << std::endl;
        std::cout << std::setw(30) << "_minWeight " << _minWeight << std::endl;
        std::cout << std::setw(30) << "_maxWeight " << _maxWeight << std::endl;
        std::cout << std::setw(30) << "_moreThanTwoWeights " << _moreThanTwoWeights << std::endl;
        std::cout << std::setw(30) << "maxIsMin " << maxIsMin << std::endl;
        std::cout << std::setw(30) << "withHC " << withHC << std::endl;
        std::cout << std::setw(30) << "minIsSet " << minIsSet << std::endl;
        std::cout << std::setw(30) << "maxIsSet " << maxIsSet << std::endl;
        std::cout << std::setw(30) << "onlyHC " << onlyHC << std::endl;
        std::cout << std::setw(30) << "onlySCwithOneWeight " << onlySCwithOneWeight << std::endl;
        std::cout << std::setw(30) << "oneHCWeightAndSCWeight " << oneHCWeightAndSCWeight << std::endl;
        std::cout << std::setw(30) << "onlySCwithTwoWeights " << onlySCwithTwoWeights << std::endl;
        std::cout << std::setw(30) << "_sumOfSoftWeights " << _sumOfSoftWeights << std::endl;
      }

    if(onlyHC)
      {
        return ISSAT;
      }
    if (onlySCwithTwoWeights)
      {
        uint32_t sumOfMinWeights(0);

        // the sum of all _minWeights has to be smaller than _maxWeight
        // then it can be solved like MaxSAT formula.
        for (uint32_t ind = 0; ind < _softClauses.size(); ++ind)
	  {
            if (_softClauses[ind]->weight != _minWeight)
	      continue;

            sumOfMinWeights += _softClauses[ind]->weight;
	  }

        if (sumOfMinWeights < _maxWeight)
	  {
            _sumOfSoftWeights = sumOfMinWeights;
            return CONVERTTOMAXSAT;
	  }
      }
    if (oneHCWeightAndSCWeight || onlySCwithOneWeight || oneHCWeightAndSCWeight)
      {
        return ISMAXSAT;
      }
//    if (greatestCommonDivisor > 1)
//      {
//        _greatestCommonDivisor = greatestCommonDivisor;
//        std::cout << "c greatest common divisor: " << greatestCommonDivisor << std::endl;
//        return antom::DIVIDEWEIGHTSBYDIVISOR;
//      }
    return ISWEIGHTEDMAXSAT;
  }

  uint64_t Antom::GreatestCommonDivisor(uint64_t a, uint64_t b)
  {
    uint64_t temp;
    while(b > 0) {
      temp = b;
      b = a % b;
      a = temp;
    }
    return a;
  }

  void Antom::ConvertFormulaToMaxSAT(uint64_t maxWeight)
  {
    // configure all _maxWeights as hardclauses
    std::vector< SoftClause* > newSoftClauseVector;
    for (uint32_t ind = 0; ind < _softClauses.size(); ++ind)
      {
        if (_softClauses[ind]->weight != maxWeight)
	  {
            newSoftClauseVector.push_back(_softClauses[ind]);
            continue;
	  }

        AddClause(_softClauses[ind]->clause);
      }

    _softClauses = newSoftClauseVector;
  }

  void Antom::DivideAllSoftClausesByFactor(uint64_t factor)
  {
    for (uint32_t ind = 0; ind < _softClauses.size(); ++ind)
      {
        _softClauses[ind]->weight /= factor;
      }
    _sumOfSoftWeights /= factor;
  }

  uint64_t Antom::CalculateOverallOptimum(uint64_t satWeight, bool countAgain)
  {
    if (_antomSetting->verbosity > 3)
        std::cout << __PRETTY_FUNCTION__ << std::endl;

    // struct rusage resources;
    // Cascade and Bucket counts the satisfied SC only for their SC's
    // for an overall result count again.
    if (countAgain)
      {
        // maybe _maxSatWeight - because it could be a local optima of this Solver call
        satWeight = CountSatisfiedSoftClauses(nullptr);
      }

    if (*_optimum > static_cast<int64_t>(_sumOfSoftWeights - satWeight) || *_optimum == -1)
      {
	/*
	  if (_antomSetting->verbosity > 0)
	  {
	  getrusage(RUSAGE_SELF, &resources);
	  double timeC = (double) resources.ru_utime.tv_sec + 1.e-6 * (double) resources.ru_utime.tv_usec;
	  std::cout << "c " << (timeC - _control->GetStartTime()) << "s" << std::endl;
	  }
	*/
        // better actualize satWeight once at the end.
        _satWeight = satWeight;
        *_optimum = static_cast<int64_t>(_sumOfSoftWeights - satWeight);

        _totalTime->PrintActualTimeDiff();
        std::cout << "o " << *_optimum * _greatestCommonDivisor << std::endl;
//        _lastModel = Model();

        if (_antomSetting->verbosity > 2)
	  std::cout << std::setw(50) << "Calculated Global SATWeight: " << satWeight << std::endl;

      } else if (_antomSetting->verbosity > 2)
      {
	/*
	  if (_antomSetting->verbosity > 3)
	  {
	  getrusage(RUSAGE_SELF, &resources);
	  double timeC = (double) resources.ru_utime.tv_sec + 1.e-6 * (double) resources.ru_utime.tv_usec;
	  //std::cout << "c " << (timeC - _control->GetStartTime()) << "s" << std::endl;
	  }
	*/
        std::cout << "o " << *_optimum * _greatestCommonDivisor << std::endl;
        std::cout << std::setw(50) << "Calculated Global SATWeight: " << satWeight << std::endl;
      }

    return _satWeight;
  }

  void Antom::SetMoreThanTwoWeights(bool val)
  {
    _moreThanTwoWeights = val;
  }

  bool Antom::GetHasMoreThanTwoWeights()
  {
      return _moreThanTwoWeights;
  }

  void Antom::SetTopWeight(uint64_t val)
  {
    assert( val > 0 );
    _topWeight = val;
  }

  void Antom::SetMinWeight(uint64_t val)
  {
    //assert( val < (uint64_t) - 1 );
    _minWeight = val;
  }

  uint64_t Antom::GetMinWeight()
  {
      return _minWeight;
  }

  void Antom::SetMaxWeight(uint64_t val)
  {
    //assert( val > 0 );
    _maxWeight = val;
  }

  uint64_t Antom::GetMaxWeight()
  {
      return _maxWeight;
  }

  void Antom::SetHasHardClauses(bool val)
  {
      _hasHardClauses = val;
  }

  bool Antom::GetHasHardClauses()
  {
      return _hasHardClauses;
  }

  void Antom::SetGreatestCommonDivisor(uint64_t val)
  {
      _greatestCommonDivisor = val;
  }

}
