#include "basis_pms.h"
#include "pms.h"

int main(int argc, char* argv[])
{
	start_timing();
	printf("c this is satlike-c solver\n");
	Satlike s;
	vector<int> init_solution;
	s.build_instance(argv[1]);
	s.local_search_with_decimation(init_solution,argv[1]);
	//s.simple_print();
	s.free_memory();
	
    return 0;
}
