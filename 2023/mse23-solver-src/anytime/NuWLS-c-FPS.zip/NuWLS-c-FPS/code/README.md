### README for the NuWLS-c-FPS MaxSAT Solver

### MaxSAT Evaluation 2023
./nuwls-c-fps_static <input-file>
