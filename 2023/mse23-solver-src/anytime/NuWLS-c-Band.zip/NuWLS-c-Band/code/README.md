### README for the NuWLS-c-Band MaxSAT Solver

### MaxSAT Evaluation 2023
./nuwls-c-band_static <input-file>
