/**
 * @file noSAT-MaxSAT.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "noSAT-MaxSAT.h"

#include <assert.h>
#include <stddef.h>
#include <stdint.h>

#include "2SAT.h"
#include "align.h"
#include "common.h"
#include "formulas/wcnf.h"
#include "logging.h"
#include "preprocessing.h"
#include "rng.h"
#include "util.h"

// #define TEST_2SAT
#ifdef TEST_2SAT
#  include <stdio.h>
#  include <stdlib.h>
#endif

typedef long long score_t;

typedef struct {
  nsms_uint_t* weights;                  ///< (updated) weight for each clause
  nsms_uint_t* numSatLiterals;           ///< the number of sat literals for each clause
  score_t* scores;                       ///< the score of each variable
  const nsms_wcnf_variable_t** satVars;  ///< for each clause, the (only/first) variable which satisfies it

  nsms_uint_t numDecreasingVars;          ///< the number of decreasing variables
  nsms_wcnf_variable_t** decreasingVars;  ///< decreasing variables (with score > 0)
  nsms_uint_t* decreasingVarsIdx;         ///< for each variable, its index in decrasingVars or NSMS_UINT_MAX

  nsms_uint_t numFalsifiedHardClauses;              ///< the number of falsified hard clauses
  const nsms_wcnf_clause_t** falsifiedHardClauses;  ///< falsified hard clauses
  nsms_uint_t* falsifiedHardClausesIdx;  ///< for each clause, its index in falsifiedHardClauses or NSMS_UINT_MAX

  nsms_uint_t numFalsifiedSoftClauses;              ///< the number of falsified soft clauses
  const nsms_wcnf_clause_t** falsifiedSoftClauses;  ///< falsified soft clauses
  nsms_uint_t* falsifiedSoftClausesIdx;  ///< for each clause, its index in falsifiedSoftClauses or NSMS_UINT_MAX

  nsms_uint_t* softClauseWeightBounds;

  void* decimationMem;
  void* twoSatMem;
} memory_t;

/**
 * @brief Calculates detailed memory requirements
 *
 * @param formula
 * @param varsToNumClauses Array of size formula->numVariables * sizeof(nsms_uint_t) to store for each variable, how
 * many clauses it occus in
 * @param out
 */
static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_uint_t* varsToNumClauses, nsms_memoryReq_t* out);

/**
 * @brief Calculates where pointers in out should point to
 *
 * @param mem
 * @param memReq
 * @param cfg
 * @param out
 */
static void initMemory(void* mem, const nsms_memoryReq_t* memReq, memory_t* out);

/**
 * @brief Copies weights from formula to weights
 *
 * @param formula
 * @param cfg
 * @param mem
 */
static void initWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, const memory_t* mem);

/**
 * @brief Initializes variables to current best known assignment, or randomly if no such assignment is known yet
 *
 * @param formula
 * @param result
 */
static void initVars(const nsms_wcnf_t* formula, const nsms_result_t* result);

/**
 * @brief Checks the satisfiability of the formula and updates related fields in mem and cost
 *
 * @param formula
 * @param mem
 */
static void initAlgo(const nsms_wcnf_t* formula, memory_t* mem, nsms_uint_t* cost);

/**
 * @brief Updates the algorithm's output
 *
 * @param result
 * @param variables
 * @param numVariables
 * @param infeasible
 * @param cost
 */
static void updateResult(nsms_result_t* result, const nsms_wcnf_variable_t* variables, nsms_uint_t numVariables,
                         bool infeasible, nsms_uint_t cost);

/**
 * @brief Selects a variable to flip; also updates weights if no decreasing variable is found
 *
 * @param formula
 * @param cfg
 * @param bestCost
 * @param curCost
 * @param infeasible
 * @param mem
 * @return nsms_wcnf_variable_t*
 */
static nsms_wcnf_variable_t* selectVariable(const nsms_wcnf_t* formula, const nsms_params_t* cfg, nsms_uint_t bestCost,
                                            nsms_uint_t curCost, bool infeasible, memory_t* mem);

/**
 * @brief Weighting-PMS
 *
 * @param formula
 * @param cfg
 * @param bestCost
 * @param curCost
 * @param mem
 */
static void updateWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, nsms_uint_t bestCost,
                          nsms_uint_t curCost, bool infeasible, memory_t* mem);

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 */
static void smoothHardWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem);

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 */
static void smoothSoftWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem);

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 */
static void increaseHardWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem);

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 */
static void increaseSoftWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem);

/**
 * @brief Flips the value of the given variable and updates satis/falsified status and cost accordingly
 *
 * @param variable
 * @param formula
 * @param mem
 * @param cost
 */
static void flipVariable(nsms_wcnf_variable_t* variable, const nsms_wcnf_t* formula, memory_t* mem, nsms_uint_t* cost);

/**
 * @brief
 *
 * @param numSatLiterals
 * @param formula
 * @param variable
 * @param clause
 * @param clauseIdx
 * @param clauseWeight
 * @param cost
 * @param mem
 */
static void onLiteralSatisfied(nsms_uint_t numSatLiterals, const nsms_wcnf_t* formula,
                               const nsms_wcnf_variable_t* variable, const nsms_wcnf_clause_t* clause,
                               nsms_uint_t clauseIdx, nsms_uint_t clauseWeight, nsms_uint_t* cost, memory_t* mem);

/**
 * @brief
 *
 * @param numSatLiterals
 * @param formula
 * @param variable
 * @param clause
 * @param clauseIdx
 * @param clauseWeight
 * @param cost
 * @param mem
 */
static void onLiteralFalsified(nsms_uint_t numSatLiterals, const nsms_wcnf_t* formula, const nsms_wcnf_clause_t* clause,
                               nsms_uint_t clauseIdx, nsms_uint_t clauseWeight, nsms_uint_t* cost, memory_t* mem);

/**
 * @brief Check whether there are any unsatisfied clauses left
 *
 * @param mem
 * @return true When there are no unsatisfied clauses
 * @return false Otherwise
 */
static bool done(const memory_t* mem);

/**
 * @brief Adds a variable to the decreasing variables if it is not present in the list
 *
 * @param varIdx
 * @param formula
 * @param mem
 */
static void addDecreasingVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem);

/**
 * @brief Removes a variable from the decreasing variables if it is present in the list
 *
 * @param varIdx
 * @param formula
 * @param mem
 */
static void remDecreasingVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem);

/**
 * @brief Adds a clause to the specified list of clauses
 *
 * @param clauseIdx
 * @param formula
 * @param numFalsifiedClauses
 * @param falsifiedClauses
 * @param falsifiedClausesIdx
 */
static void addFalsifiedClause(nsms_uint_t clauseIdx, const nsms_wcnf_t* formula, nsms_uint_t* numFalsifiedClauses,
                               const nsms_wcnf_clause_t** falsifiedClauses, nsms_uint_t* falsifiedClausesIdx);

/**
 * @brief Removes a list from the specified list of clauses
 *
 * @param clauseIdx
 * @param formula
 * @param numFalsifiedClauses
 * @param falsifiedClauses
 * @param falsifiedClausesIdx
 */
static void remFalsifiedClause(nsms_uint_t clauseIdx, const nsms_wcnf_t* formula, nsms_uint_t* numFalsifiedClauses,
                               const nsms_wcnf_clause_t** falsifiedClauses, nsms_uint_t* falsifiedClausesIdx);

/**
 * @brief
 *
 * @param formula
 * @param cfg
 * @param mem
 * @param memReq
 * @param result
 */
void solveHard(nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem, const nsms_memoryReq_t* memReq,
               const nsms_result_t* result);

typedef bool (*clausePredicate_t)(const nsms_wcnf_clause_t*);

/**
 * @brief In-place moves the clauses fulfilling the predicate to the front of the clauses array
 *
 * @param formula
 * @param clausePredicate
 * @return The number of clauses fulfilling the predicate
 */
nsms_uint_t moveClausesFirst(const nsms_wcnf_t* formula, clausePredicate_t clausePredicate);

/**
 * @brief Check whether a clause is a hard 2-clause
 *
 * @param clause
 * @return Whether the clause is a hard 2-clause
 */
bool isHard2Clause(const nsms_wcnf_clause_t* clause);

void nsms_init(void) {
  rngInit();
}

nsms_uint_t nsms_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_uint_t* varsToNumClauses,
                                        nsms_memoryReq_t* memReq) {
  calcMemoryReq(formula, varsToNumClauses, memReq);
  return memReq->weightsMemReq + memReq->numSatLiteralsMemReq + memReq->scoresMemReq + memReq->satVarsMemReq +
         memReq->decreasingVarMemReq + memReq->decreasingVarsIdxMemReq + memReq->falsifiedHardClausesMemReq +
         memReq->falsifiedHardClausesIdxMemReq + memReq->falsifiedSoftClausesMemReq +
         memReq->falsifiedSoftClausesIdxMemReq + memReq->softClauseWeightBoundsMemReq + memReq->decimationMemReq +
         memReq->twoSatMemReq;
}

void nsms_solve(nsms_wcnf_t* formula, const nsms_params_t* cfg, void* memory, const nsms_memoryReq_t* memReq,
                nsms_result_t* result) {
  INIT_DURATION_MEAS();

  result->status = NSMS_INFEASIBLE;
  result->cost = NSMS_UINT_MAX;

  memory_t mem;
  initMemory(memory, memReq, &mem);

  /* START_DURATION_MEAS();
  static const nsms_uint_t numClauseRemovalPredicates = 1;
  static const nsms_clause_predicate_t clauseRemovalPredicates[] = {nsms_isWCNFClauseEmpty};
  const nsms_uint_t numRemovedClauses =
      nsms_filterClauses(formula->clauses, formula->numClauses, clauseRemovalPredicates, numClauseRemovalPredicates);
  formula->numClauses -= numRemovedClauses;
  LOG("c removed " NSMS_UINT_FORMAT " irrelevant clauses" DURATION_STR, numRemovedClauses, DURATION_VAL); */

  {
    const nsms_uint_t origNumClauses = formula->numClauses;
    const nsms_uint_t numHardClauses = moveClausesFirst(formula, nsms_isWCNFClauseHard);
    assert(numHardClauses == formula->numHardClauses);
    formula->numClauses = numHardClauses;
    const nsms_uint_t numHard2Clauses = moveClausesFirst(formula, isHard2Clause);
    assert(numHard2Clauses == memReq->detailed2SatMemReq.numHard2Clauses);
    ((void)numHard2Clauses);  // suppress -Wunused-variable
    formula->numClauses = origNumClauses;
  }

  nsms_params_t hardClauseSolverCfg;
  hardClauseSolverCfg.maxTries = cfg->maxTries;
  hardClauseSolverCfg.maxFlips = cfg->maxFlips;
  {
    const nsms_uint_t numClauses = formula->numClauses;
    formula->numClauses = formula->numHardClauses;
    nsms_params(formula, &hardClauseSolverCfg);
    formula->numClauses = numClauses;
  }

  mem.numFalsifiedHardClauses = NSMS_UINT_MAX;  // so done check below is false on first check
  for (nsms_uint_t try = 0; try < cfg->maxTries && !done(&mem); ++try) {
    LOG("c try " NSMS_UINT_FORMAT "\n", try);

    /* START_DURATION_MEAS();
    initVars(formula, result);
    LOG_WITH_DURATION("c initialized variables"); */

    /* START_DURATION_MEAS();
    // TODO large instances (e.g., bnn) may get stuck in preprocessing
    nsms_decimation(formula, mem.decimationMem, &memReq->detailedDecimationMemReq, cfg->bmsSize, try > 0);
    LOG_WITH_DURATION("c performed decimation"); */

    if (formula->numHardClauses > 0) {
      solveHard(formula, &hardClauseSolverCfg, &mem, memReq, result);
    } else {
      initVars(formula, result);
    }

    START_DURATION_MEAS();
    initWeights(formula, cfg, &mem);
    LOG_WITH_DURATION("c initialized weights");

    START_DURATION_MEAS();
    nsms_uint_t cost;
    initAlgo(formula, &mem, &cost);
    LOG_WITH_DURATION("c initialized algorithm");

    for (nsms_uint_t flip = 0; flip < cfg->maxFlips && !done(&mem); ++flip) {
      const bool infeasible = mem.numFalsifiedHardClauses > 0;
      updateResult(result, formula->variables, formula->numVariables, infeasible, cost);

      LOG("c current cost is " NSMS_UINT_FORMAT " (%s)\n", cost, infeasible ? "infeasible" : "feasible");

      nsms_wcnf_variable_t* variableToFlip = selectVariable(formula, cfg, result->cost, cost, infeasible, &mem);
      flipVariable(variableToFlip, formula, &mem, &cost);
    }

    updateResult(result, formula->variables, formula->numVariables, mem.numFalsifiedHardClauses > 0, cost);
  }
}

void nsms_params(const nsms_wcnf_t* formula, nsms_params_t* params) {
  /* Values from
   * Yi Chu, Shaowei Cai, Zhendong Lei, and Xiang He, NuWLS-c in MaxSAT Evaluation 2022 (source code)
   */

  bool isWeighted = false;
  nsms_uint_t softClauseWeight = 0;
  nsms_uint_t numLitsInSoftClauses = 0;
  const nsms_uint_t numSoftClauses = formula->numClauses - formula->numHardClauses;

  if (numSoftClauses > 0) {
    for (nsms_uint_t i = 0; i < formula->numClauses; ++i) {
      const nsms_wcnf_clause_t* const clause = formula->clauses + i;
      if (!nsms_isWCNFClauseHard(clause)) {
        softClauseWeight += clause->weight;
        numLitsInSoftClauses += clause->numLiterals;
        if (clause->weight != 1) {
          isWeighted = true;
        }
      }
    }
  }

  if (!isWeighted) {
    params->sWeightInc = 1;  // NOLINT(readability-magic-numbers)
    params->hWeightInc = 1;  // NOLINT(readability-magic-numbers)

    if (formula->numHardClauses == 0) {
      params->bmsSize = 94;              // NOLINT(readability-magic-numbers)
      params->sSmoothProb = 2000;        // NOLINT(readability-magic-numbers)
      params->sWeightBoundCoef = 397;    // NOLINT(readability-magic-numbers)
      params->sWeightBoundOffset = 550;  // NOLINT(readability-magic-numbers)
      params->hSmoothProb = 0;           // NOLINT(readability-magic-numbers)
    } else {
      params->bmsSize = 50;              // NOLINT(readability-magic-numbers)
      params->sSmoothProb = 10;          // NOLINT(readability-magic-numbers)
      params->sWeightBoundCoef = 10;     // NOLINT(readability-magic-numbers)
      params->sWeightBoundOffset = 500;  // NOLINT(readability-magic-numbers)
      params->hSmoothProb = 100;         // NOLINT(readability-magic-numbers)
    }
  } else {
    if (formula->numHardClauses == 0) {
      params->bmsSize = 22;            // NOLINT(readability-magic-numbers)
      params->sSmoothProb = 1000;      // NOLINT(readability-magic-numbers)
      params->sWeightBoundCoef = 1;    // NOLINT(readability-magic-numbers)
      params->sWeightBoundOffset = 0;  // NOLINT(readability-magic-numbers)
      params->sWeightInc = 1;          // NOLINT(readability-magic-numbers)
      params->hSmoothProb = 0;         // NOLINT(readability-magic-numbers)
      params->hWeightInc = 0;          // NOLINT(readability-magic-numbers)
    } else {
      params->bmsSize = 50;                                                   // NOLINT(readability-magic-numbers)
      params->sSmoothProb = 2;                                                // NOLINT(readability-magic-numbers)
      params->sWeightBoundCoef = 1000 / (softClauseWeight / numSoftClauses);  // NOLINT(readability-magic-numbers)
      if (params->sWeightBoundCoef == 0) {                                    // NOLINT(readability-magic-numbers)
        params->sWeightBoundCoef = 1;                                         // NOLINT(readability-magic-numbers)
      }
      params->sWeightBoundOffset = 50;                    // NOLINT(readability-magic-numbers)
      params->hSmoothProb = 20;                           // NOLINT(readability-magic-numbers)
      if (numLitsInSoftClauses / numSoftClauses > 100) {  // NOLINT(readability-magic-numbers)
        params->hWeightInc = 300;                         // NOLINT(readability-magic-numbers)
        params->sWeightInc = 100;                         // NOLINT(readability-magic-numbers)
      } else {
        params->hWeightInc = 10;  // NOLINT(readability-magic-numbers)
        params->sWeightInc = 3;   // NOLINT(readability-magic-numbers)
      }
    }
  }
}

static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_uint_t* varsToNumClauses, nsms_memoryReq_t* out) {
  out->weightsMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->numSatLiteralsMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->scoresMemReq = align(formula->numVariables * sizeof(score_t));
  out->satVarsMemReq = align(formula->numClauses * sizeof(nsms_wcnf_variable_t*));

  out->decreasingVarMemReq = align(formula->numVariables * sizeof(nsms_wcnf_variable_t*));
  out->decreasingVarsIdxMemReq = align(formula->numVariables * sizeof(nsms_uint_t));

  out->falsifiedHardClausesMemReq = align(formula->numClauses * sizeof(nsms_wcnf_clause_t*));
  out->falsifiedHardClausesIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->falsifiedSoftClausesMemReq = align(formula->numClauses * sizeof(nsms_wcnf_clause_t*));
  out->falsifiedSoftClausesIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->softClauseWeightBoundsMemReq = align(formula->numClauses * sizeof(nsms_uint_t));

  out->decimationMemReq = align(nsms_decimation_calcMemoryRequirements(formula, &out->detailedDecimationMemReq));

  out->twoSatMemReq = align(nsms_2sat_calcMemoryRequirements(formula, varsToNumClauses, &out->detailed2SatMemReq));
}

static void initMemory(void* mem, const nsms_memoryReq_t* memReq, memory_t* out) {
  out->weights = mem;
  out->numSatLiterals = (nsms_uint_t*)((uint8_t*)out->weights + memReq->weightsMemReq);
  out->scores = (score_t*)((uint8_t*)out->numSatLiterals + memReq->numSatLiteralsMemReq);
  out->satVars = (const nsms_wcnf_variable_t**)((uint8_t*)out->scores + memReq->scoresMemReq);

  out->numDecreasingVars = 0;
  out->decreasingVars = (nsms_wcnf_variable_t**)((uint8_t*)out->satVars + memReq->satVarsMemReq);
  out->decreasingVarsIdx = (nsms_uint_t*)((uint8_t*)out->decreasingVars + memReq->decreasingVarMemReq);

  out->numFalsifiedHardClauses = 0;
  out->falsifiedHardClauses =
      (const nsms_wcnf_clause_t**)((uint8_t*)out->decreasingVarsIdx + memReq->decreasingVarsIdxMemReq);
  out->falsifiedHardClausesIdx =
      (nsms_uint_t*)((uint8_t*)out->falsifiedHardClauses + memReq->falsifiedHardClausesMemReq);

  out->numFalsifiedSoftClauses = 0;
  out->falsifiedSoftClauses =
      (const nsms_wcnf_clause_t**)((uint8_t*)out->falsifiedHardClausesIdx + memReq->falsifiedHardClausesIdxMemReq);
  out->falsifiedSoftClausesIdx =
      (nsms_uint_t*)((uint8_t*)out->falsifiedSoftClauses + memReq->falsifiedSoftClausesMemReq);

  out->softClauseWeightBounds =
      (nsms_uint_t*)((uint8_t*)out->falsifiedSoftClausesIdx + memReq->falsifiedSoftClausesIdxMemReq);

  out->decimationMem = (void*)((uint8_t*)out->softClauseWeightBounds + memReq->softClauseWeightBoundsMemReq);

  out->twoSatMem = (void*)((uint8_t*)out->decimationMem + memReq->decimationMemReq);
}

static void initWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, const memory_t* mem) {
  for (nsms_uint_t i = 0; i < formula->numClauses; ++i) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + i;
    mem->weights[i] = 1;
    if (!nsms_isWCNFClauseHard(clause)) {
      mem->softClauseWeightBounds[i] = cfg->sWeightBoundCoef * clause->weight + cfg->sWeightBoundOffset;
    }
  }
}

static void initVars(const nsms_wcnf_t* formula, const nsms_result_t* result) {
  if (result->status != NSMS_INFEASIBLE) {
    for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {  // best known assignment
      formula->variables[varIdx].value = result->assignment[varIdx];
    }
  } else {
    for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {  // random assignment
      formula->variables[varIdx].value = flipCoin();
    }
  }
}

static void initAlgo(const nsms_wcnf_t* formula, memory_t* mem, nsms_uint_t* cost) {
  // zero all memory that we write to (by adding) later
  *cost = 0;
  mem->numDecreasingVars = 0;
  mem->numFalsifiedHardClauses = 0;
  mem->numFalsifiedSoftClauses = 0;

  for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {
    mem->scores[varIdx] = 0;
    mem->decreasingVarsIdx[varIdx] = NSMS_UINT_MAX;
  }

  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    mem->falsifiedHardClausesIdx[clauseIdx] = NSMS_UINT_MAX;
    mem->falsifiedSoftClausesIdx[clauseIdx] = NSMS_UINT_MAX;

    // count satisfied literals per clause
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    const nsms_uint_t clauseWeight = mem->weights[clauseIdx];

    nsms_uint_t* numSatLiterals = mem->numSatLiterals + clauseIdx;
    *numSatLiterals = 0;

    for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
      const nsms_wcnf_literal_t* const literal = clause->literals + litIdx;

      if (nsms_isWCNFLiteralSatisfied(literal, formula)) {
        *numSatLiterals += 1;

        if (*numSatLiterals == 1) {
          mem->satVars[clauseIdx] = formula->variables + literal->variableIdx;
        }
      }
    }

    if (*numSatLiterals == 1) {
      // penalize score of only satVar b/c if it is flipped, total cost increases
      *(mem->scores + (mem->satVars[clauseIdx] - formula->variables)) -= (score_t)clauseWeight;
    } else if (*numSatLiterals == 0) {
      // increase scores of all variables of the unsat clause
      for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
        *(mem->scores + clause->literals[litIdx].variableIdx) += (score_t)clauseWeight;
      }

      // add unsat clause to respective list
      if (nsms_isWCNFClauseHard(clause)) {
        addFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedHardClauses, mem->falsifiedHardClauses,
                           mem->falsifiedHardClausesIdx);
      } else {
        addFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedSoftClauses, mem->falsifiedSoftClauses,
                           mem->falsifiedSoftClausesIdx);
        // add weight of unsat clause to total cost
        *cost += clause->weight;
      }
    }
  }

  // now that initial scores for all variables are calculated, filter those that are decreasing
  for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {
    addDecreasingVar(varIdx, formula, mem);
  }
}

static void updateResult(nsms_result_t* result, const nsms_wcnf_variable_t* variables, nsms_uint_t numVariables,
                         bool infeasible, nsms_uint_t cost

) {
  if (!infeasible && cost < result->cost) {
    for (nsms_uint_t i = 0; i < numVariables; ++i) {
      result->assignment[i] = variables[i].value;  // save currently best assignment
    }

    result->cost = cost;
    result->status = cost == 0 ? NSMS_OPTIMUM_FOUND : NSMS_UNKNOWN;

    LOG("c found better solution with cost " NSMS_UINT_FORMAT "\n", result->cost);
  }
}

static nsms_wcnf_variable_t* selectVariable(const nsms_wcnf_t* formula, const nsms_params_t* cfg, nsms_uint_t bestCost,
                                            nsms_uint_t curCost, bool infeasible, memory_t* mem) {
  if (mem->numDecreasingVars > 0) {
    // if there are decreasing vars, draw some of them randomly (w/ replacement)and select the one with highest score
    nsms_wcnf_variable_t* bestVar = mem->decreasingVars[randIdx(mem->numDecreasingVars)];

    for (nsms_uint_t i = 1; i < cfg->bmsSize; ++i) {
      nsms_wcnf_variable_t* curVar = mem->decreasingVars[randIdx(mem->numDecreasingVars)];
      if (mem->scores[curVar - formula->variables] > mem->scores[bestVar - formula->variables]) {
        bestVar = curVar;
      }
    }

    return bestVar;
  }

  // if there are no decreasing vars, update weights
  updateWeights(formula, cfg, bestCost, curCost, infeasible, mem);

  // select a clause randomly (prefer unsatisfied hard clauses)
  nsms_uint_t numClausesToChooseFrom;
  const nsms_wcnf_clause_t** clausesToChooseFrom;
  if (mem->numFalsifiedHardClauses > 0) {
    numClausesToChooseFrom = mem->numFalsifiedHardClauses;
    clausesToChooseFrom = mem->falsifiedHardClauses;
  } else {
    numClausesToChooseFrom = mem->numFalsifiedSoftClauses;
    clausesToChooseFrom = mem->falsifiedSoftClauses;
  }

  const nsms_wcnf_clause_t* selectedClause = clausesToChooseFrom[randIdx(numClausesToChooseFrom)];

  // select variable with highest score from selected clause
  nsms_uint_t selectedVarIdx = selectedClause->literals[0].variableIdx;
  for (nsms_uint_t litIdx = 1; litIdx < selectedClause->numLiterals; ++litIdx) {
    const nsms_wcnf_literal_t* const literal = selectedClause->literals + litIdx;
    if (*(mem->scores + literal->variableIdx) > *(mem->scores + selectedVarIdx)) {
      selectedVarIdx = literal->variableIdx;
    }
  }

  return formula->variables + selectedVarIdx;
}

static void updateWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, nsms_uint_t bestCost,
                          nsms_uint_t curCost, bool infeasible, memory_t* mem) {
  if (flipBiasedCoin(cfg->hSmoothProb) && !infeasible) {
    smoothHardWeights(formula, cfg, mem);
  } else {
    increaseHardWeights(formula, cfg, mem);
  }

  if (curCost >= bestCost) {
    if (flipBiasedCoin(cfg->sSmoothProb)) {
      smoothSoftWeights(formula, cfg, mem);
    } else if (!infeasible) {
      increaseSoftWeights(formula, cfg, mem);
    }
  }
}

static void smoothHardWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem) {
  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    // for each satisfied hard clause with increased weight ...
    if (nsms_isWCNFClauseHard(clause) && mem->falsifiedHardClausesIdx[clauseIdx] == NSMS_UINT_MAX &&
        mem->weights[clauseIdx] > cfg->hWeightInc) {
      // ... decrease the weight
      mem->weights[clauseIdx] -= cfg->hWeightInc;

      // if the clause is only satisfied by a single literal ...
      if (mem->numSatLiterals[clauseIdx] == 1) {
        // ... increase the score of the literal's variable
        const nsms_uint_t varIdx = mem->satVars[clauseIdx] - formula->variables;
        mem->scores[varIdx] += (score_t)cfg->hWeightInc;
        addDecreasingVar(varIdx, formula, mem);
      }
    }
  }
}

static void smoothSoftWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem) {
  // TODO basically a copy of smoothHardWeights, cleanup!
  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    // for each satisfied hard clause with increased weight ...
    if (!nsms_isWCNFClauseHard(clause) && mem->falsifiedSoftClausesIdx[clauseIdx] == NSMS_UINT_MAX &&
        mem->weights[clauseIdx] > cfg->sWeightInc) {
      // ... decrease the weight
      mem->weights[clauseIdx] -= cfg->sWeightInc;

      // if the clause is only satisfied by a single literal ...
      if (mem->numSatLiterals[clauseIdx] == 1) {
        // ... increase the score of the literal's variable
        const nsms_uint_t varIdx = mem->satVars[clauseIdx] - formula->variables;
        mem->scores[varIdx] += (score_t)cfg->sWeightInc;
        addDecreasingVar(varIdx, formula, mem);
      }
    }
  }
}

static void increaseHardWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem) {
  for (nsms_uint_t i = 0; i < mem->numFalsifiedHardClauses; ++i) {
    // for each falsified hard clause
    const nsms_wcnf_clause_t* const clause = mem->falsifiedHardClauses[i];
    const nsms_uint_t clauseIdx = clause - formula->clauses;

    // increment the weight
    mem->weights[clauseIdx] += (score_t)cfg->hWeightInc;

    for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
      // for all variables of the clause
      const nsms_wcnf_literal_t* literal = clause->literals + litIdx;
      // increase the score by the increment
      mem->scores[literal->variableIdx] += (score_t)cfg->hWeightInc;
      addDecreasingVar(literal->variableIdx, formula, mem);
    }
  }
}

static void increaseSoftWeights(const nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem) {
  // TODO has redundancies with increaseHardWeights, cleanup!
  for (nsms_uint_t i = 0; i < mem->numFalsifiedSoftClauses; ++i) {
    // for each falsified soft clause
    const nsms_wcnf_clause_t* const clause = mem->falsifiedSoftClauses[i];
    const nsms_uint_t clauseIdx = clause - formula->clauses;

    // if its weights hasn't reached the bound
    if (mem->weights[clauseIdx] < mem->softClauseWeightBounds[clauseIdx]) {
      // increase the weight
      mem->weights[clauseIdx] += (score_t)cfg->sWeightInc;

      for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
        // for all variables of the clause
        const nsms_wcnf_literal_t* literal = clause->literals + litIdx;
        // increase the score by the increment
        mem->scores[literal->variableIdx] += (score_t)cfg->hWeightInc;
        addDecreasingVar(literal->variableIdx, formula, mem);
      }
    }
  }
}

static void flipVariable(nsms_wcnf_variable_t* variable, const nsms_wcnf_t* formula, memory_t* mem, nsms_uint_t* cost) {
  // first things first, flip the variable
  variable->value = !variable->value;

  for (nsms_uint_t litIdx = 0; litIdx < variable->numLiterals; ++litIdx) {
    // for each literal (clause) the flipped variable occurs in
    const nsms_wcnf_literal_t* const literal = variable->literals[litIdx];
    const nsms_wcnf_clause_t* const clause = literal->clause;
    const nsms_uint_t clauseIdx = (clause - formula->clauses);

    if (clauseIdx >= formula->numClauses) {
      continue;  // the clause is out of range, may happen when solving hard clauses only
    }

    const nsms_uint_t clauseWeight = mem->weights[clauseIdx];

    nsms_uint_t* numSatLiterals = mem->numSatLiterals + clauseIdx;

    // update the number of satisfied literals
    if (nsms_isWCNFLiteralSatisfied(literal, formula)) {
      *numSatLiterals += 1;
      onLiteralSatisfied(*numSatLiterals, formula, variable, clause, clauseIdx, clauseWeight, cost, mem);
    } else {
      *numSatLiterals -= 1;
      onLiteralFalsified(*numSatLiterals, formula, clause, clauseIdx, clauseWeight, cost, mem);
    }
  }
}

static void onLiteralSatisfied(nsms_uint_t numSatLiterals, const nsms_wcnf_t* formula,
                               const nsms_wcnf_variable_t* variable, const nsms_wcnf_clause_t* clause,
                               nsms_uint_t clauseIdx, nsms_uint_t clauseWeight, nsms_uint_t* cost, memory_t* mem) {
  if (numSatLiterals == 1) {
    // if the clause is satisfied now
    // update the scores of all involved variables
    *(mem->scores + (variable - formula->variables)) -= (score_t)clauseWeight;
    for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
      const nsms_uint_t varIdx = clause->literals[litIdx].variableIdx;
      *(mem->scores + varIdx) -= (score_t)clauseWeight;
      remDecreasingVar(varIdx, formula, mem);
    }

    // save the only satisfying variable
    mem->satVars[clauseIdx] = variable;

    // decrease total cost by the clause's weight
    *cost -= clause->weight;

    // remove the clause from the falsified clauses
    if (nsms_isWCNFClauseHard(clause)) {
      remFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedHardClauses, mem->falsifiedHardClauses,
                         mem->falsifiedHardClausesIdx);
    } else {
      remFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedSoftClauses, mem->falsifiedSoftClauses,
                         mem->falsifiedSoftClausesIdx);
    }
  } else if (numSatLiterals == 2) {
    // if the clause was satisfied already, but is now satisfied by 2 literals
    // update the score of the previously only satisfying variable
    const nsms_uint_t varIdx = mem->satVars[clauseIdx] - formula->variables;
    *(mem->scores + varIdx) += (score_t)clauseWeight;
    addDecreasingVar(varIdx, formula, mem);
  }
}

static void onLiteralFalsified(nsms_uint_t numSatLiterals, const nsms_wcnf_t* formula, const nsms_wcnf_clause_t* clause,
                               nsms_uint_t clauseIdx, nsms_uint_t clauseWeight, nsms_uint_t* cost, memory_t* mem) {
  if (numSatLiterals == 1) {
    // if the clause is only satisfied by a single variable now
    // find that variable...
    for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
      const nsms_wcnf_literal_t* const literal = clause->literals + litIdx;
      if (nsms_isWCNFLiteralSatisfied(literal, formula)) {
        // ...update its score..
        *(mem->scores + literal->variableIdx) -= (score_t)clauseWeight;
        remDecreasingVar(literal->variableIdx, formula, mem);
        // ...and save it
        mem->satVars[clauseIdx] = formula->variables + literal->variableIdx;
        break;
      }
    }
  } else if (numSatLiterals == 0) {
    // if the clause is falsified now
    // update the scores of all involved variables
    *(mem->scores + (mem->satVars[clauseIdx] - formula->variables)) += (score_t)clauseWeight;
    for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
      const nsms_uint_t varIdx = clause->literals[litIdx].variableIdx;
      *(mem->scores + varIdx) += (score_t)clauseWeight;
      addDecreasingVar(varIdx, formula, mem);
    }

    // unsave the only satisfying variable
    mem->satVars[clauseIdx] = NULL;

    // increase total costs by the clause's weight
    *cost += clause->weight;

    // add the clause to the falsified clauses
    if (nsms_isWCNFClauseHard(clause)) {
      addFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedHardClauses, mem->falsifiedHardClauses,
                         mem->falsifiedHardClausesIdx);
    } else {
      addFalsifiedClause(clauseIdx, formula, &mem->numFalsifiedSoftClauses, mem->falsifiedSoftClauses,
                         mem->falsifiedSoftClausesIdx);
    }
  }
}

static bool done(const memory_t* mem) {
  return mem->numFalsifiedHardClauses == 0 && mem->numFalsifiedSoftClauses == 0;
}

static void addDecreasingVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem) {
  const score_t* const score = mem->scores + varIdx;
  if (mem->decreasingVarsIdx[varIdx] == NSMS_UINT_MAX && *score > 0) {
    // var wasn't decreasing but is now, append it to the end of the list
    mem->decreasingVars[mem->numDecreasingVars] = formula->variables + varIdx;
    mem->decreasingVarsIdx[varIdx] = mem->numDecreasingVars;
    mem->numDecreasingVars += 1;
  }
}

static void remDecreasingVar(nsms_uint_t varIdx, const nsms_wcnf_t* formula, memory_t* mem) {
  const score_t* const score = mem->scores + varIdx;
  if (mem->decreasingVarsIdx[varIdx] < NSMS_UINT_MAX && *score <= 0) {
    // var was decreasing but isn't anymore
    const nsms_uint_t replaceIdx = mem->decreasingVarsIdx[varIdx];

    // remove it from the list
    mem->numDecreasingVars -= 1;
    mem->decreasingVarsIdx[varIdx] = NSMS_UINT_MAX;

    // if it wasn't the last list element, move the last element to fill the gap
    if (mem->numDecreasingVars > 0 && replaceIdx < mem->numDecreasingVars) {
      nsms_wcnf_variable_t* const moveVar = mem->decreasingVars[mem->numDecreasingVars];
      mem->decreasingVars[replaceIdx] = moveVar;
      mem->decreasingVarsIdx[moveVar - formula->variables] = replaceIdx;
    }
  }
}

static void addFalsifiedClause(nsms_uint_t clauseIdx, const nsms_wcnf_t* formula, nsms_uint_t* numFalsifiedClauses,
                               const nsms_wcnf_clause_t** falsifiedClauses, nsms_uint_t* falsifiedClausesIdx) {
  // append to the end of the list
  falsifiedClauses[*numFalsifiedClauses] = formula->clauses + clauseIdx;
  falsifiedClausesIdx[clauseIdx] = *numFalsifiedClauses;
  *numFalsifiedClauses += 1;
}

static void remFalsifiedClause(nsms_uint_t clauseIdx, const nsms_wcnf_t* formula, nsms_uint_t* numFalsifiedClauses,
                               const nsms_wcnf_clause_t** falsifiedClauses, nsms_uint_t* falsifiedClausesIdx) {
  const nsms_uint_t replaceIdx = falsifiedClausesIdx[clauseIdx];

  // remove from the list
  *numFalsifiedClauses -= 1;
  falsifiedClausesIdx[clauseIdx] = NSMS_UINT_MAX;

  // if it wasn't the last element, move the last element to fill the gap
  if (*numFalsifiedClauses > 0 && replaceIdx < *numFalsifiedClauses) {
    const nsms_wcnf_clause_t* moveClause = falsifiedClauses[*numFalsifiedClauses];
    falsifiedClauses[replaceIdx] = moveClause;
    falsifiedClausesIdx[moveClause - formula->clauses] = replaceIdx;
  }
}

void solveHard(nsms_wcnf_t* formula, const nsms_params_t* cfg, memory_t* mem, const nsms_memoryReq_t* memReq,
               const nsms_result_t* result) {
  INIT_DURATION_MEAS();
  START_DURATION_MEAS();

  const nsms_uint_t oldNumClauses = formula->numClauses;
  formula->numClauses = formula->numHardClauses;

  const nsms_uint_t numHard2ClausesRatio = 10 * memReq->detailed2SatMemReq.numHard2Clauses / formula->numHardClauses;

  // basically nsms_solve
  for (nsms_uint_t try = 0; try < cfg->maxTries && !done(mem); ++try) {
    initVars(formula, result);

    if (numHard2ClausesRatio < 5) {  // NOLINT(readability-magic-numbers)
      nsms_decimation(formula, mem->decimationMem, &memReq->detailedDecimationMemReq, cfg->bmsSize, true);
    } else {
      formula->numClauses = memReq->detailed2SatMemReq.numHard2Clauses;
      nsms_2sat(formula, mem->twoSatMem, &memReq->detailed2SatMemReq);
      formula->numClauses = formula->numHardClauses;

#ifdef TEST_2SAT
      printf("c 2-SAT solution:\nc ");
      for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {
        printf("%s%lu ", formula->variables[varIdx].value ? "" : "-", varIdx + 1);
      }
      printf("\n");
      fflush(stdout);
      exit(0);
#endif
    }

    initWeights(formula, cfg, mem);

    nsms_uint_t cost;
    initAlgo(formula, mem, &cost);

    for (nsms_uint_t flip = 0; flip < cfg->maxFlips && !done(mem); ++flip) {
      nsms_wcnf_variable_t* variableToFlip = selectVariable(formula, cfg, result->cost, cost, true, mem);
      flipVariable(variableToFlip, formula, mem, &cost);
    }
  }

  formula->numClauses = oldNumClauses;

  // NOLINTNEXTLINE (bugprone-branch-clone)
  if (formula->numHardClauses == 0 || done(mem)) {
    LOG_WITH_DURATION("c successfully solved hard clauses");
  } else {
    LOG_WITH_DURATION("c couldn't solve hard clauses");
  }
}

nsms_uint_t moveClausesFirst(const nsms_wcnf_t* formula, clausePredicate_t clausePredicate) {
  // in-place sorting clauses to beginning of array
  nsms_uint_t numClauses = 0;
  nsms_uint_t lastClauseIdx = 0;

  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;

    if (clausePredicate(clause)) {
      numClauses += 1;
      continue;
    }

    // search next clause
    nsms_wcnf_clause_t* nextClause = NULL;
    for (nsms_uint_t nextClauseSearchIdx = (clauseIdx > lastClauseIdx ? clauseIdx : lastClauseIdx) + 1;
         nextClauseSearchIdx < formula->numClauses; ++nextClauseSearchIdx) {
      nsms_wcnf_clause_t* candidate = formula->clauses + nextClauseSearchIdx;
      if (nsms_isWCNFClauseHard(candidate)) {
        lastClauseIdx = nextClauseSearchIdx;
        nextClause = candidate;
        break;
      }
    }

    if (!nextClause) {
      break;  // all clauses found
    }

    // swap places
    const nsms_wcnf_clause_t tmp = *clause;
    *clause = *nextClause;
    *nextClause = tmp;

    // update back pointers
    fixLitToClausePtrs(clause);
    fixLitToClausePtrs(nextClause);

    numClauses += 1;
  }

  return numClauses;
}

bool isHard2Clause(const nsms_wcnf_clause_t* clause) {
  return nsms_isWCNFClauseHard(clause) && clause->numLiterals <= 2;
}
