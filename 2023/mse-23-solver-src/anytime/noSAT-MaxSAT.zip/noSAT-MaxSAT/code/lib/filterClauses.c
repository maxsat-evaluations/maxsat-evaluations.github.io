/**
 * @file filterClauses.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "common.h"
#include "formulas/wcnf.h"
#include "preprocessing.h"
#include "util.h"

/**
 * @brief Removes a clause by moving it to the end of the array and replacing it with the clause that was there before
 *
 * @param clauseIdx
 * @param clauses
 * @param numClauses
 */
void removeClause(nsms_uint_t clauseIdx, nsms_wcnf_clause_t* clauses, nsms_uint_t numClauses);

nsms_uint_t nsms_filterClauses(nsms_wcnf_clause_t* clauses, nsms_uint_t numClauses,
                               const nsms_clause_predicate_t* predicates, nsms_uint_t numPredicates) {
  nsms_uint_t numRemovedClauses = 0;

  for (nsms_uint_t clauseIdx = 0; clauseIdx < numClauses; ++clauseIdx) {
    for (nsms_uint_t predIdx = 0; predIdx < numPredicates; ++predIdx) {
      if (predicates[predIdx](clauses + clauseIdx)) {
        removeClause(clauseIdx, clauses, numClauses);
        numClauses -= 1;
        numRemovedClauses += 1;
        break;
      }
    }
  }

  return numRemovedClauses;
}

void removeClause(nsms_uint_t clauseIdx, nsms_wcnf_clause_t* clauses, nsms_uint_t numClauses) {
  const nsms_uint_t lastClauseIdx = numClauses - 1;

  {
    const nsms_wcnf_clause_t clauseToRemove = clauses[clauseIdx];
    clauses[clauseIdx] = clauses[lastClauseIdx];
    clauses[lastClauseIdx] = clauseToRemove;
  }

  fixLitToClausePtrs(clauses + clauseIdx);
  fixLitToClausePtrs(clauses + lastClauseIdx);
}
