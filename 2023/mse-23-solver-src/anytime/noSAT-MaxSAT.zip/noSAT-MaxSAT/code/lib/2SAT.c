/**
 * @file 2SAT.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2023 Ole Lübke
 *
 * @note S. Even, A. Itai, A. Shamir. "On the complexity of time table and multi-commodity flow problems". 1975
 */

#include "2SAT.h"

#include <stdint.h>
#include <string.h>

#include "align.h"
#include "common.h"
#include "formulas/wcnf.h"
#include "logging.h"

typedef enum { UNASSIGNED = -1, FALSE, TRUE } varState_t;

typedef struct {
  varState_t* varStates1;
  varState_t* varStates2;

  nsms_uint_t numUnits1;
  nsms_uint_t* units1;
  nsms_uint_t* unitsIdx1;

  nsms_uint_t numNonUnits1;
  nsms_uint_t* nonUnits1;
  nsms_uint_t* nonUnitsIdx1;

  nsms_uint_t numUnits2;
  nsms_uint_t* units2;
  nsms_uint_t* unitsIdx2;

  nsms_uint_t numNonUnits2;
  nsms_uint_t* nonUnits2;
  nsms_uint_t* nonUnitsIdx2;

  nsms_uint_t* varsToNumClauses;
  const nsms_wcnf_clause_t*** varsToClauses;
} memory_t;

static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_uint_t* varsToNumClauses, nsms_2sat_memoryReq_t* out);

static void initMemory(void* mem, const nsms_2sat_memoryReq_t* memReq, nsms_uint_t numVars, memory_t* out);

static void initAlgorithm(const nsms_wcnf_t* formula, memory_t* mem);

static inline void pushClause(nsms_uint_t* clauses, nsms_uint_t* numClauses, nsms_uint_t* clausesIdx,
                              nsms_uint_t clauseIdx);

static inline nsms_uint_t peekClauses(const nsms_uint_t* clauses, nsms_uint_t numClauses);

static inline void remClause(nsms_uint_t* clauses, nsms_uint_t* numClauses, nsms_uint_t* clausesIdx,
                             nsms_uint_t clauseIdx);

static inline bool isInStack(const nsms_uint_t* clausesIdx, nsms_uint_t clauseIdx);

static inline void setVariable(nsms_uint_t varIdx, varState_t value, varState_t* varStates, bool* conflict,
                               const nsms_wcnf_clause_t** affectedClauses, nsms_uint_t numAffectedClauses,
                               nsms_uint_t* units, nsms_uint_t* numUnits, nsms_uint_t* unitsIdx, nsms_uint_t* nonUnits,
                               nsms_uint_t* numNonUnits, nsms_uint_t* nonUnitsIdx, const nsms_wcnf_clause_t* clauses);

static inline void step(varState_t* varStates, nsms_uint_t* units, nsms_uint_t* numUnits, nsms_uint_t* unitsIdx,
                        nsms_uint_t* nonUnits, nsms_uint_t* numNonUnits, nsms_uint_t* nonUnitsIdx,
                        const nsms_wcnf_clause_t*** varsToClauses, const nsms_uint_t* varsToNumClauses,
                        const nsms_wcnf_clause_t* clauses, bool* branch, bool* conflict);

static inline void choose(bool choose1, memory_t* mem, const nsms_wcnf_t* formula);

static inline void assignOutput(const varState_t* varStates, nsms_wcnf_variable_t* variables, nsms_uint_t numVariables);

nsms_uint_t nsms_2sat_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_uint_t* varsToNumClauses,
                                             nsms_2sat_memoryReq_t* memReq) {
  calcMemoryReq(formula, varsToNumClauses, memReq);
  return (2 * memReq->varStateMemReq) + (2 * memReq->unitsMemReq) + (2 * memReq->unitsIdxMemReq) +
         (2 * memReq->nonUnitsMemReq) + (2 * memReq->nonUnitsIdxMemReq) + memReq->varsToClausesMemReq;
}

bool nsms_2sat(const nsms_wcnf_t* formula, void* memory, const nsms_2sat_memoryReq_t* memReq) {
  memory_t mem;
  initMemory(memory, memReq, formula->numVariables, &mem);

  initAlgorithm(formula, &mem);

  bool res = true;

  for (nsms_uint_t i = 0; i < formula->numVariables; ++i) {
    bool conflict1 = false, conflict2 = false, branch1 = false, branch2 = false, chose1 = false, chose2 = false;

    step(mem.varStates1, mem.units1, &mem.numUnits1, mem.unitsIdx1, mem.nonUnits1, &mem.numNonUnits1, mem.nonUnitsIdx1,
         mem.varsToClauses, mem.varsToNumClauses, formula->clauses, &branch1, &conflict1);
    step(mem.varStates2, mem.units2, &mem.numUnits2, mem.unitsIdx2, mem.nonUnits2, &mem.numNonUnits2, mem.nonUnitsIdx2,
         mem.varsToClauses, mem.varsToNumClauses, formula->clauses, &branch2, &conflict2);

    if (conflict1 && conflict2) {
      LOG("c 2SAT: conflict in both branches\n");
      res = false;
      break;
    }

    if (conflict1) {
      LOG("c 2SAT: conflict in branch 1\n");
      choose(false, &mem, formula);
      chose2 = true;
    } else if (conflict2) {
      LOG("c 2SAT: conflict in branch 2\n");
      choose(true, &mem, formula);
      chose1 = true;
    }

    if (branch1) {
      if (!chose1) {
        choose(true, &mem, formula);
      }
    } else if (branch2) {
      if (!chose2) {
        choose(false, &mem, formula);
      }
    }

    if (branch1 || branch2) {
      if (mem.numNonUnits1 == 0) {
        LOG("c 2SAT: no more non-units, done\n");
        break;
      }

      const nsms_uint_t nonUnitClauseIdx = peekClauses(mem.nonUnits1, mem.numNonUnits1);

      LOG("c 2SAT: branching on clause %lu\n", nonUnitClauseIdx);

      const nsms_wcnf_clause_t* const clause = formula->clauses + nonUnitClauseIdx;
      const nsms_wcnf_literal_t* const lit = clause->literals;
      const nsms_uint_t varIdx = lit->variableIdx;

      LOG("c 2SAT: setting variable %lu\n", varIdx);

      setVariable(varIdx, TRUE, mem.varStates1, &conflict1, mem.varsToClauses[varIdx], mem.varsToNumClauses[varIdx],
                  mem.units1, &mem.numUnits1, mem.unitsIdx1, mem.nonUnits1, &mem.numNonUnits1, mem.nonUnitsIdx1,
                  formula->clauses);
      setVariable(varIdx, FALSE, mem.varStates2, &conflict2, mem.varsToClauses[varIdx], mem.varsToNumClauses[varIdx],
                  mem.units2, &mem.numUnits2, mem.unitsIdx2, mem.nonUnits2, &mem.numNonUnits2, mem.nonUnitsIdx2,
                  formula->clauses);
    }
  }

  if (res) {
    assignOutput(mem.varStates1, formula->variables, formula->numVariables);
  }

  return res;
}

static void calcMemoryReq(const nsms_wcnf_t* formula, nsms_uint_t* varsToNumClauses, nsms_2sat_memoryReq_t* out) {
  for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {
    varsToNumClauses[varIdx] = 0;
  }

  nsms_uint_t numHard2Clauses = 0;
  nsms_uint_t varsToNumClausesSum = 0;
  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    const nsms_uint_t nLits = clause->numLiterals;
    if (nsms_isWCNFClauseHard(clause) && nLits <= 2) {
      numHard2Clauses += 1;

      for (nsms_uint_t litIdx = 0; litIdx < nLits; ++litIdx) {
        const nsms_wcnf_literal_t* const literal = clause->literals + litIdx;
        varsToNumClauses[literal->variableIdx] += 1;
        varsToNumClausesSum += 1;
      }
    }
  }

  out->varStateMemReq = align(formula->numVariables * sizeof(varState_t));
  out->unitsMemReq = align(numHard2Clauses * sizeof(nsms_uint_t));
  out->unitsIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->nonUnitsMemReq = align(numHard2Clauses * sizeof(nsms_uint_t));
  out->nonUnitsIdxMemReq = align(formula->numClauses * sizeof(nsms_uint_t));
  out->varsToClausesMemReq =
      align(formula->numVariables * sizeof(nsms_wcnf_clause_t**) + varsToNumClausesSum * sizeof(nsms_wcnf_clause_t*));
  out->varsToNumClauses = varsToNumClauses;
  out->numHard2Clauses = numHard2Clauses;
}

static void initMemory(void* mem, const nsms_2sat_memoryReq_t* memReq, nsms_uint_t numVars, memory_t* out) {
  out->varStates1 = mem;
  out->varStates2 = (varState_t*)((uint8_t*)out->varStates1 + memReq->varStateMemReq);
  out->numUnits1 = 0;
  out->units1 = (nsms_uint_t*)((uint8_t*)out->varStates2 + memReq->varStateMemReq);
  out->unitsIdx1 = (nsms_uint_t*)((uint8_t*)out->units1 + memReq->unitsMemReq);
  out->numNonUnits1 = 0;
  out->nonUnits1 = (nsms_uint_t*)((uint8_t*)out->unitsIdx1 + memReq->unitsIdxMemReq);
  out->nonUnitsIdx1 = (nsms_uint_t*)((uint8_t*)out->nonUnits1 + memReq->nonUnitsMemReq);

  out->numUnits2 = 0;
  out->units2 = (nsms_uint_t*)((uint8_t*)out->nonUnitsIdx1 + memReq->nonUnitsIdxMemReq);
  out->unitsIdx2 = (nsms_uint_t*)((uint8_t*)out->units2 + memReq->unitsMemReq);
  out->numNonUnits2 = 0;
  out->nonUnits2 = (nsms_uint_t*)((uint8_t*)out->unitsIdx2 + memReq->unitsIdxMemReq);
  out->nonUnitsIdx2 = (nsms_uint_t*)((uint8_t*)out->nonUnits2 + memReq->nonUnitsMemReq);

  out->varsToClauses = (const nsms_wcnf_clause_t***)((uint8_t*)out->nonUnitsIdx2 + memReq->nonUnitsIdxMemReq);
  out->varsToClauses[0] =
      (const nsms_wcnf_clause_t**)((uint8_t*)out->varsToClauses + numVars * sizeof(nsms_wcnf_clause_t**));
  for (nsms_uint_t varIdx = 1; varIdx < numVars; ++varIdx) {
    out->varsToClauses[varIdx] =
        (const nsms_wcnf_clause_t**)((uint8_t*)out->varsToClauses[varIdx - 1] +
                                     memReq->varsToNumClauses[varIdx - 1] * sizeof(nsms_wcnf_clause_t*));
  }
  out->varsToNumClauses = memReq->varsToNumClauses;
}

static inline void pushClause(nsms_uint_t* clauses, nsms_uint_t* numClauses, nsms_uint_t* clausesIdx,
                              nsms_uint_t clauseIdx) {
  clauses[*numClauses] = clauseIdx;
  clausesIdx[clauseIdx] = (*numClauses)++;
}

static inline nsms_uint_t peekClauses(const nsms_uint_t* clauses, nsms_uint_t numClauses) {
  return clauses[numClauses - 1];
}

static inline void remClause(nsms_uint_t* clauses, nsms_uint_t* numClauses, nsms_uint_t* clausesIdx,
                             nsms_uint_t clauseIdx) {
  nsms_uint_t* const overwriteIdx = clausesIdx + clauseIdx;
  nsms_uint_t* const overwriteClause = clauses + *overwriteIdx;
  *overwriteClause = clauses[--(*numClauses)];
  clausesIdx[*overwriteClause] = *overwriteIdx;
  *overwriteIdx = NSMS_UINT_MAX;
}

static inline bool isInStack(const nsms_uint_t* clausesIdx, nsms_uint_t clauseIdx) {
  return clausesIdx[clauseIdx] < NSMS_UINT_MAX;
}

static void initAlgorithm(const nsms_wcnf_t* formula, memory_t* mem) {
  LOG("c 2SAT: initializing\n");

  for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {
    mem->varStates1[varIdx] = UNASSIGNED;
    mem->varStates2[varIdx] = UNASSIGNED;
    mem->varsToNumClauses[varIdx] = 0;
  }

  for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
    const nsms_wcnf_clause_t* const clause = formula->clauses + clauseIdx;
    const nsms_uint_t nLits = clause->numLiterals;
    if (nsms_isWCNFClauseHard(clause) && nLits <= 2) {
      for (nsms_uint_t litIdx = 0; litIdx < nLits; ++litIdx) {
        const nsms_wcnf_literal_t* const literal = clause->literals + litIdx;
        const nsms_uint_t varIdx = literal->variableIdx;
        mem->varsToClauses[varIdx][mem->varsToNumClauses[varIdx]++] = clause;

        LOG("c 2SAT: var %lu occurs in clause %lu\n", varIdx, clauseIdx);
      }

      if (nLits == 1) {
        LOG("c 2SAT: pushing unit %lu\n", clauseIdx);

        pushClause(mem->units1, &mem->numUnits1, mem->unitsIdx1, clauseIdx);
        pushClause(mem->units2, &mem->numUnits2, mem->unitsIdx2, clauseIdx);

        mem->nonUnitsIdx1[clauseIdx] = NSMS_UINT_MAX;
        mem->nonUnitsIdx2[clauseIdx] = NSMS_UINT_MAX;
      } else if (nLits == 2) {
        LOG("c 2SAT: pushing non-unit %lu\n", clauseIdx);

        pushClause(mem->nonUnits1, &mem->numNonUnits1, mem->nonUnitsIdx1, clauseIdx);
        pushClause(mem->nonUnits2, &mem->numNonUnits2, mem->nonUnitsIdx2, clauseIdx);

        mem->unitsIdx1[clauseIdx] = NSMS_UINT_MAX;
        mem->unitsIdx2[clauseIdx] = NSMS_UINT_MAX;
      } else {
        mem->unitsIdx1[clauseIdx] = NSMS_UINT_MAX;
        mem->unitsIdx2[clauseIdx] = NSMS_UINT_MAX;
        mem->nonUnitsIdx1[clauseIdx] = NSMS_UINT_MAX;
        mem->nonUnitsIdx2[clauseIdx] = NSMS_UINT_MAX;
      }
    }
  }
  LOG("c 2SAT: finished initializing\n");
}

static inline void setVariable(nsms_uint_t varIdx, varState_t value, varState_t* varStates, bool* conflict,
                               const nsms_wcnf_clause_t** affectedClauses, nsms_uint_t numAffectedClauses,
                               nsms_uint_t* units, nsms_uint_t* numUnits, nsms_uint_t* unitsIdx, nsms_uint_t* nonUnits,
                               nsms_uint_t* numNonUnits, nsms_uint_t* nonUnitsIdx, const nsms_wcnf_clause_t* clauses) {
  LOG("c 2SAT: setting var %lu to %s\n", varIdx, value ? "true" : "false");

  varStates[varIdx] = value;

  *conflict = false;
  for (nsms_uint_t i = 0; i < numAffectedClauses && !*conflict; ++i) {
    const nsms_wcnf_clause_t* const affClause = affectedClauses[i];
    const nsms_uint_t affClauseIdx = affClause - clauses;

    if (isInStack(unitsIdx, affClauseIdx)) {
      remClause(units, numUnits, unitsIdx, affClauseIdx);
    } else if (isInStack(nonUnitsIdx, affClauseIdx)) {
      remClause(nonUnits, numNonUnits, nonUnitsIdx, affClauseIdx);

      bool affClauseSatisfiable = false;

      for (nsms_uint_t litIdx = 0; litIdx < affClause->numLiterals; ++litIdx) {
        const nsms_wcnf_literal_t* const literal = affClause->literals + litIdx;
        const bool negated = literal->negated;
        const nsms_uint_t litVarIdx = literal->variableIdx;

        const varState_t varState = varStates[litVarIdx];
        affClauseSatisfiable = affClauseSatisfiable || varState == UNASSIGNED || varState == (negated ? FALSE : TRUE);

        if (varIdx == litVarIdx) {
          if (!((negated && value == FALSE) || (!negated && value == TRUE))) {
            // setting the variable to value did not make literal true, so clause is still undetermined
            pushClause(units, numUnits, unitsIdx, affClauseIdx);
          }
        }
      }

      *conflict = !affClauseSatisfiable;
    }
  }
}

static inline void step(varState_t* varStates, nsms_uint_t* units, nsms_uint_t* numUnits, nsms_uint_t* unitsIdx,
                        nsms_uint_t* nonUnits, nsms_uint_t* numNonUnits, nsms_uint_t* nonUnitsIdx,
                        const nsms_wcnf_clause_t*** varsToClauses, const nsms_uint_t* varsToNumClauses,
                        const nsms_wcnf_clause_t* clauses, bool* branch, bool* conflict) {
  if (*numUnits > 0) {
    const nsms_uint_t unitClauseIdx = peekClauses(units, *numUnits);

    LOG("c 2SAT: propagating unit %lu\n", unitClauseIdx);

    const nsms_wcnf_clause_t* const clause = clauses + unitClauseIdx;
    const nsms_wcnf_literal_t* const literal =
        clause->literals +
        (clause->numLiterals == 1 ? 0 : (varStates[clause->literals[0].variableIdx] == UNASSIGNED ? 0 : 1));
    const nsms_uint_t varIdx = literal->variableIdx;

    setVariable(varIdx, literal->negated ? FALSE : TRUE, varStates, conflict, varsToClauses[varIdx],
                varsToNumClauses[varIdx], units, numUnits, unitsIdx, nonUnits, numNonUnits, nonUnitsIdx, clauses);
  } else {
    *branch = true;
  }
}

static inline void choose(bool choose1, memory_t* mem, const nsms_wcnf_t* formula) {
  LOG("c 2SAT: choosing branch %d\n", choose1 ? 1 : 2);

  memcpy(choose1 ? mem->varStates2 : mem->varStates1, choose1 ? mem->varStates1 : mem->varStates2,
         sizeof(varState_t) * formula->numVariables);
  memcpy(choose1 ? mem->units2 : mem->units1, choose1 ? mem->units1 : mem->units2,
         sizeof(nsms_uint_t) * (choose1 ? mem->numUnits1 : mem->numUnits2));
  memcpy(choose1 ? mem->unitsIdx2 : mem->unitsIdx1, choose1 ? mem->unitsIdx1 : mem->unitsIdx2,
         sizeof(nsms_uint_t) * formula->numClauses);
  memcpy(choose1 ? mem->nonUnits2 : mem->nonUnits1, choose1 ? mem->nonUnits1 : mem->nonUnits2,
         sizeof(nsms_uint_t) * (choose1 ? mem->numNonUnits1 : mem->numNonUnits2));
  memcpy(choose1 ? mem->nonUnitsIdx2 : mem->nonUnitsIdx1, choose1 ? mem->nonUnitsIdx1 : mem->nonUnitsIdx2,
         sizeof(nsms_uint_t) * formula->numClauses);
  *(choose1 ? &mem->numUnits2 : &mem->numUnits1) = choose1 ? mem->numUnits1 : mem->numUnits2;
  *(choose1 ? &mem->numNonUnits2 : &mem->numNonUnits1) = choose1 ? mem->numNonUnits1 : mem->numNonUnits2;
}

static inline void assignOutput(const varState_t* varStates, nsms_wcnf_variable_t* variables,
                                nsms_uint_t numVariables) {
  for (nsms_uint_t varIdx = 0; varIdx < numVariables; ++varIdx) {
    bool* const varValue = &variables[varIdx].value;
    switch (varStates[varIdx]) {
      case TRUE:
        *varValue = true;
        break;
      case FALSE:
        *varValue = false;
        break;
      case UNASSIGNED:  // do nothing
        break;
    }
  }
}
