/**
 * @file rng.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief RNG module tests
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "private/rng.h"

#include <check.h>
#include <limits.h>
#include <stdlib.h>

#ifdef LOGGING
#  include <stdio.h>
#endif

START_TEST(testRandIdxRange) {
  const nsms_uint_t max = RAND_MAX;
  const nsms_uint_t numIterations = 1000000;
  for (nsms_uint_t i = 0; i < numIterations; ++i) {
    const nsms_uint_t r = randIdx(max);
    ck_assert_uint_lt(r, max);
  }
}
END_TEST

START_TEST(testRandIdxUniform) {
  const nsms_uint_t max = 10;
  nsms_uint_t counts[max];
  for (nsms_uint_t i = 0; i < max; ++i) {
    counts[i] = 0;
  }

  const nsms_uint_t numIterations = 1000000;
  for (nsms_uint_t i = 0; i < numIterations; ++i) {
    counts[randIdx(max)] += 1;
  }

  // chi squared test for uniform distribution
  const double expectedCount = ((double)numIterations) / max;
  double chiSquared = 0;
  for (nsms_uint_t i = 0; i < max; ++i) {
    double summand = counts[i] - expectedCount;
    summand *= summand;
    summand /= expectedCount;
    chiSquared += summand;
  }

#ifdef LOGGING
  printf("\ntestRandIdxUniform\n==================\nexpected count: %f\n", expectedCount);
  for (nsms_uint_t i = 0; i < max; ++i) {
    printf("%u. %u\n", i, counts[i]);
  }
  printf("chi-squared value: %f\n\n", chiSquared);
#endif

  ck_assert_double_le(chiSquared, 14.68);  // 9 degrees of freedom, significance level 0.1
}

Suite* rngSuite() {
  Suite* suite = suite_create("rng");
  TCase* tcRandIdx = tcase_create("randIdx");
  tcase_add_test(tcRandIdx, testRandIdxRange);
  tcase_add_test(tcRandIdx, testRandIdxUniform);
  suite_add_tcase(suite, tcRandIdx);
  return suite;
}

int main() {
  rngInit();

  Suite* rngS = rngSuite();
  SRunner* rngSRunner = srunner_create(rngS);

  srunner_run_all(rngSRunner, CK_NORMAL);
  const int numFailedTests = srunner_ntests_failed(rngSRunner);
  srunner_free(rngSRunner);

  return (numFailedTests == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
