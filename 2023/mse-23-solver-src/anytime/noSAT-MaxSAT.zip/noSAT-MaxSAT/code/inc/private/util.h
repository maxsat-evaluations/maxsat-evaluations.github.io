/**
 * @file util.h
 * @author Ole Lübke
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_PRIVATE_UTIL_H
#define NSMS_PRIVATE_UTIL_H

#include "common.h"
#include "formulas/wcnf.h"

static inline void fixLitToClausePtrs(const nsms_wcnf_clause_t* clause) {
  for (nsms_uint_t litIdx = 0; litIdx < clause->numLiterals; ++litIdx) {
    clause->literals[litIdx].clause = clause;
  }
}

#endif
