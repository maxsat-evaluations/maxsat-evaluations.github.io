/**
 * @file rng.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief Random number generation
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_PRIVATE_RNG_H
#define NSMS_PRIVATE_RNG_H

#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <time.h>

#include "common.h"

#define RNG_MAXIMUM_PROBABILITY 1000000
#define RNG_FAIR_COIN_PROBABILITY (RNG_MAXIMUM_PROBABILITY / 2)

/**
 * @brief Initializes the RNG module
 */
static inline void rngInit() {
  // TODO don't use standard library for RNG?
  srand(time(NULL));
}

/**
 * @brief Generates a random index < max
 *
 * @param max
 * @return nsms_uint_t
 */
static inline nsms_uint_t randIdx(nsms_uint_t max) {
  // TODO don't use standard library?
  // TODO truly uniform RNG for [0, max)?
  return rand() % max;
}

/**
 * @brief Returns true with (bias / 10000)% probability, otherwise returns false
 *
 * @param bias [0, RNG_MAXIMUM_PROBABILITY]
 * @return true
 * @return false
 */
static inline bool flipBiasedCoin(nsms_uint_t bias) {
  return randIdx(RNG_MAXIMUM_PROBABILITY) < bias;
}

/**
 * @brief Returns true with 50% probability, otherwise returns false
 *
 * @return true
 * @return false
 */
static inline bool flipCoin() {
  return flipBiasedCoin(RNG_FAIR_COIN_PROBABILITY);
}
#endif
