/**
 * @file logging.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_PRIVATE_LOGGING_H
#define NSMS_PRIVATE_LOGGING_H

#ifdef LOGGING
#  include <stdio.h>
#  include <time.h>
#  define LOG(...)               printf(__VA_ARGS__)
#  define INIT_DURATION_MEAS()   clock_t startTime
#  define START_DURATION_MEAS()  startTime = clock()
#  define DURATION_STR           " in %.3f sec.\n"
#  define DURATION_VAL           (((double)(clock() - startTime)) / CLOCKS_PER_SEC)
#  define LOG_WITH_DURATION(str) printf(str DURATION_STR, DURATION_VAL)
#else
#  define LOG(...)
#  define INIT_DURATION_MEAS()
#  define START_DURATION_MEAS()
#  define DURATION_STR
#  define DURATION_VAL
#  define LOG_WITH_DURATION(str)
#endif

#endif
