/**
 * @file align.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_PRIVATE_ALIGN_H
#define NSMS_PRIVATE_ALIGN_H

#include "common.h"

/**
 * @brief Make sure x is divisible by the pointer size of the system
 *
 * @param x
 * @return nsms_uint_t x or the next number after x that is divisible by the pointer size of the system
 */
static inline nsms_uint_t align(nsms_uint_t x) {
  static const nsms_uint_t ptrSize = sizeof(void*);
  const nsms_uint_t mod = x % ptrSize;
  return mod != 0 ? x + ptrSize - mod : x;
}

#endif
