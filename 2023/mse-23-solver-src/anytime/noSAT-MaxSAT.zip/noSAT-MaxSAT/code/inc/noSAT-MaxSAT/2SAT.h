/**
 * @file 2SAT.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2023 Ole Lübke
 *
 */

#ifndef NSMS_2SAT_H
#define NSMS_2SAT_H

#include <stdbool.h>

#include "common.h"
#include "formulas/wcnf.h"

typedef struct {
  nsms_uint_t varStateMemReq, unitsMemReq, unitsIdxMemReq, nonUnitsMemReq, nonUnitsIdxMemReq, varsToClausesMemReq;
  nsms_uint_t* varsToNumClauses;
  nsms_uint_t numHard2Clauses;
} nsms_2sat_memoryReq_t;

nsms_uint_t nsms_2sat_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_uint_t* varsToNumClauses,
                                             nsms_2sat_memoryReq_t* memReq);

bool nsms_2sat(const nsms_wcnf_t* formula, void* memory, const nsms_2sat_memoryReq_t* memReq);

#endif
