/**
 * @file common.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief Common definitions used across other files of the project.
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_COMMON_H
#define NSMS_COMMON_H

#include <limits.h>

#define NSMS_UINT_FORMAT "%llu"
#define NSMS_UINT_MAX    ULLONG_MAX
typedef unsigned long long nsms_uint_t;

#endif
