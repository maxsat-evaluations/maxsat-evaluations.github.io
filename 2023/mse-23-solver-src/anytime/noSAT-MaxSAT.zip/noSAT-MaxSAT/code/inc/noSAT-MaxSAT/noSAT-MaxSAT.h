/**
 * @file noSAT-MaxSAT.h
 * @author Ole Lübke (ole.luebke@tuhh.de)
 * @brief
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef NSMS_H
#define NSMS_H

#include <stdbool.h>

#include "2SAT.h"
#include "common.h"
#include "formulas/wcnf.h"
#include "preprocessing.h"

/**
 * @brief Holds the status of incomplete MaxSAT solving
 *
 */
typedef enum {
  NSMS_OPTIMUM_FOUND,  //!< The formula is satisfiable
  NSMS_UNKNOWN,        //!< The satisfiability of the formula is unknown
  NSMS_INFEASIBLE      //!< As NSMS_UNKNOWN but no assignment satisfying all hard clauses was found
} nsms_status_t;

/**
 * @brief Holds the result of incomplete MaxSAT solving
 *
 */
typedef struct {
  nsms_status_t status;  //!< The solution status
  nsms_uint_t cost;      //!< The solution cost (sum of weights of clauses falsified by the solution)
  bool* assignment;      //!< The solution assignment, memory must be allocated by user
} nsms_result_t;

/**
 * @brief Holds parameters of the algorithm
 *
 */
typedef struct {
  nsms_uint_t maxTries; /*!< The maximum number of restarts (i.e., how often a new initial assignment is generated) */
  nsms_uint_t maxFlips; /*!< The maximum number of variable flips the algorithm performs within one iteration (total
                             no. of iterations <= maxTries * maxFlips) */
  nsms_uint_t bmsSize;  /*!< The number of decreasing variables selected for "best from multiple selections" strategy */
  nsms_uint_t hWeightInc;         /*!< Weight increment for hard clauses during clause reweighting */
  nsms_uint_t sWeightInc;         /*!< Weight increment for soft clauses during clause reweighting */
  nsms_uint_t sWeightBoundCoef;   /*!< Coefficient for soft clause weight upper bound (when reweighting) */
  nsms_uint_t sWeightBoundOffset; /*!< Offset for soft clause weight upper bound (when reweighting) */
  nsms_uint_t hSmoothProb;        /*!< Smoothing probability for hard clauses: 100000000 == 100% */
  nsms_uint_t sSmoothProb;        /*!< Smoothing probability for soft clauses: 100000000 == 100% */
} nsms_params_t;

/**
 * @brief Memory requirements
 */
typedef struct {
  nsms_uint_t weightsMemReq, numSatLiteralsMemReq, scoresMemReq, satVarsMemReq, decreasingVarMemReq,
      decreasingVarsIdxMemReq, falsifiedHardClausesMemReq, falsifiedHardClausesIdxMemReq, falsifiedSoftClausesMemReq,
      falsifiedSoftClausesIdxMemReq, softClauseWeightBoundsMemReq, decimationMemReq, twoSatMemReq;
  nsms_decimation_memoryReq_t detailedDecimationMemReq;
  nsms_2sat_memoryReq_t detailed2SatMemReq;
} nsms_memoryReq_t;

/**
 * @brief Initializes the library
 *
 */
void nsms_init(void);

/**
 * @brief Calculates memory requirements for the algorithm
 *
 * @param formula The formula the algorithm is supposed to run on
 * @param varsToNumClauses Array of size formula->numVariables * sizeof(nsms_uint_t) to store for each variable in how
 * many clauses it occurs
 * @param memReq
 * @return bsat_uint_t The number of bytes required to run the algorithm on the formula
 */
nsms_uint_t nsms_calcMemoryRequirements(const nsms_wcnf_t* formula, nsms_uint_t* varsToNumClauses,
                                        nsms_memoryReq_t* memReq);

/**
 * @brief Tries to solve MaxSAT instance
 *
 * @param formula The formula to try to solve
 * @param cfg @see nsms_params_t
 * @param mem @see A memory block of sufficient size (calculate with nsms_calcMemoryRequirements)
 * @param memReq @see nsms_memoryReq_t
 * @param result @see nsms_result_t
 */
void nsms_solve(nsms_wcnf_t* formula, const nsms_params_t* cfg, void* memory, const nsms_memoryReq_t* memReq,
                nsms_result_t* result);

/**
 * @brief Calculates default parameters based on the given formula
 *
 * @param formula
 * @param params
 */
void nsms_params(const nsms_wcnf_t* formula, nsms_params_t* params);

#endif
