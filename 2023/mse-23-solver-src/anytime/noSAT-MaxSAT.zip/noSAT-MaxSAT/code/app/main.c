/**
 * @file main.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <argp.h>
#include <errno.h>
#include <math.h>
#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/formulas/wcnf.h>
#include <noSAT-MaxSAT/noSAT-MaxSAT.h>
#include <private/logging.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "common.h"
#include "formulas/wcnf.h"
#include "io/MaxSAT22.h"

#define PERCENTAGE_SCALING_FACTOR ((nsms_uint_t)10000)
#define DEFAULT_MAX_FLIPS_FACTOR  10

typedef struct {
  const char* file;
  nsms_params_t params;
  double maxFlipsFactor;
  struct {
    bool usrMaxFlips;
  } flags;
} arguments_t;

static void signalHandler(int signal);

static void registerSignalHandlers(void);

// NOLINTNEXTLINE(readability-non-const-parameter)
static error_t parseOpt(int key, char* arg, struct argp_state* state);

static void parseUIntOpt(nsms_uint_t* val, const char* name, const char* arg, struct argp_state* state);

static void parseDoubleOpt(double* val, const char* name, const char* arg, struct argp_state* state);

static void setParameters(arguments_t* args, const nsms_wcnf_t* formula);

static void printResult(const nsms_result_t* result, nsms_uint_t numVariables);

static void run(nsms_wcnf_t* formula, const arguments_t* args);

const char* argp_program_version = "noSAT-MaxSAT";
const char* argp_program_bug_address = "<ole.luebke@tuhh.de>";

static nsms_result_t result = {.status = NSMS_INFEASIBLE, .cost = NSMS_UINT_MAX, .assignment = NULL};
static nsms_uint_t numVariables = 0;

int main(int argc, char** argv) {
  INIT_DURATION_MEAS();

  char doc[] = "Try to solve MaxSAT problem read from FILE using noSAT-MaxSAT";
  char argsDoc[] = "FILE";
  struct argp_option options[] = {
      {"maxTries", 't', "NUM", 0, "Maximum number of retries (outer loop).\nDefault: UINT64_MAX", 0},
      {"maxFlips", 'l', "NUM", 0,
       "Maximum number of flips (inner loop).\nIf not specified, maxFlipsFactor is used to determine this.", 0},
      {"maxFlipsFactor", 'f', "NUM", 0,
       "No. of variables * maxFlipsFactor =: maxFlips.\nIgnored if maxFlips is specified directly.\nDefault: 10", 0},
      {0}};
  struct argp argp = {options, parseOpt, argsDoc, doc, NULL, NULL, NULL};
  arguments_t args = {.file = NULL,
                      .params = {.maxTries = NSMS_UINT_MAX, .maxFlips = NSMS_UINT_MAX},
                      .maxFlipsFactor = DEFAULT_MAX_FLIPS_FACTOR,
                      .flags = {.usrMaxFlips = false}};

  registerSignalHandlers();

  argp_parse(&argp, argc, argv, 0, NULL, &args);

  FILE* inputStream = fopen(args.file, "r");
  if (inputStream) {
    LOG("c starting to read problem\n");
    START_DURATION_MEAS();
    nsms_uint_t errLine = 0;
    nsms_wcnf_t* formula = wcnfFromMaxSAT22(inputStream, &errLine);
    LOG_WITH_DURATION("c read problem");

    if (formula) {
      setParameters(&args, formula);

#ifdef LOGGING
      double avgNumLitsInClause = (double)formula->clauses[0].numLiterals;
      for (nsms_uint_t clauseIdx = 1; clauseIdx < formula->numClauses; ++clauseIdx) {
        const double numClausesSoFar = (double)clauseIdx + 1.0;
        avgNumLitsInClause = ((double)clauseIdx / numClausesSoFar) * avgNumLitsInClause +
                             (1 / numClausesSoFar) * (double)formula->clauses[clauseIdx].numLiterals;
      }
#endif
      LOG("c running on a formula with " NSMS_UINT_FORMAT " variables and " NSMS_UINT_FORMAT
          " clauses\n"
          "c on average a clause has %.1f literals\n"
          "c parameters: maxTries: " NSMS_UINT_FORMAT ", maxFlips: " NSMS_UINT_FORMAT "\n",
          formula->numVariables, formula->numClauses, avgNumLitsInClause, args.params.maxTries, args.params.maxFlips);

      run(formula, &args);

      deleteWCNF(formula);
      formula = NULL;
    } else {
      if (errLine) {
        fprintf(stderr, "c Syntax error on line " NSMS_UINT_FORMAT ".\n", errLine);
      } else {
        fprintf(stderr, "c Ran out of memory while parsing SAT problem.\n");
      }
    }

    fclose(inputStream);
  } else {
    fprintf(stderr, "c Could not open file \"%s\".\n", args.file);
  }

  return 0;
}

static void signalHandler(int signal) {
  switch (signal) {
    case SIGINT:  // fall-through
    case SIGTERM:
      printResult(&result, numVariables);
      exit(EXIT_SUCCESS);
      break;
    default:
      break;
  }
}

static void registerSignalHandlers(void) {
  // NOLINTNEXTLINE(performance-no-int-to-ptr)
  if (signal(SIGTERM, signalHandler) == SIG_ERR) {
    fprintf(stderr, "c Failed to register SIGTERM handler\n");
    exit(EXIT_FAILURE);
  }
  // NOLINTNEXTLINE(performance-no-int-to-ptr)
  if (signal(SIGINT, signalHandler) == SIG_ERR) {
    fprintf(stderr, "c Failed to register SIGINT handler\n");
    exit(EXIT_FAILURE);
  }
}

static error_t parseOpt(int key, char* arg, struct argp_state* state) {
  arguments_t* const arguments = state->input;

  switch (key) {
    case 't':
      parseUIntOpt(&arguments->params.maxTries, "maxTries", arg, state);
      break;
    case 'l':
      parseUIntOpt(&arguments->params.maxFlips, "maxFlips", arg, state);
      arguments->flags.usrMaxFlips = true;
      break;
    case 'f':
      parseDoubleOpt(&arguments->maxFlipsFactor, "maxFlipsFactor", arg, state);
      break;
    case ARGP_KEY_ARG:
      if (state->arg_num >= 1) {
        argp_usage(state);
      }
      arguments->file = arg;
      break;
    case ARGP_KEY_END:
      if (!arguments->file) {
        argp_usage(state);
      }
      break;
    default:
      return ARGP_ERR_UNKNOWN;
  }

  return EXIT_SUCCESS;
}

static void parseUIntOpt(nsms_uint_t* val, const char* name, const char* arg, struct argp_state* state) {
  *val = strtoull(arg, NULL, NSMS_DECIMAL_SYSTEM_BASE);
  if (*val == 0 || errno == ERANGE) {
    argp_error(state, "Could not parse %s: %s\n", name, arg);
  }
}

static void parseDoubleOpt(double* val, const char* name, const char* arg, struct argp_state* state) {
  *val = strtod(arg, NULL);
  if (*val == 0 || *val == HUGE_VAL || *val == -HUGE_VAL || errno == ERANGE) {
    argp_error(state, "Could not parse %s: %s\n", name, arg);
  }
}

static void setParameters(arguments_t* args, const nsms_wcnf_t* formula) {
  nsms_params(formula, &args->params);

  if (!args->flags.usrMaxFlips) {
    args->params.maxFlips = (nsms_uint_t)(args->maxFlipsFactor * (double)formula->numVariables);
    const nsms_uint_t numVariables = (nsms_uint_t)((double)args->params.maxFlips / args->maxFlipsFactor);
    if (!(formula->numVariables - 1 <= numVariables && numVariables <= formula->numVariables + 1)) {
      fprintf(stderr, "c warning: the configured maxFlipsFactor caused an overflow\n");
    }
  }
}

static void printResult(const nsms_result_t* result, nsms_uint_t numVariables) {
  const bool optFound = result->status == NSMS_OPTIMUM_FOUND;
  const char* const msg = optFound ? "OPTIMUM FOUND" : "UNKNOWN";
  printf("s %s\n", msg);
  if (result->status != NSMS_INFEASIBLE) {
    printf("o " NSMS_UINT_FORMAT "\n", result->cost);

    if (wcnfVariablesToMaxSAT22(stdout, result->assignment, numVariables)) {
      fputs("c Failed to write result.\n", stderr);
    }
  }
}

static void run(nsms_wcnf_t* formula, const arguments_t* args) {
  nsms_init();

  nsms_uint_t* varsToNumClauses = malloc(formula->numVariables * sizeof(nsms_uint_t));

  if (varsToNumClauses) {
    nsms_memoryReq_t detailMemReq;
    const nsms_uint_t memReq = nsms_calcMemoryRequirements(formula, varsToNumClauses, &detailMemReq);
    void* memory = malloc(memReq);

    result.assignment = malloc(formula->numVariables * sizeof(bool));
    numVariables = formula->numVariables;

    if (memory && result.assignment) {
      nsms_solve(formula, &args->params, memory, &detailMemReq, &result);
      printResult(&result, formula->numVariables);
    } else {
      fputs("c Out of memory\n", stderr);
    }

    if (memory) {
      free(memory);
      memory = NULL;
    }
    if (result.assignment) {
      free(result.assignment);
      result.assignment = NULL;
    }
  } else {
    fputs("c Out of memory\n", stderr);
  }

  if (varsToNumClauses) {
    free(varsToNumClauses);
    varsToNumClauses = NULL;
  }
}
