/**
 * @file wcnf.c
 * @author Ole Lübke (ole.luebke@tuhh.de)
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "wcnf.h"

#include <noSAT-MaxSAT/common.h>
#include <noSAT-MaxSAT/formulas/wcnf.h>
#include <stdbool.h>
#include <stdlib.h>

nsms_wcnf_t* newWCNF(nsms_uint_t numVariables, nsms_uint_t numClauses) {
  nsms_wcnf_t* formula = malloc(sizeof(nsms_wcnf_t));

  if (formula) {
    formula->numVariables = numVariables;
    formula->variables = calloc(numVariables, sizeof(nsms_wcnf_variable_t));

    formula->numClauses = numClauses;
    formula->clauses = calloc(numClauses, sizeof(nsms_wcnf_clause_t));

    if (!formula->variables || !formula->clauses) {
      deleteWCNF(formula);
      formula = NULL;
    }
  }

  return formula;
}

void deleteWCNF(nsms_wcnf_t* formula) {
  if (formula) {
    if (formula->clauses) {
      for (nsms_uint_t clauseIdx = 0; clauseIdx < formula->numClauses; ++clauseIdx) {
        nsms_wcnf_clause_t* clause = formula->clauses + clauseIdx;
        if (clause->literals) {
          free(clause->literals);
          clause->literals = NULL;
        }
      }

      free(formula->clauses);
      formula->clauses = NULL;
    }

    if (formula->variables) {
      for (nsms_uint_t varIdx = 0; varIdx < formula->numVariables; ++varIdx) {
        nsms_wcnf_variable_t* variable = formula->variables + varIdx;
        if (variable->literals) {
          free(variable->literals);
          variable->literals = NULL;
        }
      }

      free(formula->variables);
      formula->variables = NULL;
    }

    free(formula);
  }
}

bool newWCNFLiterals(nsms_wcnf_clause_t* clause, nsms_uint_t numLiterals) {
  bool error = false;
  clause->numLiterals = numLiterals;
  clause->literals = calloc(numLiterals, sizeof(nsms_wcnf_literal_t));
  if (!clause->literals) {
    error = true;
  }
  return error;
}
