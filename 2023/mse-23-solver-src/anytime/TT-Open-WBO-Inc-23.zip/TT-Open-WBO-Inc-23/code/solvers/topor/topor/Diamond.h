#pragma once

static void DIAMOND([[maybe_unused]] const std::string&, bool&) {}
