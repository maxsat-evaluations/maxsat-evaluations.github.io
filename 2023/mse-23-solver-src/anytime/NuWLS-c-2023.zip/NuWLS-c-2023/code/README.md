### README for the NuWLS-c Solver

### MaxSAT Evaluation 2023
./NuWLS-c_static <input-file>
