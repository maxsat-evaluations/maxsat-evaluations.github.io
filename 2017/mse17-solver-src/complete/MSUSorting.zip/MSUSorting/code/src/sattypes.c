#include "sattypes.h"
Var lit_to_var(Literal a)
{
  return a > 0 ? a : -a;
}
