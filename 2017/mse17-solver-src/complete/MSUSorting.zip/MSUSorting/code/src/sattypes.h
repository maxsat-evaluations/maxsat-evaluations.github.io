#ifndef SATTYPES_H
#define SATTYPES_H

/**
 * Commonly used types for sat.
 */
typedef unsigned int uint;

typedef int Literal;
typedef int Var;

Var lit_to_var(Literal a);
#endif
