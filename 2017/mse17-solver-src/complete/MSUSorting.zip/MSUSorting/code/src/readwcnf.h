#ifndef READWCF_H
#define READWCF_H
#include "sattypes.h"
#include "stdio.h"

/*
 * Read a wcnf file
 * /param file The input wcnf file.
 * /param softcl Where to put the list of soft clauses.
 * /param numSoftLit the length of softcl.
 * /param hardcl Where to put the list of hard clauses.
 * /param numHardLit the length of hardcl.
 * /param numVar the number of variables.
 * /param numClauses the number of clauses.
 */
void read_wcnf(
    FILE* file,
    Literal** softcl,
    int* numSoftLit,
    Literal** hardcl,
    int* numHardLit,
    int* numVar,
    int* numClauses);
#endif
