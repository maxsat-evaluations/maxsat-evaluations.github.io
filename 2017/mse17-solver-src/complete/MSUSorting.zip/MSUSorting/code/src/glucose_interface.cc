#include "glucose_interface.h"
#include "core/Solver.h"
#include "picosat.h"

#define myabs(a) (((a) > 0) ? (a) : (-a))
using namespace Glucose;

typedef struct Gluc {
  Solver* g;
  vec<Lit>* clause;
  vec<Lit>* assumes;

} Gluc;

void glucose_assume(void* v, Literal l)
{
  Gluc* gluc = (Gluc*)v;
  gluc->assumes->push(mkLit(myabs(l), l > 0));
}

void glucose_add(void* v, Literal l)
{
  Gluc* gluc = (Gluc*)v;
  if (l == 0) {
    gluc->g->addClause(*(gluc->clause));
    delete gluc->clause;
    gluc->clause = new vec<Lit>;
  } else {
    int var = myabs(l);
    while (var >= gluc->g->nVars())
      gluc->g->newVar();
    Lit li = mkLit(var, l > 0);
    gluc->clause->push(li);
  }
}

bool glucose_lookup(void* v, Literal l)
{
  Gluc* gluc = (Gluc*)v;
  lbool b = gluc->g->modelValue(mkLit(myabs(l), l > 0));
  if (b == l_True) {
    return true;
  } else {
    return false;
  }
}

bool glucose_corelit(void* v, Literal l)
{
  Gluc* gluc = (Gluc*)v;
  Lit l1 = mkLit(myabs(l), l > 0);
  Lit l2 = mkLit(myabs(l), l < 0);
  for (int i = 0; i < gluc->g->conflict.size(); i++) {
    if (gluc->g->conflict[i] == l1
        || gluc->g->conflict[i] == l2) {
      return true;
    }
  }
  return false;
}

int glucose_checksat(void* v)
{
  Gluc* gluc = (Gluc*)v;
  bool res = gluc->g->solve(*(gluc->assumes));
  delete gluc->assumes;
  gluc->assumes = new vec<Lit>;
  if (res == true) {
    return PICOSAT_SATISFIABLE;
  } else if (res == false) {
    return PICOSAT_UNSATISFIABLE;
  } else {
    return PICOSAT_UNKNOWN;
  }
}

void glucose_set_phase(void* v, Literal l, bool b)
{
  Gluc* gluc = (Gluc*)v;
  Solver* g = gluc->g;
  g->setPolarity(l, b);
}

void glucose_free(void* v)
{
  Gluc* gluc = (Gluc*)v;
  delete gluc->g;
  delete gluc->assumes;
  delete gluc->clause;
  free(v);
}

SATSolver* glucose_satmake()
{
  Gluc* gluc = (Gluc*)malloc(sizeof(Gluc));
  gluc->g = new Solver;
  gluc->g->setIncrementalMode();
  gluc->clause = new vec<Lit>;
  gluc->assumes = new vec<Lit>;
  SATSolver* s = (SATSolver*)malloc(sizeof(SATSolver));
  s->data = gluc;
  s->assume = glucose_assume;
  s->add = glucose_add;
  s->lookup = glucose_lookup;
  s->conflict_assumes = glucose_corelit;
  s->checksat = glucose_checksat;
  s->setphase = glucose_set_phase;
  s->freer = glucose_free;
  return s;
}
