#include "totalizer.h"
#include "common.h"
#include <assert.h>
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Merge {
  Literal* as;
  Literal* bs;
  Literal* outlits;
  uint maxa;
  uint maxb;
  uint alength;
  uint blength;
  int k;
} Merge;

void merge_free(void* mv)
{
  Merge* m = (Merge*)mv;
  free(m);
}

typedef struct TotalizerStruct {
  GPtrArray* merges;
  GPtrArray* toFree;
  bool biDirectional;
} TotalizerStruct;

Totalizer* tot_make(ExtraClauses extra)
{
  Totalizer* ret = malloc(sizeof(TotalizerStruct));
  ret->merges = g_ptr_array_new_with_free_func(merge_free);
  ret->toFree = g_ptr_array_new_with_free_func(free);
  ret->biDirectional = extra.biDirectional;
  return ret;
}
void tot_free(Totalizer* t)
{
  g_ptr_array_free(t->merges, true);
  g_ptr_array_free(t->toFree, true);
  free(t);
}
void tot_add_merge(Totalizer* t, Literal* as, Literal* bs, Literal* outlits, uint alength, uint blength, uint maxa, uint maxb, int k)
{
  Merge* m = malloc(sizeof(Merge));
  m->as = as;
  m->bs = bs;
  m->outlits = outlits;
  m->alength = alength;
  m->blength = blength;
  m->maxa = maxa;
  m->maxb = maxb;
  m->k = k;
  g_ptr_array_add(t->merges, m);
}

void tot_add_to_free(Totalizer* t, void* frs)
{
  g_ptr_array_add(t->toFree, frs);
}

void tot_merge(Literal* lits, uint alength, uint blength, Formula* f)
{
  if (alength == 0 || blength == 0) {
    return;
  }
  int length = alength + blength;
  Literal ret[length];
  for (int i = 0; i < length; ++i) {
    ret[i] = formula_make_fresh(f);
  }

  for (int i = 0; i < (int)alength; ++i) {
    formula_cl(f, 2, ret[i], -lits[i]);
    for (int j = 0; j < (int)blength && i + j + 1 < length; ++j) {
      formula_cl(f, 3, ret[i + j + 1], -lits[i], -lits[alength + j]);
    }
  }
  for (uint i = 0; i < blength; ++i) {
    formula_cl(f, 2, ret[i], -lits[alength + i]);
  }
  memcpy(lits, ret, sizeof(Literal) * length);
}

void tot_sort(Literal* lits, uint length, Formula* f)
{
  if (length < 2)
    return;
  int alength = length / 2;
  int blength = length - alength;
  tot_sort(lits, alength, f);
  tot_sort(lits + alength, blength, f);
  tot_merge(lits, alength, blength, f);
}

Literal* tot_k_sort(Totalizer* t, Literal* lits, uint length, Formula* f, int k)
{
  if (length < 1) {
    return NULL;
  }
  if (length == 1) {
    return lits;
  }
  int alength = length / 2;
  int blength = length - alength;
  Literal* as = tot_k_sort(t, lits, alength, f, k);
  Literal* bs = tot_k_sort(t, lits + alength, blength, f, k);
  Literal* ret = tot_k_merge(t, as, bs, alength, blength, f, k);
  return ret;
}

Literal* tot_k_merge(Totalizer* t, Literal* as, Literal* bs, uint alength, uint blength, Formula* f, int k)
{
  if (blength == 0) {
    return as;
  }
  if (alength == 0) {
    return bs;
  }
  int length = alength + blength;
  if (k > length)
    k = length;
  Literal* ret = malloc(sizeof(Literal) * length);
  memset(ret, 0, sizeof(Literal) * length);
  tot_add_to_free(t, ret);
  for (int i = 0; i < length; ++i) {
    ret[i] = 0;
  }

  int maxa = alength;
  int maxb = blength;
  for (uint i = 0; i < alength; ++i) {
    if (as[i] == 0) {
      maxa = i;
      break;
    }
  }
  for (uint i = 0; i < blength; ++i) {
    if (bs[i] == 0) {
      maxb = i;
      break;
    }
  }
  tot_add_merge(t, as, bs, ret, alength, blength, maxa, maxb, k);

  for (int i = 0; i < (int)alength && i < k; ++i) {
    if (as[i] == 0) {
      break;
    }
    if (ret[i] == 0) {
      ret[i] = formula_make_fresh(f);
    }
    formula_cl(f, 2, ret[i], -as[i]);
    for (int j = 0; j < (int)blength && i + j < k; ++j) {
      if (bs[j] == 0) {
        break;
      }
      if (i + j + 1 < k) {
        if (ret[i + j + 1] == 0) {
          ret[i + j + 1] = formula_make_fresh(f);
        }
        formula_cl(f, 3, ret[i + j + 1], -as[i], -bs[j]);
      }
      if (t->biDirectional) {
        formula_cl(f, 3, -ret[i + j], as[i], bs[j]);
      }
    }
  }
  for (int i = 0; i < (int)blength && i < k; ++i) {
    if (bs[i] == 0) {
      break;
    }
    if (ret[i] == 0) {
      ret[i] = formula_make_fresh(f);
    }
    formula_cl(f, 2, ret[i], -bs[i]);
  }
  if (t->biDirectional) {
    for (int i = 0; i < k; ++i) {
      if (ret[i] == 0) {
        break;
      }
      if (i >= (int)blength && as[i - blength] != 0) {
        formula_cl(f, 2, -ret[i], as[i - blength]);
      }
      if (i >= (int)alength && bs[i - alength] != 0) {
        formula_cl(f, 2, -ret[i], bs[i - alength]);
      }
    }
  }
  assert(zeros_only_end(ret, length));

  assert(first_zero(as, alength) + first_zero(bs, blength)
      >= first_zero(ret, length));
  return ret;
}

void merge_update(Merge* m, Formula* f, int k2, bool biDirectional)
{
  int k1 = m->k;
  uint alength = m->alength;
  uint blength = m->blength;
  if (alength == 0 || blength == 0) {
    return;
  }
  int prevmaxa = m->maxa;
  int prevmaxb = m->maxb;
  m->maxa = alength;
  m->maxb = blength;
  for (uint i = 0; i < alength; ++i) {
    if (m->as[i] == 0) {
      m->maxa = i;
      break;
    }
  }
  for (uint i = 0; i < blength; ++i) {
    if (m->bs[i] == 0) {
      m->maxb = i;
      break;
    }
  }
  int length = alength + blength;
  int astart = min(k1, prevmaxa);
  int bstart = min(k1, prevmaxb);
  if (k2 > length)
    k2 = length;
  for (int i = 0; i < (int)alength; ++i) {
    if (m->as[i] == 0)
      break;
    if (i >= k2)
      break;
    if (m->outlits[i] == 0) {
      m->outlits[i] = formula_make_fresh(f);
    }
    if (i >= astart) {
      formula_cl(f, 2, m->outlits[i], -m->as[i]);
    }
    for (int j = 0; j < (int)blength; ++j) {
      if (m->bs[j] == 0)
        break;
      int outindex = i + j + 1;
      if ((outindex >= k1 || j >= bstart) && outindex < k2) {
        if (m->outlits[outindex] == 0) {
          m->outlits[outindex] = formula_make_fresh(f);
        }
        formula_cl(f, 3, m->outlits[outindex], -m->as[i], -m->bs[j]);
      }
      if (biDirectional && (outindex - 1 >= k1 || j >= bstart) && outindex - 1 < k2) {
        if (m->outlits[outindex - 1] != 0) {
          formula_cl(f, 3, -m->outlits[outindex - 1], m->as[i], m->bs[j]);
        }
      }
    }
  }
  for (int i = bstart; i < (int)blength && i < k2; ++i) {
    if (m->bs[i] == 0)
      break;
    if (m->outlits[i] == 0) {
      m->outlits[i] = formula_make_fresh(f);
    }
    formula_cl(f, 2, m->outlits[i], -m->bs[i]);
  }
  if (biDirectional) {
    for (int i = 0; i < k2; ++i) {
      if (m->outlits[i] == 0) {
        break;
      }
      if (i >= (int)blength && i - (int)(m->blength) >= astart) {
        formula_cl(f, 2, -m->outlits[i], m->as[i - blength]);
      }
      if (i >= (int)alength && i - (int)alength >= bstart) {
        formula_cl(f, 2, -m->outlits[i], m->bs[i - alength]);
      }
    }
  }
  assert(zeros_only_end(m->outlits, length));
  m->k = k2;
}

void tot_k_update(Totalizer* t, Formula* f, int k)
{
  GPtrArray* mrgs = t->merges;
  for (uint i = 0; i < mrgs->len; ++i) {
    Merge* m = g_ptr_array_index(mrgs, i);
    merge_update(m, f, k, t->biDirectional);
  }
}

SortingScheme* tot_make_scheme(ExtraClauses extra)
{
  SortingScheme* ret = malloc(sizeof(SortingScheme));
  ret->encodingData = tot_make(extra);
  ret->merge = (Merger)tot_k_merge;
  ret->sort = (Sorter)tot_k_sort;
  ret->update = (Updater)tot_k_update;
  ret->freer = (Freer)tot_free;
  return ret;
}
