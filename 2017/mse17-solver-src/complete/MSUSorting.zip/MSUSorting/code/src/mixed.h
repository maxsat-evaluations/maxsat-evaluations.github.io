#ifndef MIXED_H
#define MIXED_H

#include "extra_clauses.h"
#include "sattypes.h"
#include "sortingscheme.h"

/**
 * The Mixed struct is used to provide a SortingScheme (/see sortingscheme.h)
 * that uses the mixed strategy (a parametrized choice between totalizer and sortingnetworks).
 */
typedef struct MixedStruct Mixed;

/** There are two choices for parametrized choice between totalizer and
 * sortingnetworks.
 */
typedef enum {
  OPT_RATIO,   /*!< Optimize a ratio between variables and clauses */
  CLAUSE_LIMIT /*!< Set a limit on the amount of clauses beyond the minimum.*/
} SortStrategyType;

/** Sortstrategy holds the information about the
 * strategy chosen. */
typedef struct SortStrategy {
  SortStrategyType type; /** The type of strategy */
  double ratio;          /** The ratio of variables to clauses to optimize for (minimize ratio * numVars + numCls). (in case OPT_RATIO) */
  int budget;            /** The budget of clauses (beyond minimum) to use (in case of CLAUSE_LIMIT)*/
  int budgetIncrease;    /** How much the budget is increased between calls to mixed_k_merge (in case of CLAUSE_LIMIT) */
} SortStrategy;

/** Make a Mixed
 * /param strat the Sorting strategy to use
 * /param extra The extra clauses strategy to use.
 */
Mixed* mixed_make(SortStrategy strat, ExtraClauses extra);
/**
 * Free the mixed struct.
 */
void mixed_free(Mixed* t);

/**
 * /param lits the literals to be sorted.
 * /param length the length of lits
 * /param k the number of outputs to provide
 * /return Literals that are the k first lits in sorted order guaranteed by the clauses added for the formula.
 */
Literal* mixed_k_sort(Mixed*, Literal* lits, uint length, Formula*, int k);
/**
 * /param as the literals to be merged.
 * /param bs the literals to be merged.
 * /param alength the length of as.
 * /param blength the length of bs.
 * /param k the number of outputs to provide.
 * /return Literals that are the k first lits of as and bs merged, guaranteed by the clauses added to f.
 */
Literal* mixed_k_merge(Mixed*, Literal* as, Literal* bs, uint alength, uint blength, Formula* f, int k);

/**
 * Update the mixed network
 */
void mixed_k_update(Mixed*, Formula*, int k);

/**
 * /return a SortingScheme implemented using mixed
 */
SortingScheme* mixed_make_scheme(SortStrategy strat, ExtraClauses extra);
#endif
