#ifndef SORTINGNETWORK_H
#define SORTINGNETWORK_H

#include "extra_clauses.h"
#include "sattypes.h"
#include "sortingscheme.h"

/**
 * SortingNetwork is used to implement a SortingScheme (/see sortingscheme.h)
 * using sorting networks.
 */
typedef struct NetworkStruct SortingNetwork;

/**
 * /param extra What redundant clauses to use (/see extra_clauses.h).
 * /return An empty SortingNetwork.
 */
SortingNetwork* sn_make(ExtraClauses extra);
/** Free a sortingnetwork */
void sn_free(SortingNetwork* t);

/**
 * /param lits The literals to be sorted
 * /param length the length of lits
 * /param k The number of outputs to provide.
 * /return A list of the k first lits in sorted order guaranteed by the clauses added to the formula */
Literal* sn_k_sort(SortingNetwork*, Literal* lits, uint length, Formula*, int k);
/**
 * /param as The first literals to be merged
 * /param bs The sencond literals to be merged
 * /param alength the length of as
 * /param blength the length of bs
 * /param k The number of outputs to provide.
 * /return A list of the k first lits in sorted order guaranteed by the clauses added to the formula */
Literal* sn_k_merge(SortingNetwork*, Literal* as, Literal* bs, uint alength, uint blength, Formula* f, int k);
/** Update the sorting network so that the number of outputs is k+1*/
void sn_k_update(SortingNetwork*, Formula*, int k);

/** Make a sorting scheme using sorting networks */
SortingScheme* sn_make_scheme(ExtraClauses extra);

/** Split a into those literals ad oddindecies (aodd) and those at even indecies  (aeven) */
void splitEvenOdd(Literal* a, Literal** aeven, Literal** aodd, int length, int* elength, int* olength);
/** Same as splitEvenOdd but with ints instead of literals */
void splitOddEvenIndecies(int* indecies, int** oddInd, int** evenInd, int numOdd, int numEven);

#endif
