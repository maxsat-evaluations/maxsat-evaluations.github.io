#include "glib.h"
#define GETTEXT_PACKAGE "gtk20"
#include <glib/gi18n-lib.h>
#include <signal.h>

#include "cryptominisat_interface.h"
#include "glucose_interface.h"
#include "mixed.h"
#include "msu3.h"
#include "msu4.h"
#include "msu3tomsu4.h"
#include "picosat_interface.h"
#include "readwcnf.h"
#include "satsolver.h"
#include "sortingnetwork.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "totalizer.h"


static char* wcnfFile = NULL;
static char* algorithm = NULL;
static char* solver = NULL;
static char* encoding = NULL;
static double mixedRatio = 5.0;
static double mixedLimit = 4.0;
static double mixedLimitIncrease = 1.0;
static bool wboUpdate = false;
static bool forwardExtra = false;
static bool backwardExtra = false;
static bool bidirectional = false;
static bool sortedness = false;
static int msu3seconds = 300;

void interrupt_handler(int sig){
  if(sig == SIGINT){
    printf("\ns UNKNOWN\n");
    exit(0);
  }
}

int main(int argc, char** argv)
{

  signal(SIGINT,interrupt_handler);

  GError* error = NULL;

  GOptionEntry entries[] = {
    { "input-file", 'f', 0, G_OPTION_ARG_FILENAME, &wcnfFile, "The input wcnf file.", "F" },
    { "algorithm", 'a', 0, G_OPTION_ARG_STRING, &algorithm, "Algorithm used for solving. Either msu4, msu3 or msu3to4.", "A" },
    { "msu3seconds", 0, 0, G_OPTION_ARG_INT, &msu3seconds, "Number of seconds to run msu3 in the msu3to4 algorithm", NULL },
    { "solver", 's', 0, G_OPTION_ARG_STRING, &solver, "The Sat Solver used, either glucose,cryptominisat, or picosat.", "S" },
    { "encoding", 'e', 0, G_OPTION_ARG_STRING, &encoding, "Encoding used by the algorithm. Either totalizer, sort, mixed-ratio, or mixed-limit.", "E" },
    { "mixed-ratio", 'r', 0, G_OPTION_ARG_DOUBLE, &mixedRatio, "If mixed-ratio is used, the ratio between clauses\n and variables used for optimizing size.", "E" },
    { "mixed-limit", 'l', 0, G_OPTION_ARG_DOUBLE, &mixedLimit, "If mixed-limit is used, sets the limit on additional\n clauses used beyond the minimal amount to C * num_input_clauses ", "C" },
    { "mixed-limit-increase", 'i', 0, G_OPTION_ARG_DOUBLE, &mixedLimitIncrease, "If mixed-limit is used, sets the limit on \n additional clauses is increased by, each time new indicator variables are activated.\n The increased budget is CI*NUM_ORIG_CLAUSES", "CI" },
    { "wbo-update", 'w', 0, G_OPTION_ARG_NONE, &wboUpdate, "Uses the original way of updating the encoding as in open-wbo.", NULL },
    { "sortedness", 0, 0, G_OPTION_ARG_NONE, &sortedness, "Adds the sortedness redundant clauses.", NULL },
    { "bidirectional", 0, 0, G_OPTION_ARG_NONE, &bidirectional, "Adds redundant clauses for bidirectional sorting.", NULL },
    { "forward-extra", 0, 0, G_OPTION_ARG_NONE, &forwardExtra, "Adds the forward propagation redundant clauses.", NULL },
    { "backward-extra", 0, 0, G_OPTION_ARG_NONE, &backwardExtra, "Adds the backward propagation redundant clauses.", NULL },
    { NULL, 0, 0, G_OPTION_ARG_NONE, NULL, NULL, NULL },
  };

  GOptionContext* context = g_option_context_new("- solve MaxSAT using sorting and msu3/4.");
  g_option_context_add_main_entries(context, entries, GETTEXT_PACKAGE);
  if (!g_option_context_parse(context, &argc, &argv, &error)) {
    g_print("option parsing failed: %s\n", error->message);
    exit(1);
  }

  FILE* file = fopen(wcnfFile, "rt");
  if (file == NULL) {
    printf("c No input file was supplied!");
    exit(1);
  }
  int numSoft = 0;
  int numHard = 0;
  int numCl = 0;
  int numVar = 0;
  Literal* hardcl;
  Literal* softcl;

  if (file == NULL) {
    fprintf(stderr, "please supply a file through the -f parameter\n");
    exit(-1);
  }

  read_wcnf(file, &softcl, &numSoft, &hardcl, &numHard, &numVar, &numCl);
  fclose(file);

  SortingScheme* scheme;
  SATSolver* sat;

  if (solver == NULL) {
    sat = glucose_satmake();
  } else if (!strcmp(solver, "picosat")) {
    sat = picosat_satmake(0);
  } else if (!strcmp(solver, "glucose")) {
    sat = glucose_satmake();
  } else if (!strcmp(solver, "cryptominisat")) {
    sat = cryptominisat_satmake();
  } else {
    fprintf(stderr, "unknown solver %s\n", solver);
    exit(-1);
  }

  SortStrategy strat = { OPT_RATIO, mixedRatio, mixedLimit * (numSoft + numHard), mixedLimitIncrease * (numSoft + numHard) };
  ExtraClauses extra = { bidirectional, forwardExtra, backwardExtra, sortedness };
  if (encoding == NULL) {
    strat.type = CLAUSE_LIMIT;
    scheme = mixed_make_scheme(strat, extra);
  } else if (!strcmp(encoding, "sort")) {
    scheme = sn_make_scheme(extra);
  } else if (!strcmp(encoding, "totalizer")) {
    scheme = tot_make_scheme(extra);
  } else if (!strcmp(encoding, "mixed-ratio")) {
    SortStrategy strat = { OPT_RATIO, mixedRatio, 0, 0 };
    scheme = mixed_make_scheme(strat, extra);
  } else if (!strcmp(encoding, "mixed-limit")) {
    strat.type = CLAUSE_LIMIT;
    scheme = mixed_make_scheme(strat, extra);
  } else {
    fprintf(stderr, "unknown encoding %s\n", encoding);
    exit(-1);
  }
  if (algorithm == NULL) {
    msu3tomsu4_run(scheme, sat, softcl, numSoft, hardcl, numHard, numVar, numCl, wboUpdate,msu3seconds);
  } else if (!strcmp(algorithm, "msu3")) {
    msu3_run(scheme, sat, softcl, numSoft, hardcl, numHard, numVar, numCl, wboUpdate);
  } else if (!strcmp(algorithm, "msu4")) {
    msu4_run(scheme, sat, softcl, numSoft, hardcl, numHard, numVar, numCl, wboUpdate);
  } else if (!strcmp(algorithm, "msu3to4")) {
    msu3tomsu4_run(scheme, sat, softcl, numSoft, hardcl, numHard, numVar, numCl, wboUpdate,msu3seconds);
  } else {
    fprintf(stderr, "unknown algorithm %s\n", algorithm);
    exit(-1);
  }


  g_option_context_free(context);
  sat_free(sat);
  sorter_free(scheme);
  free(hardcl);
  free(softcl);
}
