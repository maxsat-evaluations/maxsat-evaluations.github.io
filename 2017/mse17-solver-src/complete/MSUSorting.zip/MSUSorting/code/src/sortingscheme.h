#ifndef SORTINGSCHEME_H
#define SORTINGSCHEME_H

#include "formula.h"
#include "sattypes.h"
#include "stdlib.h"

#define delayed 0
#define isDelayed(a) ((a) == 0)

typedef Literal* (*Merger)(void* data, Literal* as, Literal* bs, uint alength, uint blength, Formula*, int k);
typedef Literal* (*Sorter)(void* data, Literal* lits, uint length, Formula*, int k);
typedef void (*Updater)(void* data, Formula*, int k);
typedef void (*Freer)(void* data);

/**
 * An interface for sorting schemes including data provided by the implementer.
 * For each function sorter_* simply passes the data along to the given function ie.
 * sorter_merge(s,a,b,alength,blength,f,k) = s->merge(s->encodingData,a,b,alength,blength,f,k).
 * See the documentation for sorter_* for each function.
 *
 * The sorting functions adds clauses necessary to guarantee the sortedness of
 * the outputs.  Also the sorting functions uses a special literal 'delayed'
 * which signifies that the input (or output) is not used yet. Each function
 * can specify how many outputs is needed (k). This can be changed and the
 * changes updated using the update function:
 *
 *   SortingScheme ss = sn_make(extra);
 *   Formula f = formula_make();
 *
 *   Literal * lits = {2,3,4,5,0};
 *
 *   Literal * outs = sorter_sort(ss,lits,5,f,2); //outs = {6,7,0,0,0}
 *
 *   lits[4] = formula_make_fresh(); // lits[4] = 8
 *
 *   sorter_update(ss,f,5); // outs = {6,7,9,10,11}
 *
 * All lists provided as input or given as output to the sorter are owned
 * by the the sorter and therefore freed by sorter_free. The only change
 * that can be made to these lists is to give fresh variables to
 * those positions that are delayed.
 */
typedef struct SortingScheme {
  void* encodingData;
  Merger merge;
  Sorter sort;
  Updater update;
  Freer freer;
} SortingScheme;

/**
 * /param as First list of literals to merge
 * /param bs Second list of literals to merge
 * /param alength length of as
 * /param blength length of bs
 * /param k The number of outputs to provide
 * /return list of the k first literals that are as and bs merged.
 */
static inline Literal* sorter_merge(SortingScheme* s, Literal* as, Literal* bs, uint alength, uint blength, Formula* f, int k)
{
  return s->merge(s->encodingData, as, bs, alength, blength, f, k);
}

/**
 * /param lits List of literals to sort
 * /param length length of lits
 * /param k The number of outputs to provide
 * /return list of the k first literals that are lits sorted.
 */
static inline Literal* sorter_sort(SortingScheme* s, Literal* lits, uint length, Formula* f, int k)
{
  return s->sort(s->encodingData, lits, length, f, k);
}

/**
 * Update the sorting network to take into account literals that are no longer
 * delayed and increase k.
 */
static inline void sorter_update(SortingScheme* s, Formula* f, int k)
{
  s->update(s->encodingData, f, k);
}

/** Free the sorter */
static inline void sorter_free(SortingScheme* s)
{
  s->freer(s->encodingData);
  free(s);
}

#endif
