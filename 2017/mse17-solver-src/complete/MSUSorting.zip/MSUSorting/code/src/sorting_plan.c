#include <glib.h>
#include <stdio.h>
#include <stdlib.h>

#include "assert.h"
#include "common.h"
#include "sorting_plan.h"
#include "sortingnetwork.h"
#include "string.h"

void sp_free(SortPlan* sp)
{
  if (sp == NULL)
    return;
  sp_free(sp->left);
  sp_free(sp->right);
  ms_free(sp->merge);
  free(sp);
}

static void ms_update_costs(MergeStep* ms, int k)
{
  if (ms == NULL || ms->type != SN_MERGE)
    return;

  ms_update_costs(ms->odd, k);
  ms_update_costs(ms->even, k);

  ms->numCls = ms->numClsThis + ms->even->numCls + ms->odd->numCls;
  ms->numVar = ms->numVarThis + ms->even->numVar + ms->odd->numVar;
}

static void sp_update_costs(SortPlan* sp)
{
  if (sp == NULL)
    return;
  sp_update_costs(sp->left);
  sp_update_costs(sp->right);
  ms_update_costs(sp->merge, sp->k);
}

int num_cls_tot(int in1, int in2, int* outIndecies, int k)
{
  int k2 = first_larger(k, outIndecies, in1 + in2);
  int sum = 0;
  int a = max(in1, in2);
  int b = min(in1, in2);
  for (int i = 0; i < min(k2, a); ++i) {
    sum += min(b + 1, k2 - i);
  }
  sum += min(b, k2);
  return sum;
}

int num_var_tot(int in1, int in2, int* outIndecies, int k)
{
  return first_larger(k, outIndecies, in1 + in2);
}

int ms_out_length(MergeStep* ms)
{
  if (ms == NULL)
    return 0;
  return ms->in1length + ms->in2length;
}

int ms_undelayed(MergeStep* ms)
{
  if (ms == NULL)
    return 0;
  assert(ms->in1undelayed <= ms->in1length);
  assert(ms->in2undelayed <= ms->in2length);
  return ms->in1undelayed + ms->in2undelayed;
}

int sp_length(SortPlan* sp)
{
  if (sp == NULL)
    return 0;
  int mergeout = ms_out_length(sp->merge);
  return mergeout;
}

int sp_undelayed(SortPlan* sp)
{
  if (sp == NULL)
    return 0;
  int mergeout = ms_undelayed(sp->merge);
  return min(mergeout, sp->k);
}

void ms_free(MergeStep* ms)
{
  if (ms == NULL)
    return;
  free(ms->outIndecies);
  ms_free(ms->odd);
  ms_free(ms->even);
  free(ms);
}

static MergeStep* ms_make_empty(int alength, int blength, int undelayeda, int undelayedb, int* outIndecies)
{
  MergeStep* ret = malloc(sizeof(MergeStep));
  ret->in1length = alength;
  ret->in2length = blength;
  ret->in1undelayed = undelayeda;
  ret->in2undelayed = undelayedb;

  ret->even = NULL;
  ret->odd = NULL;

  ret->numClsThis = 0;
  ret->numVarThis = 0;
  ret->numCls = 0;
  ret->numVar = 0;

  ret->outIndecies = outIndecies;

  return ret;
}

static MergeStep* ms_make_singleton(int length, int undelayed, int* outIndecies)
{
  MergeStep* ret = ms_make_empty(length, 0, undelayed, 0, outIndecies);
  ret->type = SINGLETON;
  return ret;
}

MergeStep* ms_merge_tot(int alength, int blength, int undelayeda, int undelayedb, int* outIndecies, int k)
{

  if (alength == 0 || blength == 0)
    return ms_make_singleton(alength + blength, undelayeda + undelayedb, outIndecies);

  MergeStep* ret = ms_make_empty(alength, blength, undelayeda, undelayedb, outIndecies);
  ret->type = TOT_MERGE;

  ret->even = NULL;
  ret->odd = NULL;

  ret->numClsThis = num_cls_tot(undelayeda, undelayedb, outIndecies, k);
  ret->numCls = ret->numClsThis;
  ret->numVarThis = num_var_tot(undelayeda, undelayedb, outIndecies, k);
  ret->numVar = ret->numVarThis;

  return ret;
}

MergeStep* ms_merge_sn(int alength, int blength, int undelayeda, int undelayedb, int* outIndecies, int k)
{
  assert(alength >= undelayeda && blength >= undelayedb);
  assert(undelayeda >= 0 && undelayedb >= 0);
  if (alength == 0 || blength == 0)
    return ms_make_singleton(alength + blength, undelayeda + undelayedb, outIndecies);
  if (undelayeda <= 1 && undelayedb <= 1)
    return ms_merge_tot(alength, blength, undelayeda, undelayedb, outIndecies, k);
  int length = alength + blength;
  MergeStep* ret = ms_make_empty(alength, blength, undelayeda, undelayedb, outIndecies);
  ret->type = SN_MERGE;

  int anumOdd = alength / 2;
  int anumEven = alength - anumOdd;
  int bnumOdd = blength / 2;
  int bnumEven = blength - bnumOdd;
  int numOdd = anumOdd + bnumOdd;
  int numEven = anumEven + bnumEven;

  assert(numOdd + numEven == length);
  int *evenIndecies, *oddIndecies;
  splitOddEvenIndecies(outIndecies, &oddIndecies, &evenIndecies, numOdd, numEven);

  int aundelayedOdd = undelayeda / 2;
  int aundelayedEven = undelayeda - aundelayedOdd;
  int bundelayedOdd = undelayedb / 2;
  int bundelayedEven = undelayedb - bundelayedOdd;
  int undelayedOdd = aundelayedOdd + bundelayedOdd;
  int undelayedEven = aundelayedEven + bundelayedEven;

  ret->even = ms_merge_sn(anumEven, bnumEven, aundelayedEven, bundelayedEven, evenIndecies, k);
  ret->odd = ms_merge_sn(anumOdd, bnumOdd, aundelayedOdd, bundelayedOdd, oddIndecies, k);

  int elength = first_larger(k, evenIndecies, numEven);
  elength = min(elength, undelayedEven);
  int olength = first_larger(k, oddIndecies, numOdd);
  olength = min(olength, undelayedOdd);
  int outlen = first_larger(k, outIndecies, length);
  outlen = min(outlen, undelayedOdd + undelayedEven);

  for (int i = 1; 2 * i < length; ++i) {
    if (2 * i - 1 < outlen) {
      if (i < elength) {
        ret->numCls += 1;
      }
      if (i - 1 < olength) {
        ret->numCls += 1;
      }
    }
    if (2 * i < outlen && i < elength && i - 1 < olength) {
      ret->numCls += 1;
    }
  }

  ret->numClsThis = ret->numCls;
  ret->numVarThis = outlen;

  ret->numVar = ret->numVarThis;

  if (ret->even != NULL) {
    ret->numCls += ret->even->numCls;
    ret->numVar += ret->even->numVar;
  }
  if (ret->odd != NULL) {
    ret->numCls += ret->odd->numCls;
    ret->numVar += ret->odd->numVar;
  }
  return ret;
}

static SortPlan* sp_make_empty(int k)
{
  SortPlan* sp = malloc(sizeof(SortPlan));
  sp->left = NULL;
  sp->right = NULL;
  sp->merge = NULL;
  sp->k = k;

  return sp;
}

SortPlan* sp_merge_sn(SortPlan* sp1, SortPlan* sp2, int k)
{
  int length1 = sp_length(sp1);
  if (length1 == 0)
    return sp2;

  int length2 = sp_length(sp2);
  if (length2 == 0)
    return sp1;

  int length = length1 + length2;

  int undelayed1 = sp_undelayed(sp1);
  int undelayed2 = sp_undelayed(sp2);

  SortPlan* ret = sp_make_empty(k);

  int* outIndecies = malloc(sizeof(int) * length);
  for (int i = 0; i < length; ++i) {
    outIndecies[i] = i;
  }
  if (k > length)
    k = length;

  ret->left = sp1;
  ret->right = sp2;
  ret->merge = ms_merge_sn(length1, length2, undelayed1, undelayed2, outIndecies, k);

  return ret;
}

static SortPlan* sp_make_singleton(int length, int undelayed, int k)
{
  SortPlan* ret = sp_make_empty(k);
  ret->left = NULL;
  ret->right = NULL;
  int* outIndecies = malloc(sizeof(int));
  outIndecies[0] = 0;
  ret->merge = ms_make_singleton(length, undelayed, outIndecies);
  return ret;
}

SortPlan* sp_make_sn(int length, int undelayed, int k)
{
  if (length <= 1)
    return sp_make_singleton(length, undelayed, k);

  int half = length / 2;
  int rest = length - half;
  assert(length >= undelayed);

  int halfundelayed = min(half, undelayed);
  int restundelayed = undelayed - halfundelayed;

  assert(0 <= halfundelayed && halfundelayed <= half);
  assert(0 <= restundelayed && restundelayed <= rest);
  assert(halfundelayed + restundelayed == undelayed);

  SortPlan* fsthalf = sp_make_sn(half, halfundelayed, k);
  SortPlan* sndhalf = sp_make_sn(rest, restundelayed, k);

  return sp_merge_sn(fsthalf, sndhalf, k);
}

static void ms_minimize_ratio(MergeStep* ms, int k, double clsweight, double varweight)
{
  if (ms == NULL || ms->type != SN_MERGE)
    return;

  int totCls = num_cls_tot(
      ms->in1undelayed,
      ms->in2undelayed,
      ms->outIndecies, k);
  int totVars = num_var_tot(
      ms->in1undelayed,
      ms->in2undelayed,
      ms->outIndecies, k);

  ms_minimize_ratio(ms->odd, k, clsweight, varweight);
  ms_minimize_ratio(ms->even, k, clsweight, varweight);
  ms->numCls = ms->numClsThis;
  ms->numVar = ms->numVarThis;
  if (ms->even != NULL) {
    ms->numVar += ms->even->numVar;
    ms->numCls += ms->even->numCls;
  }
  if (ms->odd != NULL) {
    ms->numVar += ms->odd->numVar;
    ms->numCls += ms->odd->numCls;
  }

  if (clsweight * totCls + varweight * totVars <= clsweight * ms->numCls + varweight * ms->numVar) {
    ms->type = TOT_MERGE;
    ms_free(ms->odd);
    ms->odd = NULL;
    ms_free(ms->even);
    ms->even = NULL;
    ms->numCls = totCls;
    ms->numVar = totVars;
    ms->numClsThis = totCls;
    ms->numVarThis = totVars;
  }
}

int sp_num_cls(SortPlan* sp)
{
  if (sp == NULL)
    return 0;
  int sum = sp->merge->numCls;
  sum += sp_num_cls(sp->left);
  sum += sp_num_cls(sp->right);
  return sum;
}

int sp_num_var(SortPlan* sp)
{
  if (sp == NULL)
    return 0;
  int sum = sp->merge->numVar;
  sum += sp_num_var(sp->left);
  sum += sp_num_var(sp->right);
  return sum;
}

static void sp_minimize_ratio(SortPlan* sp, double clsweight, double varweight)
{
  if (sp == NULL)
    return;
  ms_minimize_ratio(sp->merge, sp->k, clsweight, varweight);
  sp_minimize_ratio(sp->left, clsweight, varweight);
  sp_minimize_ratio(sp->right, clsweight, varweight);
}

static void sp_minimize_cls(SortPlan* sp)
{
  sp_minimize_ratio(sp, 1.0, 0.0);
}

SortPlan* sp_make_min_cls(int length, int undelayed, int k)
{
  SortPlan* sp = sp_make_sn(length, undelayed, k);
  sp_minimize_cls(sp);
  return sp;
}

SortPlan* sp_make_min_ratio(int length, int undelayed, int k, double clsweight, double varweight)
{
  SortPlan* sp = sp_make_sn(length, undelayed, k);
  sp_minimize_ratio(sp, clsweight, varweight);
  return sp;
}

MergeStep* ms_make_min_ratio(int alength, int blength, int aundelayed, int bundelayed, int k, double clsweight, double varweight)
{
  int length = alength + blength;

  int* outIndex = malloc(sizeof(int) * length);
  for (int i = 0; i < length; ++i) {
    outIndex[i] = i;
  }
  k = min(k, alength + blength);
  MergeStep* ms = ms_merge_sn(alength, blength, aundelayed, bundelayed, outIndex, k);

  ms_minimize_ratio(ms, k, clsweight, varweight);
  return ms;
}

static int calc_size_reduction(MergeStep* m, int k)
{
  if (m == NULL || m->type != SN_MERGE)
    return 0;

  int new = m->numClsThis;
  int orig = num_cls_tot(m->in1length,
      m->in2length,
      m->outIndecies, k);

  int newOdd = 0;
  if (m->odd != NULL && m->odd->type != SINGLETON) {
    newOdd = num_cls_tot(m->odd->in1length,
        m->odd->in2length,
        m->odd->outIndecies, k);
  }

  int newEven = 0;
  if (m->even != NULL && m->even->type != SINGLETON) {
    newEven = num_cls_tot(m->even->in1length,
        m->even->in2length,
        m->even->outIndecies, k);
  }

  return orig - new - newOdd - newEven;
}

static int calc_var_increase(MergeStep* m, int k)
{
  if (m == NULL || m->type != SN_MERGE)
    return 0;

  int newOdd = 0;
  if (m->odd != NULL && m->odd->type != SINGLETON) {
    newOdd = num_var_tot(m->odd->in1length,
        m->odd->in2length,
        m->odd->outIndecies, k);
  }

  int newEven = 0;
  if (m->even != NULL && m->even->type != SINGLETON) {
    newEven = num_var_tot(m->even->in1length,
        m->even->in2length,
        m->even->outIndecies, k);
  }

  return newOdd + newEven;
}

typedef struct QueueElem {
  MergeStep* merge;
  int sizeRed;
  double varClsRedRatio;
} QueueElem;

static bool is_sorted(GPtrArray* queue)
{
  for (uint i = 1; i < queue->len; ++i) {
    QueueElem* iel = g_ptr_array_index(queue, i);
    QueueElem* imel = g_ptr_array_index(queue, i - 1);
    if (iel->varClsRedRatio > imel->varClsRedRatio)
      return false;
  }
  return true;
}

static void enqueue(GPtrArray* queue, MergeStep* m, int k)
{
  QueueElem* qe = malloc(sizeof(QueueElem));

  qe->merge = m;
  qe->sizeRed = calc_size_reduction(m, k);
  int varIncrease = calc_var_increase(m, k);
  assert(varIncrease > 0 || qe->sizeRed == 0);
  if (qe->sizeRed > 0) {
    qe->varClsRedRatio = qe->sizeRed / (double)varIncrease;
  } else {
    qe->varClsRedRatio = 0.0;
  }
  uint i = 0;
  for (; i < queue->len; ++i) {
    QueueElem* qei = g_ptr_array_index(queue, i);
    if (qei->varClsRedRatio < qe->varClsRedRatio)
      break;
  }
  g_ptr_array_insert(queue, i, qe);
}

static int sum_cls_tot_ms(GPtrArray* queue, int k)
{
  int sum = 0;
  for (uint i = 0; i < queue->len; ++i) {
    QueueElem* qe = g_ptr_array_index(queue, i);
    if (qe->merge->type == SN_MERGE) {
      sum += num_cls_tot(qe->merge->in1length,
          qe->merge->in2length,
          qe->merge->outIndecies, k);
    } else {
      sum += qe->merge->numCls;
    }
  }
  return sum;
}

static int sum_cls_ms(GPtrArray* queue, int k)
{
  (void)k;
  int sum = 0;
  for (uint i = 0; i < queue->len; ++i) {
    QueueElem* qe = g_ptr_array_index(queue, i);
    sum += qe->merge->numCls;
  }
  return sum;
}

static int make_tot_greedily(GPtrArray* msqueue, int limit, int k)
{
  int totCost = sum_cls_tot_ms(msqueue, k);
  int bestCost = sum_cls_ms(msqueue, k);

  assert(is_sorted(msqueue));
  while (msqueue->len > 0 && totCost - bestCost > limit) {
    assert(is_sorted(msqueue));
    // Consider using sn for ms's by most reduction in number of cls first (greedily)
    QueueElem* qm = g_ptr_array_index(msqueue, 0);
    MergeStep* m = qm->merge;
    int redsize = qm->sizeRed;
    printf("c ratio %f\n", qm->varClsRedRatio);
    g_ptr_array_remove_index(msqueue, 0);
    if (m == NULL || m->type != SN_MERGE)
      continue;
    totCost -= redsize;

    if (m->odd != NULL && m->odd->type == SN_MERGE) {
      enqueue(msqueue, m->odd, k);
    }
    if (m->even != NULL && m->even->type == SN_MERGE) {
      enqueue(msqueue, m->even, k);
    }
  }

  int numChanged = 0;
  int increase = 0;
  for (uint i = 0; i < msqueue->len; ++i) {
    QueueElem* qe = g_ptr_array_index(msqueue, i);
    MergeStep* m = qe->merge;
    if (m == NULL)
      continue;
    if (m->type != SN_MERGE)
      continue;
    numChanged++;
    m->type = TOT_MERGE;
    ms_free(m->odd);
    m->odd = NULL;
    ms_free(m->even);
    m->even = NULL;
    m->numClsThis = num_cls_tot(m->in1length, m->in2length, m->outIndecies, k);
    m->numVarThis = num_var_tot(m->in1length, m->in2length, m->outIndecies, k);
    increase += m->numClsThis - m->numCls;
    m->numCls = m->numClsThis;
    m->numVar = m->numVarThis;
  }
  assert(numChanged != 0 || totCost == bestCost);
  assert(totCost == increase + bestCost);
  return totCost;
}

static void enqueue_all_top_ms(GPtrArray* msqueue, SortPlan* sp)
{
  if (sp == NULL)
    return;
  enqueue(msqueue, sp->merge, sp->k);
  enqueue_all_top_ms(msqueue, sp->left);
  enqueue_all_top_ms(msqueue, sp->right);
}

SortPlan* sp_limit(int length, int undelayed, int k, int limit)
{
  SortPlan* sp = sp_make_min_cls(length, undelayed, k);

  GPtrArray* msqueue = g_ptr_array_new_with_free_func(free);

  enqueue_all_top_ms(msqueue, sp);

  make_tot_greedily(msqueue, limit, k);

  sp_update_costs(sp);

  g_ptr_array_free(msqueue, true);

  return sp;
}

MergeStep* ms_limit(int alength, int blength, int aundelayed, int bundelayed, int k, int limit)
{
  int length = alength + blength;
  int* outindecies = malloc(sizeof(int) * length);
  for (int i = 0; i < length; ++i) {
    outindecies[i] = i;
  }
  k = min(k, alength + blength);
  MergeStep* ms = ms_merge_sn(alength, blength, aundelayed, bundelayed, outindecies, k);

  GPtrArray* msqueue = g_ptr_array_new_with_free_func(free);

  enqueue(msqueue, ms, k);

  make_tot_greedily(msqueue, limit, k);

  ms_update_costs(ms, k);

  g_ptr_array_free(msqueue, true);

  return ms;
}
