#ifndef EXTRA_CLAUSES_H
#define EXTRA_CLAUSES_H

#include <stdbool.h>

/**
 * Additinal clauses used during a sorting scheme.
 *
 * A bidirectional sort sets the kth output to true output if and only if
 * there are k inputs set to true. (The default definition uses "if" instead
 * of "if and only if".)
 *
 * fwdExtraCls (and bwdExtraCls) adds extra clauses to a merge guaranteeing that
 * if that if the kth output is set to true (false resp.) then there are no more
 * than $k$ set to true in the input (resp. at least n-k set to false).
 *
 * The extra clauses added by sortedness asserts that the output of each merge
 * is sorted, that is output $k$ is smaller or equal than output $k-1$.
 *
 */
typedef struct ExtraClauses {
  bool biDirectional;
  bool fwdExtraCls;
  bool bwdExtraCls;
  bool sortedness;
} ExtraClauses;

#endif
