#ifndef MSU3_H
#define MSU3_H
#include "glib.h"
#include "satsolver.h"
#include "sattypes.h"
#include "sortingscheme.h"

typedef struct Msu3 {
  SATSolver* sat;
  Formula* formula;
  GArray* indicators;
  GArray* usedIndicators;
  Literal* sortedIndicators;
  GArray* indicatorInCore;
  GArray* unusedLits;
  SortingScheme* sorter;
  bool sat_with_indicators;
  bool wboUpdate;
  int numUnused;
  int nextUnused;
  int lowerbound;
  int upperbound;
  int numVar;
  int numSorted;
  int sortOutputSize;
  int numClauses;
} Msu3;

Msu3* msu3_make(
    SortingScheme* sorter,
    SATSolver* s,
    Literal* softcl,
    int numSoftLit,
    Literal* hardcl,
    int numHardLit,
    int numVar,
    int numClauses,
    bool wboUpdate);

void msu3_free(Msu3* m);
int msu3_phase1(Msu3* m);
int msu3_step_phase2(Msu3* m);
void msu3_increase_bound(Msu3* m);
void msu3_print_solution(Msu3* m);

/**
 * The msu3 algorithm for solving maxsat
 * /param softcl list of soft clauses
 * /param numSoftLit The length of softcl
 * /param harcl list of hard clauses.
 * /param numHardLit The length of hardcl
 * /param numVar The number of variables
 * /param numClauses The number of clauses
 * /param wboUpdate If the update scheme should
 *   mimic the one used in open-wbo.
 */
void msu3_run(
    SortingScheme*,
    SATSolver*,
    Literal* softcl,
    int numSoftLit,
    Literal* hardcl,
    int numHardLit,
    int numVar,
    int numClauses,
    bool wboUpdate);
#endif
