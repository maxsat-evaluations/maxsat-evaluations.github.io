#ifndef SATSOLVER_H
#define SATSOLVER_H

#include "formula.h"
#include "sattypes.h"
#include "stdbool.h"
#include "stdlib.h"

typedef void (*Assumer)(void* data, Literal l);
typedef void (*Adder)(void* data, Literal l);
typedef bool (*Lookuper)(void* data, Literal);
typedef bool (*CoreLit)(void* data, Literal);
typedef void (*SATFreer)(void* data);
typedef int (*CheckSater)(void* data);
typedef void (*SetPhase)(void* data, Literal, bool);

/**
 * The interface to a SATSolver.
 *
 * The interface uses a data portion, used by the implementer, which is passed
 * to every function. The sat_* functions simply pass the data to the relevant
 * function: sat_assume(s,l) = s->assume(s->data,l). See the documentation of
 * sat_* functions for description of functions.
 *
 */
typedef struct SATSolver {
  void* data; /*!< Pointer to the data used by the SATSolver */
  Assumer assume;
  Adder add;
  Lookuper lookup;
  CoreLit conflict_assumes;
  CheckSater checksat;
  SetPhase setphase;
  SATFreer freer;
} SATSolver;

/**
 * Check whether the given formula is satisfiable.
 */
static inline int sat_check(SATSolver* s)
{
  return s->checksat(s->data);
}

/**
 * Assume a literal to be true. Assumptions are removed
 * between calls to sat_check.
 */
static inline void sat_assume(SATSolver* s, Literal l)
{
  s->assume(s->data, l);
}

/**
 * Add a literal to the set of clauses. 0 separates
 * clauses.
 */
static inline void sat_add(SATSolver* s, Literal l)
{
  s->add(s->data, l);
}

/**
 * Lookup the assignment of a literal after check.
 * Note: add and assume removes assignments so sat_lookup
 * has to be called after check but before add and assume.
 */
static inline bool sat_lookup(SATSolver* s, Literal l)
{
  return s->lookup(s->data, l);
}

/**
 * /return true if l is contained in a core.
 */
static inline bool sat_corelit(SATSolver* s, Literal l)
{
  return s->conflict_assumes(s->data, l);
}

/**
 * Used for tweaking the decision heuristic of the sat solver:
 * l is first tried to assign value b before trying not b, unless
 * propagation said otherwise.
 */
static inline void sat_set_phase(SATSolver* s, Literal l, bool b)
{
  s->setphase(s->data, l, b);
}

/** free the sat solver.*/
static inline void sat_free(SATSolver* s)
{
  s->freer(s->data);
  free(s);
}

#endif
