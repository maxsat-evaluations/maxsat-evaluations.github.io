#include "readwcnf.h"
#include "glib.h"
#include "stdbool.h"
#include "stdint.h"
#include "stdlib.h"

void read_wcnf(
    FILE* file,
    Literal** softcl,
    int* numSoftLit,
    Literal** hardcl,
    int* numHardLit,
    int* numVar,
    int* numClauses)
{
  char line[1024 * 128];
  int nv, nc;
  int top = -1;
  bool isWCNF = false;
  GArray* soft = g_array_new(false, true, sizeof(Literal));
  GArray* hard = g_array_new(false, true, sizeof(Literal));
  *numClauses = 0;
  while (1) {
    char* ret = fgets(line, sizeof(line), file);
    if (ret != line) {
      printf("c Error while reading wcnf file\n");
      abort();
    }
    if (line[0] == 'c')
      continue;
    else if (line[0] == 'p') {
      int ret = sscanf(line, "p cnf %d %d", &nv, &nc);
      if (ret == 2)
        break;
      ret = sscanf(line, "p wcnf %d %d %d", &nv, &nc, &top);
      if (ret >= 2) {
        isWCNF = true;
        break;
      }
    }
    fprintf(stderr, "unexpected line: %s\n", line);
    exit(1);
  }
  for (int i = 1; i <= nc; i++) {
    int cost = 1;
    if (isWCNF) {
      int ret = fscanf(file, " %d", &cost);
      if (ret != 1) {
        printf("c Error while reading weight\n");
        abort();
      }
    }
    while (1) {
      int lit;
      int ret = fscanf(file, "%d", &lit);
      if (ret != 1) {
        printf("c Error while reading literal\n");
        abort();
      }
      if (cost == 1) {
        g_array_append_val(soft, lit);
      } else if (cost == top) {
        g_array_append_val(hard, lit);
      } else {
        printf("c Solver does not support weighted maxsat only partial and unweighted.\n");
        abort();
      }
      if (lit == 0) {
        (*numClauses)++;
        break;
      }
    }
  }
  *softcl = (Literal*)soft->data;
  *hardcl = (Literal*)hard->data;
  *numSoftLit = soft->len;
  *numHardLit = hard->len;
  *numVar = nv;
  g_array_free(soft, false);
  g_array_free(hard, false);
}
