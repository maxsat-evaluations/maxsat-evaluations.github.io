#include <assert.h>
#include <glib.h>
#include <stdio.h>
#include <string.h>

#include "formula.h"
#include "sattypes.h"

//#define CHECK_DUPLICATE

guint lit_to_index(Literal l)
{
  guint v = lit_to_var(l);
  if (l < 0) {
    return v * 2;
  } else {
    return (v * 2) + 1;
  }
}

#ifdef CHECK_DUPLICATE
typedef struct Clause {
  Literal* lits;
  int numLits;
} Clause;

gboolean cls_eq(gconstpointer vcls1, gconstpointer vcls2)
{
  Clause* cls1 = (Clause*)vcls1;
  Clause* cls2 = (Clause*)vcls2;
  if (cls1->numLits != cls2->numLits)
    return false;
  for (uint i = 0; i < cls1->numLits; ++i) {
    if (cls1->lits[i] != cls2->lits[i])
      return false;
  }
  return true;
}

guint cls_hash(gconstpointer vcls)
{
  Clause* cls = (Clause*)vcls;
  guint hash = cls->numLits;
  for (uint i = 0; i < cls->numLits; ++i) {
    hash <<= 2;
    hash += cls->lits[i];
  }
  return hash;
}

void cls_free(void* vcls)
{
  Clause* cls = (Clause*)cls;
  free(cls->lits);
  free(cls);
}
#endif

typedef struct FormulaStruct {
  Literal nextFresh;
  GArray* origVars;
  Literal* lits;
  uint numLits;
  uint litcap;
#ifdef CHECK_DUPLICATE
  GHashTable* hashedCls;
#endif
} FormulaStruct;

int formula_num_variables(Formula* f)
{
  return f->nextFresh;
}

#ifdef CHECK_DUPLICATE
void formula_insert_clause(Formula* f, Literal* l, int numLits)
{
  Literal* l2 = malloc(sizeof(Literal) * numLits);
  memcpy(l2, l, sizeof(Literal) * numLits);
  Clause* cls = malloc(sizeof(Clause));
  cls->lits = l2;
  cls->numLits = numLits;
  g_hash_table_insert(f->hashedCls, cls, (void*)1);
}

bool formula_lookup_clause(Formula* f, Literal* l, int numLits)
{
  Clause cls = { l, numLits };
  return g_hash_table_lookup(f->hashedCls, &cls) != NULL;
}
#endif

Formula* formula_make(void)
{
  Formula* f = malloc(sizeof(Formula));

#ifdef CHECK_DUPLICATE
  f->hashedCls = g_hash_table_new_full(cls_hash, cls_eq, cls_free, NULL);
#endif

  f->nextFresh = 2;

  f->lits = malloc(sizeof(Literal) * 4);
  f->numLits = 0;
  f->litcap = 4;

  f->origVars = g_array_new(true, true, sizeof(Literal));
  int z = 0;
  f->lits[0] = 1;
  f->lits[1] = 0; //Adding constant true
  f->numLits = 2;
  g_array_append_val(f->origVars, z); //zero lit
  return f;
}
Literal formula_constant_false(Formula* f)
{
  (void)f;
  return -1;
}
Literal formula_constant_true(Formula* f)
{
  (void)f;
  return 1;
}

void formula_free(Formula* f)
{
  free(f->lits);
  g_array_free(f->origVars, true);
  free(f);
}
Literal formula_make_fresh(Formula* f)
{
  Literal ret = (f->nextFresh)++;
  return ret;
}

Literal formula_make_orig(Formula* f, Literal l)
{
  int v = lit_to_var(l);
  if (v < (int)f->origVars->len) {
    int prev = g_array_index(f->origVars, Literal, v);
    if (prev != 0) {
      if (l > 0) {
        return prev;
      } else {
        return -prev;
      }
    }
  }
  Literal ret = (f->nextFresh)++;
  if (v + 1 >= (int)f->origVars->len) {
    g_array_set_size(f->origVars, 2 * (v + 1));
  }
  g_array_index(f->origVars, Literal, v) = ret;
  if (l > 0) {
    return ret;
  } else {
    return -ret;
  }
}

Literal* formula_get_new_clauses(Formula* f, uint* num)
{
  (*num) = f->numLits;
  f->numLits = 0;
  return f->lits;
}

void formula_cl(Formula* f, int numLit, ...)
{
  va_list ls;
  va_start(ls, numLit);
  Literal* l = malloc(sizeof(Literal) * numLit);
  for (int i = 0; i < numLit; ++i) {
    l[i] = va_arg(ls, Literal);
    assert(l[i] != 0);
  }
  va_end(ls);
  formula_add_clause(f, numLit, l);
  free(l);
}

void formula_add_clause(Formula* f, int numLit, Literal* l)
{
  if (f->litcap <= f->numLits + numLit + 1) {
    f->litcap = 2 * f->litcap + numLit + 2;
    f->lits = realloc(f->lits, sizeof(Literal) * f->litcap);
  }
#ifdef CHECK_DUPLICATE
  assert(!formula_lookup_clause(f, l, numLit));
  formula_insert_clause(f, l, numLit);
#endif
  for (int i = 0; i < numLit; ++i) {
    assert(f->numLits < f->litcap);
    f->lits[(f->numLits)++] = l[i];
  }
  f->lits[(f->numLits)++] = 0;
}

Literal formula_lookup_orig(Formula* f, Literal l)
{
  if (l >= (int)f->origVars->len) {
    return 0;
  } else {
    return g_array_index(f->origVars, Literal, l);
  }
}
