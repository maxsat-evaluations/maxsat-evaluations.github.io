#ifndef SORTING_PLAN_H
#define SORTING_PLAN_H

#include "common.h"
#include "sattypes.h"

/**
 * SortPlan is used by mixed to make a parametrized choice
 * between sortingnetworks and totalizer networks. The plan
 * contains a set of merges each either a sorting network merge,
 * totalizer merge or a "singleton merge" (only merge one variable).
 */

/** The types of merges */
typedef enum {
  SN_MERGE,  /*!< Sorting Network Merge */
  TOT_MERGE, /*!< Totalizer Merge */
  SINGLETON  /*!< Only merge a single variable */
} MergePlanType;

/**
 * A Merge step is one of the MergePlanTypes and
 * contains information about the input and output
 * lengths aswell as how many variables are delayed.
 */
typedef struct MergeStep {
  MergePlanType type;     /*!< The type of merge */
  int in1length;          /*!< Length of input 1 */
  int in2length;          /*!< Length of input 2 */
  int in1undelayed;       /*!< Number of delayed variables in input 1*/
  int in2undelayed;       /*!< Number of delayed variables in input 2*/
  struct MergeStep* odd;  /*!< NULL if type == TOT_MERGE */
  struct MergeStep* even; /*!< NULL if type == TOT_MERGE */
  int* outIndecies;       /*!< The smallest k for which output at each index is used */
  int numClsThis;         /*!< Number of clauses in this merge */
  int numVarThis;         /*!< Number of variables in this merge */
  int numCls;             /*!< Number of clauses in this merge and */
                          /*!< odd->numCls + even->numCls */
  int numVar;             /*!< Number of variables in this merge and
               odd->numCls + even->numCls */
} MergeStep;

typedef struct SortPlan {
  MergeStep* merge;       /* The merge performed at the root level */
  int k;                  /* The number of outputs needed */
  struct SortPlan* left;  /* The left recursive step of the sort */
  struct SortPlan* right; /* The right recursive step of the sort */
} SortPlan;

/** Free a merge step*/
void ms_free(MergeStep* ms);

/** Construct a merge step using sorting networks only. */
MergeStep* ms_merge_sn(int alength, int blength, int undelayeda, int undelayedb, int* outIndecies, int k);
/** Construct a merge step using totalizer only. */
MergeStep* ms_merge_tot(int alength, int blength, int undelayeda, int undelayedb, int* outIndecies, int k);

/** Make a sorting plan using sorting networks only */
SortPlan* sp_make_sn(int length, int undelayed, int k);
/** Merge two sortingplans. */
SortPlan* sp_merge_sn(SortPlan* sp1, SortPlan* sp2, int k);

/** Free a sortingplan. */
void sp_free(SortPlan* sp);

/** Constructs a SortPlan where number of TOT_MERGE is maximized,
st. num_cls - num_cls_sn  <= limit */
SortPlan* sp_limit(int length, int undelayed, int k, int limit);
/** Constructs a MergeStep where number of TOT_MERGE is maximized,
st. num_cls - num_cls_sn  <= limit */
MergeStep* ms_limit(int alength, int blength, int aundelayed, int bundelayed, int k, int limit);

/** /return Number of clauses used in the sortingplan. */
int sp_num_cls(SortPlan* sp);
/** /return Number of variables used in the sortingplan. */
int sp_num_var(SortPlan* sp);

/** /return a sorting plan where the number of clauses is minimized */
SortPlan* sp_make_min_cls(int length, int undelayed, int k);
/** /return a sorting plan where clsweight * num_clauses + varweight * num_varaibles is minimized.*/
SortPlan* sp_make_min_ratio(int length, int undelayed, int k, double clsweight, double varweight);
/** /return a merge step where clsweight * num_clauses + varweight * num_varaibles is minimized.*/
MergeStep* ms_make_min_ratio(int alength, int blength, int aundelayed, int bundelayed, int k, double clsweight, double varweight);

/** /return The number of clauses made by a totalizer network */
int num_cls_tot(int in1, int in2, int* outIndecies, int k);
/** /return The number of variables made by a totalizer network */
int num_var_tot(int in1, int in2, int* outIndecies, int k);

#endif
