#include "common.h"
#include "stdio.h"
#include "string.h"
int first_larger(int i, int* is, int length)
{
  for (int j = 0; j < length; ++j) {
    if (is[j] >= i) {
      return j;
    }
  }
  return length;
}
int first_zero(int* is, int length)
{
  for (int j = 0; j < length; ++j) {
    if (is[j] == 0) {
      return j;
    }
  }
  return length;
}
bool zeros_only_end(int* is, int length)
{
  bool iszero = false;
  int firstzero = length;
  for (int j = 0; j < length; ++j) {
    if (is[j] == 0) {
      iszero = true;
      firstzero = min(firstzero, j);
    }
    if (iszero && is[j] != 0) {
      fprintf(stderr, "%d %d\n", firstzero, j);
      return false;
    }
  }
  return true;
}

bool no_zeros(int* is, int length)
{
  for (int j = 0; j < length; ++j) {
    if (is[j] == 0) {
      return false;
    }
  }
  return true;
}

#if GLIB_MAJOR_VERSION < 2 || (GLIB_MAJOR_VERSION <= 2 && GLIB_MINOR_VERSION < 40)
void g_ptr_array_insert(GPtrArray* array,
    gint index_,
    gpointer data)
{

  g_ptr_array_set_size(array, array->len + 1);

  if (index_ < 0)
    index_ = array->len;

  if (index_ < array->len)
    memmove(&(array->pdata[index_ + 1]),
        &(array->pdata[index_]),
        (array->len - index_) * sizeof(gpointer));

  array->pdata[index_] = data;
}
#endif
