#ifndef FORMULA_H
#define FORMULA_H

#include "sattypes.h"
#include <stdbool.h>
#include <stdlib.h>


/**
 * A Formula is used to build a set of clauses
 * (a CNF formula). Formula contains functionality
 * for keeping track of fresh variables.
 *
 * The Cnf format uses indecies for variables. Formula
 * optimizes the maximum index used by mapping between
 * declared literals (fresh and original) and outputted
 * literals. Use make_fresh and make_orig to declare
 * variables. With make_orig you can declare a original literal reference
 * to your variable. Use lookup_orig to find what original literal
 * the outputted literal corresponds to:
 *
 *     Formula * f = formula_make();
 *     Literal myOrig = 2;
 *     Literal l1 = formula_make_orig(f,myOrig);
 *
 *     formula_cl(f,1,l1);
 *
 *     formula_get_new_clause(f); // Returns the clause {l1}
 *     formula_lookup_orig(f,myOrig); // Returns l1
 *     formula_free(f);
 *
 */
typedef struct FormulaStruct Formula;

/**
 * Returns the new clauses added to the formula
 * since last time the formula_get_new_clauses
 * was called.
 */
Literal* formula_get_new_clauses(Formula*, uint*);

/** Make a new formula */
Formula* formula_make(void);
/** Make a new formula */
void formula_free(Formula*);

/** Add a clause to the formula */
void formula_add_clause(Formula*, int numLit, Literal*);
/** Add a clause to the formula */
void formula_cl(Formula*, int numLit, ...);
/** /return the number of variables in the formula */
int formula_num_variables(Formula*);

/** /return A literal the is set to constant true*/
Literal formula_constant_true(Formula*);
/** /return A literal the is set to constant false*/
Literal formula_constant_false(Formula* f);
/** /return A fresh literal*/
Literal formula_make_fresh(Formula*);
/** /param l A literal occuring in your original formula,
 *           that you would want to look up later.
 *  /return A literal to use in input clauses.
 */
Literal formula_make_orig(Formula*, Literal l);
/** /param l The original literal you would like to look up.
 *  /return The outputted literal it corresponds to or 0 if
 *        the given literal is not an original literal.*/
Literal formula_lookup_orig(Formula*, Literal l);

#endif
