#include "sortingnetwork.h"
#include "common.h"
#include <assert.h>
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { MOVE,
  MERGE,
  ADDEXTRA } MergeType;

typedef struct Merge {
  MergeType type;
  Literal* in1;
  Literal* in2;
  Literal* out;
  Literal* out2;
  int* outIndex;
  int alength;
  int blength;
  int maxa;
  int maxb;
  int k;
} Merge;

typedef struct NetworkStruct {
  GPtrArray* merges;
  GPtrArray* toFree;
  ExtraClauses extra;
} NetworkStruct;

void sn_add_merge(SortingNetwork* t, Literal* out, Literal* as, Literal* bs, int* outIndex, int alength, int blength, int maxa, int maxb, int k)
{
  Merge* u = malloc(sizeof(Merge));
  g_ptr_array_add(t->merges, u);
  u->type = MERGE;
  u->in1 = as;
  u->in2 = bs;
  u->out = out;
  u->out2 = NULL;
  u->outIndex = outIndex;
  u->alength = alength;
  u->blength = blength;
  u->maxa = maxa;
  u->maxb = maxb;
  u->k = k;
}
void sn_add_extra(SortingNetwork* t, Literal* out, Literal* as, Literal* bs, int* outIndex, int alength, int blength, int maxa, int maxb, int k)
{
  Merge* u = malloc(sizeof(Merge));
  g_ptr_array_add(t->merges, u);
  u->type = ADDEXTRA;
  u->in1 = as;
  u->in2 = bs;
  u->out = out;
  u->out2 = NULL;
  u->outIndex = outIndex;
  u->alength = alength;
  u->blength = blength;
  u->maxa = maxa;
  u->maxb = maxb;
  u->k = k;
}
void sn_add_move(SortingNetwork* t, Literal* out, Literal* out2, Literal* as, int alength)
{
  Merge* u = malloc(sizeof(Merge));
  g_ptr_array_add(t->merges, u);
  u->type = MOVE;
  u->in1 = as;
  u->out = out;
  u->out2 = out2;
  u->alength = alength;
}

SortingNetwork* sn_make(ExtraClauses extra)
{
  SortingNetwork* sn = malloc(sizeof(NetworkStruct));
  sn->merges = g_ptr_array_new_with_free_func(free);
  sn->toFree = g_ptr_array_new_with_free_func(free);
  sn->extra = extra;
  return sn;
}
void sn_free(SortingNetwork* sn)
{
  g_ptr_array_free(sn->merges, true);
  g_ptr_array_free(sn->toFree, true);
  free(sn);
}

void sn_add_to_free(SortingNetwork* t, void* frs)
{
  g_ptr_array_add(t->toFree, frs);
}

void sn_or(SortingNetwork* t, Formula* f, Literal* out, Literal* ain, Literal* bin, int index, int k)
{
  if (index >= k) {
    *out = 0;
    return;
  }
  if (((*ain) != 0 || (*bin) != 0) && (*out) == 0)
    (*out) = formula_make_fresh(f);

  if ((*ain) != 0) {
    formula_cl(f, 2, *out, -(*ain));
  }
  if ((*bin) != 0) {
    formula_cl(f, 2, *out, -(*bin));
  }
  if (t->extra.biDirectional) {
    if ((*ain) != 0 && (*bin) != 0) {
      if ((*out) == 0) {
        (*out) = formula_make_fresh(f);
      }
      formula_cl(f, 3, -(*out), (*bin), (*ain));
    }
  }
}

void sn_and(SortingNetwork* t, Formula* f, Literal* out, Literal* ain, Literal* bin, int index, int k)
{
  if (index >= k) {
    *out = 0;
    return;
  }
  if (t->extra.biDirectional) {
    if (((*ain) != 0 || (*bin) != 0) && (*out) == 0)
      (*out) = formula_make_fresh(f);

    if ((*ain) != 0) {
      formula_cl(f, 2, -(*out), (*ain));
    }
    if ((*bin) != 0) {
      formula_cl(f, 2, -(*out), (*bin));
    }
  }
  if ((*ain) != 0 && (*bin) != 0) {
    if ((*out) == 0) {
      (*out) = formula_make_fresh(f);
    }
    formula_cl(f, 3, *out, -(*bin), -(*ain));
  }
}

void splitEvenOdd(Literal* a, Literal** aeven, Literal** aodd, int length, int* elength, int* olength)
{
  *olength = length / 2;
  *elength = length - (*olength);

  *aeven = malloc(sizeof(Literal) * (*elength));
  *aodd = malloc(sizeof(Literal) * (*olength));
  memset(*aeven, 0, sizeof(Literal) * (*elength));
  memset(*aodd, 0, sizeof(Literal) * (*olength));

  int e = 0, o = 0;
  for (int i = 0; i < length;) {
    (*aeven)[e++] = a[i++];
    if (i >= length)
      break;
    (*aodd)[o++] = a[i++];
  }
  assert(e == *elength);
  assert(o == *olength);
  assert(first_zero(*aeven, e) + first_zero(*aodd, o)
      == first_zero(a, length));
}

void splitOddEvenIndecies(int* indecies, int** oddInd, int** evenInd, int numOdd, int numEven)
{
  (*evenInd) = malloc(sizeof(Literal) * numEven);
  (*oddInd) = malloc(sizeof(Literal) * numOdd);
  (*evenInd)[0] = indecies[0];
  int length = numOdd + numEven;
  for (int i = 1; 2 * i < length; ++i) {
    assert(i < numEven);
    assert(i - 1 < numOdd);
    (*evenInd)[i] = min(indecies[2 * i - 1], indecies[2 * i]);
    (*oddInd)[i - 1] = min(indecies[2 * i - 1], indecies[2 * i]);
  }
  if (numEven == numOdd) {
    (*oddInd)[numOdd - 1] = indecies[length - 1];
  } else if (numEven == numOdd + 2) {
    (*evenInd)[numEven - 1] = indecies[length - 1];
  }
}

Literal* sn_k_merge_worker(SortingNetwork* t, Literal* as, Literal* bs, int* outIndex, int alength, int blength, Formula* f, int k)
{
  if (alength == 0) {
    return bs;
  }
  if (blength == 0) {
    return as;
  }
  assert(alength + 1 == blength
      || blength + 1 == alength || alength == blength);
  if (alength == 1 && blength == 1) {
    Literal* out = malloc(sizeof(Literal) * 2);
    memset(out, 0, sizeof(Literal) * 2);
    sn_add_to_free(t, out);
    sn_or(t, f, out, as, bs, outIndex[0], k);
    sn_and(t, f, out + 1, as, bs, outIndex[1], k);
    int maxa = 0;
    int maxb = 0;
    if (as[0] != 0)
      maxa = 1;
    if (bs[0] != 0)
      maxb = 1;
    sn_add_merge(t, out, as, bs, outIndex, alength, blength, maxa, maxb, k);
    assert(zeros_only_end(out, alength + blength));
    assert(zeros_only_end(as, alength));
    assert(zeros_only_end(bs, blength));
    return out;
  }
  int numAOdd, numAEven, numBEven, numBOdd;
  Literal *aevens, *aodds, *bevens, *bodds;
  splitEvenOdd(as, &aevens, &aodds, alength, &numAEven, &numAOdd);
  splitEvenOdd(bs, &bevens, &bodds, blength, &numBEven, &numBOdd);
  int numOdd = numAOdd + numBOdd;
  int numEven = numAEven + numBEven;
  int length = alength + blength;
  assert(numOdd + numEven == length);
  sn_add_to_free(t, aevens);
  sn_add_to_free(t, bevens);
  sn_add_to_free(t, aodds);
  sn_add_to_free(t, bodds);
  sn_add_move(t, aevens, aodds, as, alength);
  sn_add_move(t, bevens, bodds, bs, blength);

  int *oddIndecies, *evenIndecies;
  splitOddEvenIndecies(outIndex, &oddIndecies, &evenIndecies, numOdd, numEven);
  sn_add_to_free(t, oddIndecies);
  sn_add_to_free(t, evenIndecies);

  Literal* sortEvens = sn_k_merge_worker(t, aevens, bevens, evenIndecies, numAEven, numBEven, f, k);
  Literal* sortOdds = sn_k_merge_worker(t, aodds, bodds, oddIndecies, numAOdd, numBOdd, f, k);
  Literal* out = malloc(sizeof(Literal) * length);
  memset(out, 0, sizeof(Literal) * length);
  sn_add_to_free(t, out);
  int maxeven = first_zero(sortEvens, numEven);
  int maxodd = first_zero(sortOdds, numOdd);
  sn_add_merge(t, out, sortEvens, sortOdds, outIndex, numEven, numOdd, maxeven, maxodd, k);
  out[0] = sortEvens[0];
  for (int i = 1; 2 * i < length; ++i) {
    assert(i < numEven);
    assert(i - 1 < numOdd);
    if (2 * i - 1 < length && 2 * i - 1 < k) {
      sn_or(t, f, out + (2 * i) - 1, sortEvens + i, sortOdds + i - 1, outIndex[2 * i - 1], k);
    }
    if (2 * i < length && 2 * i < k) {
      sn_and(t, f, out + (2 * i), sortEvens + i, sortOdds + i - 1, outIndex[2 * i], k);
    }
  }
  for (int i = k; i < length; ++i) {
    out[i] = 0;
  }
  if (length <= k && numEven == numOdd) {
    out[length - 1] = sortOdds[numOdd - 1];
  } else if (length <= k && numEven == numOdd + 2) {
    out[length - 1] = sortEvens[numEven - 1];
  } else {
    assert(length > k || (numEven == numOdd + 1));
  }

  // Add optional redundant clauses
  if ((t->extra.fwdExtraCls || t->extra.bwdExtraCls || t->extra.sortedness) && length > 3) {
    int maxa = first_zero(as, alength);
    int maxb = first_zero(bs, blength);
    for (int i = 1; i < alength; ++i) {
      if (t->extra.fwdExtraCls && as[i] != 0 && out[i] != 0 && outIndex[i] < k) {
        formula_cl(f, 2, out[i], -as[i]);
      }
      if (t->extra.bwdExtraCls && as[(alength - 1) - i] != 0 && out[(length - 1) - i] != 0 && outIndex[(length - 1) - i] < k) {
        formula_cl(f, 2, -out[(length - 1) - i], as[(alength - 1) - i]);
      }
    }
    for (int i = 1; i < blength; ++i) {
      if (t->extra.fwdExtraCls && bs[i] != 0 && out[i] != 0 && outIndex[i] < k) {
        formula_cl(f, 2, out[i], -bs[i]);
      }
      if (t->extra.bwdExtraCls && bs[(blength - 1) - i] != 0 && out[(length - 1) - i] != 0 && outIndex[(length - 1) - i] < k) {
        formula_cl(f, 2, -out[(length - 1) - i], bs[(blength - 1) - i]);
      }
    }
    if (t->extra.sortedness) {
      for (int i = 0; i < length - 1; i += 2) {
        if (out[i] != 0 && out[i + 1] != 0) {
          formula_cl(f, 2, out[i], -out[i + 1]);
        }
      }
    }
    sn_add_extra(t, out, as, bs, outIndex, alength, blength, maxa, maxb, k);
  }
  assert(zeros_only_end(out, length));
  assert(zeros_only_end(as, alength));
  assert(zeros_only_end(bs, blength));
  assert(zeros_only_end(sortEvens, numEven));
  assert(zeros_only_end(sortOdds, numOdd));
  return out;
}

Literal* sn_k_merge(SortingNetwork* t, Literal* as, Literal* bs, uint alength, uint blength, Formula* f, int k)
{
  int* outIndex = malloc(sizeof(int) * (alength + blength));
  for (uint i = 0; i < alength + blength; ++i) {
    outIndex[i] = i;
  }
  sn_add_to_free(t, outIndex);
  return sn_k_merge_worker(t, as, bs, outIndex, alength, blength, f, k);
}

Literal* sn_k_sort(SortingNetwork* t, Literal* lits, uint length, Formula* f, int k)
{
  if (length < 1) {
    return NULL;
  }
  if (length == 1) {
    return lits;
  }
  int alength = length / 2;
  int blength = length - alength;
  Literal* as = sn_k_sort(t, lits, alength, f, k);
  Literal* bs = sn_k_sort(t, lits + alength, blength, f, k);
  Literal* out = sn_k_merge(t, as, bs, alength, blength, f, k);
  return out;
}

static bool inside(int start, int index, int end)
{
  return start <= index && end > index;
}

static bool checkbounds(int astart, int aend, int bstart, int bend, int outstart, int outend, int i, int j, int r)
{
  return (inside(astart, i, aend) || inside(bstart, j, bend) || outstart <= r) && outend > r;
}

void sn_k_update(SortingNetwork* t, Formula* f, int k)
{
  GPtrArray* ms = t->merges;
  for (uint i = 0; i < ms->len; ++i) {
    Merge* m = g_ptr_array_index(ms, i);
    if (m->type == MERGE) {
      int length = m->alength + m->blength;
      assert(length > 0);
      int astart = min(m->maxa, m->k);
      int bstart = min(m->maxb, m->k);
      m->maxa = first_zero(m->in1, m->alength);
      m->maxb = first_zero(m->in2, m->blength);
      int aend = min(k, m->maxa);
      int bend = min(k, m->maxb);
      int outstart = first_larger(m->k, m->outIndex, length);
      int outend = first_larger(k, m->outIndex, length);
      assert(zeros_only_end(m->out, length));
      assert(zeros_only_end(m->in1, m->alength));
      assert(zeros_only_end(m->in2, m->blength));
      if (m->alength == 1 && m->blength == 1) {
        if (checkbounds(astart, aend, bstart, bend, outstart, outend, 0, 0, 0)) {
          if (inside(astart, 0, aend)) {
            if (m->out[0] == 0)
              m->out[0] = formula_make_fresh(f);
            formula_cl(f, 2, m->out[0], -m->in1[0]);
          }
          if (inside(bstart, 0, bend)) {
            if (m->out[0] == 0)
              m->out[0] = formula_make_fresh(f);
            formula_cl(f, 2, m->out[0], -m->in2[0]);
          }
          if (t->extra.biDirectional) {
            if (m->in1[0] != 0 && m->in2[0] != 0) {
              if (m->out[0] == 0)
                m->out[0] = formula_make_fresh(f);
              formula_cl(f, 3, -m->out[0], m->in1[0], m->in2[0]);
            }
          }
        }
        if (checkbounds(astart, aend, bstart, bend, outstart, outend, 0, 0, 1)) {
          if (t->extra.biDirectional) {
            if (inside(astart, 0, aend)) {
              if (m->out[1] == 0)
                m->out[1] = formula_make_fresh(f);
              formula_cl(f, 2, -m->out[1], m->in1[0]);
            }
            if (inside(bstart, 0, bend)) {
              if (m->out[1] == 0)
                m->out[1] = formula_make_fresh(f);
              formula_cl(f, 2, -m->out[1], m->in2[0]);
            }
          }
          if (m->in1[0] != 0 && m->in2[0] != 0) {
            if (m->out[1] == 0)
              m->out[1] = formula_make_fresh(f);
            formula_cl(f, 3, m->out[1], -m->in1[0], -m->in2[0]);
          }
        }
        if (m->in1[0] != 0)
          m->maxa = 1;
        if (m->in2[0] != 0)
          m->maxb = 1;
        m->k = k;
        continue;
      }
      m->out[0] = m->in1[0];
      for (int i = 1; 2 * i < length; ++i) {
        assert(i < m->alength);
        assert(i - 1 < m->blength);
        if (checkbounds(astart, aend, bstart, bend, outstart, outend, i, i - 1, 2 * i - 1)) {

          if (inside(astart, i, aend)) {
            if (m->out[2 * i - 1] == 0)
              m->out[2 * i - 1] = formula_make_fresh(f);
            formula_cl(f, 2, m->out[2 * i - 1], -m->in1[i]);
          }
          if (inside(bstart, i - 1, bend)) {
            if (m->out[2 * i - 1] == 0)
              m->out[2 * i - 1] = formula_make_fresh(f);
            formula_cl(f, 2, m->out[2 * i - 1], -m->in2[i - 1]);
          }
          if (t->extra.biDirectional) {
            if (m->in1[i] != 0 && m->in2[i - 1] != 0) {
              if (m->out[2 * i - 1] == 0)
                m->out[2 * i - 1] = formula_make_fresh(f);
              formula_cl(f, 3, -m->out[2 * i - 1], m->in1[i], m->in2[i - 1]);
            }
          }
        }
        if (checkbounds(astart, aend, bstart, bend, outstart, outend, i, i - 1, 2 * i)) {
          if (t->extra.biDirectional) {
            if (inside(astart, i, aend)) {
              if (m->out[2 * i] == 0)
                m->out[2 * i] = formula_make_fresh(f);
              formula_cl(f, 2, -m->out[2 * i], m->in1[i]);
            }
            if (inside(bstart, i - 1, bend)) {
              if (m->out[2 * i] == 0)
                m->out[2 * i] = formula_make_fresh(f);
              formula_cl(f, 2, -m->out[2 * i], m->in2[i - 1]);
            }
          }
          if (m->in1[i] != 0 && m->in2[i - 1] != 0) {
            if (m->out[2 * i] == 0)
              m->out[2 * i] = formula_make_fresh(f);
            formula_cl(f, 3, m->out[2 * i], -m->in1[i], -m->in2[i - 1]);
          }
        }
      }
      if (length <= k && m->alength == m->blength) {
        m->out[length - 1] = m->in2[m->blength - 1];
      } else if (length <= k && m->alength == m->blength + 2) {
        m->out[length - 1] = m->in1[m->alength - 1];
      } else {
        assert(length > k || m->alength == m->blength + 1);
      }
      m->k = k;
      assert(zeros_only_end(m->out, length));
      assert(zeros_only_end(m->in1, m->alength));
      assert(zeros_only_end(m->in2, m->blength));
    } else if (m->type == MOVE) {
      int e = 0;
      int o = 0;
      for (int i = 0; i < m->alength;) {
        m->out[e++] = m->in1[i++];
        if (i >= m->alength)
          break;
        m->out2[o++] = m->in1[i++];
      }
      assert(zeros_only_end(m->out, e));
      assert(zeros_only_end(m->out2, o));
    } else if (m->type == ADDEXTRA) {
      int alength = m->alength;
      int blength = m->blength;
      int length = alength + blength;
      int astart = min(m->maxa, m->k);
      int bstart = min(m->maxb, m->k);
      m->maxa = first_zero(m->in1, alength);
      m->maxb = first_zero(m->in2, blength);
      int aend = min(k, m->maxa);
      int bend = min(k, m->maxb);
      int outstart = first_larger(m->k, m->outIndex, length);
      int outend = first_larger(k, m->outIndex, length);
      for (int i = 1; i < alength; ++i) {
        if (t->extra.fwdExtraCls && m->in1[i] != 0 && m->out[i] != 0 && (inside(outstart, i, outend) || inside(astart, i, aend))) {
          formula_cl(f, 2, m->out[i], -m->in1[i]);
        }
        if (t->extra.bwdExtraCls && m->in1[(alength - 1) - i] != 0 && m->out[(length - 1) - i] != 0 && (inside(outstart, (length - 1) - i, outend) || inside(astart, (alength - 1) - i, aend))) {
          formula_cl(f, 2, -m->out[(length - 1) - i], m->in1[(alength - 1) - i]);
        }
      }
      for (int i = 1; i < blength; ++i) {
        if (t->extra.fwdExtraCls && m->in2[i] != 0 && m->out[i] != 0 && (inside(outstart, i, outend) || inside(bstart, i, bend))) {
          formula_cl(f, 2, m->out[i], -m->in2[i]);
        }
        if (t->extra.bwdExtraCls && m->in2[(blength - 1) - i] != 0 && m->out[(length - 1) - i] != 0 && (inside(outstart, (length - 1) - i, outend) || inside(bstart, (blength - 1) - i, bend))) {
          formula_cl(f, 2, -m->out[(length - 1) - i], m->in2[(blength - 1) - i]);
        }
      }
      if (t->extra.sortedness) {
        for (int i = 0; i < length - 1; i += 2) {
          if ((inside(outstart, i, outend) || inside(outstart, i + 1, outend)) && m->out[i] != 0 && m->out[i + 1] != 0) {
            formula_cl(f, 2, m->out[i], -m->out[i + 1]);
          }
        }
      }
      assert(zeros_only_end(m->out, length));
      assert(zeros_only_end(m->in1, m->alength));
      assert(zeros_only_end(m->in2, m->blength));
      m->k = k;
    } else {
      assert(false);
    }
  }
}

SortingScheme* sn_make_scheme(ExtraClauses extra)
{
  SortingScheme* ret = malloc(sizeof(SortingScheme));
  ret->encodingData = sn_make(extra);
  ret->merge = (Merger)sn_k_merge;
  ret->sort = (Sorter)sn_k_sort;
  ret->update = (Updater)sn_k_update;
  ret->freer = (Freer)sn_free;
  return ret;
}
