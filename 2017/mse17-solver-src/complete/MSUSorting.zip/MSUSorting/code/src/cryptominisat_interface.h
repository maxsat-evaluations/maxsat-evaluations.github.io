#ifndef CRYPTOMINISAT_INTERFACE_H
#define CRYPTOMINISAT_INTERFACE_H
#ifdef __cplusplus
extern "C" {
#endif
#include "satsolver.h"

/**
 * /return a SATSolver (/see satsolver.h) that uses the
 *   glucose sat solver to solve formulas.
 */
SATSolver* cryptominisat_satmake();
#ifdef __cplusplus
}
#endif
#endif
