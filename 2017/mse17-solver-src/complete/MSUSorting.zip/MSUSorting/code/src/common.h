#ifndef COMMON_H
#define COMMON_H
#include <glib.h>
#include <stdbool.h>
#include <stdlib.h>

/**
 * The following file contains help functions used
 * throughout the project.
 */

/** \return the smallest value of a and b */
#define min(a, b) (((a) > (b)) ? (b) : (a))
/** \return the largest value of a and b */
#define max(a, b) (((a) < (b)) ? (b) : (a))
/** \return the absolute value value of a*/
#define abs(a) (((a) > 0) ? (a) : (-a))

/** \param is  a list of integers.
 *  \param length  the number of integers in is
 *  \return the first index of a value in is that is larger than i.
 */
int first_larger(int i, int* is, int length);
/** \param is  a list of integers.
 *  \param length  the number of integers in is
 *  \return the first index of a zero in is.
 */
int first_zero(int* is, int length);
/** \param is  a list of integers.
 *  \param length  the number of integers in is.
 *  \return true if is only has zeros in a continous block at the end.
 */
bool zeros_only_end(int* is, int length);
/** \param is  a list of integers.
 *  \param length  the number of integers in is.
 *  \return true if is contains no zeros.
 */
bool no_zeros(int* is, int length);

/**
 * Depending on the version of glib, it might not contain
 * g_ptr_array_insert. We therefore insert a version of
 * it if the system does not provide this function.
 */
#if GLIB_MAJOR_VERSION < 2 || (GLIB_MAJOR_VERSION <= 2 && GLIB_MINOR_VERSION < 40)
void g_ptr_array_insert(GPtrArray* array,
    gint index_,
    gpointer data);
#endif
#endif
