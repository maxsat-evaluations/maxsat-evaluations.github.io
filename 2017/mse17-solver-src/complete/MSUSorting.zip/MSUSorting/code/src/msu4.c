#include "msu4.h"
#include "assert.h"
#include "common.h"
#include "formula.h"
#include "glib.h"
#include "picosat.h"
#include "sortingscheme.h"
#include "stdbool.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "totalizer.h"

Msu4* msu4_make(
    SortingScheme* sorter,
    SATSolver* solver,
    Literal* softcl,
    int numSoftLit,
    Literal* hardcl,
    int numHardLit,
    int numVar,
    int numClauses,
    bool wboUpdate)
{
  Msu4* ret = malloc(sizeof(Msu4));
  ret->solver = solver;
  ret->wboUpdate = wboUpdate;
  ret->formula = formula_make();
  ret->indicators = g_array_new(false, true, sizeof(Literal));
  ret->usedIndicators = g_array_new(false, true, sizeof(Literal));
  ret->unusedLits = g_array_new(true, true, sizeof(Literal));
  ret->sortedIndicators = NULL;
  ret->numSorted = 0;
  ret->nextUnused = 0;
  ret->numUnused = 0;
  ret->sortOutputSize = 0;
  ret->indicatorInCore = g_array_new(false, true, sizeof(bool));
  ret->sat_with_indicators = false;
  ret->lowerbound = 0;
  ret->upperbound = numSoftLit;
  ret->numVar = numVar;
  ret->sorter = sorter;
  ret->numClauses = numClauses;
  ret->bestSolution = malloc(sizeof(bool) * numVar);

  int numCl = 0;
  GArray* cl = g_array_new(false, false, sizeof(Literal));
  bool false_ = false;
  g_array_set_size(cl, 0);
  for (int i = 0; i < numSoftLit; ++i) {
    if (softcl[i] == 0) {
      Literal indicator = formula_make_fresh(ret->formula);
      g_array_append_val(cl, indicator);
      g_array_append_val(ret->indicators, indicator);
      g_array_append_val(ret->indicatorInCore, false_);
      formula_add_clause(ret->formula, cl->len, (Literal*)cl->data);
      numCl++;
      g_array_set_size(cl, 0);
    } else {
      Literal l = formula_make_orig(ret->formula, softcl[i]);
      g_array_append_val(cl, l);
    }
  }
  for (int i = 0; i < numHardLit; ++i) {
    if (hardcl[i] == 0) {
      formula_add_clause(ret->formula, cl->len, (Literal*)cl->data);
      g_array_set_size(cl, 0);
      numCl++;
    } else {
      Literal l = formula_make_orig(ret->formula, hardcl[i]);
      g_array_append_val(cl, l);
    }
  }
  g_array_free(cl, true);
  for (uint i = 0; i < ret->indicators->len; ++i) {
    Literal l = g_array_index(ret->indicators, Literal, i);
    sat_assume(ret->solver, -l);
  }
  assert(numCl == numClauses);
  uint numW = 0;
  Literal* el = formula_get_new_clauses(ret->formula, &numW);
  for (uint i = 0; i < numW; ++i) {
    sat_add(ret->solver, el[i]);
  }
  return ret;
}

Msu4 * msu4_convert(Msu3 * m,bool * bestSolution){
  Msu4* ret = malloc(sizeof(Msu4));

  ret->solver = m->sat;
  ret->formula = m->formula;
  ret->indicators = m->indicators;
  ret->usedIndicators = m->usedIndicators;
  ret->sortedIndicators = m->sortedIndicators;
  ret->indicatorInCore = m->indicatorInCore;
  ret->unusedLits = m->unusedLits;
  ret->sorter = m->sorter;
  ret->bestSolution = bestSolution;
  ret->sat_with_indicators = m->sat_with_indicators;
  ret->wboUpdate = m->wboUpdate;
  ret->numUnused = m->numUnused;
  ret->nextUnused = m->nextUnused;
  ret->lowerbound = m->lowerbound;
  ret->upperbound = m->upperbound;
  ret->numVar = m->numVar;
  ret->numSorted = m->numSorted;
  ret->sortOutputSize = m->sortOutputSize;
  ret->numClauses = m->numClauses;

  free(m);

  return ret;
}

void msu4_free(Msu4* m)
{
  g_array_free(m->indicators, true);
  g_array_free(m->indicatorInCore, true);
  g_array_free(m->unusedLits, true);
  formula_free(m->formula);
  free(m->bestSolution);
  free(m);
}

void msu4_print_solution(Msu4* m)
{
  printf("s");
  for (int i = 0; i < m->numVar; ++i) {
    if (m->bestSolution[i]) {
      printf(" %d", i + 1);
    } else {
      printf(" -%d", i + 1);
    }
  }
  printf("\n");
}

void msu4_set_bound(Msu4* m)
{
  GArray* ind = m->usedIndicators;
  Literal* sind = m->sortedIndicators;
  Formula* f = m->formula;
  if (m->sat_with_indicators) {
    int numNotSorted = ind->len - m->numSorted;
    int sortbound = m->upperbound + 1;
    if (m->wboUpdate) {
      sorter_update(m->sorter, f, sortbound);
      if (numNotSorted > 0) {
        Literal* ins = malloc(sizeof(Literal*) * numNotSorted);
        for (int i = 0; i < numNotSorted; ++i) {
          ins[i] = g_array_index(ind, Literal, i + m->numSorted);
        }
        Literal* outLits = sorter_sort(m->sorter, ins, numNotSorted, f, sortbound);
        if (m->numSorted > 0) {
          m->sortedIndicators = sorter_merge(m->sorter, sind, outLits, m->numSorted, numNotSorted, f, sortbound);
        } else {
          m->sortedIndicators = outLits;
        }
        sind = m->sortedIndicators;
        m->numSorted = ind->len;
        numNotSorted = 0;
      }
    } else {
      //sorter_update(m->sorter,f,sortbound);
      uint firstUnused = m->unusedLits->len - m->numUnused;

      for (uint i = firstUnused; i < m->unusedLits->len && numNotSorted > 0; ++i) {
        assert(g_array_index(ind, Literal, (m->numSorted)) != 0);
        g_array_index(m->unusedLits, Literal, i) = g_array_index(ind, Literal, (m->numSorted)++);
        numNotSorted = ind->len - m->numSorted;
        (m->numUnused)--;
      }
      assert(zeros_only_end((Literal*)m->unusedLits->data, m->unusedLits->len));
      sorter_update(m->sorter, f, sortbound);
      while (numNotSorted > 0) {
        assert(m->unusedLits->len == 0 || no_zeros((Literal*)m->unusedLits->data, m->unusedLits->len));
        int numNewLits = m->sortOutputSize;
        if (numNewLits == 0) {
          numNewLits = numNotSorted;
        }
        assert(m->numUnused == 0);
        g_array_free(m->unusedLits, false);
        m->unusedLits = g_array_new(true, true, sizeof(Literal));
        g_array_set_size(m->unusedLits, numNewLits);
        m->numUnused = numNewLits;
        for (int i = 0; i < numNewLits && numNotSorted > 0; ++i) {
          g_array_index(m->unusedLits, Literal, i) = g_array_index(ind, Literal, (m->numSorted)++);
          numNotSorted = ind->len - m->numSorted;
          m->numUnused--;
        }
        assert(zeros_only_end((Literal*)m->unusedLits->data, numNewLits));
        Literal* outLits = sorter_sort(m->sorter, (Literal*)m->unusedLits->data, numNewLits, f, sortbound);
        if (m->sortOutputSize != 0) {
          assert(zeros_only_end(sind, m->sortOutputSize));
          assert(zeros_only_end(outLits, numNewLits));
          sind = sorter_merge(m->sorter, sind, outLits, m->sortOutputSize, numNewLits, f, sortbound);
        } else {
          sind = outLits;
        }
        m->sortedIndicators = sind;
        m->sortOutputSize += numNewLits;
      }
      sorter_update(m->sorter, f, sortbound);
      printf("c current=%d unused=%d\n", ind->len, m->numUnused);
    }
    assert(m->numSorted >= m->upperbound);
    Literal il = sind[m->upperbound - 1];
    assert(il != 0);
    sat_assume(m->solver, -il);
  }
  for (uint i = 0; i < m->indicators->len; ++i) {
    Literal l = g_array_index(m->indicators, Literal, i);
    if (!g_array_index(m->indicatorInCore, bool, i)) {
      assert(l != 0);
      sat_assume(m->solver, -l);
    }
  }

  uint newlits = 0;
  int clsNum = 0;
  Literal* ls = formula_get_new_clauses(f, &newlits);
  for (uint i = 0; i < newlits; ++i) {
    if (ls[i] == 0) {
      clsNum++;
    }
    sat_add(m->solver, ls[i]);
  }
  printf("c num new clauses = %d\n", clsNum);
  m->numClauses += clsNum;
  printf("c num total clauses = %d\n", m->numClauses);
  printf("c num total variables = %d\n", formula_num_variables(m->formula));
}

bool msu4_extract_new_core(Msu4* m)
{
  GArray* ind = m->indicators;
  int numLit = 0;
  for (uint i = 0; i < ind->len; ++i) {
    Literal l = g_array_index(ind, Literal, i);
    if (sat_corelit(m->solver, l)) {
      if ((!g_array_index(m->indicatorInCore, bool, i))
          || m->sat_with_indicators) {
        numLit++;
      }
      if (!g_array_index(m->indicatorInCore, bool, i)) {
        g_array_index(m->indicatorInCore, bool, i) = true;
        assert(l != 0);
        g_array_append_val(m->usedIndicators, l);
      }
    }
  }
  return numLit > 0;
}

void msu4_set_best_solution(Msu4* m)
{
  Formula* f = m->formula;
  for (int i = 0; i < m->numVar; ++i) {
    Literal il = formula_lookup_orig(f, i + 1);
    if (il != 0 && sat_lookup(m->solver, il)) {
      m->bestSolution[i] = true;
    } else {
      m->bestSolution[i] = false;
    }
  }
}

int msu4_calc_ub(Msu4* m)
{
  int ret = 0;
  GArray* ind = m->indicators;
  for (uint i = 0; i < ind->len; i++) {
    Literal l = g_array_index(ind, Literal, i);
    if (sat_lookup(m->solver, l)) {
      ret++;
    }
  }
  Literal* sind = m->sortedIndicators;
  int sret = 0;
  for (int i = 0; i < m->lowerbound && m->numSorted > 0; i++) {
    Literal il = sind[i];
    if (sat_lookup(m->solver, il)) {
      sret++;
    }
  }
  return ret;
}

int msu4_step_phase2(Msu4 * m)
{
    msu4_set_bound(m);
    int res = sat_check(m->solver);
    if (res == 20) {
      msu4_extract_new_core(m);
      GArray* ind = m->usedIndicators;
      int numNotSorted = ind->len - m->numSorted;
      if (numNotSorted > 0) {
        m->lowerbound++;
      } else {
        m->lowerbound = m->upperbound;
      }
      printf("o %d\n", m->lowerbound);
    } else if (res == 10) {
      m->upperbound = msu4_calc_ub(m);
      printf("c New upperbound: %d\n", m->upperbound);
      msu4_set_best_solution(m);
    }
    return res;
}

void msu4_solve(Msu4* m)
{
  int res = sat_check(m->solver);
  while (res == 20) {
    bool newfound = msu4_extract_new_core(m);
    if (!newfound) {
      printf("c hard clauses unsat\n");
      printf("s UNSATISFIABLE\n");
      return;
    }
    msu4_set_bound(m);
    printf("o %d\n", m->lowerbound);
    res = sat_check(m->solver);
    m->lowerbound++;
  }
  msu4_set_best_solution(m);
  m->upperbound = msu4_calc_ub(m);
  m->sat_with_indicators = true;
  printf("c Found upperbound %d\n", m->upperbound);

  while (m->upperbound > m->lowerbound) {
    res = msu4_step_phase2(m);
  }
  printf("s OPTIMUM FOUND\n");
  printf("o %d\n", m->lowerbound);
  printf("c Solution has value %d\n", m->upperbound);
  msu4_print_solution(m);
}

void msu4_run(
    SortingScheme* strat,
    SATSolver* s,
    Literal* softcl,
    int numSoftLit,
    Literal* hardcl,
    int numHardLit,
    int numVar,
    int numClauses,
    bool wboUpdate)
{
  Msu4* m = msu4_make(
      strat,
      s,
      softcl,
      numSoftLit,
      hardcl,
      numHardLit,
      numVar,
      numClauses,
      wboUpdate);
  msu4_solve(m);
  msu4_free(m);
}
