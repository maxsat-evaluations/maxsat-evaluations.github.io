#ifndef MSU4_H
#define MSU4_H
#include "msu3.h"
#include "satsolver.h"
#include "sattypes.h"
#include "sortingscheme.h"

typedef struct Msu4 {
  SATSolver* solver;
  Formula* formula;
  GArray* indicators;
  GArray* usedIndicators;
  Literal* sortedIndicators;
  GArray* indicatorInCore;
  GArray* unusedLits;
  SortingScheme* sorter;
  bool* bestSolution;
  bool sat_with_indicators;
  bool wboUpdate;
  int numUnused;
  int nextUnused;
  int lowerbound;
  int upperbound;
  int numVar;
  int numSorted;
  int sortOutputSize;
  int numClauses;
} Msu4;

int msu4_step_phase2(Msu4* m);
Msu4* msu4_convert(Msu3* m,bool * bestSolution);
void msu4_free(Msu4*);
void msu4_print_solution(Msu4* m);

/**
 * The msu4 algorithm for solving maxsat
 * /param softcl list of soft clauses
 * /param numSoftLit The length of softcl
 * /param harcl list of hard clauses.
 * /param numHardLit The length of hardcl
 * /param numVar The number of variables
 * /param numClauses The number of clauses
 * /param wboUpdate If the update scheme should
 *   mimic the one used in open-wbo.
 */
void msu4_run(
    SortingScheme*,
    SATSolver*,
    Literal* softcl,
    int numSoftLit,
    Literal* hardcl,
    int numHardLit,
    int numVar,
    int numClauses,
    bool wboUpdate);
#endif
