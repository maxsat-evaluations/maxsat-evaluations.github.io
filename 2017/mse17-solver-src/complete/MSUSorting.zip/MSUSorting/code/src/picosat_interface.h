#ifndef PICOSAT_INTERFACE_H
#define PICOSAT_INTERFACE_H
#include "satsolver.h"

/**
 * /seed random seed to use.
 * /return A SATSolver (/see satsolver.h)implemented using picosat.
 */
SATSolver* picosat_satmake(int seed);

#endif
