#ifndef MSU3TO4_H
#define MSU3TO4_H
#include "msu3.h"
#include "msu4.h"

void msu3tomsu4_run(
    SortingScheme* strat,
    SATSolver* s,
    Literal* softcl,
    int numSoftLit,
    Literal* hardcl,
    int numHardLit,
    int numVar,
    int numClauses,
    bool wboUpdate,
    int msu3seconds);
#endif
