#include "msu3tomsu4.h"
#include "assert.h"
#include "common.h"
#include "formula.h"
#include "glib.h"
#include "picosat.h"
#include "satsolver.h"
#include "sortingscheme.h"
#include "stdbool.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "totalizer.h"
#include "time.h"

void msu3tomsu4_run(
    SortingScheme* strat,
    SATSolver* s,
    Literal* softcl,
    int numSoftLit,
    Literal* hardcl,
    int numHardLit,
    int numVar,
    int numClauses,
    bool wboUpdate,
    int msu3seconds)
{
  Msu3* m = msu3_make(
      strat,
      s,
      softcl,
      numSoftLit,
      hardcl,
      numHardLit,
      numVar,
      numClauses,
      wboUpdate);
  printf("c Running phase1\n");
  int res = msu3_phase1(m);

  Formula* f = m->formula;
  bool * bestSolution = malloc(sizeof(bool) * numVar);
  for (int i = 0; i < m->numVar; ++i) {
    Literal il = formula_lookup_orig(f, i + 1);
    if (il != 0 && sat_lookup(m->sat, il)) {
      bestSolution[i] = true;
    } else {
      bestSolution[i] = false;
    }
  }

  if(res == -1){
    printf("c Hard Clauses unsat.\n");
    printf("s UNSATISFIABLE\n");
    return;
  }
  printf("c Running msu3 phase2\n");
  time_t startTime = time(NULL);
  if (m->upperbound > m->lowerbound) {
    //This is a bit of a hack.
    //We decrease lowerbound and then
    //increase it again after setting
    //sat_with_indicators to change
    //the formula built while not really
    //increasing the lowerbound.
    m->lowerbound--;
    msu3_increase_bound(m);
    res = sat_check(m->sat);
    while (res == 20 && time(NULL) - startTime < msu3seconds) {
      res = msu3_step_phase2(m);
    }
  }
  if(m->upperbound == m->lowerbound){
    printf("s OPTIMUM FOUND\n");
    printf("o %d\n", m->lowerbound);
    printf("c Solution has value %d\n", m->upperbound);
    msu3_print_solution(m);
    return;
  }

  printf("c Switching to msu4 phase 2\n");
  Msu4* m4 = msu4_convert(m,bestSolution);
  m = NULL;

  while(m4->lowerbound < m4->upperbound){
    res = msu4_step_phase2(m4);
  }

  printf("c Solution has value %d\n", m4->upperbound);
  printf("s OPTIMUM FOUND\n");
  printf("o %d\n", m4->lowerbound);
  msu4_print_solution(m4);
  msu4_free(m4);
}
