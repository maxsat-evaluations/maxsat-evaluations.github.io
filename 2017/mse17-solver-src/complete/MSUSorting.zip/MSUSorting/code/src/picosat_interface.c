#include "picosat_interface.h"
#include "picosat.h"

bool picosat_lookup(void* v, Literal l)
{
  return picosat_deref((PicoSAT*)v, l) > 0;
}

int picosat_check(void* v)
{
  return picosat_sat((PicoSAT*)v, -1);
}

void picosat_set_phase(void* v, Literal l, bool b)
{
  if (b) {
    picosat_set_default_phase_lit((PicoSAT*)v, l, l);
  } else {
    picosat_set_default_phase_lit((PicoSAT*)v, l, -l);
  }
}

SATSolver* picosat_satmake(int seed)
{
  SATSolver* ret = malloc(sizeof(SATSolver));
  PicoSAT* p = picosat_init();
  picosat_enable_trace_generation(p);
  picosat_set_output(p, stdout);
  picosat_set_verbosity(p, 0);
  picosat_set_seed(p, seed);
  ret->data = p;
  ret->assume = (Assumer)picosat_assume;
  ret->add = (Adder)picosat_add;
  ret->lookup = picosat_lookup;
  ret->conflict_assumes = (CoreLit)picosat_corelit;
  ret->checksat = picosat_check;
  ret->setphase = picosat_set_phase;
  ret->freer = (SATFreer)picosat_reset;
  return ret;
}
