#include "picosat.h"
#include "cryptominisat_interface.h"
#include "cryptominisat5/cryptominisat.h"
#include <vector>
#include <cassert>

#define myabs(a) (((a) > 0) ? (a) : (-a))
using std::vector;


typedef struct CM {
  CMSat::SATSolver* s;
  vector<CMSat::Lit>* clause;
  vector<CMSat::Lit>* assumes;

} CM;

void cryptominisat_assume(void* v, Literal l)
{
  CM* cm = (CM*)v;
  cm->assumes->push_back(CMSat::Lit(myabs(l), l < 0));
}

void  cryptominisat_add(void* v, Literal l)
{
  CM* cm = (CM*)v;
  if (l == 0) {
    cm->s->add_clause(*(cm->clause));
    delete cm->clause;
    cm->clause = new vector<CMSat::Lit>;
  } else {
    unsigned int var = myabs(l);
    while (var+1 >= cm->s->nVars())
      cm->s->new_var();
    CMSat::Lit li = CMSat::Lit(var, l < 0);
    cm->clause->push_back(li);
  }
}

bool cryptominisat_lookup(void* v, Literal l)
{
  assert (l != 0);
  CM* cm = (CM*)v;
  vector<CMSat::lbool> model = cm->s->get_model();
  int var = myabs(l);
  CMSat::lbool b = model[var];
  if (b == CMSat::l_True) {
    return l > 0;
  } else {
    return l < 0;
  }
}

bool cryptominisat_corelit(void* v, Literal l)
{
  CM* cm = (CM*)v;
  assert(l != 0);
  CMSat::Lit l1 = CMSat::Lit(myabs(l), l < 0);
  CMSat::Lit l2 = CMSat::Lit(myabs(l), l > 0);
  vector<CMSat::Lit> conflict = cm->s->get_conflict();
  for (size_t i = 0; i < conflict.size(); i++) {
    if (conflict[i] == l1
        || conflict[i] == l2) {
      return true;
    }
  }
  return false;
}

int cryptominisat_checksat(void* v)
{
  CM* cm = (CM*)v;
  CMSat::lbool res = cm->s->solve(cm->assumes);
  delete cm->assumes;
  cm->assumes = new vector<CMSat::Lit>;
  if (res == CMSat::l_True) {
    return PICOSAT_SATISFIABLE;
  } else if (res == CMSat::l_False) {
    return PICOSAT_UNSATISFIABLE;
  } else {
    return PICOSAT_UNKNOWN;
  }
}

void cryptominisat_set_phase(void* v, Literal l, bool b)
{
  //cryptominisat does not have this functionality
}

void cryptominisat_free(void* v)
{
  CM* cm = (CM*)v;
  delete cm->s;
  delete cm->assumes;
  delete cm->clause;
  free(v);
}

SATSolver* cryptominisat_satmake()
{
  CM* cm = (CM*)malloc(sizeof(CM));
  cm->s = new CMSat::SATSolver;
  cm->clause = new vector<CMSat::Lit>;
  cm->assumes = new vector<CMSat::Lit>;
  SATSolver* s = (SATSolver*)malloc(sizeof(SATSolver));
  s->data = cm;
  s->assume = cryptominisat_assume;
  s->add = cryptominisat_add;
  s->lookup = cryptominisat_lookup;
  s->conflict_assumes = cryptominisat_corelit;
  s->checksat = cryptominisat_checksat;
  s->setphase = cryptominisat_set_phase;
  s->freer = cryptominisat_free;
  return s;
}
