#ifndef TOTALIZER_H
#define TOTALIZER_H

#include "extra_clauses.h"
#include "sattypes.h"
#include "sortingscheme.h"

/** Totalizer uses the totalizer encoding to provide
 * a SortingScheme (/see sortingscheme.h).
 */
typedef struct TotalizerStruct Totalizer;

void tot_sort(Literal* lits, uint length, Formula*);
void tot_merge(Literal* lits, uint alength, uint blength, Formula*);

/** Make a Totalizer
 * /param strat the Sorting strategy to use
 * /param extra The extra clauses strategy to use (/see extra_clauses.h).
 */
Totalizer* tot_make(ExtraClauses extra);
/** Free a totalizer */
void tot_free(Totalizer* t);

/**
 * /param lits the literals to be sorted.
 * /param length the length of lits
 * /param k the number of outputs to provide
 * /return Literals that are the k first lits in sorted order guaranteed by the clauses added for the formula.
 */
Literal* tot_k_sort(Totalizer*, Literal* lits, uint length, Formula*, int k);
/**
 * /param as the literals to be merged.
 * /param bs the literals to be merged.
 * /param alength the length of as.
 * /param blength the length of bs.
 * /param k the number of outputs to provide.
 * /return Literals that are the k first lits of as and bs merged, guaranteed by the clauses added to f.
 */
Literal* tot_k_merge(Totalizer*, Literal* as, Literal* bs, uint alength, uint blength, Formula*, int k);
/**
 * Update the totalizer network
 */
void tot_k_update(Totalizer*, Formula*, int k);

/** /return a sorting scheme implemented using the totalizer network */
SortingScheme* tot_make_scheme(ExtraClauses extra);
#endif
