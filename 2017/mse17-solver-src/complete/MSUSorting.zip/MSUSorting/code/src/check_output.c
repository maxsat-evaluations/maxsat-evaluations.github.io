#include "assert.h"
#include "readwcnf.h"
#include "stdbool.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#define abs(a) (a) > 0 ? (a) : (-(a))

int main(int argc, char** argv)
{

  if (argc != 4 || !strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) {
    printf("c USAGE: %s OUTPUT WCNF NAME\n", argv[0]);
    exit(1);
  }

  FILE* file = fopen(argv[2], "rt");
  FILE* output = fopen(argv[1], "rt");
  FILE* solutionFile = fopen("solutions.txt", "rt");
  if (file == NULL) {
    printf("could not open wcnf file %s.\n", argv[2]);
    exit(1);
  }
  if (output == NULL) {
    printf("could not open output file %s.\n", argv[1]);
    exit(1);
  }
  if (solutionFile == NULL) {
    printf("could not open solution file.\n");
    exit(1);
  }
  int numSoft = 0;
  int numHard = 0;
  int numCl = 0;
  int numVar = 0;
  Literal* hardcl;
  Literal* softcl;
  read_wcnf(file, &softcl, &numSoft, &hardcl, &numHard, &numVar, &numCl);
  fclose(file);

  int optval = 0;
  bool isSAT = false;
  bool isUNSAT = false;
  Literal solution[numVar + 1];
  int linesize = 1024 * 1024 * 16;
  char* line = malloc(sizeof(char) * linesize);
  char* retline = fgets(line, linesize, output);
  while (!feof(output)) {
    if (retline != line) {
      printf("Error while reading output file\n");
      abort();
    }
    if (line[0] == 'c') {
    } else if (line[0] == 'o') {
      int ret = sscanf(line, "o %d", &optval);
      if (ret != 1) {
        fprintf(stderr, "couldn't read: %s\n", line);
        exit(1);
      }
    } else if (line[0] == 's') {
      char* tok = strtok(line, " ");
      assert(tok[0] == 's');
      tok = strtok(NULL, " ");
      while (tok != NULL) {
        int val = 0;
        int ret = sscanf(tok, "%d", &val);
        int aval = abs(val);
        if (aval > numVar) {
          printf("Unknown variable given in solution\n");
          exit(1);
        }
        solution[aval] = val;
        if (ret != 1) {
          printf("expected lit, but got %s\n", tok);
          exit(1);
        }
        tok = strtok(NULL, " ");
      }
    } else if (!strcmp(line, "s OPTIMUM FOUND\n")) {
      isSAT = true;
    } else if (!strcmp(line, "s UNSATISFIABLE\n")) {
      isUNSAT = true;
    } else {
      printf("unexpected line: \"%s\"\n", line);
      exit(1);
    }
    retline = fgets(line, linesize, output);
  }
  if (isSAT) {
    int numUnsat = 0;
    bool isSAT = false;
    for (int i = 0; i < numSoft; ++i) {
      if (softcl[i] == 0) {
        if (!isSAT) {
          numUnsat++;
        }
        isSAT = false;
        continue;
      }
      int sign = 1;
      if (softcl[i] < 0) {
        sign = -1;
      }
      int v = lit_to_var(softcl[i]);
      if (v > numVar) {
        fprintf(stderr, "Unexpected literal %d\n", softcl[i]);
        exit(1);
      }
      if ((sign * solution[v]) > 0) {
        isSAT = true;
      }
    }
    if (numUnsat != optval) {
      fprintf(stderr, "optvalue missmatch %d vs %d\n", numUnsat, optval);
      exit(1);
    }
    for (int i = 0; i < numHard; ++i) {
      if (hardcl[i] == 0) {
        if (!isSAT) {
          fprintf(stderr, "Unsat hard clause!\n");
          exit(1);
        }
        isSAT = false;
        continue;
      }
      int sign = 1;
      if (hardcl[i] < 0) {
        sign = -1;
      }
      int v = lit_to_var(hardcl[i]);
      if (v > numVar) {
        fprintf(stderr, "Unexpected literal %d\n", softcl[i]);
        exit(1);
      }
      assert(solution[v] == v || solution[v] == -v);
      if (sign * solution[v] > 0) {
        isSAT = true;
      }
    }
    printf("SAT given with value %d\n", optval);
  }
  if (isUNSAT) {
    printf("UNSAT answer was given\n");
  }
  fclose(output);

  bool found = false;
  retline = fgets(line, linesize, solutionFile);
  while (!feof(solutionFile)) {
    char name[1024];
    int value = 0;
    if (retline != line) {
      printf("Error while reading solution file\n");
      abort();
    }

    sscanf(line, "%s %d", name, &value);

    if (!strcmp(name, argv[3])) {
      found = true;
      if (value == optval && isSAT) {
        printf("Found solution value in table and it is correct\n");
      }
      if (value != optval && isSAT) {
        printf("ERROR: Incorrect value was given\n");
      }
    }
    retline = fgets(line, linesize, solutionFile);
  }

  if (!found) {
    printf("WARNING: Solution not found in solution file\n");
  }

  fclose(solutionFile);
  free(line);
  free(hardcl);
  free(softcl);
}
