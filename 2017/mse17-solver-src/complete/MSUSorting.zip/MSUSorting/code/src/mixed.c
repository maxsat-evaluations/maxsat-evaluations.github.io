#include "mixed.h"
#include "common.h"
#include "sorting_plan.h"
#include "sortingnetwork.h"
#include "totalizer.h"
#include <assert.h>
#include <glib.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { MOVE,
  MERGE,
  ADDEXTRA } MergeType;

typedef struct Merge {
  MergeType type;
  Literal* in1;
  Literal* in2;
  Literal* out;
  Literal* out2;
  int* outIndex;
  int alength;
  int blength;
  int maxa;
  int maxb;
  int k;
} Merge;

typedef enum { NETWORK,
  TOT } UpdateType;

typedef struct Update {
  UpdateType type;
  int* outIndex;
  int length;
  void* update;
} Update;

typedef struct MixedStruct {
  GPtrArray* updates;
  GPtrArray* toFree;
  SortStrategy strat;
  ExtraClauses extra;
} MixedStruct;

void freeUpdate(void* vp)
{
  Update* u = (Update*)vp;
  if (u->type == NETWORK) {
    free(u->update);
  }
  if (u->type == TOT) {
    sorter_free(u->update);
  }
  free(u);
}

Mixed* mixed_make(SortStrategy strat, ExtraClauses extra)
{
  Mixed* mixed = malloc(sizeof(MixedStruct));
  mixed->updates = g_ptr_array_new_with_free_func(freeUpdate);
  mixed->toFree = g_ptr_array_new_with_free_func(free);
  mixed->extra = extra;
  mixed->strat = strat;
  return mixed;
}
void mixed_free(Mixed* mixed)
{
  g_ptr_array_free(mixed->updates, true);
  g_ptr_array_free(mixed->toFree, true);
  free(mixed);
}

void mixed_add_to_free(Mixed* t, void* frs)
{
  g_ptr_array_add(t->toFree, frs);
}
void mixed_add_tot(Mixed* m, int* outIndex, int length, SortingScheme* s)
{
  Update* up = malloc(sizeof(Update));
  up->type = TOT;
  up->outIndex = outIndex;
  up->update = s;
  up->length = length;
  g_ptr_array_add(m->updates, up);
}
void mixed_add_merge(Mixed* t, Literal* out, Literal* as, Literal* bs, int* outIndex, int alength, int blength, int maxa, int maxb, int k)
{
  Merge* u = malloc(sizeof(Merge));
  u->type = MERGE;
  u->in1 = as;
  u->in2 = bs;
  u->out = out;
  u->outIndex = outIndex;
  u->alength = alength;
  u->blength = blength;
  u->maxa = maxa;
  u->maxb = maxb;
  u->k = k;
  Update* up = malloc(sizeof(Update));
  up->type = NETWORK;
  up->update = u;
  g_ptr_array_add(t->updates, up);
}

void mixed_add_extra(Mixed* t, Literal* out, Literal* as, Literal* bs, int* outIndex, int alength, int blength, int maxa, int maxb, int k)
{
  Merge* u = malloc(sizeof(Merge));
  u->type = ADDEXTRA;
  u->in1 = as;
  u->in2 = bs;
  u->out = out;
  u->outIndex = outIndex;
  u->alength = alength;
  u->blength = blength;
  u->maxa = maxa;
  u->maxb = maxb;
  u->k = k;
  Update* up = malloc(sizeof(Update));
  up->type = NETWORK;
  up->update = u;
  g_ptr_array_add(t->updates, up);
}

void mixed_add_move(Mixed* t, Literal* out, Literal* out2, Literal* as, int alength)
{
  Merge* u = malloc(sizeof(Merge));
  u->type = MOVE;
  u->in1 = as;
  u->out = out;
  u->out2 = out2;
  u->alength = alength;
  Update* up = malloc(sizeof(Update));
  up->type = NETWORK;
  up->update = u;
  g_ptr_array_add(t->updates, up);
}

void mixed_or(Mixed* t, Formula* f, Literal* out, Literal* ain, Literal* bin, int index, int k)
{
  if (index >= k) {
    *out = 0;
    return;
  }
  if (((*ain) != 0 || (*bin) != 0) && (*out) == 0)
    (*out) = formula_make_fresh(f);

  if ((*ain) != 0) {
    formula_cl(f, 2, *out, -(*ain));
  }
  if ((*bin) != 0) {
    formula_cl(f, 2, *out, -(*bin));
  }
  if (t->extra.biDirectional) {
    if ((*ain) != 0 && (*bin) != 0) {
      if ((*out) == 0) {
        (*out) = formula_make_fresh(f);
      }
      formula_cl(f, 3, -(*out), (*bin), (*ain));
    }
  }
}

void mixed_and(Mixed* t, Formula* f, Literal* out, Literal* ain, Literal* bin, int index, int k)
{
  if (index >= k) {
    *out = 0;
    return;
  }
  if (t->extra.biDirectional) {
    if (((*ain) != 0 || (*bin) != 0) && (*out) == 0)
      (*out) = formula_make_fresh(f);

    if ((*ain) != 0) {
      formula_cl(f, 2, -(*out), (*ain));
    }
    if ((*bin) != 0) {
      formula_cl(f, 2, -(*out), (*bin));
    }
  }
  if ((*ain) != 0 && (*bin) != 0) {
    if ((*out) == 0) {
      (*out) = formula_make_fresh(f);
    }
    formula_cl(f, 3, *out, -(*bin), -(*ain));
  }
}

Literal* mixed_k_merge_worker(Mixed* t, MergeStep* ms, Literal* as, Literal* bs, int* outIndex, int alength, int blength, Formula* f, int k)
{
  assert(alength == ms->in1length);
  assert(blength == ms->in2length);
  assert(zeros_only_end(as, alength));
  assert(zeros_only_end(bs, blength));
  if (alength == 0) {
    assert(ms == NULL || ms->type == SINGLETON);
    return bs;
  }
  if (blength == 0) {
    assert(ms == NULL || ms->type == SINGLETON);
    return as;
  }
  assert(ms->type == TOT_MERGE || ms->type == SN_MERGE);
  int length = alength + blength;

  if (ms->type == TOT_MERGE) {
    SortingScheme* tot = tot_make_scheme(t->extra);
    int k2 = first_larger(k, outIndex, length);
    Literal* ret = sorter_merge(tot, as, bs, alength, blength, f, k2);
    mixed_add_tot(t, outIndex, length, tot);
    return ret;
  }

  assert(ms->type == SN_MERGE);

  if (alength == 1 && blength == 1) {
    Literal* out = malloc(sizeof(Literal) * 2);
    memset(out, 0, sizeof(Literal) * 2);
    mixed_add_to_free(t, out);
    mixed_or(t, f, out, as, bs, outIndex[0], k);
    mixed_and(t, f, out + 1, as, bs, outIndex[1], k);
    int maxa = 0;
    int maxb = 0;
    if (as[0] != 0)
      maxa = 1;
    if (bs[0] != 0)
      maxb = 1;
    mixed_add_merge(t, out, as, bs, outIndex, alength, blength, maxa, maxb, k);
    assert(zeros_only_end(out, alength + blength));
    return out;
  }
  int numAOdd, numAEven, numBEven, numBOdd;
  Literal *aevens, *aodds, *bevens, *bodds;
  splitEvenOdd(as, &aevens, &aodds, alength, &numAEven, &numAOdd);
  splitEvenOdd(bs, &bevens, &bodds, blength, &numBEven, &numBOdd);
  assert(first_zero(aevens, numAEven)
          + first_zero(bevens, numBEven)
          + first_zero(aodds, numAOdd)
          + first_zero(bodds, numBOdd)
      == first_zero(as, alength) + first_zero(bs, blength));
  int numOdd = numAOdd + numBOdd;
  int numEven = numAEven + numBEven;
  assert(numOdd + numEven == length);

  mixed_add_to_free(t, aevens);
  mixed_add_to_free(t, bevens);
  mixed_add_to_free(t, aodds);
  mixed_add_to_free(t, bodds);
  mixed_add_move(t, aevens, aodds, as, alength);
  mixed_add_move(t, bevens, bodds, bs, blength);

  int *oddIndecies, *evenIndecies;
  splitOddEvenIndecies(outIndex, &oddIndecies, &evenIndecies, numOdd, numEven);
  mixed_add_to_free(t, oddIndecies);
  mixed_add_to_free(t, evenIndecies);
  for (int i = 0; i < numEven; ++i) {
    assert(evenIndecies[i] >= outIndex[i]);
  }
  for (int i = 0; i < numOdd; ++i) {
    assert(oddIndecies[i] >= outIndex[i]);
  }

  Literal* sortEvens = mixed_k_merge_worker(t, ms->even, aevens, bevens, evenIndecies, numAEven, numBEven, f, k);
  Literal* sortOdds = mixed_k_merge_worker(t, ms->odd, aodds, bodds, oddIndecies, numAOdd, numBOdd, f, k);

  Literal* out = malloc(sizeof(Literal) * length);
  memset(out, 0, sizeof(Literal) * length);
  mixed_add_to_free(t, out);

  int maxeven = first_zero(sortEvens, numEven);
  int maxodd = first_zero(sortOdds, numOdd);
  mixed_add_merge(t, out, sortEvens, sortOdds, outIndex, numEven, numOdd, maxeven, maxodd, k);
  out[0] = sortEvens[0];
  for (int i = 1; 2 * i < length; ++i) {
    assert(i < numEven);
    assert(i - 1 < numOdd);
    if (2 * i - 1 < length && 2 * i - 1 < k) {
      mixed_or(t, f, out + (2 * i) - 1, sortEvens + i, sortOdds + i - 1, outIndex[2 * i - 1], k);
      assert(out[2 * i - 2] != 0 || out[2 * i - 1] == 0);
    }
    if (2 * i < length && 2 * i < k) {
      mixed_and(t, f, out + (2 * i), sortEvens + i, sortOdds + i - 1, outIndex[2 * i], k);
      assert(out[2 * i] == 0 || out[2 * i - 1] != 0);
    }
  }
  for (int i = k; i < length; ++i) {
    out[i] = 0;
  }

  if (length <= k && numEven == numOdd) {
    out[length - 1] = sortOdds[numOdd - 1];
  } else if (length <= k && numEven == numOdd + 2) {
    out[length - 1] = sortEvens[numEven - 1];
  } else {
    assert(length > k || (numEven == numOdd + 1));
  }

  // Add optional redundant clauses
  if ((t->extra.fwdExtraCls || t->extra.bwdExtraCls || t->extra.sortedness) && length > 3) {
    int maxa = first_zero(as, alength);
    int maxb = first_zero(bs, blength);
    for (int i = 1; i < alength; ++i) {
      if (t->extra.fwdExtraCls && as[i] != 0 && out[i] != 0 && outIndex[i] < k) {
        formula_cl(f, 2, out[i], -as[i]);
      }
      if (t->extra.bwdExtraCls && as[(alength - 1) - i] != 0 && out[(length - 1) - i] != 0 && outIndex[(length - 1) - i] < k) {
        formula_cl(f, 2, -out[(length - 1) - i], as[(alength - 1) - i]);
      }
    }
    for (int i = 1; i < blength; ++i) {
      if (t->extra.fwdExtraCls && bs[i] != 0 && out[i] != 0 && outIndex[i] < k) {
        formula_cl(f, 2, out[i], -bs[i]);
      }
      if (t->extra.bwdExtraCls && bs[(blength - 1) - i] != 0 && out[(length - 1) - i] != 0 && outIndex[(length - 1) - i] < k) {
        formula_cl(f, 2, -out[(length - 1) - i], bs[(blength - 1) - i]);
      }
    }
    if (t->extra.sortedness) {
      for (int i = 0; i < length - 1; i += 2) {
        if (out[i] != 0 && out[i + 1] != 0) {
          formula_cl(f, 2, out[i], -out[i + 1]);
        }
      }
    }
    mixed_add_extra(t, out, as, bs, outIndex, alength, blength, maxa, maxb, k);
  }
  assert(zeros_only_end(sortEvens, numEven));
  assert(zeros_only_end(sortOdds, numOdd));
  assert(first_zero(as, alength) + first_zero(bs, blength)
      >= first_zero(out, length));
  assert(zeros_only_end(out, length));
  return out;
}

Literal* mixed_k_merge_setup(Mixed* t, MergeStep* ms, Literal* as, Literal* bs, uint alength, uint blength, Formula* f, int k)
{
  int* outIndex = malloc(sizeof(int) * (alength + blength));
  for (uint i = 0; i < alength + blength; ++i) {
    outIndex[i] = i;
  }
  mixed_add_to_free(t, outIndex);
  return mixed_k_merge_worker(t, ms, as, bs, outIndex, alength, blength, f, k);
}

Literal* mixed_k_merge(Mixed* t, Literal* as, Literal* bs, uint alength, uint blength, Formula* f, int k)
{
  MergeStep* ms;
  int realalength = first_zero(as, alength);
  int realblength = first_zero(bs, blength);

  if (t->strat.type == OPT_RATIO) {
    ms = ms_make_min_ratio(alength, blength, realalength, realblength, k, 1.0, t->strat.ratio);
  } else if (t->strat.type == CLAUSE_LIMIT) {
    t->strat.budget += t->strat.budgetIncrease;
    ms = ms_limit(alength, blength, realalength, realblength, k, t->strat.budget);
  } else {
    assert(false);
  }
  Literal* ret = mixed_k_merge_setup(t, ms, as, bs, alength, blength, f, k);
  ms_free(ms);
  return ret;
}

Literal* mixed_k_sort_worker(Mixed* t, SortPlan* sp, Literal* lits, int length, Formula* f, int k)
{
  if (length < 1) {
    return NULL;
  }
  if (length == 1) {
    return lits;
  }
  int alength = length / 2;
  int blength = length - alength;
  Literal* as = mixed_k_sort_worker(t, sp->left, lits, alength, f, k);
  Literal* bs = mixed_k_sort_worker(t, sp->right, lits + alength, blength, f, k);
  Literal* out = mixed_k_merge_setup(t, sp->merge, as, bs, alength, blength, f, k);
  return out;
}

Literal* mixed_k_sort(Mixed* t, Literal* lits, uint length, Formula* f, int k)
{
  SortPlan* sp;

  int reallength = first_zero(lits, length);

  if (t->strat.type == OPT_RATIO) {
    sp = sp_make_min_ratio(length, reallength, k, 1.0, t->strat.ratio);
  } else if (t->strat.type == CLAUSE_LIMIT) {
    sp = sp_limit(length, reallength, k, t->strat.budget);
  } else {
    assert(false);
  }

  Literal* ret = mixed_k_sort_worker(t, sp, lits, length, f, k);
  sp_free(sp);
  return ret;
}

static bool inside(int start, int index, int end)
{
  return start <= index && end > index;
}

static bool checkbounds(int astart, int aend, int bstart, int bend, int outstart, int outend, int i, int j, int r)
{
  return (inside(astart, i, aend) || inside(bstart, j, bend) || outstart <= r) && outend > r;
}

void mixed_k_update(Mixed* t, Formula* f, int k)
{
  GPtrArray* ms = t->updates;
  for (int i = 0; i < (int)(ms->len); ++i) {
    Update* up = g_ptr_array_index(ms, i);
    if (up->type == TOT) {
      SortingScheme* tot = up->update;
      int k2 = k;
      for (int i = 0; i < up->length; ++i) {
        if (up->outIndex[i] >= k) {
          k2 = i;
          break;
        }
      }
      sorter_update(tot, f, k2);
    } else if (up->type == NETWORK) {
      Merge* m = up->update;
      if (m->type == MERGE) {
        int length = m->alength + m->blength;
        assert(length > 0);
        int astart = min(m->maxa, m->k);
        int bstart = min(m->maxb, m->k);
        m->maxa = first_zero(m->in1, m->alength);
        m->maxb = first_zero(m->in2, m->blength);
        int aend = min(k, m->maxa);
        int bend = min(k, m->maxb);
        int outstart = first_larger(m->k, m->outIndex, length);
        int outend = first_larger(k, m->outIndex, length);
        assert(zeros_only_end(m->out, length));
        assert(zeros_only_end(m->in1, m->alength));
        assert(zeros_only_end(m->in2, m->blength));
        if (m->alength == 1 && m->blength == 1) {
          if (checkbounds(astart, aend, bstart, bend, outstart, outend, 0, 0, 0)) {
            if (inside(astart, 0, aend)) {
              if (m->out[0] == 0)
                m->out[0] = formula_make_fresh(f);
              formula_cl(f, 2, m->out[0], -m->in1[0]);
            }
            if (inside(bstart, 0, bend)) {
              if (m->out[0] == 0)
                m->out[0] = formula_make_fresh(f);
              formula_cl(f, 2, m->out[0], -m->in2[0]);
            }
            if (t->extra.biDirectional) {
              if (m->in1[0] != 0 && m->in2[0] != 0) {
                if (m->out[0] == 0)
                  m->out[0] = formula_make_fresh(f);
                formula_cl(f, 3, -m->out[0], m->in1[0], m->in2[0]);
              }
            }
          }
          if (checkbounds(astart, aend, bstart, bend, outstart, outend, 0, 0, 1)) {
            if (t->extra.biDirectional) {
              if (inside(astart, 0, aend)) {
                if (m->out[1] == 0)
                  m->out[1] = formula_make_fresh(f);
                formula_cl(f, 2, -m->out[1], m->in1[0]);
              }
              if (inside(bstart, 0, bend)) {
                if (m->out[1] == 0)
                  m->out[1] = formula_make_fresh(f);
                formula_cl(f, 2, -m->out[1], m->in2[0]);
              }
            }
            if (m->in1[0] != 0 && m->in2[0] != 0) {
              if (m->out[1] == 0)
                m->out[1] = formula_make_fresh(f);
              formula_cl(f, 3, m->out[1], -m->in1[0], -m->in2[0]);
            }
          }
          if (m->in1[0] != 0)
            m->maxa = 1;
          if (m->in2[0] != 0)
            m->maxb = 1;
          assert(zeros_only_end(m->out, length));
          assert(zeros_only_end(m->in1, m->alength));
          assert(zeros_only_end(m->in2, m->blength));
          m->k = k;
          continue;
        }
        m->out[0] = m->in1[0];
        for (int i = 1; 2 * i < length; ++i) {
          assert(i < m->alength);
          assert(i - 1 < m->blength);
          if (checkbounds(astart, aend, bstart, bend, outstart, outend, i, i - 1, 2 * i - 1)) {

            if (inside(astart, i, aend)) {
              if (m->out[2 * i - 1] == 0)
                m->out[2 * i - 1] = formula_make_fresh(f);
              formula_cl(f, 2, m->out[2 * i - 1], -m->in1[i]);
            }
            if (inside(bstart, i - 1, bend)) {
              if (m->out[2 * i - 1] == 0)
                m->out[2 * i - 1] = formula_make_fresh(f);
              formula_cl(f, 2, m->out[2 * i - 1], -m->in2[i - 1]);
            }
            if (t->extra.biDirectional) {
              if (m->in1[i] != 0 && m->in2[i - 1] != 0) {
                if (m->out[2 * i - 1] == 0)
                  m->out[2 * i - 1] = formula_make_fresh(f);
                formula_cl(f, 3, -m->out[2 * i - 1], m->in1[i], m->in2[i - 1]);
              }
            }
          }
          if (checkbounds(astart, aend, bstart, bend, outstart, outend, i, i - 1, 2 * i)) {
            if (t->extra.biDirectional) {
              if (inside(astart, i, aend)) {
                if (m->out[2 * i] == 0)
                  m->out[2 * i] = formula_make_fresh(f);
                formula_cl(f, 2, -m->out[2 * i], m->in1[i]);
              }
              if (inside(bstart, i - 1, bend)) {
                if (m->out[2 * i] == 0)
                  m->out[2 * i] = formula_make_fresh(f);
                formula_cl(f, 2, -m->out[2 * i], m->in2[i - 1]);
              }
            }
            if (m->in1[i] != 0 && m->in2[i - 1] != 0) {
              if (m->out[2 * i] == 0)
                m->out[2 * i] = formula_make_fresh(f);
              formula_cl(f, 3, m->out[2 * i], -m->in1[i], -m->in2[i - 1]);
            }
          }
        }
        if (length <= k && m->alength == m->blength) {
          m->out[length - 1] = m->in2[m->blength - 1];
        } else if (length <= k && m->alength == m->blength + 2) {
          m->out[length - 1] = m->in1[m->alength - 1];
        } else {
          assert(length > k || m->alength == m->blength + 1);
        }
        m->k = k;
        assert(zeros_only_end(m->out, length));
        assert(zeros_only_end(m->in1, m->alength));
        assert(zeros_only_end(m->in2, m->blength));
      } else if (m->type == MOVE) {
        int e = 0;
        int o = 0;
        for (int i = 0; i < m->alength;) {
          m->out[e++] = m->in1[i++];
          if (i >= m->alength)
            break;
          m->out2[o++] = m->in1[i++];
        }
        assert(zeros_only_end(m->out, e));
        assert(zeros_only_end(m->out2, o));
      } else if (m->type == ADDEXTRA) {
        int alength = m->alength;
        int blength = m->blength;
        int length = alength + blength;
        int astart = min(m->maxa, m->k);
        int bstart = min(m->maxb, m->k);
        m->maxa = first_zero(m->in1, alength);
        m->maxb = first_zero(m->in2, blength);
        int aend = min(k, m->maxa);
        int bend = min(k, m->maxb);
        int outstart = first_larger(m->k, m->outIndex, length);
        int outend = first_larger(k, m->outIndex, length);
        for (int i = 1; i < alength; ++i) {
          if (t->extra.fwdExtraCls && m->in1[i] != 0 && m->out[i] != 0 && (inside(outstart, i, outend) || inside(astart, i, aend))) {
            formula_cl(f, 2, m->out[i], -m->in1[i]);
          }
          if (t->extra.bwdExtraCls && m->in1[(alength - 1) - i] != 0 && m->out[(length - 1) - i] != 0 && (inside(outstart, (length - 1) - i, outend) || inside(astart, (alength - 1) - i, aend))) {
            formula_cl(f, 2, -m->out[(length - 1) - i], m->in1[(alength - 1) - i]);
          }
        }
        for (int i = 1; i < blength; ++i) {
          if (t->extra.fwdExtraCls && m->in2[i] != 0 && m->out[i] != 0 && (inside(outstart, i, outend) || inside(bstart, i, bend))) {
            formula_cl(f, 2, m->out[i], -m->in2[i]);
          }
          if (t->extra.bwdExtraCls && m->in2[(blength - 1) - i] != 0 && m->out[(length - 1) - i] != 0 && (inside(outstart, (length - 1) - i, outend) || inside(bstart, (blength - 1) - i, bend))) {
            formula_cl(f, 2, -m->out[(length - 1) - i], m->in2[(blength - 1) - i]);
          }
        }
        if (t->extra.sortedness) {
          for (int i = 0; i < length - 1; i += 2) {
            if ((inside(outstart, i, outend) || inside(outstart, i + 1, outend)) && m->out[i] != 0 && m->out[i + 1] != 0) {
              formula_cl(f, 2, m->out[i], -m->out[i + 1]);
            }
          }
        }
        assert(zeros_only_end(m->out, length));
        assert(zeros_only_end(m->in1, m->alength));
        assert(zeros_only_end(m->in2, m->blength));
        m->k = k;
      } else {
        assert(false);
      }
    } else {
      assert(false);
    }
  }
}

SortingScheme* mixed_make_scheme(SortStrategy strat, ExtraClauses extra)
{
  SortingScheme* ret = malloc(sizeof(SortingScheme));
  ret->encodingData = mixed_make(strat, extra);
  ret->merge = (Merger)mixed_k_merge;
  ret->sort = (Sorter)mixed_k_sort;
  ret->update = (Updater)mixed_k_update;
  ret->freer = (Freer)mixed_free;
  return ret;
}
