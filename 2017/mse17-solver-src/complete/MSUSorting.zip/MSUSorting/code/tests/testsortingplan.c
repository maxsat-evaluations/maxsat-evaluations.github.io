#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "mixed.h"
#include "sorting_plan.h"
#include "sortingnetwork.h"
#include "tassert.h"
#include "totalizer.h"

ExtraClauses extra = { false, false, false, false };
SortStrategy strat = { OPT_RATIO, 5.0, 0, 0 };

void test_tot_size(int alength, int blength, int k)
{
  SortingScheme* tot = tot_make_scheme(extra);
  Formula* f = formula_make();

  Literal as[alength];
  for (int i = 0; i < alength; ++i) {
    as[i] = formula_make_fresh(f);
  }

  Literal bs[blength];
  for (int i = 0; i < blength; ++i) {
    bs[i] = formula_make_fresh(f);
  }

  sorter_merge(tot, as, bs, alength, blength, f, k);

  int numCls = 0;
  uint numLits = 0;
  Literal* written = formula_get_new_clauses(f, &numLits);

  for (uint i = 0; i < numLits; ++i) {
    if (written[i] == 0) {
      numCls++;
    }
  }

  int length = alength + blength;
  int outIndecies[length];
  for (int i = 0; i < length; ++i) {
    outIndecies[i] = i;
  }

  assert_int_eq(numCls, 1 + num_cls_tot(alength, blength, outIndecies, k));
  formula_free(f);
  sorter_free(tot);
}

void test_sn_size(int alength, int blength, int k)
{
  SortingScheme* sn = sn_make_scheme(extra);
  Formula* f = formula_make();

  Literal as[alength];
  for (int i = 0; i < alength; ++i) {
    as[i] = formula_make_fresh(f);
  }

  Literal bs[blength];
  for (int i = 0; i < blength; ++i) {
    bs[i] = formula_make_fresh(f);
  }

  sorter_merge(sn, as, bs, alength, blength, f, k);

  int numCls = 0;
  uint numLits = 0;
  Literal* written = formula_get_new_clauses(f, &numLits);

  for (uint i = 0; i < numLits; ++i) {
    if (written[i] == 0) {
      numCls++;
    }
  }

  int length = alength + blength;
  int* outIndecies = malloc(sizeof(int) * length);
  for (int i = 0; i < length; ++i) {
    outIndecies[i] = i;
  }

  MergeStep* ms = ms_merge_sn(alength, blength, alength, blength, outIndecies, k);
  assert_int_eq(numCls, 1 + ms->numCls);
  ms_free(ms);
  formula_free(f);
  sorter_free(sn);
}

void test_min_cls(int length, int k)
{
  SortingScheme* mixed = mixed_make_scheme(strat, extra);
  SortingScheme* tot = tot_make_scheme(extra);
  Formula* f = formula_make();

  Literal as[length];
  for (int i = 0; i < length; ++i) {
    as[i] = formula_make_fresh(f);
  }

  sorter_sort(mixed, as, length, f, k);

  int numClsMixed = 0;
  uint numLits = 0;
  Literal* written = formula_get_new_clauses(f, &numLits);

  for (uint i = 0; i < numLits; ++i) {
    if (written[i] == 0) {
      numClsMixed++;
    }
  }

  sorter_sort(tot, as, length, f, k);

  int numClsTot = 0;
  numLits = 0;
  written = formula_get_new_clauses(f, &numLits);

  for (uint i = 0; i < numLits; ++i) {
    if (written[i] == 0) {
      numClsTot++;
    }
  }

  SortPlan* sp = sp_make_min_cls(length, length, k);
  int numClsSp = sp_num_cls(sp);
  assert_true(numClsMixed >= 1 + numClsSp);
  assert_true(numClsTot >= numClsSp);
  sp_free(sp);
  sorter_free(mixed);
  sorter_free(tot);
  formula_free(f);
}

void test_min_cls_delayed(int length, int k)
{
  SortingScheme* mixed = mixed_make_scheme(strat, extra);
  SortingScheme* tot = tot_make_scheme(extra);
  Formula* f = formula_make();

  Literal as[length];
  for (int i = 0; i < length / 2; ++i) {
    as[i] = formula_make_fresh(f);
  }
  for (int i = length / 2; i < length; ++i) {
    as[i] = 0;
  }

  sorter_sort(mixed, as, length, f, k);

  int numClsMixed = 0;
  uint numLits = 0;
  Literal* written = formula_get_new_clauses(f, &numLits);

  for (uint i = 0; i < numLits; ++i) {
    if (written[i] == 0) {
      numClsMixed++;
    }
  }

  sorter_sort(tot, as, length, f, k);

  int numClsTot = 0;
  numLits = 0;
  written = formula_get_new_clauses(f, &numLits);

  for (uint i = 0; i < numLits; ++i) {
    if (written[i] == 0) {
      numClsTot++;
    }
  }

  SortPlan* sp = sp_make_min_cls(length, length / 2, k);
  int numClsSp = sp_num_cls(sp);
  assert_true(numClsMixed >= 1 + numClsSp);
  assert_true(numClsTot >= numClsSp);
  sp_free(sp);
  sorter_free(mixed);
  sorter_free(tot);
  formula_free(f);
}

void test_limit_size(int length, int k, int limit)
{
  SortingScheme* mixed = mixed_make_scheme(strat, extra);
  SortingScheme* tot = tot_make_scheme(extra);
  Formula* f = formula_make();

  Literal as[length];
  for (int i = 0; i < length; ++i) {
    as[i] = formula_make_fresh(f);
  }

  sorter_sort(mixed, as, length, f, k);

  int numClsMixed = 0;
  uint numLits = 0;
  Literal* written = formula_get_new_clauses(f, &numLits);

  for (uint i = 0; i < numLits; ++i) {
    if (written[i] == 0) {
      numClsMixed++;
    }
  }

  sorter_sort(tot, as, length, f, k);

  int numClsTot = 0;
  numLits = 0;
  written = formula_get_new_clauses(f, &numLits);

  for (uint i = 0; i < numLits; ++i) {
    if (written[i] == 0) {
      numClsTot++;
    }
  }

  SortPlan* sp = sp_limit(length, length, k, limit);
  SortPlan* spmin = sp_make_min_cls(length, length, k);
  int numClsSp = sp_num_cls(sp);
  assert_true(numClsMixed + limit >= 1 + numClsSp);
  assert_true(numClsTot >= numClsSp);
  sp_free(sp);
  sp_free(spmin);
  sorter_free(mixed);
  sorter_free(tot);
  formula_free(f);
}

void print_stats(int length, int k, int limit)
{
  SortPlan* spmincls = sp_make_min_cls(length, length, k);
  SortPlan* splim = sp_limit(length, length, k, limit);
  SortPlan* sprat = sp_make_min_ratio(length, length, k, 1.0, 0.5);

  printf("stat %d %d %d\n", length, k, limit);
  printf("cls %d %d %d\n",
      sp_num_cls(spmincls),
      sp_num_cls(splim),
      sp_num_cls(sprat));
  printf("var %d %d %d\n",
      sp_num_var(spmincls),
      sp_num_var(splim),
      sp_num_var(sprat));

  assert_true(sp_num_var(spmincls) >= sp_num_var(sprat));

  sp_free(spmincls);
  sp_free(splim);
  sp_free(sprat);
}

int main(int argc, char** argv)
{
  (void)argv;
  (void)argc;
  for (uint alength = 1; alength < 10; ++alength) {
    for (uint blength = 1; blength < 10; ++blength) {
      for (uint k = 2; k < 10; ++k) {
        test_tot_size(alength, blength, k);
        if (alength - blength <= 1 && alength >= blength) {
          test_sn_size(alength, blength, k);
        }
      }
    }
  }

  for (uint length = 1; length < 10; ++length) {
    for (uint k = 1; k < length; ++k) {
      test_min_cls(length, k);
      test_min_cls_delayed(length, k);
      for (uint limit = 100; limit < 1000; limit += 100) {
        //   print_stats(length,k,limit);
        test_limit_size(length, k, limit);
      }
    }
  }
}
