#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "math.h"
#include "mixed.h"
#include "picosat.h"
#include "sortingnetwork.h"
#include "tassert.h"
#include "totalizer.h"

ExtraClauses extra = { true, true, true, true };
SortStrategy strat = { OPT_RATIO, 5.0, 0, 0 };

void test1(void)
{
  Formula* f = formula_make();
  int n = 4;
  int k = 2;

  Literal inp[n];
  Literal intInp[n];
  for (int i = 0; i < n; ++i) {
    inp[i] = i + 1;
    intInp[i] = formula_make_orig(f, inp[i]);
  }
  tot_sort(intInp, n, f);
  if (k > 0) {
    formula_cl(f, 1, intInp[k - 1]);
  }

  PicoSAT* pico = picosat_init();
  picosat_assume(pico, -intInp[k]);

  uint numLit = 0;
  Literal* written = formula_get_new_clauses(f, &numLit);

  for (uint i = 0; i < numLit; ++i) {
    picosat_add(pico, written[i]);
  }

  int ret = picosat_sat(pico, -1);
  assert_true(ret == PICOSAT_SATISFIABLE);
  int numTrue = 0;
  for (int i = 0; i < n; ++i) {
    Literal el = formula_lookup_orig(f, inp[i]);
    if (picosat_deref(pico, el) > 0) {
      numTrue++;
    }
  }
  assert_true(numTrue <= k);
  picosat_reset(pico);
  formula_free(f);
}

void test2(SortingScheme* s, int m, int k, int incr)
{
  //printf("=======================\n");
  Formula* f = formula_make();
  time_t t;
  srand((unsigned)time(&t));
  int n = 4 * m;

  Literal inp[n];
  for (int i = 0; i < n; ++i) {
    inp[i] = formula_make_orig(f, i + 1);
  }

  Literal* intInp = sorter_sort(s, inp, m, f, k);

  int numSet[n + 1];
  numSet[0] = 0;
  for (int i = 0; i < n; ++i) {
    if (rand() % 2) {
      formula_cl(f, 1, inp[i]);
      numSet[i + 1] = numSet[i] + 1;
    } else {
      formula_cl(f, 1, -inp[i]);
      numSet[i + 1] = numSet[i];
    }
  }
  PicoSAT* pico = picosat_init();
  while (n > m) {
    //printf("-----------------------\n");
    uint numLits = 0;
    Literal* newlits = formula_get_new_clauses(f, &numLits);
    for (uint j = 0; j < numLits; ++j) {
      //if(newlits[j]){
      //  printf("%d ",newlits[j]);
      //} else {
      //  printf("\n");
      //}
      picosat_add(pico, newlits[j]);
    }
    //printf("assuming %d\n",-intInp[k-1]);
    picosat_assume(pico, -intInp[k - 1]);
    int res = picosat_sat(pico, -1);
    //printf("Asserting that after %d no more than %d, actually %d\n",m,k-1,numSet[m]);
    if (k > numSet[m]) {
      if (res != 10) {
        printf("In the cummulative sequence: ");
        for (int i = 0; i < m; ++i) {
          printf("%d ", numSet[i]);
        }
        printf("\nAssumed no more than %d was set\n", k - 1);
        printf("incr=%d \n", incr);
        printf("Total number=%d \n", m);
        assert_int_eq(res, 10);
      }
    } else {
      if (res != 20) {
        printf("In the cummulative sequence: ");
        for (int i = 0; i < m; ++i) {
          printf("%d ", numSet[i]);
        }
        printf("\n Assumed no more than %d was set\n", k - 1);
        printf("incr=%d \n", incr);
        printf("Total number=%d \n", m);
        assert_int_eq(res, 20);
      }
    }
    m += incr;
    k++;
    if (m > n)
      break;
    sorter_update(s, f, k);
    Literal* bs = sorter_sort(s, inp + (m - incr), incr, f, k);
    intInp = sorter_merge(s, intInp, bs, m - incr, incr, f, k);
  }
  formula_free(f);
  picosat_reset(pico);
}

void test3(void)
{
  uint numLit = 0;
  for (int n = 1; n < 100; ++n) {
    for (int k = 1; k < n; ++k) {
      Formula* f = formula_make();
      Literal* written = formula_get_new_clauses(f, &numLit);
      SortingScheme* mixed = mixed_make_scheme(strat, extra);
      SortingScheme* tot = tot_make_scheme(extra);
      Literal inp[n];
      Literal intInp[n];
      for (int i = 0; i < n; ++i) {
        inp[i] = i + 1;
        intInp[i] = formula_make_orig(f, inp[i]);
      }
      int alength = n / 2;
      int blength = n - alength;
      sorter_merge(tot, intInp, intInp + alength, alength, blength, f, k);

      int totNumCls = 0;
      written = formula_get_new_clauses(f, &numLit);

      for (uint i = 0; i < numLit; ++i) {
        if (written[i] == 0) {
          totNumCls++;
        }
      }
      sorter_merge(mixed, intInp, intInp + alength, alength, blength, f, k);
      written = formula_get_new_clauses(f, &numLit);
      int mixedNumCls = 0;

      for (uint i = 0; i < numLit; ++i) {
        if (written[i] == 0) {
          mixedNumCls++;
        }
      }
      //printf("n=%d,k=%d, %d vs %d\n",n,k,mixedNumCls,totNumCls);
      assert_true(mixedNumCls <= totNumCls);
      formula_free(f);
      sorter_free(mixed);
      sorter_free(tot);
    }
  }
}

void test5(SortingScheme* s, int m, int k)
{
  //printf("===========\n");
  Formula* f = formula_make();
  time_t t;
  srand((unsigned)time(&t));
  int n = 16 * m;

  Literal inp[n];
  for (int i = 0; i < n; ++i) {
    inp[i] = formula_make_orig(f, i + 1);
  }

  Literal* intInp = sorter_sort(s, inp, m, f, k);

  int numSet[n + 1];
  numSet[0] = 0;
  for (int i = 0; i < n; ++i) {
    if (rand() % 2) {
      formula_cl(f, 1, inp[i]);
      numSet[i + 1] = numSet[i] + 1;
    } else {
      formula_cl(f, 1, -inp[i]);
      numSet[i + 1] = numSet[i];
    }
  }
  PicoSAT* pico = picosat_init();
  while (n > m) {
    uint numLits = 0;
    Literal* newlits = formula_get_new_clauses(f, &numLits);
    //printf("-----------------\n");
    for (uint j = 0; j < numLits; ++j) {
      //if(newlits[j]){
      //  printf("%d ",newlits[j]);
      //} else {
      //  printf("\n");
      //}
      picosat_add(pico, newlits[j]);
    }
    picosat_assume(pico, -intInp[k - 1]);
    int res = picosat_sat(pico, -1);
    if (k > numSet[m]) {
      if (res != 10) {
        printf("In the cummulative sequence: ");
        for (int i = 0; i < m; ++i) {
          printf("%d ", numSet[i]);
        }
        printf("\nAssumed no more than %d was set\n", k - 1);
        assert_int_eq(res, 10);
      }
    } else {
      if (res != 20) {
        printf("In the cummulative sequence: ");
        for (int i = 0; i < m; ++i) {
          printf("%d ", numSet[i]);
        }
        printf("\nAssumed no more than %d was set\n", k - 1);
        printf("%d number of elements\n", m);
        assert_int_eq(res, 20);
      }
    }
    m *= 2;
    k++;
    if (m > n)
      break;
    sorter_update(s, f, k);
    Literal* bs = sorter_sort(s, inp + (m / 2), m / 2, f, k);
    intInp = sorter_merge(s, intInp, bs, m / 2, m / 2, f, k);
  }
  formula_free(f);
  picosat_reset(pico);
}

void test6(SortingScheme* s)
{
  Formula* f = formula_make();
  time_t t;
  srand((unsigned)time(&t));
  int n = 12;

  Literal inp[n];
  for (int i = 0; i < n; ++i) {
    inp[i] = formula_make_orig(f, i + 1);
  }

  Literal* intInp = sorter_sort(s, inp, 6, f, 5);
  sorter_update(s, f, 6);
  Literal* bs = sorter_sort(s, inp + 6, 6, f, 6);
  intInp = sorter_merge(s, intInp, bs, 6, 6, f, 6);

  formula_cl(f, 1, inp[0]);
  formula_cl(f, 1, -inp[1]);
  formula_cl(f, 1, inp[2]);
  formula_cl(f, 1, -inp[3]);
  formula_cl(f, 1, inp[4]);
  formula_cl(f, 1, inp[5]);
  formula_cl(f, 1, -inp[6]);
  formula_cl(f, 1, -inp[7]);
  formula_cl(f, 1, -inp[8]);
  formula_cl(f, 1, -inp[9]);
  formula_cl(f, 1, -inp[10]);
  formula_cl(f, 1, inp[11]);

  PicoSAT* pico = picosat_init();
  uint numLits = 0;
  Literal* newlits = formula_get_new_clauses(f, &numLits);
  //printf("-----------------\n");
  for (uint j = 0; j < numLits; ++j) {
    //if(newlits[j]){
    //  printf("%d ",newlits[j]);
    //} else {
    //  printf("\n");
    //}
    picosat_add(pico, newlits[j]);
  }
  picosat_assume(pico, -intInp[5]);
  int res = picosat_sat(pico, -1);
  assert_int_eq(res, 10);
  formula_free(f);
  picosat_reset(pico);
}

void test7(SortingScheme* s)
{
  //printf("=======================\n");
  Formula* f = formula_make();
  time_t t;
  srand((unsigned)time(&t));
  int n = 82;

  Literal inp[n];
  for (int i = 0; i < n; ++i) {
    inp[i] = formula_make_orig(f, i + 1);
  }

  int len = n - 59;
  int k = 45 - len;
  Literal* intInp = sorter_sort(s, inp, 59, f, k);
  int sums[] = { 0, 0, 0, 1, 1, 2, 2, 3, 3, 3, 3, 4, 5, 6, 6, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 9, 10, 11, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 28, 29, 30, 31, 32, 33, 34, 34, 34, 34, 35, 36, 37, 37, 37, 38, 39, 40, 40, 40, 41, 42, 42, 42, 43, 44, 45, 45, 45, 45, 46, 47, 47, 48, 48, 49, 49, 49, 50 };
  for (int i = 0; i < n; ++i) {
    if (sums[i] != sums[i + 1]) {
      formula_cl(f, 1, inp[i]);
    } else {
      formula_cl(f, 1, -inp[i]);
    }
  }
  PicoSAT* pico = picosat_init();
  uint numLits = 0;
  for (int i = 0; i < len; ++i) {
    sorter_update(s, f, k + i + 1);
    Literal* bs = sorter_sort(s, inp + 59 + i, 1, f, k + i + 1);
    intInp = sorter_merge(s, intInp, bs, 59 + i, 1, f, k + i + 1);
    Literal* newlits = formula_get_new_clauses(f, &numLits);
    //printf("-----------------\n");
    for (uint j = 0; j < numLits; ++j) {
      //if(newlits[j]){
      //  printf("%d ",newlits[j]);
      //} else {
      //  printf("\n");
      //}
      picosat_add(pico, newlits[j]);
    }
    assert_true(intInp[k + i] != 0);
    //printf("Assuming %d\n",-intInp[k+i]);
    picosat_assume(pico, -intInp[k + i]);
    int res = picosat_sat(pico, -1);
    if (k + i > sums[59 + i + 1]) {
      if (res != 10) {
        printf("In the cummulative sequence: ");
        for (int j = 0; j < 59 + i + 1; ++j) {
          printf("%d ", sums[j]);
        }
        printf("\nAssumed no more than %d was set\n", k - 1);
        printf("%d number of elements\n", 59 + i + 1);
        assert_int_eq(res, 10);
      }
    } else {
      if (res != 20) {
        printf("In the cummulative sequence: ");
        for (int j = 0; j < 59 + i + 1; ++j) {
          printf("%d ", sums[j]);
        }
        printf("\nAssumed no more than %d was set\n", k + i);
        printf("%d number of elements\n", 59 + i + 1);
        assert_int_eq(res, 20);
      }
    }
  }
  formula_free(f);
  picosat_reset(pico);
}

void test8(SortingScheme* s)
{
  Formula* f = formula_make();
  time_t t;
  srand((unsigned)time(&t));
  int n = 26;
  int m = 17;

  Literal inp[n];
  for (int i = 0; i < n; ++i) {
    inp[i] = formula_make_orig(f, i + 1);
  }

  int len = n - m;
  int k = 12 - len;
  Literal* intInp = sorter_sort(s, inp, m, f, k);
  int sums[] = { 0, 1, 2, 3, 3, 4, 5, 5, 5, 5, 6, 7, 8, 9, 10, 10, 11, 12, 12, 13, 13, 13, 13, 14, 15, 16, 16 };
  for (int i = 0; i < n; ++i) {
    if (sums[i] != sums[i + 1]) {
      formula_cl(f, 1, inp[i]);
    } else {
      formula_cl(f, 1, -inp[i]);
    }
  }
  PicoSAT* pico = picosat_init();
  uint numLits = 0;
  for (int i = 0; i < len; ++i) {
    sorter_update(s, f, k + i + 1);
    Literal* bs = sorter_sort(s, inp + m + i, 1, f, k + i + 1);
    intInp = sorter_merge(s, intInp, bs, m + i, 1, f, k + i + 1);
    Literal* newlits = formula_get_new_clauses(f, &numLits);
    //printf("-----------------\n");
    for (uint j = 0; j < numLits; ++j) {
      //if(newlits[j]){
      //  printf("%d ",newlits[j]);
      //} else {
      //  printf("\n");
      //}
      picosat_add(pico, newlits[j]);
    }
    assert_true(intInp[k + i] != 0);
    picosat_assume(pico, -intInp[k + i]);
    int res = picosat_sat(pico, -1);
    //printf("Asserting that after %d no more than %d, actually %d\n",m+i,k+i+1,sums[m+i]);
    if (k + i + 1 > sums[m + i]) {
      assert_int_eq(res, 10);
    } else {
      assert_int_eq(res, 20);
    }
  }
  formula_free(f);
  picosat_reset(pico);
}

void test9(SortingScheme* s, int m, int k, int incr)
{
  //printf("===========\n");
  Formula* f = formula_make();
  time_t t;
  srand((unsigned)time(&t));
  int n = 16 * m;
  int numInputs = m;

  Literal inp[n];
  Literal origs[n];
  for (int i = 0; i < m; ++i) {
    inp[i] = formula_make_orig(f, i + 1);
    origs[i] = inp[i];
  }
  for (int i = m; i < n; ++i) {
    inp[i] = 0;
    origs[i] = formula_make_orig(f, i + 1);
  }

  Literal* intInp = sorter_sort(s, inp, m, f, k);

  int numSet[n + 1];
  numSet[0] = 0;
  for (int i = 0; i < n; ++i) {
    if (rand() % 2) {
      formula_cl(f, 1, origs[i]);
      numSet[i + 1] = numSet[i] + 1;
    } else {
      formula_cl(f, 1, -origs[i]);
      numSet[i + 1] = numSet[i];
    }
  }
  PicoSAT* pico = picosat_init();
  while (n > m) {
    uint numLits = 0;
    Literal* newlits = formula_get_new_clauses(f, &numLits);
    for (uint j = 0; j < numLits; ++j) {
      picosat_add(pico, newlits[j]);
    }
    picosat_assume(pico, -intInp[k - 1]);
    int res = picosat_sat(pico, -1);
    if (k > numSet[numInputs]) {
      if (res != 10) {
        printf("In the cummulative sequence: ");
        for (int i = 0; i < m; ++i) {
          printf("%d ", numSet[i]);
        }
        printf("\nAssumed no more than %d was set\n", k - 1);
        printf("%d number of elements\n", numInputs);
        assert_int_eq(res, 10);
      }
    } else {
      if (res != 20) {
        printf("In the cummulative sequence: ");
        for (int i = 0; i < m; ++i) {
          printf("%d ", numSet[i]);
        }
        printf("\nAssumed no more than %d was set\n", k - 1);
        printf("%d number of elements\n", numInputs);
        assert_int_eq(res, 20);
      }
    }
    numInputs += incr;
    if (numInputs >= m) {
      m *= 2;
      if (m > n)
        break;
      Literal* bs = sorter_sort(s, inp + (m / 2), m / 2, f, k);
      intInp = sorter_merge(s, intInp, bs, m / 2, m / 2, f, k);
    }
    for (int i = numInputs - incr; i < numInputs; ++i) {
      inp[i] = origs[i];
    }
    sorter_update(s, f, k);
  }
  formula_free(f);
  picosat_reset(pico);
}

void test10(SortingScheme* s1, SortingScheme* s2, int n)
{
  Formula* f = formula_make();
  time_t t;
  srand((unsigned)time(&t));

  Literal inp[n];
  Literal diff[n];
  for (int i = 0; i < n; ++i) {
    inp[i] = formula_make_orig(f, i + 1);
  }
  for (int i = 0; i < n; ++i) {
    diff[i] = formula_make_orig(f, n + i + 1);
  }

  Literal* intInp = sorter_sort(s1, inp, n, f, n);
  Literal* intInp2 = sorter_sort(s2, inp, n, f, n);
  for (int i = 0; i < n; ++i) {
    formula_cl(f, 3, -intInp[i], -intInp2[i], -diff[i]);
    formula_cl(f, 3, intInp[i], intInp2[i], -diff[i]);
    formula_cl(f, 3, -intInp[i], intInp2[i], diff[i]);
    formula_cl(f, 3, intInp[i], -intInp2[i], diff[i]);
  }
  formula_add_clause(f, n, diff);

  PicoSAT* pico = picosat_init();
  uint numLits = 0;
  Literal* newlits = formula_get_new_clauses(f, &numLits);
  for (uint j = 0; j < numLits; ++j) {
    //if(newlits[j]){
    //  printf("%d ",newlits[j]);
    //} else {
    //  printf("\n");
    //}
    picosat_add(pico, newlits[j]);
  }
  int res = picosat_sat(pico, -1);
  if (res != 20) {
    for (int i = 0; i < n; ++i) {
      if (picosat_deref(pico, diff[i]) > 0) {
        printf("Outputs are different on outputs %d\n", i);
        printf("%d vs %d\n", picosat_deref(pico, intInp[i]), picosat_deref(pico, intInp2[i]));
      }
    }
    assert_int_eq(res, 20);
  }

  formula_free(f);
  picosat_reset(pico);
}

int main(int argc, char** argv)
{
  (void)argc;
  (void)argv;
  test1();
  SortingScheme* scheme;

  for (uint m = 1; m < 16; m++) {
    printf("m=%d\n", m);
    for (uint k = 2; k < m; k++) {
      for (uint inc = 1; inc <= m; inc++) {
        scheme = tot_make_scheme(extra);
        test2(scheme, m, k, inc);
        sorter_free(scheme);
        scheme = mixed_make_scheme(strat, extra);
        test2(scheme, m, k, inc);
        sorter_free(scheme);
        scheme = tot_make_scheme(extra);
        test9(scheme, m, k, inc);
        sorter_free(scheme);
        scheme = mixed_make_scheme(strat, extra);
        test9(scheme, m, k, inc);
        sorter_free(scheme);
      }
    }
  }
  for (uint m = 1; m < 12; m++) {
    printf("m=%d\n", m);
    SortingScheme* scheme2 = NULL;
    //printf("Testing tot vs tot\n");
    scheme = tot_make_scheme(extra);
    scheme2 = tot_make_scheme(extra);
    test10(scheme, scheme2, m);
    sorter_free(scheme);
    sorter_free(scheme2);
    //printf("Testing mixed vs tot\n");
    scheme = mixed_make_scheme(strat, extra);
    scheme2 = tot_make_scheme(extra);
    test10(scheme, scheme2, m);
    sorter_free(scheme);
    sorter_free(scheme2);
  }
  scheme = tot_make_scheme(extra);
  test6(scheme);
  sorter_free(scheme);
  scheme = mixed_make_scheme(strat, extra);
  test6(scheme);
  sorter_free(scheme);
  scheme = tot_make_scheme(extra);
  test7(scheme);
  sorter_free(scheme);
  scheme = mixed_make_scheme(strat, extra);
  test7(scheme);
  sorter_free(scheme);
  scheme = tot_make_scheme(extra);
  test8(scheme);
  sorter_free(scheme);
  scheme = mixed_make_scheme(strat, extra);
  test8(scheme);
  sorter_free(scheme);
  test3();
}
