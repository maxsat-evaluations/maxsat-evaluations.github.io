#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define assert_true(a)                      \
  {                                         \
    bool tassert_v = !(a);                  \
    if (tassert_v) {                        \
      printf("Assertion " #a " failed!\n"); \
      abort();                              \
    }                                       \
  }
#define assert_false(a)                         \
  {                                             \
    bool tassert_v = (a);                       \
    if (tassert_v) {                            \
      printf("Assertion not " #a " failed!\n"); \
      abort();                                  \
    }                                           \
  }

#define assert_int_eq(a, b)                                                   \
  {                                                                           \
    int tassert_v1 = (a);                                                     \
    int tassert_v2 = (b);                                                     \
    if (tassert_v1 != tassert_v2) {                                           \
      printf("Asserted " #a " was equal to " #b " but " #a "=%d," #b "=%d\n", \
          ((int)(a)), ((int)(b)));                                            \
      abort();                                                                \
    }                                                                         \
  }

#define assert_str_eq(a, b)                                         \
  {                                                                 \
    char* tassert_v1 = (a);                                         \
    char* tassert_v2 = (b);                                         \
    if (strcmp(tassert_v1, tassert_v2)) {                           \
      printf("Asserted " #a " was equal to " #b "but a=%s, b=%s\n", \
          tassert_v1, tassert_v2);                                  \
      abort();                                                      \
    }                                                               \
  }

#define assert_float_eq(a, b)                                       \
  {                                                                 \
    float tassert_v1 = (a);                                         \
    float tassert_v2 = (b);                                         \
    if (tassert_v1 != tassert_v2) {                                 \
      printf("Asserted " #a " was equal to " #b "but a=%f, b=%f\n", \
          tassert_v1, tassert_v2);                                  \
      abort();                                                      \
    }                                                               \
  }

#define assert_double_eq(a, b)                                        \
  {                                                                   \
    double tassert_v1 = (a);                                          \
    double tassert_v2 = (b);                                          \
    if (tassert_v1 != tassert_v2) {                                   \
      printf("Asserted " #a " was equal to " #b "but a=%lf, b=%lf\n", \
          tassert_v1, tassert_v2);                                    \
      abort();                                                        \
    }                                                                 \
  }
