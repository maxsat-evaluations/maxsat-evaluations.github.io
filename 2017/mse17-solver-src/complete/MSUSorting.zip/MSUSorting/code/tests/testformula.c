#include <glib.h>
#include <stdio.h>
#include <stdlib.h>

#include "picosat.h"

#include "formula.h"
#include "tassert.h"

void test1()
{
  Formula* f = formula_make();
  uint numCls = 0;
  Literal* cls = formula_get_new_clauses(f, &numCls);
  assert_true(cls != NULL);
  assert_int_eq(numCls, 2);
  Literal l = formula_make_orig(f, 2);
  formula_cl(f, 1, l);
  uint numLit = 0;
  Literal* el = formula_get_new_clauses(f, &numLit);
  assert_int_eq(el[0], formula_lookup_orig(f, l));
  formula_free(f);
}

int main(int argc, char** argv)
{
  (void)argc;
  (void)argv;
  test1();
}
