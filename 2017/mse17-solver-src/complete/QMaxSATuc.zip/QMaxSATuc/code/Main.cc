/*****************************************************************************************[Main.cc]
Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007,      Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include <errno.h>

#include <signal.h>
#include <zlib.h>
#include <sys/resource.h>

#include "utils/System.h"
#include "ParseUtils.h" // koshi 20170612 
#include "utils/Options.h"
#include "Dimacs.h" // koshi 20170612
#include "simp/SimpSolver.h"

using namespace Glucose;

/*
  koshi 20141021
  based on minisat2-070721/maxsat14.08-2.0simp
 */
// koshi 20140106
#define TOTALIZER 128

//=================================================================================================


void printStats(Solver& solver)
{
    double cpu_time = cpuTime();
    double mem_used = memUsedPeak();
    printf("c restarts              : %"PRIu64"\n", solver.starts);
    printf("c conflicts             : %-12"PRIu64"   (%.0f /sec)\n", solver.conflicts   , solver.conflicts   /cpu_time);
    printf("c decisions             : %-12"PRIu64"   (%4.2f %% random) (%.0f /sec)\n", solver.decisions, (float)solver.rnd_decisions*100 / (float)solver.decisions, solver.decisions   /cpu_time);
    printf("c propagations          : %-12"PRIu64"   (%.0f /sec)\n", solver.propagations, solver.propagations/cpu_time);
    printf("c conflict literals     : %-12"PRIu64"   (%4.2f %% deleted)\n", solver.tot_literals, (solver.max_literals - solver.tot_literals)*100 / (double)solver.max_literals);
    if (mem_used != 0) printf("c Memory used           : %.2f MB\n", mem_used);
    printf("c CPU time              : %g s\n", cpu_time);
}


static Solver* solver;
// Terminate by notifying the solver and back out gracefully. This is mainly to have a test-case
// for this feature of the Solver as it may take longer than an immediate call to '_exit()'.
static void SIGINT_interrupt(int signum) { solver->interrupt(); }

// Note that '_exit()' rather than 'exit()' has to be used. The reason is that 'exit()' calls
// destructors and may cause deadlocks if a malloc/free function happens to be running (these
// functions are guarded by locks for multithreaded use).
static void SIGINT_exit(int signum) {
    printf("\n"); printf("*** INTERRUPTED ***\n");
    if (solver->verbosity > 0){
        printStats(*solver);
        printf("\n"); printf("*** INTERRUPTED ***\n"); }
    _exit(1); }

// koshi 20140106 based on minisat2-070721/maxsat0.2e
// Lit -> mkLit, addClause -> addClause_
// koshi 2013.05.23
long long int sumWeight(vec<long long int>& weights) {
  long long int sum = 0;
  for(int i = 0; i < weights.size(); i++) sum += weights[i];
  return sum;
}

/*
  Cardinality Constraints:
  Joost P. Warners, "A linear-time transformation of linear inequalities
  into conjunctive normal form", 
  Information Processing Letters 68 (1998) 63-69
 */

// koshi 2013.04.16
void genWarnersHalf(Lit& a, Lit& b, Lit& carry, Lit& sum, int comp,
		       Solver& S, vec<Lit>& lits) {
  // carry
  lits.clear();
  lits.push(~a); lits.push(~b); lits.push(carry);  S.addClause_(lits);
  // sum
  lits.clear();
  lits.push(a); lits.push(~b); lits.push(sum);  S.addClause_(lits);
  lits.clear();
  lits.push(~a); lits.push(b); lits.push(sum);  S.addClause_(lits);
  //
  if (comp == 1 || comp == 2) {
    lits.clear();
    lits.push(carry); lits.push(sum); lits.push(~a); S.addClause_(lits);
    lits.clear();
    lits.push(carry); lits.push(sum); lits.push(~b); S.addClause_(lits);
  }
  if (comp == 2) {
    lits.clear();
    lits.push(~carry); lits.push(~sum); S.addClause_(lits);
    lits.clear();
    lits.push(~carry); lits.push(sum); lits.push(a); S.addClause_(lits);
    lits.clear();
    lits.push(~carry); lits.push(sum); lits.push(b); S.addClause_(lits);
  }
  // koshi 2013.05.31
  if (comp == 10 || comp == 11) { // [Warners 1996]
    // carry
    lits.clear(); lits.push(a); lits.push(~carry); S.addClause_(lits);
    lits.clear(); lits.push(b); lits.push(~carry); S.addClause_(lits);
    // sum
    lits.clear();
    lits.push(~a); lits.push(~b); lits.push(~sum);  S.addClause_(lits);
    lits.clear();
    lits.push(a); lits.push(b); lits.push(~sum);  S.addClause_(lits);
  }
}

// koshi 2013.04.16
void genWarnersFull(Lit& a, Lit& b, Lit& c, Lit& carry, Lit& sum, int comp,
		       Solver& S, vec<Lit>& lits) {
  // carry
  lits.clear();
  lits.push(~a); lits.push(~b); lits.push(carry); S.addClause_(lits);
  lits.clear();
  lits.push(~a); lits.push(~c); lits.push(carry); S.addClause_(lits);
  lits.clear();
  lits.push(~b); lits.push(~c); lits.push(carry); S.addClause_(lits);
  // sum
  lits.clear();
  lits.push(a); lits.push(b); lits.push(~c); lits.push(sum);
  S.addClause_(lits);
  lits.clear();
  lits.push(a); lits.push(~b); lits.push(c); lits.push(sum);
  S.addClause_(lits);
  lits.clear();
  lits.push(~a); lits.push(b); lits.push(c); lits.push(sum);
  S.addClause_(lits);
  lits.clear();
  lits.push(~a); lits.push(~b); lits.push(~c); lits.push(sum);
  S.addClause_(lits);
  if (comp == 1 || comp == 2) {
    lits.clear();
    lits.push(carry); lits.push(sum); lits.push(~a); S.addClause_(lits);
    lits.clear();
    lits.push(carry); lits.push(sum); lits.push(~b); S.addClause_(lits);
    lits.clear();
    lits.push(carry); lits.push(sum); lits.push(~c); S.addClause_(lits);
  }
  if (comp == 2) {
    lits.clear();
    lits.push(~carry); lits.push(~sum); lits.push(a); S.addClause_(lits);
    lits.clear();
    lits.push(~carry); lits.push(~sum); lits.push(b); S.addClause_(lits);
    lits.clear();
    lits.push(~carry); lits.push(~sum); lits.push(c); S.addClause_(lits);
  }
  // koshi 2013.05.31
  if (comp == 10 || comp == 11) {// [Warners 1996]
    // carry
    lits.clear();
    lits.push(a); lits.push(b); lits.push(~carry); S.addClause_(lits);
    lits.clear();
    lits.push(a); lits.push(c); lits.push(~carry); S.addClause_(lits);
    lits.clear();
    lits.push(b); lits.push(c); lits.push(~carry); S.addClause_(lits);
    // sum
    lits.clear();
    lits.push(a); lits.push(b); lits.push(c); lits.push(~sum);
    S.addClause_(lits);
    lits.clear();
    lits.push(~a); lits.push(~b); lits.push(c); lits.push(~sum);
    S.addClause_(lits);
    lits.clear();
    lits.push(~a); lits.push(b); lits.push(~c); lits.push(~sum);
    S.addClause_(lits);
    lits.clear();
    lits.push(a); lits.push(~b); lits.push(~c); lits.push(~sum);
    S.addClause_(lits);
  }
}
/*
#define wbsplit(wL,wR, ws,bs, wsL,bsL, wsR,bsR) \
  wsL.clear(); bsL.clear(); wsR.clear(); bsR.clear(); \
  for(int i = 0; i < ws.size(); i++) { \
    if (wL < wR) { \
      wsL.push(ws[i]); \
      bsL.push(bs[i]); \
      wL += ws[i]; \
    } else { \
      wsR.push(ws[i]); \
      bsR.push(bs[i]); \
      wR += ws[i]; \
    } \
  } 
*/
/*
#define wbsplit(half,wL,wR, ws,bs, wsL,bsL, wsR,bsR) \
  wsL.clear(); bsL.clear(); wsR.clear(); bsR.clear(); \
  int ii = 0; \
  for(; ii < ws.size()-1; ii++) { \
    if(wL >= half) break; \
    wsL.push(ws[ii]); \
    bsL.push(bs[ii]); \
    wL += ws[ii]; \
  } \
  for(; ii < ws.size(); ii++) { \
    wsR.push(ws[ii]); \
    bsR.push(bs[ii]); \
    wR += ws[ii]; \
  }
*/
#define wbsplit(half,wL,wR, ws,bs, wsL,bsL, wsR,bsR) \
  wsL.clear(); bsL.clear(); wsR.clear(); bsR.clear(); \
  int ii = 0; \
  int wsSizeHalf = ws.size()/2; \
  for(; ii < wsSizeHalf; ii++) { \
    wsL.push(ws[ii]); \
    bsL.push(bs[ii]); \
    wL += ws[ii]; \
  } \
  for(; ii < ws.size(); ii++) { \
    wsR.push(ws[ii]); \
    bsR.push(bs[ii]); \
    wR += ws[ii]; \
  }


// koshi 2013.03.25 
// Parallel counter
// koshi 2013.04.16, 2013.05.23
void genWarners(vec<long long int>& weights, vec<Lit>& blockings,
		long long int max, int k, 
		int comp, Solver& S, const Lit zero,
		vec<Lit>& lits, vec<Lit>& linkingVar) {

  linkingVar.clear();
  bool dvar = (comp == 11) ? false : true;

  if (weights.size() == 1) {
    long long int weight = weights[0];
    vec<bool> pn;
    pn.clear(); 
    while (weight > 0) {
      if (weight%2 == 0) pn.push(false);
      else pn.push(true);
      weight /= 2;
    }
    for(int i = 0; i < pn.size(); i++) {
      if (pn[i]) linkingVar.push(blockings[0]);
      else linkingVar.push(zero);
    }
    pn.clear();
  } else if (weights.size() > 1) {
    long long int weightL = 0; long long int weightR = 0;
    vec<long long int> weightsL, weightsR;
    vec<Lit> blockingsL, blockingsR;
    /*
    weightsL.clear(); weightsR.clear();
    blockingsL.clear(); blockingsR.clear();
    for(int i = 0; i < weights.size(); i++) {
      if (weightL < weightR) {
	weightsL.push(weights[i]);
	blockingsL.push(blockings[i]);
	weightL += weights[i];
      } else {
	weightsR.push(weights[i]);
	blockingsR.push(blockings[i]);
	weightR += weights[i];
      }
    }
    */
    long long int half = max/2;
    wbsplit(half,weightL,weightR, weights,blockings,
	    weightsL,blockingsL, weightsR,blockingsR);

    vec<Lit> alpha;
    vec<Lit> beta;
    Lit sum = mkLit(S.newVar(true,dvar));
    Lit carry = mkLit(S.newVar(true,dvar));
    genWarners(weightsL, blockingsL, weightL,k, comp, S, zero, lits,alpha);
    genWarners(weightsR, blockingsR, weightR,k, comp, S, zero, lits,beta);
    weightsL.clear(); weightsR.clear();
    blockingsL.clear(); blockingsR.clear();

    bool lessthan = (alpha.size() < beta.size());
    vec<Lit> &smalls = lessthan ? alpha : beta;
    vec<Lit> &larges = lessthan ? beta : alpha;
    assert(smalls.size() <= larges.size());

    genWarnersHalf(smalls[0],larges[0], carry,sum, comp, S,lits);
    linkingVar.push(sum);

    int i = 1;
    Lit carryN;
    for(; i < smalls.size(); i++) {
      sum = mkLit(S.newVar(true,dvar));
      carryN = mkLit(S.newVar(true,dvar));
      genWarnersFull(smalls[i],larges[i],carry, carryN,sum, comp, S,lits);
      linkingVar.push(sum);
      carry = carryN;
    }
    for(; i < larges.size(); i++) {
      sum = mkLit(S.newVar(true,dvar));
      carryN = mkLit(S.newVar(true,dvar));
      genWarnersHalf(larges[i],carry, carryN,sum, comp, S,lits);
      linkingVar.push(sum);
      carry = carryN;
    }
    linkingVar.push(carry);
    alpha.clear();beta.clear();
  }
  int lsize = linkingVar.size();
  for (int i = k; i < lsize; i++) { // koshi 2013.05.27
    //    printf("shrink: k = %d, lsize = %d\n",k,lsize);
    lits.clear();
    lits.push(~linkingVar[i]);
    S.addClause_(lits);
  }
  for (int i = k; i < lsize; i++) linkingVar.shrink(1); // koshi 2013.05.27
}

// koshi 2013.05.23
void wbSort(vec<long long int>& weights, vec<Lit>& blockings,
	    vec<long long int>& sweights, vec<Lit>& sblockings) {
  sweights.clear(); sblockings.clear();
  /*
  for(int i = 0; i < weights.size(); i++) {
    int maxi = i;
    for(int j = i+1; j < weights.size(); j++) {
      if(weights[maxi] < weights[j]) maxi = j;
    }
    if (maxi != i) { // swap
      long long int tweight = weights[maxi];
      Lit tblocking = blockings[maxi];
      weights[maxi] = weights[i];
      blockings[maxi] = blockings[i];
      weights[i] = tweight;
      blockings[i] = tblocking;
    }
  }
  */
  for(int i = 0; i < weights.size(); i++) {
    sweights.push(weights[i]);
    sblockings.push(blockings[i]);
  }
}

// koshi 20140121
void wbFilter(long long int UB, Solver& S,vec<Lit>& lits,
	      vec<long long int>& weights, vec<Lit>& blockings,
	      vec<long long int>& sweights, vec<Lit>& sblockings) {
  sweights.clear(); sblockings.clear();

  for(int i = 0; i < weights.size(); i++) {
    if (weights[i] < UB) {
      sweights.push(weights[i]);
      sblockings.push(blockings[i]);
    } else {
      lits.clear();
      lits.push(~blockings[i]);
      S.addClause_(lits); // koshi 20141111
    }
  }
}

// koshi 2013.06.28
void genWarners0(vec<long long int>& weights, vec<Lit>& blockings,
		 long long int max,long long int k, int comp, Solver& S,
		  vec<Lit>& lits, vec<Lit>& linkingVar) {
  // koshi 20140109
  printf("c Warners' encoding for Cardinality Constraints\n");

  int logk = 1;
  while ((k >>= 1) > 0) logk++;
  Lit zero = mkLit(S.newVar());
  lits.clear();
  lits.push(~zero);
  S.addClause_(lits);
  genWarners(weights,blockings, max,logk, comp, S, zero,lits,linkingVar);
}

/*
  Cardinaltiy Constraints:
  Olivier Bailleux and Yacine Boufkhad, 
  "Efficient CNF Encoding of Boolean Cardinality Constraints",
  CP 2003, LNCS 2833, pp.108-122, 2003
 */
// koshi 10.01.08
// 10.01.15 argument UB is added
void genBailleux(vec<long long int>& weights, vec<Lit>& blockings,
		 long long int total,
		 Lit zero, Lit one, int comp,Solver& S, 
		 vec<Lit>& lits, vec<Lit>& linkingVar, long long int UB) {
  assert(weights.size() == blockings.size());

  linkingVar.clear();
  bool dvar = (comp == 11) ? false : true;

  vec<Lit> linkingAlpha;
  vec<Lit> linkingBeta;

  if (blockings.size() == 1) {// koshi 20140121
    long long int weight = weights[0];
    assert(weight < UB);
    linkingVar.push(one);
    for(int i = 0; i<weight; i++) linkingVar.push(blockings[0]);
    linkingVar.push(zero);
  } else if (blockings.size() > 1) {
    long long int weightL = 0; long long int weightR = 0;
    vec<long long int> weightsL, weightsR;
    vec<Lit> blockingsL, blockingsR;
    long long int half = total/2;
    wbsplit(half, weightL,weightR, weights,blockings,
	    weightsL,blockingsL, weightsR,blockingsR);

    genBailleux(weightsL,blockingsL,weightL,
		zero,one, comp,S, lits, linkingAlpha, UB);
    genBailleux(weightsR,blockingsR,weightR,
		zero,one, comp,S, lits, linkingBeta, UB);

    weightsL.clear();blockingsL.clear();
    weightsR.clear();blockingsR.clear();

    linkingVar.push(one);
    for (int i = 0; i < total && i <= UB; i++) 
      linkingVar.push(mkLit(S.newVar(true,dvar)));
    linkingVar.push(zero);
      
    for (long long int sigma = 0; sigma <= total && sigma <= UB; sigma++) {
      for (long long int alpha = 0; 
	   alpha < linkingAlpha.size()-1 && alpha <= UB;
	   alpha++) {
	long long int beta = sigma - alpha;
	if (0 <= beta && beta < linkingBeta.size()-1 && beta <= UB) {
	  lits.clear();
	  lits.push(~linkingAlpha[alpha]);
	  lits.push(~linkingBeta[beta]);
	  lits.push(linkingVar[sigma]);
	  S.addClause_(lits);
	  if (comp >= 10) {
	    lits.clear();
	    lits.push(linkingAlpha[alpha+1]);
	    lits.push(linkingBeta[beta+1]);
	    lits.push(~linkingVar[sigma+1]);
	    S.addClause_(lits);
	  }
	}
      }
    }
  }
  linkingAlpha.clear();
  linkingBeta.clear();
}

void genBailleux0(vec<long long int>& weights, vec<Lit>& blockings,
		  long long int max, long long int k, int comp, Solver& S,
		  vec<Lit>& lits, vec<Lit>& linkingVar) {
  // koshi 20140109
  printf("c Bailleux's encoding for Cardinailty Constraints k = %lld\n", k);

  Lit one = mkLit(S.newVar());
  lits.clear();
  lits.push(one);
  S.addClause_(lits);

  genBailleux(weights,blockings,max, ~one,one, comp,S, lits, linkingVar, k);
}

/*
  Cardinaltiy Constraints:
  Robert Asin, Robert Nieuwenhuis, Albert Oliveras, Enric Rodriguez-Carbonell
  "Cardinality Networks: a theoretical and empirical study",
  Constraints (2011) 16:195-221
 */
// koshi 2013.07.01
inline void sComparator(Lit& a, Lit& b, Lit& c1, Lit& c2, 
		       int comp,Solver& S, vec<Lit>& lits) {
  lits.clear();
  lits.push(~a); lits.push(~b); lits.push(c2);
  S.addClause_(lits);
  lits.clear();
  lits.push(~a); lits.push(c1);
  S.addClause_(lits);
  lits.clear();
  lits.push(~b); lits.push(c1);
  S.addClause_(lits);
  if (comp >= 10) {
    lits.clear();
    lits.push(a); lits.push(b); lits.push(~c1);
    S.addClause_(lits);
    lits.clear();
    lits.push(a); lits.push(~c2);
    S.addClause_(lits);
    lits.clear();
    lits.push(b); lits.push(~c2);
    S.addClause_(lits);
  }
}

// koshi 2013.07.01
void genSMerge(vec<Lit>& linkA, vec<Lit>& linkB,
	      Lit zero, Lit one, int comp,Solver& S, 
	      vec<Lit>& lits, vec<Lit>& linkingVar, long long int UB) {

  /* koshi 2013.12.10
  assert(UB > 0); is violated when k <= 1
  */

  bool lessthan = (linkA.size() <= linkB.size());
  vec<Lit> &tan = lessthan ? linkA : linkB;
  vec<Lit> &tyou = lessthan ? linkB : linkA;
  assert(tan.size() <= tyou.size());

  linkingVar.clear();
  bool dvar = (comp == 11) ? false : true;

  if (tan.size() == 0)
    for(long long int i = 0; i < tyou.size(); i++) linkingVar.push(tyou[i]);
  else if (tan.size() == 1 && tyou.size() == 1) {
    Lit c1 = mkLit(S.newVar(true,dvar));
    Lit c2 = mkLit(S.newVar(true,dvar));
    linkingVar.push(c1); linkingVar.push(c2);
    sComparator(tan[0],tyou[0], c1,c2, comp,S, lits);
  } else {
    vec<Lit> oddA,oddB, evenA,evenB;
    oddA.clear(); oddB.clear(); evenA.clear(); evenB.clear();

    long long int i;
    for(i = 0; i < tan.size(); i++) {
      if (i%2 == 0) {
	evenA.push(tan[i]); evenB.push(tyou[i]);
      } else {
	oddA.push(tan[i]); oddB.push(tyou[i]);
      }
    }
    for(; i < tyou.size(); i++) {
      if (i%2 == 0) {
	evenA.push(zero); evenB.push(tyou[i]);
      } else {
	oddA.push(zero); oddB.push(tyou[i]);
      }
    }

    // koshi 2013.07.04
    long long int UBceil = UB/2 + UB%2;
    long long int UBfloor = UB/2;
    assert(UBfloor <= UBceil);
    vec<Lit> d, e;
    genSMerge(evenA,evenB, zero,one, comp,S, lits, d, UBceil);
    genSMerge(oddA,oddB, zero,one, comp,S, lits, e, UBfloor);
    oddA.clear(); oddB.clear(); evenA.clear(); evenB.clear();

    linkingVar.push(d[0]);

    assert(d.size() >= e.size());

    while (d.size() > e.size()) e.push(zero);
    for(i = 0; i < e.size()-1; i++) {
      Lit c2i = mkLit(S.newVar(true,dvar));
      Lit c2ip1 = mkLit(S.newVar(true,dvar));
      linkingVar.push(c2i); linkingVar.push(c2ip1);
      sComparator(d[i+1],e[i], c2i,c2ip1, comp,S, lits);
    }

    linkingVar.push(e[i]);

    for (long long int i = UB+1; i < linkingVar.size(); i++) {
      lits.clear();
      lits.push(~linkingVar[i]);
      S.addClause_(lits);
    }
    long long int ssize = linkingVar.size() - UB - 1;
    if (ssize > 0) linkingVar.shrink(ssize);

    d.clear(); e.clear();
  }

}
// koshi 2013.07.01
void genKCard(vec<long long int>& weights, vec<Lit>& blockings,
	      long long int total,
	      Lit zero, Lit one, int comp,Solver& S, 
	      vec<Lit>& lits, vec<Lit>& linkingVar, long long int UB) {

  linkingVar.clear();

  if (blockings.size() == 1) {
    long long int weight = weights[0];
    assert(weight <= UB);
    // koshi 20140121
    for(int i = 0; i<weight; i++) linkingVar.push(blockings[0]);
  } else if (blockings.size() > 1) {
    vec<Lit> linkingAlpha;
    vec<Lit> linkingBeta;

    long long int weightL = 0; long long int weightR = 0;
    vec<long long int> weightsL, weightsR;
    vec<Lit> blockingsL, blockingsR;
    long long int half = total/2;
    wbsplit(half,weightL,weightR, weights,blockings,
	    weightsL,blockingsL, weightsR,blockingsR);

    genKCard(weightsL,blockingsL,weightL,
		zero,one, comp,S, lits, linkingAlpha, UB);
    genKCard(weightsR,blockingsR,weightR,
		zero,one, comp,S, lits, linkingBeta, UB);

    genSMerge(linkingAlpha,linkingBeta, zero,one, comp,S, lits, linkingVar, UB);

    linkingAlpha.clear();
    linkingBeta.clear();
  }
}

// koshi 2013.07.01
void genAsin(vec<long long int>& weights, vec<Lit>& blockings,
		  long long int max, long long int k, int comp, Solver& S,
		  vec<Lit>& lits, vec<Lit>& linkingVar) {
  // koshi 20140109
  printf("c Asin's encoding for Cardinailty Constraints\n");

  Lit one = mkLit(S.newVar());
  lits.clear();
  lits.push(one);
  S.addClause_(lits);

  genKCard(weights,blockings,max, ~one,one, comp,S, lits, linkingVar, k);
}


/*
  Cardinaltiy Constraints:
  Toru Ogawa, YangYang Liu, Ryuzo Hasegawa, Miyuki Koshimura, Hiroshi Fujita,
  "Modulo Based CNF Encoding of Cardinality Constraints and Its Application to
   MaxSAT Solvers",
  ICTAI 2013.
 */
// koshi 2013.10.03
void genOgawa(long long int weightX, vec<Lit>& linkingX,
	      long long int weightY, vec<Lit>& linkingY,
	      long long int& total, long long int divisor,
	      Lit zero, Lit one, int comp,Solver& S, 
	      vec<Lit>& lits, vec<Lit>& linkingVar, long long int UB) {

  total = weightX+weightY;
  if (weightX == 0) 
    for(int i = 0; i < linkingY.size(); i++) linkingVar.push(linkingY[i]);
  else if (weightY == 0)
    for(int i = 0; i < linkingX.size(); i++) linkingVar.push(linkingX[i]);
  else {
    long long int upper= total/divisor;
    long long int divisor1=divisor-1;
    /*
    printf("weightX = %lld, linkingX.size() = %d ", weightX,linkingX.size());
    printf("weightY = %lld, linkingY.size() = %d\n", weightY,linkingY.size());
    printf("upper = %lld, divisor1 = %lld\n", upper,divisor1);
    */

    linkingVar.push(one);
    for (int i = 0; i < divisor1; i++) linkingVar.push(mkLit(S.newVar()));
    linkingVar.push(one);
    for (int i = 0; i < upper; i++) linkingVar.push(mkLit(S.newVar()));
    Lit carry = mkLit(S.newVar());

    // lower part
    for (int i = 0; i < divisor; i++)
      for (int j = 0; j < divisor; j++) {
	int ij = i+j;
	lits.clear();
	lits.push(~linkingX[i]);
	lits.push(~linkingY[j]);
	if (ij < divisor) {
	  lits.push(linkingVar[ij]);
	  lits.push(carry);
	} else if (ij == divisor) lits.push(carry);
	else if (ij > divisor) lits.push(linkingVar[ij%divisor]);
	S.addClause_(lits);
      }

    // upper part
    for (int i = divisor; i < linkingX.size(); i++)
      for (int j = divisor; j < linkingY.size(); j++) {
	int ij = i+j-divisor;
	lits.clear();
	lits.push(~linkingX[i]);
	lits.push(~linkingY[j]);
	if (ij < linkingVar.size()) lits.push(linkingVar[ij]);
	S.addClause_(lits);
	//	printf("ij = %lld, linkingVar.size() = %lld\n",ij,linkingVar.size());
	lits.clear();
	lits.push(~carry);
	lits.push(~linkingX[i]);
	lits.push(~linkingY[j]);
	if (ij+1 < linkingVar.size()) lits.push(linkingVar[ij+1]);
	S.addClause_(lits);
      }
  }
  linkingX.clear(); linkingY.clear();
}

void genOgawa(vec<long long int>& weights, vec<Lit>& blockings,
	      long long int& total, long long int divisor,
	      Lit zero, Lit one, int comp,Solver& S, 
	      vec<Lit>& lits, vec<Lit>& linkingVar, long long int UB) {

  linkingVar.clear();

  vec<Lit> linkingAlpha;
  vec<Lit> linkingBeta;

  if (total < divisor) {
    vec<Lit> linking;
    genBailleux(weights,blockings,total,
		zero,one, comp,S, lits, linking, UB);
    total = linking.size()-2;
    for(int i = 0; i < divisor; i++) 
      if (i < linking.size()) linkingVar.push(linking[i]);
      else linkingVar.push(zero);
    linkingVar.push(one);
    linking.clear();
    //    printf("total = %lld, linkngVar.size() = %d\n", total,linkingVar.size());
  } else if (blockings.size() == 1) {
    long long int weight = weights[0];
    if (weight < UB) {
      long long int upper = weight/divisor; 
      long long int lower = weight%divisor;
      long long int pad = divisor-lower-1;
      linkingVar.push(one);
      for (int i = 0; i < lower; i++) linkingVar.push(blockings[0]);
      for (int i = 0; i < pad; i++) linkingVar.push(zero);
      linkingVar.push(one);
      for (int i = 0; i < upper; i++) linkingVar.push(blockings[0]);
      total = weight;
    } else {
      lits.clear();
      lits.push(~blockings[0]);
      S.addClause_(lits);
      total = 0;
    }
  } else if (blockings.size() > 1) {
    long long int weightL = 0; long long int weightR = 0;
    vec<long long int> weightsL, weightsR;
    vec<Lit> blockingsL, blockingsR;
    long long int half = total/2;
    wbsplit(half, weightL,weightR, weights,blockings,
	    weightsL,blockingsL, weightsR,blockingsR);

    genOgawa(weightsL,blockingsL,weightL,divisor,
	     zero,one, comp,S, lits, linkingAlpha, UB);
    genOgawa(weightsR,blockingsR,weightR,divisor,
	     zero,one, comp,S, lits, linkingBeta, UB);
    
    weightsL.clear();blockingsL.clear();
    weightsR.clear();blockingsR.clear();

    genOgawa(weightL,linkingAlpha, weightR,linkingBeta, total,divisor,
	      zero,one, comp,S, lits, linkingVar, UB);
  }
  // koshi 2013.11.12
  long long int upper = (UB-1)/divisor;
  for (long long int i = divisor+upper+1; i < linkingVar.size(); i++) {
    lits.clear();
    lits.push(~linkingVar[i]);
    S.addClause_(lits);
  }
  while (divisor+upper+2 < linkingVar.size()) linkingVar.shrink(1);
}

void genOgawa0(int& card, // koshi 2013.12.24
	       vec<long long int>& weights, vec<Lit>& blockings,
	       long long int max, long long int k,
	       long long int& divisor, int comp, Solver& S,
	       vec<Lit>& lits, vec<Lit>& linkingVar) {
  // koshi 20140603  assert(max >= TOTALIZER);

  /* koshi 2013.11.11
  long long int max0 = max;
  */
  long long int k0 = k;
  long long int odd = 1;
  divisor = 0;
  /* koshi 2013.11.11
  while (max0 > 0) {
    divisor++;
    max0 -= odd;
    odd += 2;
  }
  */
  while (k0 > 0) {
    divisor++;
    k0 -= odd;
    odd += 2;
  }
  printf("c max = %lld, divisor = %lld\n", max,divisor);

  // koshi 2013.12.24
  if (divisor <= 2) {
    printf("c divisor is less than or equal to 2 ");
    printf("so we use Warner's encoding, i.e. -card=warn\n");
    card = 0;
    genWarners0(weights,blockings, max,k, comp, S, lits,linkingVar);
  } else {
    // koshi 20140109
    printf("c Ogawa's encoding for Cardinality Constraints\n");

    Lit one = mkLit(S.newVar());
    lits.clear();
    lits.push(one);
    S.addClause_(lits);
    genOgawa(weights,blockings, max,divisor,
	     ~one,one, comp,S, lits, linkingVar, k);
  }
}


// koshi 2013.04.05, 2013.05.21, 2013.06.28, 2013.07.01, 2013.10.04
// koshi 20140121
void genCardinals(int& card, int comp,
		  vec<long long int>& weights, vec<Lit>& blockings, 
		  long long int max, long long int k, 
		  long long int& divisor, // koshi 2013.10.04
		  Solver& S, vec<Lit>& lits, vec<Lit>& linkingVar) {
  assert(weights.size() == blockings.size());

  vec<long long int> sweights;
  vec<Lit> sblockings;
  /* koshi 20150122
  wbSort(weights,blockings, sweights,sblockings);
  wbFilter(k,S,lits, sweights,sblockings, weights,blockings);
  */
  wbFilter(k,S,lits, weights,blockings, sweights,sblockings);

  /* koshi 20150122
  long long int sum = sumWeight(weights); // koshi 20140124
  printf("c Sum of weights = %lld\n",sum);
  printf("c A number of soft clauses remained = %d\n",blockings.size());
  */
  long long int sum = sumWeight(sweights); // koshi 20140124
  printf("c Sum of weights = %lld\n",sum);
  printf("c A number of soft clauses remained = %d\n",sblockings.size());

  if (card == -1) { // koshi 20140324 auto mode
    printf("c auto-mode for generating cardinality constraints\n");
    int logk = 0;
    int logsum = 0;
    for (long long int ok = k; ok > 0; ok = ok >> 1) logk++;
    for (long long int osum = sum; osum > 0; osum = osum >> 1) logsum++;
    printf("c logk = %d, logsum = %d\n",logk,logsum);
    if (logk+logsum < 15) {
      // Bailleux
      card = 1; comp = 0;
      printf("c Bailleux's encoding (comp=0)\n");
    } else if (k < 3) {// Warners
      card = 0; comp = 1;
      printf("c Warners' encoding (comp=1)\n");
    } else if (logsum < 17) {// Ogawa
      card = 3; comp = 0;
      printf("c Ogawa's encoding (comp=0)\n");
    } else {
      card = 0; comp = 1;
      printf("c Warners' encoding (comp=1)\n");
    }
  }

  /* koshi 20150122
  if (weights.size() == 0) {linkingVar.clear();} else // koshi 20140124 20140129
  // koshi 2013.06.28
  if (card == 0) // Warners
    genWarners0(weights,blockings, max,k, comp, S, lits,linkingVar);
  else if (card == 1) // Bailleux
    genBailleux0(weights,blockings, max,k, comp, S, lits,linkingVar);
  else if (card == 2) // Asin
    genAsin(weights,blockings, max,k, comp, S, lits,linkingVar);
  else if (card == 3) // Ogawa
    genOgawa0(card, // koshi 2013.12.24
	      weights,blockings, max,k,divisor, comp, S, lits,linkingVar);
  */
  if (sweights.size() == 0) {linkingVar.clear();} 
  else if (card == 0) // Warners
    genWarners0(sweights,sblockings, max,k, comp, S, lits,linkingVar);
  else if (card == 1) // Bailleux
    genBailleux0(sweights,sblockings, max,k, comp, S, lits,linkingVar);
  else if (card == 2) // Asin
    genAsin(sweights,sblockings, max,k, comp, S, lits,linkingVar);
  else if (card == 3) // Ogawa
    genOgawa0(card, // koshi 2013.12.24
	      sweights,sblockings, max,k,divisor, comp, S, lits,linkingVar);

  sweights.clear(); sblockings.clear();
}

// koshi 13.04.05, 13.06.28, 13.07.01, 13.10.04
void lessthan(int card, vec<Lit>& linking, long long int ok, long long int k,
	      long long int divisor, // koshi 13.10.04
	      vec<long long int>& cc, Solver& S, vec<Lit>& lits) {
  assert(k > 0);
  if (linking.size() == 0) {} else // koshi 20140124 20140129
  if (card == 1) {// Bailleux encoding (Totalizer)
    for (long long int i = k; 
	 i < linking.size() && i < ok; i++) {
      lits.clear();
      lits.push(~linking[i]);
      S.addClause_(lits);
    }
  } else if (card == 2) {// Asin encoding
    for (long long int i = k-1; 
	 i < linking.size() && i < ok; i++) {
      lits.clear();
      lits.push(~linking[i]);
      S.addClause_(lits);
    }
  } else if (card == 3) {// Ogawa encoding (Modulo Totalizer)
    long long int upper = (k-1)/divisor;
    long long int lower = k%divisor;
    long long int oupper = ok/divisor;
    //    printf("upper = %lld, oupper = %lld\n", upper,oupper);
    if (upper < oupper) 
      for (long long int i = divisor+upper+1; i < divisor+oupper+1; i++) {
	if (linking.size() <= i) break;
	else {
	  //	  printf("linking i = %lld ",i);
	  lits.clear();
	  lits.push(~linking[i]);
	  S.addClause_(lits);
	}
      }
    upper = k/divisor;
    lits.clear();
    lits.push(~linking[divisor+upper]);
    lits.push(~linking[lower]);
    //    printf("divisor+upper = %lld, lower = %lld\n",divisor+upper,lower);
    S.addClause_(lits);
  } else if (card == 0) {// Warners encoding
    vec<long long int> cls;
    cls.clear();
    
    k--;
    if (k%2 == 0) cls.push(1);
    k = k/2;
    int cnt = 1;
    long long int pos = 0x0002LL;
    while (k > 0) {
      if (k%2 == 0) cls.push(pos);
      //    else if (cls.size() == 0) cls.push(pos);
      else for(int i = 0; i < cls.size(); i++) cls[i] = cls[i] | pos;
      pos = pos << 1;
      k = k/2;
      cnt++;
    }
    for(int i = cnt; i < linking.size(); i++) {
      cls.push(pos);
      pos = pos << 1;
    }
    for(int i = 0; i < cls.size(); i++) {
      long long int x = cls[i];
      bool found = false;
      for(int j = 0; j < cc.size(); j++) {
	if (x == cc[j]) {
	  found = true; break;
	}
      }
      if (!found) {
	cc.push(x); // koshi 2013.10.04
	lits.clear();
	int j = 0;
	while (x > 0) {
	  if ((x & 0x0001L) == 0x0001L) {
	    lits.push(~linking[j]);
	  }
	  x = x >> 1;
	  j++;
	}
	S.addClause_(lits);
      }
    }
  }
}

// koshi 20150508
void greaterthanequal(int card, vec<Lit>& linking, 
		      long long int ol, long long int l,
		      long long int divisor, // koshi 13.10.04
		      vec<long long int>& cc, Solver& S, vec<Lit>& lits) {

  //  printf("greaterthanequal ol = %lld, l = %lld\n",ol,l);
  if (linking.size() == 0) {} else
  if (card == 1) {// Bailleux encoding (Totalizer)
    ol++;l++;
    for (long long int i = ol; i < linking.size() && i < l; i++) {
      lits.clear();
      lits.push(linking[i]);
      S.addClause(lits);
    }
  } else if (card == 2) {// Asin encoding
    for (long long int i = ol; 
	 i < linking.size() && i < l; i++) {
      lits.clear();
      lits.push(linking[i]);
      S.addClause(lits);
    }
  } else if (card == 3) {// Ogawa encoding (Modulo Totalizer)
    long long int upper = l/divisor;
    long long int lower = l%divisor;
    long long int oupper = ol/divisor;

    lits.clear();
    lits.push(~linking[lower]);
    lits.push(linking[divisor+upper]);
    S.addClause(lits);

    lits.clear();
    lits.push(linking[lower]);
    if (divisor+upper+1 < linking.size()) lits.push(linking[divisor+upper+1]);
    S.addClause(lits);
    //    printf("divisor+upper = %lld, lower = %lld\n",divisor+upper,lower);
  } else if (card == 0) {// Warners encoding
    vec<long long int> cls;
    cls.clear();

    unsigned long long int pos = ~0;
    
    long long int ll = l;
    while (ll > 0) {
      if (ll%2 == 1) cls.push(l);
      pos <<= 1;
      ll /= 2;
      l &= pos;
    }
    
    for(int i = 0; i < cls.size(); i++) {
      long long int x = cls[i];
      //      if (x == 0) printf("illegal x == 0\n");
      bool found = false;
      for(int j = 0; j < cc.size(); j++)
	if (x == cc[j]) {
	  found = true; break;
	}

      long long int xx = x;
      /*
      while(xx > 0) {
	printf("%d ", xx % 2);
	xx /= 2;
      }
      printf("\n");
      */

      if (!found) {
	cc.push(x);
	lits.clear();
	int j = 0;
	while (x%2 == 0) {
	  x /= 2;
	  j++;
	}
	x /= 2;
	lits.push(linking[j]);
	//	printf("linking[%d] |",j);
	while (x > 0) {
	  j++;
	  if (x%2 == 0) {
	    lits.push(linking[j]);
	    //	    printf("linking[%d] |",j);
	  }
	  x /= 2;
	}
	for(int i = j+1; i < linking.size(); i++) {
	  lits.push(linking[i]);
	  //	  printf("linking[%d] |",i);
	}
	//	printf("\n");
	S.addClause(lits);
      }
    }
  }
}

//=================================================================================================
// Main:

int main(int argc, char** argv)
{
    try {
        setUsageHelp("USAGE: %s [options] <input-file> <result-output-file>\n\n  where input may be either in plain or gzipped DIMACS.\n");
        // printf("This is MiniSat 2.0 beta\n");
        
#if defined(__linux__)
        fpu_control_t oldcw, newcw;
        _FPU_GETCW(oldcw); newcw = (oldcw & ~_FPU_EXTENDED) | _FPU_DOUBLE; _FPU_SETCW(newcw);
        printf("c WARNING: for repeatability, setting FPU to use double precision\n");
#endif
        // Extra options:
        //
	// koshi 20160414 for evaluation
        IntOption    verb   ("MAIN", "verb",   "Verbosity level (0=silent, 1=some, 2=more).", 0, IntRange(0, 2));
        BoolOption   pre    ("MAIN", "pre",    "Completely turn on/off any preprocessing.", false);
        StringOption dimacs ("MAIN", "dimacs", "If given, stop after preprocessing and write the result to this file.");
        IntOption    cpu_lim("MAIN", "cpu-lim","Limit on CPU time allowed in seconds.\n", INT32_MAX, IntRange(0, INT32_MAX));
        IntOption    mem_lim("MAIN", "mem-lim","Limit on memory usage in megabytes.\n", INT32_MAX, IntRange(0, INT32_MAX));

	// koshi 20140106
	/*
        IntOption    card   ("MAIN", "card",   "Type of SAT-encodings for Cardinality Constraints", 0, IntRange(0, 3));
	// 0: [Warners 1998]
	// 1: [Bailleux & Boufkhad 2003]
	// 2: [Asin et. al 2011]
	// 3: [Ogawa et. al 2013]
	// -1: auto // koshi 20140324
	*/
        StringOption cardS   ("MAIN", "card",   "Type of SAT-encodings for Cardinality Constraints\n           warn, bail, asin, ogaw, and auto", "auto");

        IntOption    comp   ("MAIN", "comp",   
			     "Variants of SAT-encodings for Cardinality Constraints\n          warn -> 0,1,2,10,11,   bail -> 0,10,11,\n          asin -> 0,10,11,    ogaw -> 0", 
			     0, IntRange(0, 11));
        IntOption    pmodel   ("MAIN", "pmodel",   "Print a MaxSAT model", 1, IntRange(0, 1));

        parseOptions(argc, argv, true);
        
	// koshi 20140606
	int card=0;
	printf("c card = ");
	if (strcmp(cardS, "warn") == 0) {
	  printf("warn, "); card = 0;
	}
	if (strcmp(cardS, "bail") == 0)  {
	  printf("bail, "); card = 1;
	}
	if (strcmp(cardS, "asin") == 0) {
	  printf("asin, "); card = 2;
	}
	if (strcmp(cardS, "ogaw") == 0) {
	  printf("ogaw, "); card = 3;
	}
	if (strcmp(cardS, "auto") == 0) {
	  printf("auto, "); card = -1;
	}
	printf("comp = %d, pmodel = %d, verb = %d\n",
	       (int) comp,(int) pmodel,(int) verb);

	/* koshi 20140603
	int card=0;
	if (strcmp(cardS, "warn") == 0) card = 0;
	if (strcmp(cardS, "bail") == 0) card = 1;
	if (strcmp(cardS, "asin") == 0) card = 2;
	if (strcmp(cardS, "ogaw") == 0) card = 3;
	*/

        SimpSolver  S;
        double      initial_time = cpuTime();

	// koshi 20141021
	printf("c This is QMaxSATuc 17.06");
	printf("c This is MiniSat 2.2.0 (simp)\n");
	printf("c This is Glucose 3.0\n");
	if (pre) printf("c simp version\n");
	else printf("c core version\n");

        if (!pre) S.eliminate(true);

        S.verbosity = verb;
        
        solver = &S;
        // Use signal handlers that forcibly quit until the solver will be able to respond to
        // interrupts:
        signal(SIGINT, SIGINT_exit);
        signal(SIGXCPU,SIGINT_exit);

        // Set limit on CPU-time:
        if (cpu_lim != INT32_MAX){
            rlimit rl;
            getrlimit(RLIMIT_CPU, &rl);
            if (rl.rlim_max == RLIM_INFINITY || (rlim_t)cpu_lim < rl.rlim_max){
                rl.rlim_cur = cpu_lim;
                if (setrlimit(RLIMIT_CPU, &rl) == -1)
                    printf("WARNING! Could not set resource limit: CPU-time.\n");
            } }

        // Set limit on virtual memory:
        if (mem_lim != INT32_MAX){
            rlim_t new_mem_lim = (rlim_t)mem_lim * 1024*1024;
            rlimit rl;
            getrlimit(RLIMIT_AS, &rl);
            if (rl.rlim_max == RLIM_INFINITY || new_mem_lim < rl.rlim_max){
                rl.rlim_cur = new_mem_lim;
                if (setrlimit(RLIMIT_AS, &rl) == -1)
                    printf("WARNING! Could not set resource limit: Virtual memory.\n");
            } }
        
        if (argc == 1)
            printf("Reading from standard input... Use '--help' for help.\n");

        gzFile in = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
        if (in == NULL)
            printf("ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), exit(1);
        
        if (S.verbosity > 0){
            printf("============================[ Problem Statistics ]=============================\n");
            printf("|                                                                             |\n"); }
        
	// koshi 20140107
	int nbvar  = 0; // number of original variables
	/* weight of hard clause
	   0 indicates ms (unweighted MaxSAT) 
	     i.e. all clauses are 1-weighted soft clauses
	   -1 indicates wms (weighted MaxSAT) 
	     i.e. all clauses are weighted soft clauses
	   positive value indicates pms or wpms (partial MaxSAT)
	 */
	long long int top    = 0;
	int nbsoft = 0; // number of soft clauses
	vec<long long int> weights;
	vec<Lit> blockings;

	// koshi 20141021
	parse_DIMACS(in, S, pre, nbvar, top, nbsoft, weights,blockings);
	//parse_DIMACS(in, S, nbvar, top, nbsoft, weights,blockings);
	//        parse_DIMACS(in, S);
        gzclose(in);
        FILE* res = (argc >= 3) ? fopen(argv[2], "wb") : NULL;

        if (S.verbosity > 0){
            printf("|  Number of variables:  %12d                                         |\n", S.nVars());
            printf("|  Number of clauses:    %12d                                         |\n", S.nClauses()); }
        
        double parsed_time = cpuTime();
        if (S.verbosity > 0)
            printf("|  Parse time:           %12.2f s                                       |\n", parsed_time - initial_time);

        // Change to signal-handlers that will only notify the solver and allow it to terminate
        // voluntarily:
        signal(SIGINT, SIGINT_interrupt);
        signal(SIGXCPU,SIGINT_interrupt);

        S.eliminate(true);
        double simplified_time = cpuTime();
        if (S.verbosity > 0){
            printf("|  Simplification time:  %12.2f s                                       |\n", simplified_time - parsed_time);
            printf("|                                                                             |\n"); }

        if (!S.okay()){
            if (res != NULL) fprintf(res, "UNSAT\n"), fclose(res);
            if (S.verbosity > 0){
                printf("===============================================================================\n");
                printf("Solved by simplification\n");
                printStats(S);
                printf("\n"); }
            printf("UNSATISFIABLE\n");
            exit(20);
        }

	// koshi 20140107
	long long int answer = sumWeight(weights);
	long long int lower = 0; // koshi 20150508

        if (dimacs){
            if (S.verbosity > 0)
                printf("==============================[ Writing DIMACS ]===============================\n");
            S.toDimacs((const char*)dimacs);
            if (S.verbosity > 0)
                printStats(S);
            exit(0);
        }

	vec<Lit> lits;
	// koshi 20150122
	int scnt = 0; // sat count
	int ucnt = 0; // unsat count
	vec<Lit> nblockings; nblockings.clear();
	blockings.copyTo(nblockings);
	// koshi 20150508
	vec<long long int> nweights; nweights.clear();
	weights.copyTo(nweights);

	vec<Lit> linkingVar;
	bool mmodel[nbvar]; // koshi 2013.07.05
	long long int divisor = 1; // koshi 2013.10.04

	vec<long long int> cc; // cardinality constraints
	cc.clear();
	vec<long long int> ccl; // 20150508
	ccl.clear();

	/* koshi 20150122
        vec<Lit> dummy;
	*/
	//        lbool ret = S.solveLimited(dummy);
	// koshi 20140603        lbool ret = S.solveLimited(dummy);
	lbool ret = l_False; // koshi 20150122

        if (S.verbosity > 0){
            printStats(S);
            printf("\n"); }

	//	while (1) { // koshi 20150122
	while (lower < answer) {// koshi 20150508
	  vec<Lit> assumps; assumps.clear();
	  // koshi 20160330
	  if (ucnt <= scnt) 
	    for (int i = 0; i < nblockings.size(); i++)
	      assumps.push(~nblockings[i]);

	SAT: 
	  // koshi 20160331
	  printf("c ucnt = %d,  scnt = %d\n", ucnt,scnt);
	  if (ucnt > scnt) assumps.clear();
	  else if (assumps.size() == 0)
	    for (int i = 0; i < nblockings.size(); i++)
	      assumps.push(~nblockings[i]);

	  if (lower >= answer) break;
	  printf("c assumps.size() = %d\n",assumps.size());
	  ret = S.solveLimited(assumps,true,true);
	  if (ret == l_True) { // satisfiable
	    if (pmodel == 1) { // koshi 20150508(move)
	      for (int i = 0; i < nbvar; i++) {
		if (S.model[i]==l_True) 
		  mmodel[i] = true;
		else mmodel[i] = false;
	      }
	    }
	    printf("c sat\n");
	    scnt++;
	    long long int answerNew = 0;

	    // koshi 20150126
	    for (int i = 0; i < blockings.size(); i++)
	      if (S.modelValue(blockings[i]) == l_True)
		  answerNew += weights[i];
	    printf("o %lld\n",answerNew);

	    if (answerNew <= lower) {// koshi 20150508
	      answer = answerNew;
	      break;
	    }

	    if (ucnt == 0) {// all soft clauses are satisfiable
	      answer = 0; break;
	    }

	    /* koshi 20150619
	    if (scnt > 1) {// koshi 20150220
	      //assert(answerNew < answer);
	      if (answerNew >= answer) {
		printf("c Unexpected situation (answerNew = %d, answer = %d)\n",answerNew,answer);
		exit(1);
	      }
	    }
	    */

	    if (scnt == 1) { // first model: generate cardinal constraints
	      int nvars = S.nVars();
	      int ncls = S.nClauses();
	      genCardinals(card,comp, weights,blockings, 
			   answer,answerNew,divisor, S, lits, linkingVar);
	      printf("c linkingVar.size() = %d\n",linkingVar.size());
	      printf("c Cardinality Constraints: %d variables and %d clauses\n",
		     S.nVars()-nvars,S.nClauses()-ncls);
	      greaterthanequal(card, linkingVar, 0,lower,divisor, 
			       ccl, S, lits);
	    }

	    assert(answerNew > 0);
	    if (card == 1 && scnt == 1) answer = linkingVar.size();
	    lessthan(card, linkingVar, answer,answerNew,divisor, cc, S, lits);
	    answer = answerNew;
	    goto SAT;
	  } else {// unsatisfiable
	    long long int minW = 0; // koshi 20150508
	    printf("c unsat\n");
	    ucnt++;
	    if (S.conflict.size() == 0) break; //
	    S.addClause(S.conflict);

	    vec<Lit> nnblockings; nnblockings.clear();
	    vec<long long int> nnweights; nnweights.clear(); // koshi 20150508

	    for(int i = 0; i < nblockings.size(); i++) {
	      Lit lit = nblockings[i];
	      long long int weight = nweights[i]; // koshi 20150508
	      bool found = false;
	      for(int j = 0; j < S.conflict.size(); j++) {
		if (lit == S.conflict[j]) {
		  // koshi 20150508
		  if (minW == 0 || minW > weight) minW = weight; 
		  found = true; break;
		}
	      }
	      //	      if (!found) nnblockings.push(lit);
	      if (!found) { // koshi 20150508
		nnblockings.push(lit);
		nnweights.push(weight);
	      }
	    }
	    //	    printf("c nblockings.size() = %d, S.conflict.size() = %d　nnblockings.size() = %d\n", nblockings.size(),S.conflict.size(),nnblockings.size());
	    printf("c S.conflict.size() = %d\n", S.conflict.size());
	    nblockings.clear();
	    nnblockings.copyTo(nblockings);
	    // koshi 20150508
	    nweights.clear();
	    nnweights.copyTo(nweights);
	    if (scnt > 0) // koshi 20150508
	      greaterthanequal(card, linkingVar, lower,lower+minW,divisor, 
			       ccl, S, lits);
	    lower += minW;
	    printf("c lower bound = %lld\n",lower); // koshi 20150427
	  }
	} // end of while

	printf((scnt > 0) ? "s OPTIMUM FOUND\n" : "s UNSATISFIABLE\n");
	// koshi 20150508
	printf("c lower:%lld, upper:%lld\n", lower,answer);
	if (lower >= answer) 
	  printf("c lower >= answer (%lld >= %lld)\n",lower,answer);

	if (scnt > 0 ) {
	  if (pmodel == 1) {
	    printf("v ");
	    for (int i = 0; i< nbvar; i++) {
	      printf("%s%d ", mmodel[i]?"":"-", i+1);
	      if ((i+1)%20 == 0 && i+1 < nbvar) printf("\nv ");
	    }
	    printf("\n");
	  }
	
	  printf("c Latest Answer = %lld by %d loops (sat:%d,unsat:%d)\n",answer,scnt+ucnt,scnt,ucnt);
	}
	printStats(S);

	/* koshi 20141021
        printf(ret == l_True ? "SATISFIABLE\n" : ret == l_False ? "UNSATISFIABLE\n" : "INDETERMINATE\n");
        if (res != NULL){
            if (ret == l_True){
                fprintf(res, "SAT\n");
                for (int i = 0; i < S.nVars(); i++)
                    if (S.model[i] != l_Undef)
                        fprintf(res, "%s%s%d", (i==0)?"":" ", (S.model[i]==l_True)?"":"-", i+1);
                fprintf(res, " 0\n");
            }else if (ret == l_False)
                fprintf(res, "UNSAT\n");
            else
                fprintf(res, "INDET\n");
            fclose(res);
        }
	*/

#ifdef NDEBUG
        exit(ret == l_True ? 10 : ret == l_False ? 20 : 0);     // (faster than "return", which will invoke the destructor for 'Solver')
#else
        return (ret == l_True ? 10 : ret == l_False ? 20 : 0);
#endif
    } catch (OutOfMemoryException&){
        printf("===============================================================================\n");
        printf("INDETERMINATE\n");
        exit(0);
    }
}
