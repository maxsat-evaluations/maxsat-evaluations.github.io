/*****************************************************************************************[Alg_WBO.cc]
Open-WBO -- Copyright (c) 2013-2015, Ruben Martins, Vasco Manquinho, Ines Lynce

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
************************************************************************************************/

#include "Alg_EvaW.h"

using namespace NSPACE;

/************************************************************************************************
 //
 // Rebuild MaxSAT solver
 //
 ************************************************************************************************/


/*_________________________________________________________________________________________________
  |
  |  rebuildSolver : [void]  ->  [Solver *]
  |
  |  Description:
  |
  |    Rebuilds a SAT solver with the current MaxSAT formula using the original
  |    WBO strategy.
  |    All soft clauses are considered in the working formula.
  |
  |  Pre-conditions:
  |    * Assumes that the weight strategy is '_WEIGHT_NONE_'.
  |
  |________________________________________________________________________________________________@*/

 Solver *EvaW::rebuildSolverInc(Solver *S)
{

  for (int i = firstIVars; i < nVars(); i++)
    newSATVariable(S);

  firstIVars = nVars();
  
  for (int i = firstIHard; i < nHard(); i++)
    S->addClause(hardClauses[i].clause);

  firstIHard =  nHard();
  
  vec<Lit> clause;
  for (int i = firstISoft; i < nSoft(); i++)
  {
    clause.clear();
    softClauses[i].clause.copyTo(clause);
    
    assert( softClauses[i].relaxationVars.size() == 0);  
    assert( !isHard(i) );  
    clause.push(softClauses[i].assumptionVar);

    S->addClause(clause);
  }
  
  firstISoft = nSoft();
  return S;
}

 Solver *EvaW::initialLCNFSolver(Solver *S)
{

  for (int i = firstIVars; i < nVars(); i++)
    newSATVariable(S);

  firstIVars = nVars();
  
  for (int i = firstIHard; i < nHard(); i++)
    S->addClause(hardClauses[i].clause);

  firstIHard =  nHard();
  
  firstISoft = nSoft();
  return S;
}


/*_________________________________________________________________________________________________
  |
  |  rebuildHardSolver : [void]  ->  [Solver *]
  |
  |  Description:
  |
  |    Rebuilds a SAT solver with the hard clauses of the MaxSAT formula.
  |    Used for testing if the MaxSAT formula is unsatisfiable.
  |
  |________________________________________________________________________________________________@*/
Solver *EvaW::rebuildHardSolver()
{

  Solver *S = newSATSolver();

  for (int i = 0; i < nVars(); i++)
    newSATVariable(S);

  for (int i = 0; i < nHard(); i++)
    S->addClause(hardClauses[i].clause);

  return S;
}

/*_________________________________________________________________________________________________
  |
  |  updateCurrentWeight : (strategy : int)  ->  [void]
  |
  |  Description:
  |
  |    Updates the value of 'currentWeight' with a predefined strategy.
  |
  |  Pre-conditions:
  |    * Assumes that the weight strategy is either '_WEIGHT_NORMAL_' or
  |      '_WEIGHT_DIVERSIFY_'.
  |
  |  Post-conditions:
  |    * 'currentWeight' is updated by this method.
  |
  |________________________________________________________________________________________________@*/
void EvaW::updateCurrentWeight()
{
	
  if (weightStrategy == _WEIGHT_NONE_) {
	 // printf("Weight strategy set to none, curw = 1\n");
	  currentWeight = 1;
  }
  else {
	  if (weightStrategy == _WEIGHT_NORMAL_)
		currentWeight = findNextWeight(currentWeight);
		else if (weightStrategy == _WEIGHT_DIVERSIFY_)
	currentWeight = findNextWeightDiversity(currentWeight);
  }
  
}

/*_________________________________________________________________________________________________
  |
  |  findNextWeight : (weight : int)  ->  [int]
  |
  |  Description:
  |
  |    Finds the greatest weight that is smaller than the 'currentWeight'.
  |
  |  For further details see:
  |    * Ruben Martins, Vasco Manquinho, Ines Lynce: On Partitioning for Maximum
  |      Satisfiability. ECAI 2012: 913-914
  |
  |________________________________________________________________________________________________@*/
int EvaW::findNextWeight(int weight)
{

  int nextWeight = 1;
  int b = firstISoft > 0 ? firstISoft : nSoft();
  for (int i = 0; i <b; i++)
  {
    if (softClauses[i].weight > nextWeight && softClauses[i].weight < weight && !isHard(i))
      nextWeight = softClauses[i].weight;
  }

  return nextWeight;
}

  int EvaW::nRealSoft() {
	  return nSoft() - allHardClauses; 
  }
  
int EvaW::findNextWeightDiversity(int weight)
{

  assert(weightStrategy == _WEIGHT_DIVERSIFY_);
  assert(nbSatisfiable > 0); // Assumes that unsatSearch was done before.

  int nextWeight = weight;
  int nbClauses = 0;
  std::set<int64_t> nbWeights;
  float alpha = 1.25;

  bool findNext = false;

  for (;;)
  {
    if (nbSatisfiable > 1 || findNext) nextWeight = findNextWeight(nextWeight);

    nbClauses = 0;
    nbWeights.clear();
    int b = firstISoft > 0 ? firstISoft : nSoft();
    for (int i = 0; i < b; i++)
    {
      if (softClauses[i].weight >= nextWeight && !isHard(i))
      {
        nbClauses++;
        nbWeights.insert(softClauses[i].weight);
      }
    }

    if ((float)nbClauses / nbWeights.size() > alpha || nbClauses == nRealSoft())
      break;

    if (nbSatisfiable == 1 && !findNext) findNext = true;
  }

  return nextWeight;
}

/************************************************************************************************
 //
 // Utils for core management
 //
 ************************************************************************************************/

  void EvaW::printLiterals(vec<Lit> &lits) {
	  for(int i = 0; i  < lits.size(); i++) {
			printf("%d ", coreMapping[lits[i]] );
		}
		printf("\n");
  }

/*_________________________________________________________________________________________________
  |
  |  encodeEO : (lits : vec<Lit>&)  ->  [void]
  |
  |  Description:
  |
  |    Encodes that exactly one literal from 'lits' is assigned value true.
  |    Uses the Ladder/Regular encoding for translating the EO constraint into
  |    CNF.
  |    NOTE: We do not use the 'encoder' since we are adding clauses to the hard
  |    clauses and not directly into the SAT solvers.
  |    If a different AMO is used, then this method should be changed
  |    accordingly.
  |
  |  For further details see:
  |    * Carlos Ansótegui, Felip Manyà: Mapping Problems with Finite-Domain
  |      Variables into Problems with Boolean Variables. SAT 2004
  |    * Ian Gent and Peter Nightingale. A New Encoding of All Different into
  |      SAT. ModRef 2004
  |
  |  Pre-conditions:
  |    * Assumes that 'lits' is not empty.
  |
  |  Post-conditions:
  |    * 'hardClauses' are updated with the clauses that encode the EO
  |      constraint.
  |
  |________________________________________________________________________________________________@*/
void EvaW::encodeMaxRes(vec<Lit> &core, int weightCore) // core are the bvars in LMHS code
{

    assert(core.size() != 0);
    
    
    int n = core.size(); // in order to mimic LMHS code to minimize errors

    vec<Lit> dVars;
    vec<Lit> clause; // for adding stuff
    for (int i = 0; i < n - 1; i++)
    {
        Lit p = newLiteral();
        dVars.push(p);
    }
    // NEW HARD CLAUSES
    clause.clear();
    core.copyTo(clause);
    addHardClause(clause);
    
    if (n > 2) {

        for (int i = 0; i < n-2; i++) {
            // d_i -> (b_{i+1} v d_{i+1})
            // clause = { ~dVars[i], dVars[i + 1], core[i + 1] };
            clause.clear();
            clause.push(~dVars[i]);
            clause.push(dVars[i + 1]);
            clause.push(core[i + 1]);
            addHardClause(clause);
            
            // (b_{i+1} v d_{i+1}) -> d_i
            // d_i v -b_{i+1}
            // clause = { dVars[i], ~core[i + 1] };
            clause.clear();
            clause.push(dVars[i]);
            clause.push(~core[i + 1]);
            addHardClause(clause);
            
            // d_i v -d_{i+1}
            // clause = { dVars[i], ~dVars[i + 1] };
            clause.clear();
            clause.push(dVars[i]);
            clause.push(~dVars[i + 1]);
            addHardClause(clause);
        }
    }
    
    if (n > 1) {
        // handle i = p - 1 case
        // clause = { dVars[p - 2], ~core[p - 1] };
        clause.clear();
        clause.push(dVars[n - 2]);
        clause.push(~core[n - 1]);
        addHardClause(clause);
        
        // clause = { ~dVars[p - 2], core[p - 1] };
        clause.clear();
        clause.push(~dVars[n - 2]);
        clause.push(core[n - 1]);
        addHardClause(clause);
    }
    
    // NEW SOFT CLAUSES
    for (int i = 0; i < n-1; i++) {
        //clause = { ~core[i], ~dVars[i] };
        clause.clear();
        clause.push(~core[i]);
        clause.push(~dVars[i]);
        addSoftClauseAndAssumptionVar(weightCore, clause);
    }



  
}

void EvaW::minimizeConflict(vec<Lit> &solverConflict) {
		assert(solverConflict.size() > 0);
		//printf("Minimizing\n");
		//MINIM
		minimizedConflict.clear();
		
		//printf("Orig confl: ");
	//	printLiterals(solverConflict);
			
		if(minimizeCores) {
			lbool res;
			vec<Lit> orig;
			vec<Lit> assumps;
			solverConflict.copyTo(orig);
		
		
			for(int i = 0; i < orig.size(); i++) {
				assumps.clear();
				for(int j = i+1; j < orig.size(); j++) {
					assumps.push(~orig[j]);
					}
				for(int j = 0; j < minimizedConflict.size(); j++) {
						assumps.push(~minimizedConflict[j]);
					}
				res = searchSATSolver(solver, assumps);
				if (res == l_True) {
					minimizedConflict.push(orig[i]);
				}
			}
		
			assert(minimizedConflict.size() > 0);
		}
		else {
			solverConflict.copyTo(minimizedConflict);
		}
 }

/*_________________________________________________________________________________________________
  |
  |  relaxCore : (conflict : vec<Lit>&) (weightCore : int) (assumps : vec<Lit>&)
  |              ->  [void]
  |
  |  Description:
  |
  |    Relaxes the core as described in the original WBO paper.
  |
  |  For further details see:
  |    * Vasco Manquinho, Joao Marques-Silva, Jordi Planes: Algorithms for
  |      Weighted Boolean Optimization. SAT 2009: 495-508
  |
  |  Pre-conditions:
  |    * Assumes that the core ('conflict') is not empty.
  |    * Assumes that the weight of the core is not 0 (should always be greater
  |      than or equal to 1).
  |
  |  Post-conditions:
  |    * If the weight of the soft clause is the same as the weight of the core:
  |      - 'softClauses[indexSoft].relaxationVars' is updated with a new
  |        relaxation variable.
  |    * If the weight of the soft clause is not the same as the weight of the
  |      core:
  |      - 'softClauses[indexSoft].weight' is decreased by the weight of the
  |        core.
  |      - A new soft clause is created. This soft clause has the weight of the
  |        core.
  |      - A new assumption literal is created and attached to the new soft
  |        clause.
  |      - 'coreMapping' is updated to map the new soft clause to its assumption
  |        literal.
  |    * 'sumSizeCores' is updated.
  |
  |________________________________________________________________________________________________@*/
void EvaW::relaxCore(vec<Lit> &conflict, int weightCore, vec<Lit> &assumps)
{

  assert(conflict.size() > 0);
  assert(weightCore > 0);

  vec<Lit> lits;
  for (int i = 0; i < conflict.size(); i++)
  {
    int indexSoft = coreMapping[conflict[i]];

    if (softClauses[indexSoft].weight == weightCore)
    {
      // If the weight of the soft clause is the same as the weight of the core
      // then harden it (by adding a relaxation variable).
      Lit p = softClauses[indexSoft].assumptionVar;
      
      softClauses[indexSoft].assumptionVar = lit_Undef;
      allHardClauses++;
      
      assert(softClauses[indexSoft].relaxationVars.size() == 0);
      lits.push(p);
      
    }
    else
    {
	//  printf(" %d ", indexSoft);
      // If the weight of the soft clause is different from the weight of the
      // core then duplicate the soft clause.
      assert(softClauses[indexSoft].weight - weightCore > 0);
      // Update the weight of the soft clause.
      softClauses[indexSoft].weight -= weightCore;
	  numClausesCloned++;
      
      Lit p = softClauses[indexSoft].assumptionVar;
      lits.push(p);
      
    }
    
  }

	encodeMaxRes(lits, weightCore);

 sumSizeCores += conflict.size();
}

void EvaW::addSoftClauseAndAssumptionVar(int weight, vec<Lit> &clause) {
	  addSoftClause(weight, clause);
	   Lit l = newLiteral();
      // Create a new assumption literal.
      softClauses[nSoft() - 1].assumptionVar = l;
      coreMapping[l] = nSoft() - 1;  // Map the new soft clause to its assumption literal.
}

uint64_t EvaW::computeCostModelEva(vec<lbool> &currentModel)
{

  assert(currentModel.size() != 0);
  uint64_t currentCost = 0;

  
  for (int i = 0; i < origWeights.size(); i++)
  {
    bool unsatisfied = true;
    for (int j = 0; j < softClauses[i].clause.size(); j++)
    {

      assert(var(softClauses[i].clause[j]) < currentModel.size());
      
      if( var(softClauses[i].clause[j]) <= nbInitialVariables ) {
      
      if ((sign(softClauses[i].clause[j]) &&
           currentModel[var(softClauses[i].clause[j])] == l_False) ||
          (!sign(softClauses[i].clause[j]) &&
           currentModel[var(softClauses[i].clause[j])] == l_True))
      {
        unsatisfied = false;
        break;
      }
		}
    }

    if (unsatisfied) {
		currentCost += origWeights[i];
	}
  }

  return currentCost;
}


/*_________________________________________________________________________________________________
  |
  |  computeCostCore : (conflict : vec<Lit>&)  ->  [int]
  |
  |    Description:
  |
  |      Computes the cost of the core. The cost of a core is the minimum weight
  |      of the soft clauses that appear in that core.
  |
  |    Pre-conditions:
  |      * Assumes that 'conflict' is not empty.
  |
  |________________________________________________________________________________________________@*/
int EvaW::computeCostCore(vec<Lit> &conflict)
{

  assert(conflict.size() != 0);

  if (problemType == _UNWEIGHTED_)
  {
    return 1;
  }

  int coreCost = INT32_MAX;

  for (int i = 0; i < conflict.size(); i++)
  {
    int indexSoft = coreMapping[conflict[i]];
    if (softClauses[indexSoft].weight < coreCost)
      coreCost = softClauses[indexSoft].weight;
  }

  return coreCost;
}


/************************************************************************************************
 //
 // WBO search
 //
 ************************************************************************************************/

/*_________________________________________________________________________________________________
  |
  |  unsatSearch : [void] ->  [void]
  |
  |  Description:
  |
  |    Calls a SAT solver only on the hard clauses of the MaxSAT formula.
  |    If the hard clauses are unsatisfiable then the MaxSAT solver terminates
  |    and returns 'UNSATISFIABLE'.
  |    Otherwise, a model has been found and it is stored. Without this call,
  |    the termination of the MaxSAT solver is not guaranteed.
  |
  |  For further details see:
  |    * Carlos Ansótegui, Maria Luisa Bonet, Jordi Levy: SAT-based MaxSAT
  |      algorithms. Artif. Intell. 196: 77-105 (2013)
  |
  |  Post-conditions:
  |   * If the hard clauses are satisfiable then 'ubCost' is updated to the cost
  |     of the model.
  |   * If the working formula is satisfiable, then 'nbSatisfiable' is increased
  |     by 1. Otherwise, 'nbCores' is increased by 1.
  |
  |________________________________________________________________________________________________@*/
void EvaW::unsatSearch()
{

  assert(assumptions.size() == 0);

  solver = rebuildHardSolver();
  lbool res = searchSATSolver(solver, assumptions);

  if (res == l_False)
  {
    nbCores++;
    printAnswer(_UNSATISFIABLE_);
    exit(_UNSATISFIABLE_);
  }
  else if (res == l_True)
  {
    nbSatisfiable++;
    uint64_t cost = computeCostModel(solver->model);
    assert(cost <= ubCost);
    ubCost = cost;
    saveModel(solver->model);
    printf("o %" PRIu64 "\n", ubCost);
  }

  delete solver;
  solver = NULL;
}


bool  EvaW::isHard(int indexSoft) {
	assert(indexSoft < nbSoft);
	return softClauses[indexSoft].assumptionVar == lit_Undef;
}

void EvaW::setAssumptions(vec<Lit> &assumps)
{
  assumps.clear();
  //printf("Added as Hard: ");
  for (int i = 0; i < nbSoft; i++)
  {
    if (!isHard(i) && softClauses[i].weight >= currentWeight) {
		Lit l = softClauses[i].assumptionVar;
		assert(l != lit_Undef);
		assumps.push(~l);
	}
  }
 // printf("\n");
}

/*_________________________________________________________________________________________________
  |
  |  normalSearch : [void] ->  [void]
  |
  |  Description:
  |
  |    Original WBO algorithm.
  |
  |  For further details see:
  |    * Vasco Manquinho, Joao Marques-Silva, Jordi Planes: Algorithms for
  |      Weighted Boolean Optimization. SAT 2009: 495-508
  |
  |  Post-conditions:
  |    * 'lbCost' is updated.
  |    * 'ubCost' is updated.
  |    * 'nbSatisfiable' is updated.
  |    * 'nbCores' is updated.
  |
  |________________________________________________________________________________________________@*/
void EvaW::normalSearch()
{

  unsatSearch();

  initAssumptions(assumptions);
  
  firstIVars = 0;
  firstISoft = 0;
  firstIHard = 0;
  numClausesCloned = 0;
  numClausesHardened = 0;
  allHardClauses = 0;
  
  Solver * solver = newSATSolver();
  if (!reuseAssumps) {  
	solver = rebuildSolverInc(solver);
  }
  else {
	  solver = initialLCNFSolver(solver);
  }
  
  updateCurrentWeight();
  
  for (;;)
  {
    setAssumptions(assumptions);
    lbool res = searchSATSolver(solver, assumptions);

    if (res == l_False)
    {
      nbCores++;
      assert(solver->conflict.size() > 0);
      minimizeConflict(solver->conflict);
      
      int coreCost = computeCostCore(minimizedConflict);
      lbCost += coreCost;
      if (verbosity > 0)
        printf("c LB : %-12" PRIu64 " CS : %-12d W  : %-12d\n", lbCost,
               minimizedConflict.size(), coreCost);
      
      if (lbCost == ubCost)
			{
			printf("DONE: UB=%d, LB=%d\n",  ubCost, lbCost);
			printf("Total Clones: %d\n", numClausesCloned);
			printf("Total Hardened: %d\n", numClausesHardened);
			printf("o %" PRIu64 "\n", lbCost);
			exit(_OPTIMUM_);
			}
      
      relaxCore(minimizedConflict, coreCost, assumptions);
      //delete solver;
      solver = rebuildSolverInc(solver);
    }

    if (res == l_True)
    {
		uint64_t cost  = computeCostModelEva(solver->model);
		nbSatisfiable++;
		if (cost < ubCost) ubCost = cost;
		printf("UB: %d\n", ubCost);
		if (lbCost == ubCost)
			{
			printf("DONE: UB=%d, LB=%d\n",  ubCost, lbCost);
			printf("Total Clones: %d\n", numClausesCloned);
			printf("Total Hardened: %d\n", numClausesHardened);
			printf("o %" PRIu64 "\n", lbCost);
			
			//saveModel(solver->model);
			// printAnswer(_OPTIMUM_);
			exit(_OPTIMUM_);
	 } 
	 assert( currentWeight > 1);
	 
	 solver = hardenClauses(solver);
	 
	 updateCurrentWeight();
	  
    }
  }
}

  Solver *EvaW::hardenClauses(Solver *S) {
	  int bound = 0;
	   
	   vec<lbool> &currentModel = S->model;
	   std::set<int> satClauses;
	   satClauses.clear();
	 //  printf("Hardening\n");
	   for (int i = 0; i < nbSoft; i++)
		{
			if (!isHard(i) && softClauses[i].weight < currentWeight) {
				 bool unsatisfied = true;
				 for (int j = 0; j < softClauses[i].clause.size(); j++)
				{
					assert(var(softClauses[i].clause[j]) < currentModel.size());
      
					if( var(softClauses[i].clause[j]) <= nbInitialVariables ) {
      
						if ((sign(softClauses[i].clause[j]) &&
							currentModel[var(softClauses[i].clause[j])] == l_False) ||
								(!sign(softClauses[i].clause[j]) &&
									currentModel[var(softClauses[i].clause[j])] == l_True))
						{
						unsatisfied = false;
						break;
						}
					}
				}
				if (unsatisfied) {
					bound += softClauses[i].weight;
				}
				else {
					satClauses.insert(i);
				}				
			}
		}
	//   printf("Bound %d\n", bound);
	   for (int i = 0; i < nbSoft; i++)
		{
			vec<Lit> clause;
			bool harden = !isHard(i) && softClauses[i].weight >= bound && softClauses[i].weight >= currentWeight;
			
			if (!harden && !isHard(i) && softClauses[i].weight >= bound) {
				harden = satClauses.count(i);
			}
			
			if (harden) {  // 
				clause.clear();
				
				Lit l = softClauses[i].assumptionVar;
				assert(l != lit_Undef);
				clause.push(~l);
				
				S->addClause(clause);
				
				
				softClauses[i].assumptionVar = lit_Undef;
				numClausesHardened++;
				allHardClauses++;
				assert(isHard(i));
			}
			
		}
		return S;
   }

// Public search method
void EvaW::search()
{
  printConfiguration();
  
  
  nbInitialVariables = nVars();

  normalSearch();

}

/************************************************************************************************
 //
 // Other protected methods
 //
 ************************************************************************************************/

/*_________________________________________________________________________________________________
  |
  |  initAssumptions : (assumps : vec<Lit>&) ->  [void]
  |
  |  Description:
  |
  |    Creates a new assumption literal for each soft clause and initializes the
  |    assumption vector with negation of this literal. Assumptions are used to
  |    extract cores.
  |
  |  Post-conditions:
  |    * For each soft clause 'i' creates an assumption literal and assigns it
  |      to 'softClauses[i].assumptionVar'.
  |    * 'coreMapping' is updated by mapping each assumption literal with the
  |      corresponding index of each soft clause.
  |    * 'assumps' is updates with the assumptions literals.
  |
  |________________________________________________________________________________________________@*/
void EvaW::initAssumptions(vec<Lit> &assumps)
{
	for (int i = 0; i < nbSoft; i++)
  {
	  origWeights.push(0);
  }
	
  for (int i = 0; i < nbSoft; i++)
  {
	  Lit l;
	  if( !reuseAssumps) {
			l = newLiteral();
		}
	  else {
		  assert(softClauses[i].clause.size() == 1);
		  l = ~softClauses[i].clause[0];
	  }
	  softClauses[i].assumptionVar = l;
	  coreMapping[l] = i;
	  assumps.push(~l);
	  origWeights[i] = softClauses[i].weight;
  }
}

// Print EVA configuration.
void EvaW::print_EvaW_configuration(int ws, bool min)
{
  printf("c |  Algorithm: %23s                                             "
         "                      |\n",
         "Eva");
  char ws_char[10];
  if (ws == 0)
    strcpy(ws_char, "None");
  else if (ws > 0)
    strcpy(ws_char, "PBO");
  if (problemType == _WEIGHTED_)
    printf("c |  Weight-Strategy: %17s                                         "
           "    "
           "                      |\n",
           ws_char);
  if (min)
    printf("c |  Core Minimisation: %16s                                       "
           "      "
           "                      |\n",
           "On");
  else
    printf("c |  Core Minimisation: %16s                                       "
           "      "
           "                      |\n",
           "Off");
  if (reuseAssumps)
    printf("c |  LCNF-Mode: %22s                                       "
           "      "
           "                      |\n",
           "On");
  else
    printf("c |  LCNF-Mode: %22s                                       "
           "      "
           "                      |\n",
           "Off"); 
  
}
