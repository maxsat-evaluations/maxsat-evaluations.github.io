/*****************************************************************************************[Alg_WBO.h]
Open-WBO -- Copyright (c) 2013-2015, Ruben Martins, Vasco Manquinho, Ines Lynce

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
************************************************************************************************/

#ifndef Alg_EvaW_h
#define Alg_EvaW_h

#ifdef SIMP
#include "simp/SimpSolver.h"
#else
#include "core/Solver.h"
#endif

#include "../MaxSAT.h"
#include "../MaxTypes.h"
#include "utils/System.h"
#include <utility>
#include <map>
#include <set>

namespace NSPACE
{

class EvaW : public MaxSAT
{

public:
  // NOTE: currently the encoding is not set as an input parameter.
  EvaW(int verb = _VERBOSITY_MINIMAL_, int weight = _WEIGHT_NONE_,
      bool minimize = true,  bool lcnf=false)
  {
    solver = NULL;
    verbosity = verb;

    nbCurrentSoft = 0;
    weightStrategy = weight;
	
	minimizeCores = minimize;
	reuseAssumps = lcnf;
  }

  ~EvaW()
  {
    if (solver != NULL) delete solver;
  }

  void search(); // WBO search.

  // Print solver configuration.
  void printConfiguration()
  {
    printf("c ==========================================[ Solver Settings "
           "]============================================\n");
    printf("c |                                                                "
           "                                       |\n");
    print_EvaW_configuration(weightStrategy, minimizeCores);
    printf("c |                                                                "
           "                                       |\n");
  }

protected:
  // Rebuild MaxSAT solver
  //
  // Rebuild MaxSAT solver with weight-based strategy.
  Solver *rebuildHardSolver(); // Rebuild MaxSAT solver with only hard clauses.
  Solver *rebuildSolverInc(Solver *S); // Add the new clauses to the MaxSAT solver (without creating a new one).
  Solver * initialLCNFSolver(Solver *S);
  void updateCurrentWeight(); // Updates 'currentWeight'.
  int findNextWeight(int weight); // Finds the next weight for 'currentWeight'.
  int findNextWeightDiversity(int weight);
 
  // Utils for core management
  //
  void encodeMaxRes(vec<Lit> &lits, int weightCore); // Encodes MaxRES
  void relaxCore(vec<Lit> &conflict, int weightCore,
                 vec<Lit> &assumps);       // Relaxes a core.
  int computeCostCore(vec<Lit> &conflict); // Computes the cost of a core.
  
  int numClausesCloned;
  int numClausesHardened;
  bool reuseAssumps;
  
  int allHardClauses;
  int nRealSoft();
  
  // Minimize Cores (Naive minimization)
  bool minimizeCores;
  vec<Lit> minimizedConflict;
  void minimizeConflict(vec<Lit> &solverConflict);
  
  Solver *hardenClauses( Solver *S ); 
  void printLiterals(vec<Lit> &lits);
  void setAssumptions(vec<Lit> &assumps);
  
  bool isHard(int indexSoft);
 
  void addSoftClauseAndAssumptionVar(int weight, vec<Lit> &clause);
  
  uint64_t computeCostModelEva(vec<lbool> &currentModel);
  vec<int> origWeights;
  
  // WBO search
  //
  void unsatSearch();  // Search using only hard clauses.
  void normalSearch(); // Original WBO search.

  // Other
  // Initializes assumptions and core extraction.
  void initAssumptions(vec<Lit> &assumps);


  

  // Print WBO configuration.
  void print_EvaW_configuration(int ws, bool min);

  // SAT solver
  Solver *solver; // SAT solver used as a black box.

  // Variables used  in 'weightSearch'
  //
  int
  nbCurrentSoft; // Current number of soft clauses used by the MaxSAT solver.
  int weightStrategy; // Weight strategy to be used in 'weightSearch'.

  // Core extraction
  //
  std::map<Lit, int>
  coreMapping; // Maps the assumption literal to the number of the soft clause.
  vec<Lit> assumptions; // Stores the assumptions to be used in the extraction
                        // of the core.
                        
  int firstIVars;
  int firstISoft;
  int firstIHard;


};
}

#endif
