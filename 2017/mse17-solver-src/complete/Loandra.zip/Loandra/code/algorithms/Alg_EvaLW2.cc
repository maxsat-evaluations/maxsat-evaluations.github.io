/*****************************************************************************************[Alg_WBO.cc]
Open-WBO -- Copyright (c) 2013-2015, Ruben Martins, Vasco Manquinho, Ines Lynce

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
************************************************************************************************/

#include "Alg_EvaLW2.h"

using namespace NSPACE;

/************************************************************************************************
 //
 // Rebuild MaxSAT solver
 //
 ************************************************************************************************/


/*_________________________________________________________________________________________________
  |
  |  rebuildSolverInc : [void]  ->  [Solver *]
  |
  |  Description:
  |
  |    Adds more clauses to the SAT solver with the current MaxSAT formula 
  |    Used in order to add delayed cardinality constraints 
  |	   Pre-condition
  |			Assumes newSatSolver() was called for input pointer. 
  |    Post-conditions:
  |  		firstIVars is updated
  | 		firstIHard is updated
  |			firstISoft is updated
  |________________________________________________________________________________________________@*/

 Solver *EvaLW2::rebuildSolverInc(Solver *S)
{
	
  for (int i = firstIVars; i < nVars(); i++) {
    newSATVariable(S);
}

  firstIVars = nVars();
  
  
  for (int i = firstIHard; i < nHard(); i++) {
    S->addClause(hardClauses[i].clause);
}

  firstIHard =  nHard();
  
  vec<Lit> clause;
  for (int i = firstISoft; i < nSoft(); i++)
  {
    clause.clear();
    softClauses[i].clause.copyTo(clause);
    if ( !isHard(i) ) {clause.push(softClauses[i].assumptionVar);}
	

    S->addClause(clause);
  }

  firstISoft = nSoft();
  
  return S;
}

/*_________________________________________________________________________________________________
  |
  |  initialLCNFSolver : [void]  ->  [Solver *]
  |
  |  Description:
  |
  |    Adds more clauses to the SAT solver with the current MaxSAT formula 
  |	   Ignores all soft clauses as they are to be reused
  |    
  |    Precoditions
  |	   Assumes newSatSolver() was called for input pointer.
  |	   Assumes all soft clauses are unit literals reusable as assumptions see:
  |			*	Jeremias Berg, Paul Saikko, Matti Järvisalo:
  |					Re-using Auxiliary Variables for MaxSAT Preprocessing. ICTAI 2015:
  |
  |    Post-conditions:
  |  		firstIVars is updated
  | 		firstIHard is updated
  |			firstISoft is updated
  |________________________________________________________________________________________________@*/

 Solver *EvaLW2::initialLCNFSolver(Solver *S)
{

  for (int i = firstIVars; i < nVars(); i++)
    newSATVariable(S);

  firstIVars = nVars();
  
  for (int i = firstIHard; i < nHard(); i++)
    S->addClause(hardClauses[i].clause);

  firstIHard = nHard();
  
  firstISoft = nSoft();

  return S;
}

/*_________________________________________________________________________________________________
  |
  |  rebuildHardSolver : [void]  ->  [Solver *]
  |
  |  Description:
  |
  |    Rebuilds a SAT solver with the hard clauses of the MaxSAT formula.
  |    Used for testing if the MaxSAT formula is unsatisfiable.
  |
  |________________________________________________________________________________________________@*/
Solver *EvaLW2::rebuildHardSolver()
{

  Solver *S = newSATSolver();

  for (int i = 0; i < nVars(); i++)
    newSATVariable(S);

  for (int i = 0; i < nHard(); i++)
    S->addClause(hardClauses[i].clause);

  return S;
}

/*_________________________________________________________________________________________________
  |
  |  updateCurrentWeight : (strategy : int)  ->  [void]
  |
  |  Description:
  |
  |    Updates the value of 'currentWeight' with a predefined strategy.
  |
  |  Pre-conditions:
  |    * Assumes that the weight strategy is either '_WEIGHT_NORMAL_' or
  |      '_WEIGHT_DIVERSIFY_'.
  |
  |  Post-conditions:
  |    * 'currentWeight' is updated by this method.
  |
  |________________________________________________________________________________________________@*/
void EvaLW2::updateCurrentWeight()
{
	
  if (weightStrategy == _WEIGHT_NONE_) {
	 // printf("Weight strategy set to none, curw = 1\n");
	  currentWeight = 1;
  }
  else {
	  if (weightStrategy == _WEIGHT_NORMAL_ )
		currentWeight = findNextWeight(currentWeight);
	  else if (weightStrategy == _WEIGHT_DIVERSIFY_)
		currentWeight = findNextWeightDiversity(currentWeight);
  }
  
}

/*_________________________________________________________________________________________________
  |
  |  findNextWeight : (weight : int)  ->  [int]
  |
  |  Description:
  |
  |    Finds the greatest weight that is smaller than the 'currentWeight'.
  |
  |  For further details see:
  |    * Ruben Martins, Vasco Manquinho, Ines Lynce: On Partitioning for Maximum
  |      Satisfiability. ECAI 2012: 913-914
  |
  |________________________________________________________________________________________________@*/
int EvaLW2::findNextWeight(int weight)
{

  int nextWeight = 1;
  int b = firstISoft > 0 ? firstISoft : nSoft();
  for (int i = 0; i < b; i++)
  {
    if (!isHard(i) && softClauses[i].weight > nextWeight && softClauses[i].weight < weight )
      nextWeight = softClauses[i].weight;
  }

  return nextWeight;
}

int EvaLW2::findNextWeightDiversity(int weight)
{

  assert(weightStrategy == _WEIGHT_DIVERSIFY_);
  assert(nbSatisfiable > 0 ); // Assumes that unsatSearch was done before.

  int nextWeight = weight;
  int nbClauses = 0;
  std::set<int64_t> nbWeights;
  float alpha = 1.25;

  
  bool findNext = false;

  for (;;)
  {
    if (nbSatisfiable > 1 || findNext) nextWeight = findNextWeight(nextWeight);
     

     
    nbClauses = 0;
    nbWeights.clear();
    

    int b = firstISoft;
   
    
    for (int i = 0; i < b; i++)
    {
      if (softClauses[i].weight >= nextWeight && !isHard(i))
      {
        nbClauses++;
        nbWeights.insert(softClauses[i].weight);
      }
    }

    if ((float)nbClauses / nbWeights.size() > alpha || nbClauses == nRealSoft())
      break;

    if (nbSatisfiable == 1 && !findNext) findNext = true;
  }

  return nextWeight;
}

 bool EvaLW2::updateUpperBound(uint64_t uB) {	 
		  if ( ubCost > (uB + lB_rem)) {
			  ubCost = uB + lB_rem;
			  return true;
		  }
		  return false;
	
  }

/************************************************************************************************
 //
 // Utils for core management
 //
 ************************************************************************************************/

  void EvaLW2::printLiterals(vec<Lit> &lits) {
	  for(int i = 0; i  < lits.size(); i++) {
			printf("%d ", coreMapping[lits[i]] );
		}
		printf("\n");
  }
  
	void EvaLW2::encodeCSTrans(vec<Lit> &cs, int minW) {
		assert(cs.size() != 0); 
		int n = cs.size(); 
		vec<Lit> dVars;
		vec<Lit> clause; // for adding stuff
		for (int i = 0; i < n - 1; i++)
		{
			Lit p = newLiteral();
			dVars.push(p);
		}
		
		// NEW HARD CLAUSES OR V NOT B_i
		clause.clear();
		for (int i = 0; i < cs.size(); i ++) {
			clause.push(~cs[i]);
		}
		addHardClause(clause);
		
		if (n > 2) {
			for (int i = 0; i < n-2; i++) {
				// d_i <-> OR_i+1^n NOT b_k <-> NOT b_{i+1} OR d_{i+1]
				
				// d_i -> NOT b_{i+1} OR d_{i+1]
				// { NOT d_i, NOT b_{i+1}, d_{i+1]}
			
				clause.clear();
				clause.push( ~dVars[i] );
				clause.push( ~cs[i+1] );
				clause.push( dVars[i+1] );
				addHardClause(clause);
		
				
				// NOT b_{i+1} OR d_{i+1] -> d_i
				// b_{i+1} , d_i
				clause.clear();
				clause.push( cs[i+1] );
				clause.push( dVars[i] );
				addHardClause(clause);
				
				// NOT d_i+1 d_i
				clause.clear();
				clause.push( ~dVars[i+1] );
				clause.push( dVars[i] );
				addHardClause(clause);
			}
		}
		if (n > 1) {
			// handle i = n - 1 case
			// d_n-1 <-> NOT b_n
			
			// d_n-1 -> NOT b_n
			// { NOT d_n-1, NOT b_n} 
			clause.clear();
			clause.push(~dVars[n - 2]);
			clause.push(~cs[n - 1]);
			addHardClause(clause);
			
			// d_n-1 <- NOT b_n
			// { b_n, d_n-1 } 
			clause.clear();
			clause.push(dVars[n - 2]);
			clause.push(cs[n - 1]);
			addHardClause(clause);
		}
	
	// NEW SOFT CLAUSES
	
    for (int i = 0; i < n-1; i++) {
		//clause = { ~core[i] AND dVars[i] };
		Lit p = newLiteral();
		
		clause.clear();
		clause.push(~cs[i]);
		clause.push(p);
		addHardClause(clause);
		
		clause.clear();
		clause.push( dVars[i] );
		clause.push(p);
		addHardClause(clause);
		
		clause.clear();
		clause.push(~p);
		
		addSoftClause(minW, clause);
		softClauses[nSoft() - 1].assumptionVar = p;
		coreMapping[p] = nSoft() - 1;  // Map the new soft clause to its assumption literal.
		firstISoft++;
	
	}
		
	}

void EvaLW2::encodeMaxRes(vec<Lit> &core, int weightCore)
{

	assert(core.size() != 0); 

  	int n = core.size(); 
    vec<Lit> dVars;
	vec<Lit> clause; // for adding stuff

	
    for (int i = 0; i < n - 1; i++)
    {
      Lit p = newLiteral();
      dVars.push(p);
    }
    // NEW HARD CLAUSES
    clause.clear();
    core.copyTo(clause);
    addHardClause(clause);
    
    if (inprocessing) addSolClauseToPreprocessor(clause);
    
    if (n > 2) {
		for (int i = 0; i < n-2; i++) {
			// d_i -> (b_{i+1} v d_{i+1})
			// clause = { ~dVars[i], dVars[i + 1], core[i + 1] };
		
			if (fullEncoding) {
				clause.clear();
				clause.push(~dVars[i]);
				clause.push(dVars[i + 1]);
				clause.push(core[i + 1]);
				addHardClause(clause);
				if (inprocessing) addSolClauseToPreprocessor(clause);
			}
		
		
			// (b_{i+1} v d_{i+1}) -> d_i
			// d_i v -b_{i+1}
			// clause = { dVars[i], ~core[i + 1] };
			clause.clear();
			clause.push(dVars[i]);
			clause.push(~core[i + 1]);
			addHardClause(clause);
			if (inprocessing) addSolClauseToPreprocessor(clause);
			
			 // d_i v -d_{i+1}
			 // clause = { dVars[i], ~dVars[i + 1] };
			clause.clear();
			clause.push(dVars[i]);
			clause.push(~dVars[i + 1]);
			addHardClause(clause);
			if (inprocessing) addSolClauseToPreprocessor(clause);
	
		}
	}
    
    if (n > 1) {
		 // handle i = p - 1 case
		 // clause = { dVars[p - 2], ~core[p - 1] };
		 clause.clear();
		 clause.push(dVars[n - 2]);
		 clause.push(~core[n - 1]);
		 addHardClause(clause);
		 if (inprocessing) addSolClauseToPreprocessor(clause);
		 
		 // clause = { ~dVars[p - 2], core[p - 1] };
		 clause.clear();
		 clause.push(~dVars[n - 2]);
		 clause.push(core[n - 1]);
		 addHardClause(clause);
		 if (inprocessing) addSolClauseToPreprocessor(clause);
	}
	
	// NEW SOFT CLAUSES
    for (int i = 0; i < n-1; i++) {
		//clause = { ~core[i], ~dVars[i] };
		clause.clear();
		clause.push(~core[i]);
		clause.push(~dVars[i]);
		addSoftClauseAndAssumptionVar(weightCore, clause);
	}

  
}

void EvaLW2::minimizeConflict(vec<Lit> &solverConflict) {
		assert(solverConflict.size() > 0);

		minimizedConflict.clear();
	
		
			lbool res;
			vec<Lit> orig;
			vec<Lit> assumps;
			solverConflict.copyTo(orig);
		
		
			for(int i = 0; i < orig.size(); i++) {
				assumps.clear();
				for(int j = i+1; j < orig.size(); j++) {
					assumps.push(~orig[j]);
					}
				for(int j = 0; j < minimizedConflict.size(); j++) {
						assumps.push(~minimizedConflict[j]);
					}
				res = searchSATSolver(solver, assumps);
				if (res == l_True) {
					minimizedConflict.push(orig[i]);
				}
			}
		
			assert(minimizedConflict.size() > 0);
		
		
 }

/*_________________________________________________________________________________________________
  |
  |  relaxCore : (conflict : vec<Lit>&) (weightCore : int) (assumps : vec<Lit>&)
  |              ->  [void]
  |
  |  Description:
  |
  |    Relaxes the core as described in the original WBO paper.
  |
  |  For further details see:
  |    * Vasco Manquinho, Joao Marques-Silva, Jordi Planes: Algorithms for
  |      Weighted Boolean Optimization. SAT 2009: 495-508
  |
  |  Pre-conditions:
  |    * Assumes that the core ('conflict') is not empty.
  |    * Assumes that the weight of the core is not 0 (should always be greater
  |      than or equal to 1).
  |
  |  Post-conditions:
  |    * If the weight of the soft clause is the same as the weight of the core:
  |      - 'softClauses[indexSoft].relaxationVars' is updated with a new
  |        relaxation variable.
  |    * If the weight of the soft clause is not the same as the weight of the
  |      core:
  |      - 'softClauses[indexSoft].weight' is decreased by the weight of the
  |        core.
  |      - A new soft clause is created. This soft clause has the weight of the
  |        core.
  |      - A new assumption literal is created and attached to the new soft
  |        clause.
  |      - 'coreMapping' is updated to map the new soft clause to its assumption
  |        literal.
  |    * 'sumSizeCores' is updated.
  |
  |________________________________________________________________________________________________@*/
void EvaLW2::relaxCore(vec<Lit> &conflict, int weightCore)
{

  assert(conflict.size() > 0);
  assert(weightCore > 0);

  vec<Lit> lits;
  for (int i = 0; i < conflict.size(); i++)
  {
    int indexSoft = coreMapping[conflict[i]];
	assert( softClauses[indexSoft].weight >= weightCore );
	
	softClauses[indexSoft].weight -= weightCore;	
	Lit p = softClauses[indexSoft].assumptionVar;
	 if (inprocessing) {
		 
		 int ppL = lit2Int(p);
		 //assert(ppL > 0);
		 if( !pif->labelToVar(abs(ppL))) {
			 std::cerr << "Error in converting label: " << ppL << " toVar" << std::endl;
			 exit(_ERROR_); 
		 }
		 
		 hasBeenInCores.insert(p);
				
	}
	if (softClauses[indexSoft].weight == 0) {
			allHardClauses++;
	}
	lits.push(p);

  }
  encodeMaxRes(lits, weightCore);
  sumSizeCores += conflict.size();
}

void EvaLW2::addSoftClauseAndAssumptionVar(int weight, vec<Lit> &clause) {
	  addSoftClause(weight, clause);
	   Lit l = newLiteral();
      // Create a new assumption literal.
      softClauses[nSoft() - 1].assumptionVar = l;
      coreMapping[l] = nSoft() - 1;  // Map the new soft clause to its assumption literal.

      if (inprocessing) {
		    int label = lit2Int(l);
		    assert(label > 0);     
		    clause.push(l);
		    if (!(pif->addLabel(label, weight) == label)) {
				std::cerr << "Error adding label to pp" << std::endl;
				std::cerr << "Label " << label << " weight " << weight << std::endl;
				std::cerr << "pif->addLabel(label, weight) " << pif->addLabel(label, weight) << std::endl;
				exit(_ERROR_);
			}	
			addSolClauseToPreprocessor(clause);		
			
	  }

      
}

uint64_t EvaLW2::computeCostModelEva(vec<lbool> &currentModel)
{
 
  
  assert(currentModel.size() != 0);
  uint64_t currentCost = 0;
  
  for (int i = 0; i < origWeights.size(); i++)
  {
    bool unsatisfied = true;
    for (int j = 0; j < softClauses[i].clause.size(); j++)
    {
      assert(var(softClauses[i].clause[j]) < currentModel.size());
      
      if( var(softClauses[i].clause[j]) <= nbInitialVariables ) {

      if ((sign(softClauses[i].clause[j]) &&
           currentModel[var(softClauses[i].clause[j])] == l_False) ||
          (!sign(softClauses[i].clause[j]) &&
           currentModel[var(softClauses[i].clause[j])] == l_True))
      {
        unsatisfied = false;
        break;
      }
		}
    }

    if (unsatisfied) {
		currentCost += origWeights[i];
	}
  }

  return currentCost;
}


/*_________________________________________________________________________________________________
  |
  |  computeCostCore : (conflict : vec<Lit>&)  ->  [int]
  |
  |    Description:
  |
  |      Computes the cost of the core. The cost of a core is the minimum weight
  |      of the soft clauses that appear in that core.
  |
  |    Pre-conditions:
  |      * Assumes that 'conflict' is not empty.
  |
  |________________________________________________________________________________________________@*/
int EvaLW2::computeCostCore(vec<Lit> &conflict)
{

  assert(conflict.size() != 0);

  if (problemType == _UNWEIGHTED_)
  {
    return 1;
  }

  int coreCost = INT32_MAX;

  for (int i = 0; i < conflict.size(); i++)
  {
    int indexSoft = coreMapping[conflict[i]];
    if (softClauses[indexSoft].weight < coreCost)
      coreCost = softClauses[indexSoft].weight;
  }

  return coreCost;
}


/************************************************************************************************
 //
 // WBO search
 //
 ************************************************************************************************/

/*_________________________________________________________________________________________________
  |
  |  unsatSearch : [void] ->  [void]
  |
  |  Description:
  |
  |    Calls a SAT solver only on the hard clauses of the MaxSAT formula.
  |    If the hard clauses are unsatisfiable then the MaxSAT solver terminates
  |    and returns 'UNSATISFIABLE'.
  |    Otherwise, a model has been found and it is stored. Without this call,
  |    the termination of the MaxSAT solver is not guaranteed.
  |
  |  For further details see:
  |    * Carlos Ansótegui, Maria Luisa Bonet, Jordi Levy: SAT-based MaxSAT
  |      algorithms. Artif. Intell. 196: 77-105 (2013)
  |
  |  Post-conditions:
  |   * If the hard clauses are satisfiable then 'ubCost' is updated to the cost
  |     of the model.
  |   * If the working formula is satisfiable, then 'nbSatisfiable' is increased
  |     by 1. Otherwise, 'nbCores' is increased by 1.
  |
  |________________________________________________________________________________________________@*/
void EvaLW2::unsatSearch()
{
  assert(assumptions.size() == 0);

  solver = rebuildHardSolver();
  lbool res = searchSATSolver(solver, assumptions);
  
  if (res == l_False)
  {
		nbCores++;
		printAnswer(_UNSATISFIABLE_);
		exit(_UNSATISFIABLE_);

  }
  else if (res == l_True)
  {
    nbSatisfiable++;
    uint64_t cost = computeCostModel(solver->model);
    assert(cost <= ubCost);
    ubCost = cost;
    if (modelPr && nVars() > 0)
       saveModel(solver->model);
    printf("o %" PRIu64 "\n", ubCost);    
  }
  
  delete solver;
  solver = NULL;
}


bool  EvaLW2::isHard(int indexSoft) {
	assert(indexSoft < nbSoft);
	return softClauses[indexSoft].weight == 0;
}

void EvaLW2::setAssumptions(vec<Lit> &assumps)
{
  assumps.clear();
  
 
  
  for (int i = 0; i < firstISoft; i++)
  {
    if (!isHard(i) && softClauses[i].weight >= currentWeight) {
		Lit l = softClauses[i].assumptionVar;
		assert(softClauses[i].weight > 0);
		assert(l != lit_Undef);
		assumps.push(~l);
		
	}
  }

}

void  EvaLW2::initializeLayer() {
	coresInLayer = 0;
	solver = rebuildSolverInc(solver);
}

int EvaLW2::lit2Int(Lit l) {
	if (sign(l)) {
		return  -(var(l) + 1);
	}
	else {
		return   var(l) + 1; 
	}
}

Lit EvaLW2::int2Lit(int l) {
	int var = abs(l) - 1;
	bool sign = l > 0;
	while (var >= nVars())
		newVar();
	return sign ? mkLit(var) : ~mkLit(var);
}

void EvaLW2::ppClause2SolClause(vec<Lit>  & solClause_out, const std::vector<int> & ppClause) {
	solClause_out.clear();
	for (int i = 0; i < ppClause.size(); i++) {
		solClause_out.push( int2Lit( ppClause[i] ));
	}
}

void EvaLW2::addSolClauseToPreprocessor( const vec<Lit>  & solClause ) {
	assert(pif != NULL);
	std::vector<int> ppClause;
	ppClause.clear();
	
	solClause2ppClause( solClause, ppClause);
	assert(ppClause.size() == solClause.size());
	
	if (!pif->addClause( ppClause )) {
		std::cerr << "Error in adding clause to preprocessor" << std::endl;
		exit(_ERROR_);
	}

}

void EvaLW2::solClause2ppClause(const vec<Lit>  & solClause,  std::vector<int> & ppClause_out) {
	ppClause_out.clear();
	for (int i = 0; i < solClause.size(); i++) {
		ppClause_out.push_back( lit2Int( solClause[i] ));
	}
}
/*_________________________________________________________________________________________________
  |
  |  initializePreprocessor : uint64_t 
  |
  |  Description:
  |		Initilaizes the oreprocessor interface, assumes "initAssumptions has not been called yet (and so no soft clauses have assumption variables)
  |    
  |
  |  Pre-Conditions
  |  	Soft clauses have no assumption variables
  |
  |  Post-conditions:
  |   
  |
  |________________________________________________________________________________________________@*/

uint64_t EvaLW2::initializePreprocessor(std::vector<std::vector<int> > & clauses_out, std::vector<uint64_t>  & weights_out ) {
	uint64_t top = 1;
	for (int i = 0; i< nSoft(); i++) top += softClauses[i].weight;
	
	std::vector<int> ppClause;
	
	for (int i = 0; i< nHard(); i++) {
		ppClause.clear();
        solClause2ppClause ( hardClauses[i].clause, ppClause);  
        assert (ppClause.size() == hardClauses[i].clause.size());
        
        weights_out.push_back(top);
		clauses_out.push_back(ppClause);
	}
	
	for (int i = 0; i< nSoft(); i++) {
		ppClause.clear();
        solClause2ppClause ( softClauses[i].clause, ppClause);  
        assert (ppClause.size() == softClauses[i].clause.size());
               
        weights_out.push_back(softClauses[i].weight);
		clauses_out.push_back(ppClause);
	}
	return top;
}

bool EvaLW2::hasBeenInprocessed() {
	return lB_rem > 0;
}

void EvaLW2::inProcessing() {
	assert(pif != NULL);
	if (verbosity > 0) std::cout << "c Before Inprocessing H:" << nHard() << " S:" << nSoft() << " NVARS:" << nVars() << std::endl;

	 for(auto l : hasBeenInCores) {
		int indexSoft = coreMapping[l];
		//ASSUMES HERE ALL HAVE BEEN TURNED INTO VARIABLES
		vec<Lit> newSoftclause;
		if (!isHard(indexSoft)) {
			newSoftclause.clear();
			newSoftclause.push(~l);
			addSoftClauseAndAssumptionVar(softClauses[indexSoft].weight, newSoftclause);
		}
	 }  
	 hasBeenInCores.clear();
	 int olDVars = nVars();

	double timeLimit = 1e9;;
	int verb = 0;
	
	

	pif->setBVEGateExtraction(false);	
	pif->setLabelMatching(true);

	pif->setSkipTechnique(20);
	
	if (verb > 0) std::cerr << "c New Inprocessing Round " << numTimesPreprocessed <<  std::endl;  
    if ( numTimesPreprocessed == 0) {
		
		std::string techniques = "[buvsrgc]";
		pif->preprocess(techniques, verb, timeLimit);
	
	
	}
	else {
		std::string techniques = "[ubg]v"; // 62s
		pif->preprocess(techniques, verb, timeLimit);
		/*
		double curClause = (double)(nbSoft + nbHard);
		double newC;
		std::string elim = "[v]";
		std::string rest = "[bug]";
		while (true) {
			pif->preprocess(rest, verb, timeLimit);
			newC = (double)(pif->getNumClauses());
			if ( newC > curClause * 0.8) {
				break;
			}
			curClause = newC;
		
			pif->preprocess(elim, verb, timeLimit);
			rest = (double)(pif->getNumClauses());
			if ( newC > curClause * 0.8) {
				break;
			}
			curClause = newC;	
		}	
		*/
	}
	
	numTimesPreprocessed++;
	setInprocessedInstance();
	
	lB_rem = lbCost;
	weightRem = pif->getRemovedWeight();
	reuseAssumps = true;
		
	firstIVars = 0;
	firstISoft = 0;
	firstIHard = 0;
	allHardClauses = 0;
	coresInLayer = 0;
	coreMapping.clear();
				
	initAssumptions();
	if (verbosity > 0) std::cout << "c After Inprocessing H:" << nHard() << " S:" << nSoft() <<  " Orig size: " << origWeights.size() << " Vars:" << nVars() << std::endl;
	nbInitialVariables = nVars();
			
	while( nVars() <= olDVars) {
		newVar();
	}
		
	if (solver != NULL) delete solver;
	solver = newSATSolver();
	solver = initialLCNFSolver(solver);

	updateCurrentWeight();
		
	correctionSet.clear();		
	hasBeenInCores.clear();
	coresSinceInprocessed = 0;
	hardenedSinceInprocessing = 0;
	updatedSinceInpr = false;

 
}

  bool EvaLW2::checkInprocessing() {
	  return  (coresSinceInprocessed > 150) && !onlyPreprocess; 
  }
  //

  
void EvaLW2::setInprocessedInstance() {
		std::vector<std::vector<int> > pre_Clauses; 
		std::vector<uint64_t> pre_Weights; 
		std::vector<int> pre_Labels; //will not be used
		
			
		pif->getInstance(pre_Clauses, pre_Weights, pre_Labels);
		if (verbosity > 0) std::cout << "c Size " << (double)(pre_Clauses.size()) << " Old: " << (double)(nbSoft + nbHard)   << std::endl;	
		
		if((double)(pre_Clauses.size()) >= 0.8 * (double)(nbSoft + nbHard)  ) {
			if (verbosity > 0) std::cout << "c Inprocessing not effective" << std::endl;		
			inprocessing = false;
		 }
		uint64_t top = pif-> getTopWeight();
		vec<Lit> lits;
				
		softClauses.clear();
		hardClauses.clear();
		
		nbVars = 0;
		nbSoft = 0;
		nbHard = 0;
		currentWeight = 1;
				
		assert(nVars() == 0);
				
		for (int i = 0; i < pre_Clauses.size(); i++) {
			lits.clear();
					
			ppClause2SolClause(lits, pre_Clauses[i]);

			assert(lits.size() == pre_Clauses[i].size());
						
			int64_t weight = pre_Weights[i];
			if (weight < top) {
						//SOFT 
				assert(lits.size() == 1);
						// Currently the weight is being represented by 'int'.
						// If soft clauses have weights larger than 2^32 this
						// can become an issue.
				if (weight > INT32_MAX) {
					std::cerr << "c Large weight: " << weight << std::endl;
				}
				assert(weight < INT32_MAX);
				assert(weight > 0);
						// Updates the maximum weight of soft clauses.
				setCurrentWeight((int)weight);
				addSoftClause((int)weight, lits);
			}
			else {
				addHardClause(lits);
			}
					
					
		}
		if (top > INT32_MAX)  top = INT32_MAX;
		setHardWeight((int)top);
	
		
	
}

/*_________________________________________________________________________________________________
  |
  |  normalSearch : [void] ->  [void]
  |
  |  Description:
  |
  |    PMRES algorithm extended with WCE
  |
  |  For further details see:
  |    * N. Narodytska. F. Bacchus
  |
  |  Post-conditions:
  |    * 'lbCost' is updated.
  |    * 'ubCost' is updated.
  |    * 'nbSatisfiable' is updated.
  |    * 'nbCores' is updated.
  |
  |________________________________________________________________________________________________@*/
void EvaLW2::normalSearch()
{
  
  unsatSearch();
  if (inprocessing || onlyPreprocess) {
		std::vector<std::vector<int> > clauses_out;
		std::vector<uint64_t> weights_out;
		uint64_t top = initializePreprocessor( clauses_out , weights_out );
		pif = new maxPreprocessor::PreprocessorInterface (clauses_out, weights_out, top, true);
		inProcessing();
  }
  else {
		firstIVars = 0;
		firstISoft = 0;
		firstIHard = 0;
		allHardClauses = 0;
		initAssumptions();
  
		solver = newSATSolver();
		if (!reuseAssumps) {  
			solver = rebuildSolverInc(solver);
		}
		else {
			solver = initialLCNFSolver(solver);
		}
		
		updateCurrentWeight();
		initializeLayer();
		correctionSet.clear();
  }
  
  maxnonHardenedW = ubCost - lbCost;
  bool endCarefully = modelPr && reconstructingNeeded;

  for (;;)
  {
	  
	if (primalDual) {
		if (lbCost > ubCost) {
			if (verbosity > 0) {
			std::cout 	<< "c PRIMAL DUAL DONE: UB=" << ubCost << " LB=" << lbCost << std::endl
						<< "c Total Hardened: " << numClausesHardened << std::endl 
						<< "c Total CS encoded: " << numCorrectionSetsEncoded << std::endl;
				}
			checkModelPrint(ubCost);
			exit(_OPTIMUM_);
		}
	}

    setAssumptions(assumptions);
    lbool res = searchSATSolver(solver, assumptions);

    if (res == l_False)
    {
      nbCores++;
      coresInLayer++;
      if(inprocessing) coresSinceInprocessed++;
      
      if (solver->conflict.size() <= 0) {
			if(primalDual) {
				if (verbosity > 0) {
					std::cout 	<< "c PRIMAL DUAL DONE DUE TO EMPTY CONFLICT: UB=" << ubCost << " LB=" << lbCost << std::endl
								<< "c Total Hardened: " << numClausesHardened << std::endl
								<< "c Total CS encoded: "<< numCorrectionSetsEncoded << std::endl;
				}
				checkModelPrint(ubCost);
				exit(_OPTIMUM_);
			}
			else {
				std::cout 	<< "ERROR: Hard clauses unsat without primal dual mode" << std::endl;
				exit(_ERROR_); 
			}
      
		}
		


	  if(minimizeCores) {
			minimizeConflict(solver->conflict);
	  }
      else {
		    minimizedConflict.clear();
			solver->conflict.copyTo(minimizedConflict);
		}
	  
       
      
      int coreCost = computeCostCore(minimizedConflict);
      lbCost += coreCost;
      
           
      if (lbCost == ubCost && !endCarefully) {
		  if (verbosity > 0) {
			std::cout 	<< "c DONE BEFORE SAT: UB=" << ubCost << " LB=" << lbCost << std::endl
						<< "c Total Hardened: " << numClausesHardened << std::endl;
			if (primalDual) std::cout 	<< "c Total CS encoded: " << numCorrectionSetsEncoded << std::endl;
			}
			checkModelPrint(lbCost);
			exit(_OPTIMUM_);
		}
      
      if (verbosity > 0) std::cout 	<<	"c LB: " << lbCost << " Conflict Size: " << minimizedConflict.size() << " Core Cost: " << coreCost << std::endl;
      relaxCore(minimizedConflict, coreCost);
    }

    if (res == l_True)
    {
			

	    nbSatisfiable++;
		// Has to use own method for computing the cost due to the delayed cardinality constraints. 	
		uint64_t cost  = computeCostModelEva(solver->model);

		bool updated = updateUpperBound(cost);	
		if (modelPr && updated && nbInitialVariables > 0) {
				saveModel(solver->model);
				updatedSinceInpr = true;
				if (verbosity > 0) std::cout 	<< "c Saved new model" << std::endl;
		}
		
		
		if (lbCost == ubCost) {
			if (modelPr && !updated) {
				if (verbosity > 0) {
					std::cout 	<< "c Need to do extra checks " << std::endl;
				}
				//THIS CLAUSE IS MOST PROBABLY REDUNDANT, the else is more important
				if((lB_rem + cost) == ubCost ) {
					saveModel(solver->model);
					if (verbosity > 0) {
					std::cout 	<< "c Saved new model to print due to DONE " << std::endl
								<< "c Cost of cur: " << cost << " lB rem " << lB_rem << " UB " << ubCost << std::endl;
					}
				}
					else if(endCarefully && !updatedSinceInpr) { // THIS means we do not have a model of this maxsat instance. Should only happen in some corner cases  (like SAT immediately after nprocessing wit ha worse model.. todo, does it happen?)
					assert( coresInLayer > 0 ); //If this is not the case something very weird is going on.
					if (verbosity > 0) {
					std::cout 	<< "c Need a model of current instance for reconstructing " << std::endl
								<< "c Cost of cur: " << cost << " lB rem " << lB_rem << " UB " << ubCost << std::endl;
					}
					initializeLayer();
					continue; 
				}
			}
			if (verbosity > 0) {
				std::cout 	<< "c DONE AFTER SAT: UB=" << ubCost << " LB=" << lbCost << std::endl
							<< "c Total Hardened: " << numClausesHardened << std::endl;
				if (primalDual) std::cout 	<< "c Total CS encoded: " << numCorrectionSetsEncoded << std::endl;
			}
			checkModelPrint(lbCost);
			exit(_OPTIMUM_);
		} 
		if (verbosity > 0) std::cout << "c UB: " << ubCost << std::endl;
		if (updated && primalDual) { 
				fillCorrectionSet(solver->model);
		}
		
		//Check that we are truly not done yet
		assert(coresInLayer > 0 || currentWeight > 1);

		if (coresInLayer  > 0) { 
			if (verbosity > 0) {
				std::cout 	<< "c Adding card constraints" << std::endl 
							<< "c Total cores mined: " << coresInLayer << std::endl;
			}
			initializeLayer();
		}
		else {
			if (verbosity > 0) {
				std::cout 	<< "c Updating Weight, (Hardening clauses) and Inprocessing: CurW: " << currentWeight << std::endl;
			}
			
			if  (maxnonHardenedW >= (ubCost - lbCost)) {
				if (verbosity > 0) {
					std::cout 	<< "c Hardening, maxW: "  << maxnonHardenedW << " gap " << (ubCost - lbCost) << std::endl;
				}
				solver = hardenClauses(solver);
			}
			updateCurrentWeight();

			if(primalDual && correctionSet.size() > 0) {
				primalDualConstraints();
			}
			if (inprocessing && checkInprocessing()) {
				if (verbosity > 0) {
					std::cout 	<< "c Inprocessing after : "  << hardenedSinceInprocessing << " hardened and " << coresSinceInprocessed << " cores" << std::endl;
				}
				inProcessing();
			}
		}
	
	
	}
	}
}

  void EvaLW2::checkModelPrint(uint64_t ans) {
	  
	  if (modelPr) {
		  if (reconstructingNeeded) {
			  //Reconstruct
			  assert(model.size() > 0);
			  std::vector<int> trueLits;
			  for (int i = 0; i < model.size(); i++)
			  {
				if (model[i] == l_True)
					trueLits.push_back(i + 1);
				else
					trueLits.push_back(-(i + 1));
			 }
			 pif->printSolution(trueLits, std::cout, ans + weightRem);
		  }
		  else {
			printModel();
			std::cout << "s OPTIMUM FOUND" << std::endl;
			std::cout << "o " << ans + weightRem << std::endl;			
	  }
	  
  }
  else {
	  std::cout << "s OPTIMUM FOUND" << std::endl;
	  std::cout << "o " << ans + weightRem << std::endl;
	}
}

  int EvaLW2::countMaxCostCS(vec<Lit> &cs) {
	  int cost = 0;
	  for (int i = 0; i < cs.size(); i++) {
		   int indexSoft = coreMapping[cs[i]];
		   assert(!isHard(indexSoft));
		   cost += softClauses[indexSoft].weight;
	  }
	  return cost;
  }
  
  void EvaLW2::buildLits(std::vector< std::pair<int, Lit> > &lits,  std::set<int> &csSet) {
	   std::map<Lit, int> counts;
	   std::set<int>::iterator it;
	   std::set<Lit> existingLits;
	   
	   for(int i = 0; i < lits.size(); i++) {
		   existingLits.insert(lits[i].second);
	   }
	   
	   lits.clear();
	   for (it = csSet.begin(); it != csSet.end(); ++it)
			{
				int indexSoft = *it; 
				for (int j = 0; j < softClauses[indexSoft].clause.size(); j++)
						{
								counts[softClauses[indexSoft].clause[j]] += softClauses[indexSoft].weight;
						}
			}
		
		std::map<Lit, int>::iterator it2;
		for ( it2 = counts.begin(); it2 != counts.end(); it2++ )
			{
				if( existingLits.count(it2->first) ) {
					lits.push_back( std::make_pair( it2->second,  it2->first ) );
				}
			}
		
		std::make_heap (lits.begin(),lits.end());
		
		
  }
  
  void EvaLW2::minimizeCorrectionSet(vec<Lit> &cs) {

	   vec<Lit> assumps;
	   vec<Lit> alwaysNegative;
	   
       int maxCost = countMaxCostCS(cs);
	   std::set<int> csSet;
	   std::set<int>::iterator it;
	   
	   std::vector< std::pair<int, Lit> > lits;
	   
	   for (int i = 0; i < cs.size() ; i++) {
		   csSet.insert(coreMapping[cs[i]]);
	   }
	   
	   buildLits( lits , csSet);
	
	   
	   
	   assert(firstISoft == nSoft());
	   for (int j = 0; j < firstISoft; j++) {
			if (!isHard(j) && !csSet.count(j)) {
					alwaysNegative.push( ~softClauses[j].assumptionVar);
			}
		}
		
		int iter = 0;
		int bound = cs.size() > 50 ? 50 : cs.size();
		cs.clear();
		
		while (maxCost >= ubCost - lbCost) {
			if (iter > bound  || lits.size() == 0) {
				if (verbosity > 0) std::cout << "c Breaking due to bound" << std::endl;
				break;
			}
			iter++;

			std::pop_heap (lits.begin(),lits.end()); 
			Lit toTest = lits.back().second;
			lits.pop_back();
			
			
			
			assumps.clear();
			alwaysNegative.copyTo(assumps);
			assumps.push(toTest);
			
			lbool res = searchSATSolver(solver, assumps);
			assert( res == l_True || res == l_False);
		    
		    if (res == l_True) {
				refineModel(csSet, solver->model, maxCost);
				buildLits( lits , csSet);
			}
			else {
				alwaysNegative.push(~toTest);

			}
			
		}
			   for (it = csSet.begin(); it != csSet.end(); ++it)
			{
				int indexSoft = *it; 
			    cs.push( softClauses[indexSoft].assumptionVar );
			}
		
	   
   }
   
   void EvaLW2::refineModel(std::set<int> &csSet, vec<lbool> &currentModel, int &mCost) {
				vec<int> toErase;
				std::set<int>::iterator it;
				
				toErase.clear();
				for (it = csSet.begin(); it != csSet.end(); ++it) {
					int i = *it; 
					bool unsatisfied = true;
					for (int j = 0; j < softClauses[i].clause.size(); j++)
						{
							assert(var(softClauses[i].clause[j]) < currentModel.size());				
							if ((sign(softClauses[i].clause[j]) &&
								currentModel[var(softClauses[i].clause[j])] == l_False) ||
									(!sign(softClauses[i].clause[j]) &&
									currentModel[var(softClauses[i].clause[j])] == l_True))
							{	
								unsatisfied = false;
								break;
								}
					
						}
					if (!unsatisfied) { 
						mCost -= softClauses[i].weight;
						toErase.push(i);
					}
				}
					
				for (int i = 0; i < toErase.size(); i ++) {
					csSet.erase(toErase[i]);
				}
				
				
   }
  void EvaLW2::fillCorrectionSet(vec<lbool> &currentModel ) { 
	   correctionSet.clear();
	   for (int i = 0; i < nbSoft; i++)
		{
			if (!isHard(i) && softClauses[i].weight < currentWeight) {
				 bool unsatisfied = true;
				 for (int j = 0; j < softClauses[i].clause.size(); j++) {
						assert(var(softClauses[i].clause[j]) < currentModel.size());
            
						if ((sign(softClauses[i].clause[j]) &&
							currentModel[var(softClauses[i].clause[j])] == l_False) ||
								(!sign(softClauses[i].clause[j]) &&
									currentModel[var(softClauses[i].clause[j])] == l_True))
						{
						unsatisfied = false;
						break;
						}
					
				}
				if (unsatisfied) {
						correctionSet.push(softClauses[i].assumptionVar);				
				}
						
			} 
		}

  }

  void EvaLW2::primalDualConstraints() {	
		vec<Lit> correctionSetR;
		for (int i = 0; i < correctionSet.size(); i++) {
			int indexSoft = coreMapping[correctionSet[i]];
			if (!isHard(indexSoft)) 
				correctionSetR.push(correctionSet[i]);
		}
		correctionSet.clear();
			
		if (correctionSet.size() < 1000 && csMin) {
			if (verbosity > 0) std::cout << "c Minimizing CS: size before: " << correctionSetR.size() << " UB-LB: " << ubCost - lbCost << std::endl;
			minimizeCorrectionSet(correctionSetR);
		}
		
		int maxCost = countMaxCostCS(correctionSetR);
		int minCost = computeCostCore(correctionSetR);

		if (verbosity > 0) std::cout << "c CS size: " << correctionSetR.size() << " CSCostSum: " << maxCost <<  " CSCostMin: " << minCost << " UB-LB: " << ubCost - lbCost << std::endl;
		
		bool isOkay = ((maxCost <= (ubCost - lbCost)) && correctionSetR.size() < 500) || ((maxCost < (ubCost - lbCost)) && correctionSetR.size() < 1000);
		if (isOkay && (maxCost < (int)(ubCost - lbCost))) {
			ubCost = lbCost + maxCost;
			if (verbosity > 0) std::cout << "c Improved UB due to CS, now: " << ubCost << std::endl;
		}
		
		
		//
		if (isOkay) {
			if (verbosity > 0) std::cout << "c CS size: " << correctionSetR.size() << " Encoded" << std::endl;
			numCorrectionSetsEncoded++;
			assert(correctionSetR.size() > 0);
			assert(minCost > 0);

			vec<Lit> lits;
			lits.clear();
			for (int i = 0; i < correctionSetR.size(); i++)
			{
				int indexSoft = coreMapping[correctionSetR[i]];
				assert( softClauses[indexSoft].weight >= minCost );
	
				softClauses[indexSoft].weight -= minCost;
				Lit p = softClauses[indexSoft].assumptionVar;
				if (softClauses[indexSoft].weight == 0) {
					allHardClauses++;
				}
				lits.push(p);
			}
			encodeCSTrans(lits, minCost);	
			solver = rebuildSolverInc(solver);
		}
		
		
  } 


  int EvaLW2::nRealSoft() {
	    return nSoft() - allHardClauses; 
  }

  Solver *EvaLW2::hardenClauses(Solver *S) {    
	   int bound = ubCost - lbCost;
	   vec<lbool> &currentModel = S->model;
	   maxnonHardenedW = 0;
	   for (int i = 0; i < nbSoft; i++)
		{
			bool satisfied = false;
			if (softClauses[i].weight == bound) {
				 
				 for (int j = 0; j < softClauses[i].clause.size(); j++)
				{
						if (var(softClauses[i].clause[j]) >= currentModel.size()) {
							break;
						}
            
						if ((sign(softClauses[i].clause[j]) &&
							currentModel[var(softClauses[i].clause[j])] == l_False) ||
								(!sign(softClauses[i].clause[j]) &&
									currentModel[var(softClauses[i].clause[j])] == l_True))
						{
						satisfied = true;
						break;
						}
					
				}
			}
			if (softClauses[i].weight > bound  || (softClauses[i].weight == bound && satisfied) ) {  // 
				vec<Lit> clause;
				clause.clear();
				 
				Lit l = softClauses[i].assumptionVar;
				assert(l != lit_Undef);
				clause.push(~l);
				
				
				S->addClause(clause);
				
				if(inprocessing) {
						int ppL = lit2Int(l);
						//assert(ppL > 0);
						if( !pif->labelToVar(abs(ppL))) {
							std::cerr << "Error in converting label: " << ppL << " toVar in hardening" << std::endl;
							exit(_ERROR_); 
						}		
						addSolClauseToPreprocessor(clause);
						hardenedSinceInprocessing++;
					
				}
				
				softClauses[i].weight = 0;
				numClausesHardened++;
				allHardClauses++;
				assert(isHard(i));
			}
			if (softClauses[i].weight < bound && !isHard(i) && softClauses[i].weight >maxnonHardenedW) {
				maxnonHardenedW = softClauses[i].weight;
			} 

			
		}
		
		return S;
   }


// Public search method
void EvaLW2::search()
{ 
  printConfiguration();
  lB_rem = 0; 
  numClausesHardened = 0;
  numCorrectionSetsEncoded = 0;
  hasBeenInCores.clear();
  nbInitialVariables = nVars();
  reconstructingNeeded = inprocessing || onlyPreprocess;
  weightRem = 0;
  if( modelPr && primalDual ) {
	  std::cerr << "ERROR: Model printing in primal dual mode not supported" << std::endl;
	  exit( _ERROR_ );
  }
  normalSearch();
}

/************************************************************************************************
 //
 // Other protected methods
 //
 ************************************************************************************************/

/*_________________________________________________________________________________________________
  |
  |  initAssumptions : (assumps : vec<Lit>&) ->  [void]
  |
  |  Description:
  |
  |    Creates a new assumption literal for each soft clause and initializes the
  |    assumption vector with negation of this literal. Assumptions are used to
  |    extract cores. Also sets the "orig weights" vector that is used for computing 
  |    the cost of models.  
  |
  |  Post-conditions:
  |    * For each soft clause 'i' creates an assumption literal and assigns it
  |      to 'softClauses[i].assumptionVar' or reuses the literal as assumption, 
  |    * 'coreMapping' is updated by mapping each assumption literal with the
  |      corresponding index of each soft clause.
  |    * 'assumps' is updates with the assumptions literals.
  |    * orig weights is filled (and should not be altered after this).  
  |
  |________________________________________________________________________________________________@*/
void EvaLW2::initAssumptions()
{
	origWeights.clear();
	for (int i = 0; i < nbSoft; i++)
  {
	  origWeights.push(0);
  }
	
  for (int i = 0; i < nbSoft; i++)
  {
      Lit l;
	  if( !reuseAssumps) {
			l = newLiteral();
		}
	  else {
		  assert(softClauses[i].clause.size() == 1);
		  l = ~softClauses[i].clause[0];
	  }
	  softClauses[i].assumptionVar = l;
	  coreMapping[l] = i;

	  origWeights[i] = softClauses[i].weight;
  }
  
}

// Print EVA configuration.
void EvaLW2::print_EvaW_configuration(int ws, bool min)
{
  printf("c |  Algorithm: %23s                                             "
         "                      |\n",
         "PMRES+WCE");
  char ws_char[10];
  if (ws == 0)
    strcpy(ws_char, "None");
  else if (ws == 1)
    strcpy(ws_char, "Weight");
  else if (ws == 2)
    strcpy(ws_char, "Diversity");
  if (problemType == _WEIGHTED_)
    printf("c |  Weight-Strategy: %17s                                         "
           "    "
           "                      |\n",
           ws_char);
  if (min)
    printf("c |  Core Minimisation: %15s                                       "
           "      "
           "                      |\n",
           "On");
  else
    printf("c |  Core Minimisation: %15s                                       "
           "      "
           "                      |\n",
           "Off");
  if (reuseAssumps)
    printf("c |  LCNF-Mode: %23s                                       "
           "      "
           "                      |\n",
           "On");
  else
    printf("c |  LCNF-Mode: %23s                                       "
           "      "
           "                      |\n",
           "Off"); 
   if (stratBl)
    printf("c |  S/to/WCE: %24s                                       "
           "      "
           "                      |\n",
           "On");
  else
    printf("c |  S/to/WCE: %24s                                       "
           "      "
           "                      |\n",
           "Off");
   if (primalDual)
    printf("c |  Primal-Dual: %21s                                       "
           "      "
           "                      |\n",
           "On");
  else
    printf("c |  Primal-Dual: %21s                                       "
           "      "
           "                      |\n",
           "Off");
   if (csMin)
    printf("c |  Correction Set Minimisation: %5s                                       "
           "      "
           "                      |\n",
           "On");
  else
    printf("c |  Correction Set Minimisation: %5s                                       "
           "      "
           "                      |\n",
           "Off");        
           
           
           
}
